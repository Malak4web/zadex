<?php
/**
 * Plugin Name:       Zadex Migrator – Import from Elementor
 * Description:       Converts Elementor pages, templates and global colors and fonts into Zadex pages, with a side-by-side preview, a report per page and one-click rollback.
 * Version:           0.1.0
 * Requires at least: 6.5
 * Requires PHP:      8.0
 * Requires Plugins:  zadex
 * Author:            Zadex
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zadex-migrator
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ZADEX_MIGRATOR_VERSION', '0.1.0');
define('ZADEX_MIGRATOR_FILE', __FILE__);
define('ZADEX_MIGRATOR_PATH', plugin_dir_path(__FILE__));
define('ZADEX_MIGRATOR_URL', plugin_dir_url(__FILE__));

if (file_exists(ZADEX_MIGRATOR_PATH . 'vendor/autoload.php') && !class_exists('ZadexMigrator\\Plugin')) {
    require_once ZADEX_MIGRATOR_PATH . 'vendor/autoload.php';
}
if (!class_exists('ZadexMigrator\\Plugin')) {
    require_once ZADEX_MIGRATOR_PATH . 'includes/Autoloader.php';
    \ZadexMigrator\Autoloader::register();
}

add_action('plugins_loaded', static function (): void {
    \ZadexMigrator\Plugin::instance()->boot();
}, 20);
