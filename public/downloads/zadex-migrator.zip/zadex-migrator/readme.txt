=== Zadex Migrator – Import from Elementor ===
Contributors: zadian
Tags: migration, import, page builder, converter, zadex
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.0
Requires Plugins: zadex
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Move Elementor pages to the Zadex page builder: layout, widgets, styles and global colors and fonts, with a preview and one-click rollback.

== Description ==

Zadex Migrator converts pages built with Elementor into Zadex pages. Your Elementor data is never changed, so you can compare, apply and roll back at any time.

* Converts sections, columns, containers and the common widgets, with responsive and hover styles.
* Imports your global colors, fonts, content width and breakpoints into Zadex.
* Side-by-side preview of the original and the converted page before anything changes for visitors.
* A report per page lists anything that could not be carried over.
* One-click rollback per page and for the global settings.

Elementor does not need to be active to convert pages. It is used, when active, for the "before" preview and to keep widgets Zadex has no equivalent for as HTML.

Zadex is a separate plugin and is required. Elementor is a trademark of its owner; this plugin is not affiliated with or endorsed by Elementor.

= Source code =

`build/` is compiled with Vite from the TypeScript and Vue sources in `src/`. It also bundles the pure CSS-generation modules of the Zadex plugin, whose sources ship in the Zadex plugin's `src/` folder. To rebuild: place the Zadex plugin's folder next to this one (or set `ZADEX_SRC` to its `src` folder), then run `npm ci` and `npm run build`.

== Installation ==

1. Install and activate Zadex, then this plugin.
2. Go to Zadex > Import from Elementor.

== Frequently Asked Questions ==

= Is anything sent to an external service? =

No. Everything happens on your own site.

= What happens to my Elementor data? =

It stays as it is. Applying a conversion only tells WordPress to show the Zadex version; rollback switches back.

== Changelog ==

= 0.1.0 =
* First release.
