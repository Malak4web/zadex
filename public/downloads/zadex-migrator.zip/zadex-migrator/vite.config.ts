import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { fileURLToPath, URL } from 'node:url';

/**
 * Builds the admin app into build/ (manifest read by PHP). End users never run this.
 *
 * `@zadex` points at the Zadex plugin sources next to this repo (../plugin zadex/src). Only pure modules are
 * imported from it (the CSS engine, settings keys, breakpoints, page controls), so the generated CSS is exactly
 * what the Zadex editor would produce for the same document. Override the location with ZADEX_SRC.
 */
const zadexSrc = process.env.ZADEX_SRC ?? fileURLToPath(new URL('../plugin zadex/src', import.meta.url));

export default defineConfig(() => ({
  plugins: [vue()],
  base: './',
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      '@zadex': zadexSrc,
    },
  },
  server: {
    port: Number(process.env.ZXM_PORT ?? 5190),
    strictPort: true,
    fs: { allow: ['..'] },
  },
  build: {
    outDir: 'build',
    emptyOutDir: true,
    manifest: 'manifest.json',
    sourcemap: false,
    target: 'es2020',
    // Not minified: WordPress.org guideline 4 (human-readable code). Sources ship in src/.
    minify: false,
    cssMinify: false,
    rollupOptions: {
      input: {
        admin: fileURLToPath(new URL('./src/admin/main.ts', import.meta.url)),
      },
      output: {
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]',
      },
    },
  },
}));
