<?php
/**
 * Uninstall: removes the migrator's own bookkeeping (drafts, rollback backups, states, the global-settings backup).
 * Pages that were applied stay Zadex pages, and Elementor's data is never touched.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

foreach (['_zadex_migrator_draft', '_zadex_migrator_backup', '_zadex_migrator_state'] as $zadex_migrator_key) {
    delete_post_meta_by_key($zadex_migrator_key);
}
delete_option('zadex_migrator_global_backup');
