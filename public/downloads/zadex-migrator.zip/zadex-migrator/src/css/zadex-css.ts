import { generateTreeCss, generateSettingsCss } from '@zadex/editor/core/css';
import { DEFAULT_BREAKPOINTS } from '@zadex/editor/core/breakpoints';
import { pageControlsById } from '@zadex/editor/core/pageControls';
import { generateGlobalCss } from '@zadex/editor/core/css/global';
import { themeControlsById } from '@zadex/editor/core/themeStyleControls';
import type { Breakpoint, BreakpointKey, ControlDef, GlobalSettings, Settings, ZElement, ZadexEnv } from '@/convert/types';

/**
 * Generates the CSS Zadex stores with a document (`_zadex_css`) and its page settings CSS, with Zadex's own CSS
 * engine (bundled from the Zadex sources) and the manifests the site's Zadex install reports. The result is what
 * the Zadex editor would save for the same tree.
 */
export function controlsResolver(env: ZadexEnv): (type: string) => Record<string, ControlDef> {
  const byType = new Map(env.manifests.map((m) => [m.type, m]));
  const cache = new Map<string, Record<string, ControlDef>>();
  return (type: string) => {
    let hit = cache.get(type);
    if (hit) return hit;
    hit = {};
    for (const c of byType.get(type)?.controls ?? []) hit[c.id] = c;
    for (const c of env.commonControls) if (!hit[c.id]) hit[c.id] = c;
    cache.set(type, hit);
    return hit;
  };
}

/** GET /zadex/v1/global returns breakpoints keyed by id; turn them into Zadex's ordered list. */
export function breakpointsFrom(config?: Partial<Record<BreakpointKey, { value?: number; enabled?: boolean }>>): Breakpoint[] {
  return DEFAULT_BREAKPOINTS.map((bp) => {
    const c = config?.[bp.key];
    return c ? { ...bp, value: typeof c.value === 'number' && bp.direction !== 'base' ? c.value : bp.value, enabled: bp.key === 'desktop' ? true : c.enabled ?? bp.enabled } : { ...bp };
  });
}

export function documentCss(elements: ZElement[], env: ZadexEnv, breakpoints: Breakpoint[]): string {
  return generateTreeCss(elements, controlsResolver(env), breakpoints);
}

export function pageCss(pageSettings: Settings, postId: number, breakpoints: Breakpoint[]): string {
  return generateSettingsCss(pageSettings, { controls: pageControlsById(), breakpoints, wrapper: `.zadex-${postId}` });
}

/**
 * Site-wide CSS for POST /zadex/v1/global (`css`): exactly what the Zadex editor saves (global store
 * `generateCss()`: variables, global classes, theme style with the editor's theme controls, floating buttons).
 * `breakpoints` may be Zadex's ordered list or the `{key: {value, enabled}}` config GET/POST /global use.
 */
export function globalCss(global: GlobalSettings, breakpoints: Breakpoint[] | Partial<Record<BreakpointKey, { value?: number; enabled?: boolean }>>): string {
  const list = Array.isArray(breakpoints) ? breakpoints : breakpointsFrom(breakpoints);
  return generateGlobalCss(global, list, themeControlsById());
}
