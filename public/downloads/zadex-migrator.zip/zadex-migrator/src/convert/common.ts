import type { ElementWriter } from './context';
import type { BreakpointKey } from './types';
import { DEVICE_SUFFIXES, VIEWPORT_KEYS } from './responsive';
import { bool, isBlank, num, slider, type Slider } from './values';

/**
 * Elementor "Advanced" tab -> Zadex common controls (`widgets/_common/controls.json` in the Zadex repo).
 * Called by `ElementWriter.finish()` for every element (wired in index.ts as `ctx.commonHandler`).
 *
 * Elementor uses different key names per element kind:
 *  - widgets: `_margin`, `_padding`, `_z_index`, `_css_classes`, `_animation`, `_animation_delay`, `_position` …
 *  - containers: `z_index`, `css_classes`, `animation`, `animation_delay`, `position`, plus the widget-style
 *    `_flex_*`, `_offset_*`, `_transform_*`, `_element_id` (their `margin` / `padding` belong to the layout mapper),
 *  - sections / columns: `z_index`, `css_classes`, `animation`, `animation_delay`, `_element_id` only.
 * Only the keys that exist on the element kind are read, so stray defaults of other kinds never leak in.
 */
export function applyCommon(w: ElementWriter): void {
  const elType = w.el.elType;
  // v4 atomic elements carry their own style model (task M8): layout `e-*` elTypes and `widget` + `e-*` widgetTypes.
  if (elType.startsWith('e-') || (w.el.widgetType ?? '').startsWith('e-')) return;
  const kind: Kind = elType === 'widget' ? 'widget' : elType === 'container' ? 'container' : 'layout';
  const k = KEYS[kind];

  if (kind === 'widget') {
    w.dimensions('_margin', '_margin');
    w.dimensions('_padding', '_padding');
    elementWidth(w);
    if (!w.has('_flex_align_self')) w.map('_element_vertical_align', '_align_self', ALIGN_SELF);
    else w.consumeResponsive('_element_vertical_align');
  }
  if (kind !== 'layout') {
    w.map('_flex_align_self', '_align_self', ALIGN_SELF);
    flexOrder(w);
    flexSize(w);
    position(w, k.position);
    transform(w);
    gridItem(w, k.gridColumn, '_col_span');
    gridItem(w, k.gridRow, '_row_span');
  }

  w.responsive(k.zIndex, '_z_index', (v) => {
    const n = num(v);
    return typeof n === 'number' ? n : undefined;
  });

  const cssId = w.raw('_element_id');
  if (typeof cssId === 'string' && cssId.trim() !== '') w.set('_css_id', cssId.trim());
  const classes = w.raw(k.classes);
  if (typeof classes === 'string' && classes.trim() !== '') w.set('_css_classes', classes.trim().replace(/\s+/g, ' '));
  const attrs = w.raw('_attributes');
  if (typeof attrs === 'string' && attrs.trim() !== '') w.set('_attributes', attrs.trim().replace(/\r\n/g, '\n'));

  hide(w);
  animation(w, k.animation, k.animationDelay);
  motionEffects(w);
  sticky(w);
  wrapperDecoration(w);
  customCss(w);
}

type Kind = 'widget' | 'container' | 'layout';

interface KindKeys {
  zIndex: string;
  classes: string;
  animation: string;
  animationDelay: string;
  position: string;
  gridColumn: string;
  gridRow: string;
}

const KEYS: Record<Kind, KindKeys> = {
  widget: { zIndex: '_z_index', classes: '_css_classes', animation: '_animation', animationDelay: '_animation_delay', position: '_position', gridColumn: '_grid_column', gridRow: '_grid_row' },
  container: { zIndex: 'z_index', classes: 'css_classes', animation: 'animation', animationDelay: 'animation_delay', position: 'position', gridColumn: 'grid_column', gridRow: 'grid_row' },
  layout: { zIndex: 'z_index', classes: 'css_classes', animation: 'animation', animationDelay: 'animation_delay', position: '', gridColumn: '', gridRow: '' },
};

const ALIGN_SELF: Record<string, string> = { 'flex-start': 'flex-start', center: 'center', 'flex-end': 'flex-end', stretch: 'stretch' };

/* ---- device chain ---- */

interface Device {
  suffix: string;
  bp: BreakpointKey | undefined;
  /** Index (in DEVICES) of the device this one inherits from; -1 for desktop. */
  parent: number;
}

/**
 * Elementor devices in Zadex cascade order. Desktop is the base; widescreen (min-width) inherits from desktop;
 * laptop … mobile (max-width) each inherit from the next larger device.
 */
const DEVICES: Device[] = DEVICE_SUFFIXES.map(({ suffix, bp }, i) => ({
  suffix,
  bp,
  parent: i === 0 ? -1 : bp === 'widescreen' || bp === 'laptop' ? 0 : i - 1,
}));

/** Elementor breakpoints that are active on the source site (kit `active_breakpoints`, default tablet + mobile). */
function activeDevices(w: ElementWriter): Set<BreakpointKey> {
  const list = w.ctx.source.kit?.active_breakpoints;
  const out = new Set<BreakpointKey>();
  if (Array.isArray(list) && list.length) {
    for (const v of list) if (typeof v === 'string' && VIEWPORT_KEYS[v]) out.add(VIEWPORT_KEYS[v]);
  } else {
    out.add('tablet');
    out.add('mobile');
  }
  return out;
}

/* ---- layout ---- */

/** `_element_width` (inherit = full width, auto = fit content, initial = `_element_custom_width`) -> `_width`. */
function elementWidth(w: ElementWriter): void {
  w.consumeResponsive('_element_width');
  w.consumeResponsive('_element_custom_width');
  const modes: Array<string | undefined> = [];
  DEVICES.forEach((d, i) => {
    const own = w.raw('_element_width' + d.suffix);
    const explicit = typeof own === 'string' && own !== '';
    const mode = explicit ? (own as string) : d.parent >= 0 ? modes[d.parent] : undefined;
    modes[i] = mode;
    if (mode === 'inherit' && explicit) w.set('_width', { size: 100, unit: '%' }, { bp: d.bp });
    else if (mode === 'auto' && explicit) w.set('_width', { size: 'auto', unit: 'custom' }, { bp: d.bp });
    else if (mode === 'initial') {
      const own = slider(w.raw('_element_custom_width' + d.suffix), '%');
      // A device that switches to "custom" without its own size uses the desktop size.
      const size = own ?? (explicit && d.bp ? slider(w.raw('_element_custom_width'), '%') : undefined);
      if (size) {
        w.set('_width', size, { bp: d.bp });
        w.set('_max_width', size, { bp: d.bp });
      }
    }
  });
}

/** `_flex_order` start|end|custom (+ `_flex_order_custom`) -> `_order`. */
function flexOrder(w: ElementWriter): void {
  w.consumeResponsive('_flex_order');
  w.consumeResponsive('_flex_order_custom');
  for (const d of DEVICES) {
    const mode = w.raw('_flex_order' + d.suffix);
    if (mode === 'start') w.set('_order', -99999, { bp: d.bp });
    else if (mode === 'end') w.set('_order', 99999, { bp: d.bp });
    else if (mode === 'custom') {
      const n = num(w.raw('_flex_order_custom' + d.suffix));
      if (typeof n === 'number') w.set('_order', n, { bp: d.bp });
    }
  }
}

/** `_flex_size` none|grow|shrink|custom (+ `_flex_grow` / `_flex_shrink`) -> `_flex_grow` / `_flex_shrink`. */
function flexSize(w: ElementWriter): void {
  w.consumeResponsive('_flex_size');
  w.consumeResponsive('_flex_grow');
  w.consumeResponsive('_flex_shrink');
  const presets: Record<string, [number, number]> = { none: [0, 0], grow: [1, 0], shrink: [0, 1] };
  for (const d of DEVICES) {
    const mode = w.raw('_flex_size' + d.suffix);
    if (typeof mode !== 'string') continue;
    if (presets[mode]) {
      w.set('_flex_grow', presets[mode][0], { bp: d.bp });
      w.set('_flex_shrink', presets[mode][1], { bp: d.bp });
    } else if (mode === 'custom') {
      const g = num(d.bp ? w.raw('_flex_grow' + d.suffix) : w.get('_flex_grow'));
      const s = num(d.bp ? w.raw('_flex_shrink' + d.suffix) : w.get('_flex_shrink'));
      if (typeof g === 'number') w.set('_flex_grow', g, { bp: d.bp });
      if (typeof s === 'number') w.set('_flex_shrink', s, { bp: d.bp });
    }
  }
}

/** Grid item span (`_grid_column` / `grid_column` 1-12 or custom `span N`) -> `_col_span` / `_row_span`. */
function gridItem(w: ElementWriter, key: string, dst: string): void {
  w.consumeResponsive(key);
  w.consumeResponsive(key + '_custom');
  for (const d of DEVICES) {
    const v = w.raw(key + d.suffix);
    if (isBlank(v)) continue;
    if (v === 'custom') {
      const custom = w.raw(key + '_custom' + d.suffix);
      const m = typeof custom === 'string' ? custom.trim().match(/^span\s+(\d+)$/) : null;
      if (m) w.set(dst, Number(m[1]), { bp: d.bp });
      else if (!isBlank(custom)) w.note(`Custom grid placement "${String(custom)}" has no Zadex equivalent.`);
      continue;
    }
    const n = num(v);
    if (typeof n === 'number' && n >= 1) w.set(dst, n, { bp: d.bp });
  }
}

/* ---- position ---- */

const AUTO: Slider = { size: 'auto', unit: 'custom' };
const ZERO: Slider = { size: 0, unit: 'px' };

/**
 * `_position` (widgets) / `position` (containers) absolute|fixed + `_offset_*` -> `_position`, `_top`, `_right`,
 * `_bottom`, `_left`. Horizontal orientation `start` is the left side on LTR sites and the right side on RTL sites
 * (Elementor prints `body.rtl` rules); `end` uses `_offset_x_end`. Vertical `start` = top, `end` = bottom.
 * Elementor's offsets default to 0, so an absolute element without offsets sits at the start/top corner.
 */
function position(w: ElementWriter, key: string): void {
  for (const k of [key, '_offset_orientation_h', '_offset_x', '_offset_x_end', '_offset_orientation_v', '_offset_y', '_offset_y_end']) w.consumeResponsive(k);
  const rtl = Boolean(w.ctx.source.rtl);
  const startSide = rtl ? '_right' : '_left';
  const endSide = rtl ? '_left' : '_right';
  const posOf: Array<string | undefined> = [];
  const hOf: string[] = [];
  const vOf: string[] = [];
  DEVICES.forEach((d, i) => {
    const p = d.parent;
    const own = w.raw(key + d.suffix);
    const pos = typeof own === 'string' ? own : p >= 0 ? posOf[p] : undefined;
    posOf[i] = pos;
    const ownH = d.bp ? w.raw('_offset_orientation_h' + d.suffix) : w.get('_offset_orientation_h');
    const ownV = d.bp ? w.raw('_offset_orientation_v' + d.suffix) : w.get('_offset_orientation_v');
    hOf[i] = typeof ownH === 'string' && ownH !== '' ? ownH : p >= 0 ? hOf[p] : 'start';
    vOf[i] = typeof ownV === 'string' && ownV !== '' ? ownV : p >= 0 ? vOf[p] : 'start';
    if (own === 'absolute' || own === 'fixed') w.set('_position', own, { bp: d.bp });
    else if (own === '' && d.bp && p >= 0 && posOf[p]) w.set('_position', '', { bp: d.bp });
    if (pos !== 'absolute' && pos !== 'fixed') return;
    // Desktop or a device that switches to positioned: write both sides even when the offsets are defaults.
    const fresh = !d.bp || (typeof own === 'string' && posOf[p] !== pos);
    const read = (k: string): Slider | undefined => slider(d.bp ? w.raw(k + d.suffix) : w.get(k));
    const side = (end: boolean, changed: boolean, value: Slider | undefined, startDst: string, endDst: string): void => {
      const dst = end ? endDst : startDst;
      if (value) w.set(dst, value, { bp: d.bp });
      else if (fresh || changed) w.set(dst, ZERO, { bp: d.bp });
      if (changed) w.set(end ? startDst : endDst, AUTO, { bp: d.bp });
    };
    const hEnd = hOf[i] === 'end';
    const vEnd = vOf[i] === 'end';
    side(hEnd, p >= 0 && hOf[p] !== hOf[i], read(hEnd ? '_offset_x_end' : '_offset_x'), startSide, endSide);
    side(vEnd, p >= 0 && vOf[p] !== vOf[i], read(vEnd ? '_offset_y_end' : '_offset_y'), '_top', '_bottom');
  });
}

/* ---- responsive visibility ---- */

/**
 * `hide_<device>` -> `_hide` keys. Elementor hides each device independently; Zadex is desktop-first with
 * inheritance (a value on tablet also applies to mobile), so a device whose state differs from the next larger
 * device gets an explicit value (`true` or `false`). Only breakpoints active on the source site count (an
 * inactive device is covered by the next larger one, in Elementor and in Zadex alike).
 */
function hide(w: ElementWriter): void {
  const active = activeDevices(w);
  const state: boolean[] = [];
  DEVICES.forEach((d, i) => {
    const v = w.raw('hide_' + (d.suffix ? d.suffix.slice(1) : 'desktop'));
    if (d.bp && !active.has(d.bp)) {
      state[i] = state[d.parent];
      return;
    }
    state[i] = bool(v);
    const inherited = d.parent >= 0 ? state[d.parent] : false;
    if (state[i] !== inherited) w.set('_hide', state[i], { bp: d.bp });
  });
}

/* ---- motion ---- */

/** Elementor entrance animations -> the closest Zadex `_animation` option. */
const ANIMATIONS: Record<string, string> = {
  fadeIn: 'fadeIn',
  fadeInUp: 'fadeInUp',
  fadeInDown: 'fadeInDown',
  fadeInLeft: 'fadeInLeft',
  fadeInRight: 'fadeInRight',
  zoomIn: 'zoomIn',
  slideInUp: 'slideInUp',
  slideInLeft: 'slideInLeft',
  bounceIn: 'bounceIn',
  rotateIn: 'rotateIn',
  // Approximations (closest direction / family).
  zoomInDown: 'zoomIn',
  zoomInLeft: 'zoomIn',
  zoomInRight: 'zoomIn',
  zoomInUp: 'zoomIn',
  slideInDown: 'fadeInDown',
  slideInRight: 'fadeInRight',
  bounceInUp: 'slideInUp',
  bounceInDown: 'fadeInDown',
  bounceInLeft: 'slideInLeft',
  bounceInRight: 'fadeInRight',
  rotateInDownLeft: 'rotateIn',
  rotateInDownRight: 'rotateIn',
  rotateInUpLeft: 'rotateIn',
  rotateInUpRight: 'rotateIn',
  lightSpeedIn: 'fadeInRight',
  rollIn: 'fadeInLeft',
  // Attention seekers: Zadex only has entrance animations.
  bounce: 'fadeIn',
  flash: 'fadeIn',
  pulse: 'fadeIn',
  rubberBand: 'fadeIn',
  shake: 'fadeIn',
  headShake: 'fadeIn',
  swing: 'fadeIn',
  tada: 'fadeIn',
  wobble: 'fadeIn',
  jello: 'fadeIn',
};
const EXACT_ANIMATIONS = new Set(['fadeIn', 'fadeInUp', 'fadeInDown', 'fadeInLeft', 'fadeInRight', 'zoomIn', 'slideInUp', 'slideInLeft', 'bounceIn', 'rotateIn']);

/** Entrance animation (`_animation` / `animation`, `animation_duration`, `_animation_delay` / `animation_delay`). */
function animation(w: ElementWriter, key: string, delayKey: string): void {
  w.consumeResponsive(key);
  w.consume('animation_duration');
  w.consumeResponsive(delayKey);
  const desktop = w.raw(key);
  const name = typeof desktop === 'string' && desktop !== 'none' ? desktop : '';
  const differs = DEVICES.slice(1).some((d) => {
    const v = w.raw(key + d.suffix);
    return !isBlank(v) && v !== desktop;
  });
  if (differs) w.note('Per-device entrance animations are not supported by Zadex; the desktop animation is used on every device.');
  if (!name) return;
  const target = ANIMATIONS[name];
  if (!target) {
    w.note(`Entrance animation "${name}" has no Zadex equivalent.`);
    return;
  }
  if (!EXACT_ANIMATIONS.has(name)) w.note(`Entrance animation "${name}" was approximated with "${target}".`);
  w.set('_animation', target);
  const duration = w.raw('animation_duration');
  if (duration === 'slow' || duration === 'fast') w.set('_animation_duration', duration);
  const delay = num(w.raw(delayKey));
  if (typeof delay === 'number' && delay > 0) w.set('_animation_delay', Math.min(10000, delay));
}

/* ---- transform ---- */

interface TransformParts {
  translateX?: Slider;
  translateY?: Slider;
  scale?: number;
  rotate?: number;
  skewX?: number;
  skewY?: number;
}

const isEmpty = (o: object): boolean => Object.keys(o).length === 0;

/**
 * `_transform_*` (rotate, translate, scale, skew, + `_hover` variants, responsive) -> Zadex `_transform`
 * `{translateX, translateY, scale, rotate, skewX, skewY, origin}`. Elementor composes the transform from CSS
 * variables that cascade per property; a Zadex value replaces the whole transform, so every written value is the
 * merged result for that device (and hover values include the normal values). 3D rotation, perspective, flips and
 * non-uniform scale have no Zadex equivalent and are noted. A hover transform also gets Elementor's transition
 * (`_transform_transition_hover`, default 400 ms) as Zadex `_transition`.
 */
function transform(w: ElementWriter): void {
  w.consume('_transform_*', 'motion_fx_transform_x_anchor_point', 'motion_fx_transform_y_anchor_point');
  const ax = w.raw('motion_fx_transform_x_anchor_point');
  const ay = w.raw('motion_fx_transform_y_anchor_point');
  const origin = (typeof ax === 'string' && ax) || (typeof ay === 'string' && ay) ? `${(ax as string) || 'center'} ${(ay as string) || 'center'}` : '';

  const read = (hover: boolean, suffix: string): TransformParts => {
    const h = hover ? '_hover' : '';
    const key = (prop: string): string => `_transform_${prop}_effect${h}${suffix}`;
    const on = (group: string): boolean => bool(w.raw(`_transform_${group}_popover${h}`));
    const size = (prop: string): number | undefined => {
      const s = slider(w.raw(key(prop)));
      return s && typeof s.size === 'number' ? s.size : undefined;
    };
    const t: TransformParts = {};
    if (on('rotate')) {
      const r = size('rotateZ');
      if (r !== undefined) t.rotate = r;
      if (bool(w.raw(`_transform_rotate_3d${h}`)) && (size('rotateX') !== undefined || size('rotateY') !== undefined)) w.note('3D rotation (rotate X / Y) is not supported by Zadex transforms.');
      if (bool(w.raw(`_transform_rotate_3d${h}`)) && size('perspective') !== undefined) w.note('Transform perspective is not supported by Zadex.');
    }
    if (on('translate')) {
      const x = slider(w.raw(key('translateX')));
      const y = slider(w.raw(key('translateY')));
      if (x) t.translateX = x;
      if (y) t.translateY = y;
    }
    if (on('scale')) {
      const keep = w.raw(`_transform_keep_proportions${h}`);
      if (keep === undefined || bool(keep)) {
        const s = size('scale');
        if (s !== undefined) t.scale = s;
      } else {
        const sx = size('scaleX');
        const sy = size('scaleY');
        if (sx !== undefined && sx === sy) t.scale = sx;
        else if (sx !== undefined || sy !== undefined) w.note('Non-uniform scale (scale X / Y) is not supported by Zadex transforms.');
      }
    }
    if (on('skew')) {
      const x = size('skewX');
      const y = size('skewY');
      if (x !== undefined) t.skewX = x;
      if (y !== undefined) t.skewY = y;
    }
    if (!suffix && (!isBlank(w.raw(`_transform_flipX_effect${h}`)) || !isBlank(w.raw(`_transform_flipY_effect${h}`)))) w.note('Flip transforms are not supported by Zadex.');
    return t;
  };

  const base: TransformParts[] = [];
  const hoverCum: TransformParts[] = [];
  const out = (t: TransformParts): Record<string, unknown> => (origin ? { ...t, origin } : { ...t });
  let hoverWritten = false;
  DEVICES.forEach((d, i) => {
    const own = read(false, d.suffix);
    const ownHover = read(true, d.suffix);
    base[i] = { ...(d.parent >= 0 ? base[d.parent] : {}), ...own };
    hoverCum[i] = { ...(d.parent >= 0 ? hoverCum[d.parent] : {}), ...ownHover };
    if (!isEmpty(own)) w.set('_transform', out(base[i]), { bp: d.bp });
    if (!isEmpty(hoverCum[i]) && (!d.bp || !isEmpty(own) || !isEmpty(ownHover))) {
      w.set('_transform', out({ ...base[i], ...hoverCum[i] }), { bp: d.bp, state: 'hover' });
      hoverWritten = true;
    }
  });
  if (hoverWritten && w.settings._transition === undefined) {
    const ms = slider(w.raw('_transform_transition_hover'));
    const duration = ms && typeof ms.size === 'number' ? ms.size / 1000 : 0.4;
    w.set('_transition', { duration, easing: '', delay: '', properties: 'transform' });
  }
}

/* ---- Pro motion effects and sticky ---- */

const sizeOf = (v: unknown, d: number): number => {
  const s = slider(v);
  return s && typeof s.size === 'number' ? s.size : d;
};
const rangeOf = (v: unknown, start: number, end: number): [number, number] => {
  const sizes = typeof v === 'object' && v !== null ? (v as Record<string, unknown>).sizes : undefined;
  if (typeof sizes !== 'object' || sizes === null) return [start, end];
  const s = num((sizes as Record<string, unknown>).start);
  const e = num((sizes as Record<string, unknown>).end);
  return [typeof s === 'number' ? s : start, typeof e === 'number' ? e : end];
};
/** Elementor opacity / blur directions (`out-in` = "Fade In") -> Zadex. */
const FADE_DIR: Record<string, string> = { 'out-in': 'in', 'in-out': 'out', 'in-out-in': 'out-in', 'out-in-out': 'in-out' };
/** Elementor scale directions (`out-in` = "Scale Up") -> Zadex. */
const SCALE_DIR: Record<string, string> = { 'out-in': 'up', 'in-out': 'down', 'in-out-in': 'down-up', 'out-in-out': 'up-down' };
const DEVICE_NAMES = new Set(['desktop', 'tablet', 'mobile']);

const devicesOf = (v: unknown): string[] | undefined =>
  Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string' && DEVICE_NAMES.has(x)) : undefined;

/** Elementor Pro element motion effects (`motion_fx_*`) -> Zadex `_scroll_fx` / `_fx_*` and `_mouse_fx` / `_mouse_*`. */
function motionEffects(w: ElementWriter): void {
  w.consume('motion_fx_*');
  const g = (k: string): unknown => w.raw('motion_fx_' + k);
  if (bool(g('motion_fx_scrolling'))) {
    w.set('_scroll_fx', true);
    const axis = (src: string, dst: string, dirs: [string, string], speed: number): void => {
      if (!bool(g(`${src}_effect`))) return;
      w.set(`_fx_${dst}`, true);
      w.set(`_fx_${dst}_dir`, g(`${src}_direction`) === 'negative' ? dirs[1] : dirs[0]);
      w.set(`_fx_${dst}_speed`, sizeOf(g(`${src}_speed`), speed));
      const [s, e] = rangeOf(g(`${src}_affectedRange`), 0, 100);
      w.set(`_fx_${dst}_start`, s);
      w.set(`_fx_${dst}_end`, e);
    };
    axis('translateY', 'y', ['up', 'down'], 4);
    axis('translateX', 'x', ['left', 'right'], 4);
    axis('rotateZ', 'rotate', ['left', 'right'], 1);
    const ranged = (src: string, dirs: Record<string, string>, amountKey: 'level' | 'speed', amount: number): void => {
      if (!bool(g(`${src}_effect`))) return;
      w.set(`_fx_${src}`, true);
      const dir = g(`${src}_direction`);
      w.set(`_fx_${src}_dir`, (typeof dir === 'string' && dirs[dir]) || dirs['out-in']);
      w.set(`_fx_${src}_${amountKey}`, sizeOf(g(`${src}_${amountKey}`), amount));
      const [s, e] = rangeOf(g(`${src}_range`), 20, 80);
      w.set(`_fx_${src}_start`, s);
      w.set(`_fx_${src}_end`, e);
    };
    ranged('opacity', FADE_DIR, 'level', 10);
    ranged('blur', FADE_DIR, 'level', 7);
    ranged('scale', SCALE_DIR, 'speed', 4);
    const devices = devicesOf(g('devices'));
    if (devices) w.set('_fx_devices', devices);
    if (g('range') === 'page') w.note('Scrolling effects relative to the entire page are relative to the viewport in Zadex.');
  }
  if (bool(g('motion_fx_mouse'))) {
    w.set('_mouse_fx', true);
    if (bool(g('mouseTrack_effect'))) {
      w.set('_mouse_track', true);
      w.set('_mouse_track_dir', g('mouseTrack_direction') === 'negative' ? 'direct' : 'opposite');
      w.set('_mouse_track_speed', sizeOf(g('mouseTrack_speed'), 1));
    }
    if (bool(g('tilt_effect'))) {
      w.set('_mouse_tilt', true);
      w.set('_mouse_tilt_dir', g('tilt_direction') === 'negative' ? 'opposite' : 'direct');
      w.set('_mouse_tilt_max', Math.min(45, Math.round(sizeOf(g('tilt_speed'), 4) * 2.5)));
      w.note('3D tilt speed was approximated with a maximum tilt angle.');
    }
  }
}

/** Elementor Pro sticky (`sticky`, `sticky_on`, `sticky_offset`, `sticky_effects_offset`, `sticky_parent`). */
function sticky(w: ElementWriter): void {
  w.consume('sticky*');
  const mode = w.raw('sticky');
  if (mode !== 'top' && mode !== 'bottom') return;
  w.set('_sticky', mode);
  const devices = devicesOf(w.raw('sticky_on'));
  if (devices) w.set('_sticky_devices', devices);
  for (const d of DEVICES) {
    const n = num(w.raw('sticky_offset' + d.suffix));
    if (typeof n === 'number') w.set('_sticky_offset', { size: n, unit: 'px' }, { bp: d.bp });
  }
  const effects = num(w.raw('sticky_effects_offset'));
  if (typeof effects === 'number' && effects > 0) w.set('_sticky_effects_offset', effects);
  if (bool(w.raw('sticky_parent'))) w.set('_sticky_parent', true);
  if (!isBlank(w.raw('sticky_anchor_link_offset'))) w.note('Sticky anchor link offset is not supported by Zadex.');
}

/* ---- widget wrapper border / shadow ---- */

/** Zadex widgets whose `{{WRAPPER}}` is an inline control rather than the widget box (Elementor's wrapper). */
const INLINE_WRAPPER = new Set(['button', 'paypal-button']);

/**
 * Widget Advanced > Border / Box shadow (`_border_*`, `_box_shadow_*`, hover variants). Zadex has no common
 * border / shadow control, but several widgets (icon-box, image-box, call-to-action, google-maps, alert …) have
 * `border` / `box_shadow` controls applied to the widget box itself: those are used when the widget mapper left
 * them empty. Otherwise the keys stay unread (reported as dropped). Widget backgrounds (`_background_*`) are left
 * to the shared background converter (src/convert/background.ts) and reported as dropped until it is wired here.
 */
function wrapperDecoration(w: ElementWriter): void {
  if (w.el.elType !== 'widget' || INLINE_WRAPPER.has(w.type)) return;
  const controls = w.ctx.manifests[w.type]?.controls ?? [];
  const wrapperControl = (id: string, type: string) =>
    controls.find((c) => c.id === id && c.type === type && (c.css ?? []).length > 0 && (c.css ?? []).every((m) => m.selector === '{{WRAPPER}}'));
  const src = w.el.settings ?? {};
  const set = (pred: (k: string) => boolean): boolean => Object.keys(src).some((k) => pred(k) && !isBlank(src[k]));
  const hoverProps: string[] = [];

  const border = wrapperControl('border', 'border');
  if (border) {
    const normal = set((k) => (k.startsWith('_border_') && !k.startsWith('_border_hover') && !k.startsWith('_border_radius_hover')));
    if (normal && w.settings.border === undefined) w.border('_border', 'border', '_border_radius');
    const hover = set((k) => k.startsWith('_border_hover_') || k.startsWith('_border_radius_hover'));
    if (hover && border.states?.includes('hover') && w.settings['border::hover'] === undefined) {
      w.border('_border_hover', 'border', '_border_radius_hover', 'hover');
      hoverProps.push('border-color', 'border-radius');
    }
  }
  const shadow = wrapperControl('box_shadow', 'boxShadow');
  if (shadow) {
    if (bool(src._box_shadow_box_shadow_type) && w.settings.box_shadow === undefined) w.boxShadow('_box_shadow', 'box_shadow');
    if (bool(src._box_shadow_hover_box_shadow_type) && shadow.states?.includes('hover') && w.settings['box_shadow::hover'] === undefined) {
      w.boxShadow('_box_shadow_hover', 'box_shadow', 'hover');
      hoverProps.push('box-shadow');
    }
  }
  if (hoverProps.length) {
    w.consume('_border_hover_transition');
    const ms = slider(w.raw('_border_hover_transition'));
    const duration = ms && typeof ms.size === 'number' ? ms.size / 1000 : 0.3;
    const current = w.settings._transition as Record<string, unknown> | undefined;
    if (current === undefined) w.set('_transition', { duration, easing: '', delay: '', properties: hoverProps.join(', ') });
    else if (current.properties === 'transform') w.set('_transition', { ...current, properties: ['transform', ...hoverProps].join(', ') });
  }
}

/* ---- custom CSS ---- */

/** Elementor Pro custom CSS is not carried over: Zadex has no custom CSS (WordPress.org rule). */
function customCss(w: ElementWriter): void {
  const css = w.raw('custom_css');
  const legacy = w.raw('_css');
  if ((typeof css === 'string' && css.trim() !== '') || (typeof legacy === 'string' && legacy.trim() !== '')) {
    w.note('Custom CSS is not supported by Zadex (WordPress.org rule); it was not carried over.');
    w.status('partial');
  }
}
