import type { SourceDocument, TemplateTarget, ZadexConditionRule } from './types';

/**
 * Elementor Theme Builder / saved templates -> Zadex targets (docs/ARCHITECTURE.md "Theme Builder and saved
 * templates" and "Templates (converter)").
 *
 * Verified against Elementor Pro 3.33.2 (`modules/theme-builder/conditions/*.php`, `classes/conditions-manager.php`,
 * `modules/woocommerce/conditions/*.php`):
 *  - `_elementor_conditions` is a list of `<include|exclude>/<name>/<sub_name>/<sub_id>` strings (`save_conditions`
 *    rtrims the joined parts; the editor's REST shape `{type, name, sub_name, sub_id}` is accepted too).
 *  - Conditions are registered flat by name: the frontend checks `name` (the "all" gate) and then `sub_name` with
 *    `{id: sub_id}`. `name` is one of `general`, `archive`, `singular`, `woocommerce` (theme builder app) or a
 *    template's `condition_type` (`product`, `product_archive` when the template was created with a sub type).
 *  - `singular` (all) checks `(is_singular() && !is_embed()) || is_404()` -> Zadex `singular` + `404`.
 *  - `archive` (all) checks `is_archive() || is_home() || is_search()` but skips WooCommerce pages.
 *  - Archive sub names: `<post type>_archive` (`post_archive` also the blog index), `author`, `date`, `search`,
 *    `<taxonomy>` (id 0 = any term), `child_of_<taxonomy>` / `any_child_of_<taxonomy>` (term archives below a term).
 *  - Singular sub names: `front_page`, `<post type>` (id = that post), `in_<taxonomy>` / `in_<taxonomy>_children`,
 *    `<post type>_by_author`, `child_of`, `any_child_of`, `by_author`, `not_found404`.
 *  - WooCommerce: `woocommerce` (all = `is_woocommerce()` or a product search) with `product_archive` (shop, product
 *    taxonomies, product search), `shop_page`, `product_search`, `product_cat|product_tag[/<id>]`, `product[/<id>]`,
 *    `in_product_cat|in_product_tag/<id>`, `product_by_author`.
 */

type Rule = ZadexConditionRule;
type Mode = Rule['mode'];

export interface ConditionsContext {
  /** Elementor `_elementor_template_type` of the template the conditions belong to (tunes the notes). */
  templateType?: string;
}

export interface ConditionsResult {
  rules: Rule[];
  notes: string[];
}

/** Elementor template types that are Zadex theme templates with display conditions. */
const THEME_TYPES: Record<string, Exclude<TemplateTarget, { kind: 'library' }>['type']> = {
  header: 'header',
  footer: 'footer',
  single: 'single',
  'single-post': 'single',
  'single-page': 'single',
  archive: 'archive',
  'search-results': 'search',
  'error-404': '404',
  'loop-item': 'loop-item',
  product: 'product',
  'product-archive': 'product_archive',
  // Phase 4: popup settings go to the page settings (src/convert/popup.ts), conditions like other templates.
  popup: 'popup',
};

/** Saved templates (free Elementor too) -> Zadex library item types. */
const LIBRARY_TYPES: Record<string, 'page' | 'section'> = {
  page: 'page',
  section: 'section',
  container: 'section',
};

/** Template types Zadex has no target for yet (reason shown in the report). */
const UNSUPPORTED_TYPES: Record<string, string> = {
  widget: 'Elementor global widgets have no Zadex equivalent; the pages using them keep their own copy of the widget.',
  kit: 'The Elementor kit (site settings) is migrated by the global settings import, not as a template.',
};

/** Template types whose location only renders on singular views (term rules cannot leak onto term archives). */
const SINGULAR_TYPES = new Set(['single', 'single-post', 'single-page', 'product']);
/** Template types whose location only renders on archive views. */
const ARCHIVE_TYPES = new Set(['archive', 'search-results', 'product-archive']);

/** Elementor condition groups that can be the `name` part (general sub conditions + template condition types). */
const PARENTS = new Set(['singular', 'archive', 'woocommerce', 'product', 'product_archive']);
/** Groups whose plain sub names are post types (archive groups: taxonomies). */
const SINGULAR_PARENTS = new Set(['singular', 'product']);

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Raw `_elementor_conditions` value -> list of condition strings. */
function conditionStrings(conditions: unknown): string[] {
  if (conditions === undefined || conditions === null || conditions === '') return [];
  const list = Array.isArray(conditions) ? conditions : isObj(conditions) && !('name' in conditions) ? Object.values(conditions) : [conditions];
  const out: string[] = [];
  for (const item of list) {
    if (typeof item === 'string') {
      if (item.trim() !== '') out.push(item.trim());
    } else if (isObj(item)) {
      // REST shape {type, name, sub_name, sub_id}.
      const parts = [item.type, item.name, item.sub_name, item.sub_id].map((p) => (p === undefined || p === null ? '' : String(p)));
      while (parts.length && parts[parts.length - 1] === '') parts.pop();
      if (parts.length) out.push(parts.join('/'));
    }
  }
  return out;
}

/** Elementor `sub_id`: numeric strings become numbers (Zadex stores ids as ints), anything else stays a slug. */
function idValue(raw: string | undefined): number | string {
  if (raw === undefined || raw === '') return '';
  return /^\d+$/.test(raw) ? Number(raw) : raw;
}

const rule = (mode: Mode, target: Rule['target'], sub = '', value: number | string = ''): Rule => ({ mode, target, sub, value });

/**
 * Elementor `_elementor_conditions` -> Zadex display rules (`{mode, target, sub, value}`, `Zadex\Theme\Conditions`).
 * Never throws: conditions Zadex cannot express are left out and named in `notes`; approximations are noted too.
 */
export function convertConditions(conditions: unknown, ctx: ConditionsContext = {}): ConditionsResult {
  const rules: Rule[] = [];
  const notes: string[] = [];
  const seen = new Set<string>();
  const note = (text: string) => {
    if (!notes.includes(text)) notes.push(text);
  };
  const add = (...list: Rule[]) => {
    for (const r of list) {
      const key = JSON.stringify(r);
      if (seen.has(key)) continue;
      seen.add(key);
      rules.push(r);
    }
  };
  const type = ctx.templateType ?? '';
  const singularOnly = SINGULAR_TYPES.has(type);
  const archiveOnly = ARCHIVE_TYPES.has(type);

  for (const condition of conditionStrings(conditions)) {
    const parts = condition.split('/').map((p) => p.trim());
    const head = parts[0] ?? '';
    if (head !== 'include' && head !== 'exclude') {
      note(`Display condition "${condition}" is not in Elementor's format and was left out.`);
      continue;
    }
    const mode: Mode = head;
    const [name = '', subName = '', subId] = parts.slice(1);
    const unsupported = (why: string) => note(`Display condition "${condition}" was left out: ${why}`);

    if (name === 'general') {
      add(rule(mode, 'entire'));
      continue;
    }
    if (!PARENTS.has(name)) {
      unsupported(`Zadex has no equivalent for the "${name}" condition.`);
      continue;
    }

    if (subName === '' || (subName === name && name !== 'product')) {
      // The "all" option of the condition group.
      if (name === 'singular') {
        // Elementor's "All singular" also covers the 404 page.
        add(rule(mode, 'singular'), rule(mode, '404'));
      } else if (name === 'archive') {
        // Elementor's "All archives" also covers the blog index and search results, but not WooCommerce pages.
        add(rule(mode, 'archive'), rule(mode, 'search'));
        note(`On WooCommerce sites Elementor's "All archives" skips the shop and product archives; the Zadex archive condition matches them too ("${condition}").`);
      } else if (name === 'woocommerce') {
        // `is_woocommerce()` (shop, product taxonomies, single products) or a product search.
        add(rule(mode, 'product'), rule(mode, 'product_archive'));
      } else if (name === 'product') {
        add(rule(mode, 'product'));
      } else {
        add(rule(mode, 'product_archive'));
      }
      continue;
    }

    // Sub conditions are registered flat by name, so the sub name alone says what is checked; the parent only
    // decides whether a plain name is a post type (singular) or a taxonomy (archive).
    if (subName === 'front_page') add(rule(mode, 'front'));
    else if (subName === 'not_found404') add(rule(mode, '404'));
    else if (subName === 'child_of' || subName === 'any_child_of') unsupported('Zadex has no "child of" condition.');
    else if (subName === 'by_author' || subName.endsWith('_by_author')) unsupported('Zadex cannot match singular posts by author (only author archives).');
    else if (subName.startsWith('in_') && subName.endsWith('_children')) unsupported('Zadex cannot match posts in the child terms of a term.');
    else if (subName.startsWith('in_')) {
      const taxonomy = subName.slice(3);
      const value = idValue(subId);
      if (value === '' || value === 0) {
        unsupported('no term was selected.');
      } else if (taxonomy === 'product_cat' || taxonomy === 'product_tag') {
        add(rule(mode, taxonomy === 'product_cat' ? 'product_in_cat' : 'product_in_tag', '', value));
      } else {
        add(rule(mode, 'term', taxonomy, value));
        if (!singularOnly) {
          note(
            mode === 'include'
              ? `Zadex term conditions also match the term archive: "${condition}" now shows the template on the ${taxonomy} #${value} archive too.`
              : `Zadex term conditions also match the term archive: "${condition}" now also hides the template on the ${taxonomy} #${value} archive.`,
          );
        }
      }
    } else if (subName.startsWith('child_of_') || subName.startsWith('any_child_of_') || subName.endsWith('_children')) {
      unsupported('Zadex cannot match the archives of child terms.');
    } else if (subName === 'author') add(rule(mode, 'author', '', idValue(subId)));
    else if (subName === 'date') add(rule(mode, 'date'));
    else if (subName === 'search') add(rule(mode, 'search'));
    else if (subName === 'shop_page') add(rule(mode, 'shop'));
    else if (subName === 'product_search') {
      add(rule(mode, 'search'));
      note(`"${condition}" became the Zadex "Search results" condition, which matches every search, not only product searches.`);
    } else if (subName === 'product_archive') add(rule(mode, 'product_archive'));
    else if (subName === 'product') {
      const value = idValue(subId);
      add(value === '' || value === 0 ? rule(mode, 'product') : rule(mode, 'product_specific', '', value));
    } else if (SINGULAR_PARENTS.has(name)) {
      // A post type: `singular/post`, `singular/page`, `singular/<cpt>[/<id>]` (the id is that post).
      const value = idValue(subId);
      add(value === '' || value === 0 ? rule(mode, 'singular', subName) : rule(mode, 'specific', subName, value));
    } else if (subName.endsWith('_archive')) {
      // `post_archive` (blog index), `<cpt>_archive`.
      const postType = subName.slice(0, -'_archive'.length);
      add(rule(mode, 'archive', postType));
      note(`Zadex post type archive conditions also match the ${postType} taxonomy, author and date archives ("${condition}").`);
    } else {
      // A taxonomy archive: `archive/<taxonomy>[/<id>]`, `woocommerce|product_archive/<product taxonomy>[/<id>]`.
      termArchive(mode, subName, subId, condition, add, note, archiveOnly || name !== 'archive');
    }
  }

  if (rules.length === 0 && type !== 'loop-item') {
    note('The template has no display conditions Zadex can use: it will not be shown anywhere until conditions are added in Zadex.');
  } else if (rules.length > 0 && rules.every((r) => r.mode === 'exclude')) {
    note('The template only has exclude conditions, so it is not shown anywhere (same as in Elementor).');
  }
  return { rules, notes };
}

/** `archive/<taxonomy>[/<id>]` (and the WooCommerce product taxonomies). */
function termArchive(mode: Mode, taxonomy: string, subId: string | undefined, condition: string, add: (...r: Rule[]) => void, note: (t: string) => void, quiet: boolean): void {
  const value = idValue(subId);
  const one = value !== '' && value !== 0;
  if (taxonomy === 'product_cat' || taxonomy === 'product_tag') {
    add(rule(mode, taxonomy === 'product_cat' ? 'product_cat_archive' : 'product_tag_archive', '', one ? value : ''));
    return;
  }
  if (!one) {
    add(rule(mode, 'taxonomy', taxonomy));
    return;
  }
  add(rule(mode, 'term', taxonomy, value));
  if (!quiet) note(`Zadex term conditions also match single posts in the term: "${condition}" now applies to posts in ${taxonomy} #${value} too.`);
}

/**
 * Where an `elementor_library` document goes in Zadex: a theme template (type, rules, template settings) or a library
 * item (popups: theme `popup`, settings in the page settings). Returns undefined for template types Zadex cannot
 * hold (global widget, kit, unknown); the reason goes
 * to `note`, like the condition notes.
 */
export function templateTarget(source: SourceDocument, note: (text: string) => void = () => undefined): TemplateTarget | undefined {
  const raw = typeof source.templateType === 'string' ? source.templateType.trim() : '';
  if (raw === '') {
    note('The Elementor template has no template type, so it was not given a Zadex destination.');
    return undefined;
  }
  const library = LIBRARY_TYPES[raw];
  if (library) return { kind: 'library', type: library };
  const type = THEME_TYPES[raw];
  if (!type) {
    note(UNSUPPORTED_TYPES[raw] ?? `Elementor "${raw}" templates have no Zadex equivalent.`);
    return undefined;
  }
  // Header stickiness stays element-level: Elementor Pro stores it on the root container (motion `sticky`), which
  // becomes the same element-level Zadex sticky (devices, offset, scrolled styles kept). Zadex template `sticky` is
  // left off so the header is not sticky twice.
  const settings = { sticky: false, transparent: false, layout: 'full_width' as 'full_width' | 'canvas' };
  if ((type === 'single' || type === 'product' || type === '404') && source.template === 'elementor_canvas') settings.layout = 'canvas';
  if (type === 'loop-item') {
    if (conditionStrings(source.conditions).length) note('Loop item templates have no display conditions in Zadex; the Elementor conditions were ignored.');
    return { kind: 'theme', type, rules: [], settings };
  }
  if (type === 'product' || type === 'product_archive') {
    note('WooCommerce templates need the Zadex WooCommerce integration (WooCommerce active) to be used.');
  }
  const { rules, notes } = convertConditions(source.conditions, { templateType: raw });
  if (type === 'popup') {
    // A popup without conditions still opens from links / buttons / form actions (Zadex prints linked popups);
    // only its automatic triggers need conditions.
    const empty = 'The template has no display conditions Zadex can use: it will not be shown anywhere until conditions are added in Zadex.';
    notes.forEach((n) => {
      if (n !== empty) note(n);
    });
    if (rules.length === 0) note('The popup has no display conditions Zadex can use: its triggers never run, it only opens from links, buttons and form actions until conditions are added in Zadex.');
    return { kind: 'theme', type, rules, settings };
  }
  notes.forEach(note);
  return { kind: 'theme', type, rules, settings };
}
