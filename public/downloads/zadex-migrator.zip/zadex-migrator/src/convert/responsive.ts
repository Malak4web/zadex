import type { BreakpointKey } from './types';

/**
 * Elementor device suffixes -> Zadex breakpoint keys. Both builders are desktop-first and use the same
 * default widths (mobile 767, mobile extra 880, tablet 1024, tablet extra 1200, laptop 1366, widescreen 2400).
 * `''` is the desktop (base) value.
 */
export const DEVICE_SUFFIXES: Array<{ suffix: string; bp: BreakpointKey | undefined }> = [
  { suffix: '', bp: undefined },
  { suffix: '_widescreen', bp: 'widescreen' },
  { suffix: '_laptop', bp: 'laptop' },
  { suffix: '_tablet_extra', bp: 'tablet_large' },
  { suffix: '_tablet', bp: 'tablet' },
  { suffix: '_mobile_extra', bp: 'mobile_large' },
  { suffix: '_mobile', bp: 'mobile' },
];

/** Elementor kit `viewport_*` keys -> Zadex breakpoint keys. */
export const VIEWPORT_KEYS: Record<string, BreakpointKey> = {
  viewport_mobile: 'mobile',
  viewport_mobile_extra: 'mobile_large',
  viewport_tablet: 'tablet',
  viewport_tablet_extra: 'tablet_large',
  viewport_laptop: 'laptop',
  viewport_widescreen: 'widescreen',
};

/** Splits `foo_tablet` into `{ base: 'foo', bp: 'tablet' }`; desktop keys return `bp: undefined`. */
export function splitDeviceKey(key: string): { base: string; bp: BreakpointKey | undefined } {
  for (const { suffix, bp } of DEVICE_SUFFIXES) {
    if (suffix && key.endsWith(suffix)) return { base: key.slice(0, -suffix.length), bp };
  }
  return { base: key, bp: undefined };
}

/** All Elementor keys of a responsive control, desktop first: `[['foo', undefined], ['foo_tablet', 'tablet'], …]`. */
export function deviceKeys(base: string): Array<[string, BreakpointKey | undefined]> {
  return DEVICE_SUFFIXES.map(({ suffix, bp }) => [base + suffix, bp]);
}
