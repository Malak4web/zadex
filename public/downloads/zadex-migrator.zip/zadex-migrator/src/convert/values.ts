/**
 * Pure converters from Elementor control values to Zadex control values (shapes: dev/reference/zadex-shapes.md).
 * Every function returns `undefined` for an empty / unusable value so callers can skip writing the key.
 */

type Obj = Record<string, unknown>;

const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

export function isBlank(v: unknown): boolean {
  if (v === undefined || v === null || v === '') return true;
  if (Array.isArray(v)) return v.length === 0;
  return false;
}

/** `"12"` -> 12, `"1.5"` -> 1.5, `""` -> undefined, numbers pass through, other strings (calc(), var()) stay strings. */
export function num(v: unknown): number | string | undefined {
  if (typeof v === 'number') return Number.isFinite(v) ? v : undefined;
  if (typeof v !== 'string') return undefined;
  const s = v.trim();
  if (s === '') return undefined;
  const n = Number(s);
  return Number.isFinite(n) ? n : s;
}

/** Elementor switcher: `'yes'` (or any truthy non-empty string other than 'no') -> true. */
export function bool(v: unknown): boolean {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  return typeof v === 'string' && v !== '' && v !== 'no' && v !== 'false';
}

export interface Slider {
  size: number | string;
  unit: string;
}

/** Elementor slider `{unit, size, sizes}` -> Zadex slider `{size, unit}`. */
export function slider(v: unknown, defaultUnit = 'px'): Slider | undefined {
  if (typeof v === 'number' || (typeof v === 'string' && v.trim() !== '')) {
    const size = num(v);
    return size === undefined ? undefined : { size, unit: defaultUnit };
  }
  if (!isObj(v)) return undefined;
  const size = num(v.size);
  if (size === undefined) return undefined;
  const unit = typeof v.unit === 'string' && v.unit !== '' ? v.unit : defaultUnit;
  return { size, unit };
}

export interface Dimensions {
  top: number | string;
  right: number | string;
  bottom: number | string;
  left: number | string;
  unit: string;
  linked: boolean;
}

/** Elementor dimensions `{unit, top, right, bottom, left, isLinked}` -> Zadex dimensions. All sides empty -> undefined. */
export function dimensions(v: unknown): Dimensions | undefined {
  if (!isObj(v)) return undefined;
  const sides = ['top', 'right', 'bottom', 'left'] as const;
  const values = sides.map((s) => num(v[s]));
  if (values.every((x) => x === undefined)) return undefined;
  const [top, right, bottom, left] = values.map((x) => (x === undefined ? 0 : x));
  return {
    top,
    right,
    bottom,
    left,
    unit: typeof v.unit === 'string' && v.unit !== '' ? v.unit : 'px',
    linked: v.isLinked === true || v.isLinked === 'true',
  };
}

export interface BoxShadow {
  x: number;
  y: number;
  blur: number;
  spread: number;
  color: string;
  inset: boolean;
}

/** Elementor box/text shadow `{horizontal, vertical, blur, spread, color}` -> Zadex boxShadow. */
export function shadow(v: unknown, inset = false): BoxShadow | undefined {
  if (!isObj(v)) return undefined;
  const n = (x: unknown, d: number): number => {
    const r = num(x);
    return typeof r === 'number' ? r : d;
  };
  return {
    x: n(v.horizontal, 0),
    y: n(v.vertical, 0),
    blur: n(v.blur, 10),
    spread: n(v.spread, 0),
    color: typeof v.color === 'string' && v.color !== '' ? v.color : 'rgba(0,0,0,0.5)',
    inset,
  };
}

export interface UrlValue {
  url: string;
  target: string;
  nofollow: boolean;
  rel?: string;
}

/** Elementor url `{url, is_external: 'on', nofollow: 'on', custom_attributes}` -> Zadex url. Empty url -> undefined. */
export function url(v: unknown): UrlValue | undefined {
  if (typeof v === 'string') return v.trim() === '' ? undefined : { url: v.trim(), target: '', nofollow: false };
  if (!isObj(v)) return undefined;
  const href = typeof v.url === 'string' ? v.url.trim() : '';
  if (href === '') return undefined;
  return { url: href, target: bool(v.is_external) ? '_blank' : '', nofollow: bool(v.nofollow) };
}

export interface IconValue {
  library: string;
  value: string;
  svg?: string;
}

const FA_LIBRARIES: Record<string, string> = {
  'fa-solid': 'fa-solid',
  'fa-regular': 'fa-regular',
  'fa-brands': 'fa-brands',
};
const FA_PREFIX: Record<string, string> = { fas: 'fa-solid', far: 'fa-regular', fab: 'fa-brands', fa: 'fa-solid' };

/**
 * Elementor icon `{value: 'fas fa-star', library: 'fa-solid'}` -> Zadex `{library: 'fa-solid', value: 'fa-star'}`.
 * SVG uploads (`library: 'svg'`, `value: {id, url}`) need the inline markup: pass it as `svg`.
 * Returns undefined for empty icons and for libraries Zadex does not ship (eicons, custom Pro sets).
 */
export function icon(v: unknown, svg?: string): IconValue | undefined {
  if (!isObj(v)) return undefined;
  const library = typeof v.library === 'string' ? v.library : '';
  if (library === 'svg') return svg ? { library: '', value: '', svg } : undefined;
  if (typeof v.value !== 'string' || v.value.trim() === '') return undefined;
  const parts = v.value.trim().split(/\s+/);
  const glyph = parts.find((p) => p.startsWith('fa-') && !FA_LIBRARIES[p]);
  if (!glyph) return undefined;
  const lib = FA_LIBRARIES[library] ?? FA_PREFIX[parts[0]] ?? (parts.find((p) => FA_LIBRARIES[p]) as string | undefined);
  if (!lib) return undefined;
  return { library: lib, value: glyph };
}

/** Parses `globals/colors?id=primary` -> `{ kind: 'colors', id: 'primary' }`. */
export function parseGlobalRef(ref: unknown): { kind: string; id: string } | undefined {
  if (typeof ref !== 'string') return undefined;
  const m = ref.match(/^globals\/([a-z_-]+)\?id=([A-Za-z0-9_-]+)$/);
  return m ? { kind: m[1], id: m[2] } : undefined;
}
