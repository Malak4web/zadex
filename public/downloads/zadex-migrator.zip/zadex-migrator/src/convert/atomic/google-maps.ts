import { registerWidget } from '../registry';
import { atomicWriter } from './writer';
import { applyStyles } from './styles';

/**
 * Elementor v4 `e-google-maps` -> Zadex `google-maps`. Settings: `location`, `zoom`. The atomic map is a bare
 * iframe: 150px high unless styled, interactive (Zadex's scroll protection is turned off to match).
 * Styles: height, border-radius -> border_radius, border, box shadow.
 */
registerWidget('e-google-maps', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'google-maps');
  w.common();
  w.set('address', w.text('location', 'London Eye, London, United Kingdom'));
  w.set('zoom', w.number('zoom') ?? 10);
  w.set('prevent_scroll', false);
  applyStyles(
    w,
    { height: 'height', radius: 'border_radius', border: 'border', boxShadow: 'box_shadow', ignore: ['display'] },
    { height: { $$type: 'size', value: { size: 150, unit: 'px' } } },
  );
  return w.finish();
});
