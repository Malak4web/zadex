import { registerWidget } from '../registry';
import { atomicWriter } from './writer';
import * as P from './props';
import { applyStyles } from './styles';

const size = (n: number) => ({ $$type: 'size', value: { size: n, unit: 'px' } });

/**
 * Elementor v4 `e-button` -> Zadex `button`. Settings: `text`, `link` (no link = a `<button>` in Elementor; the
 * Zadex button gets an empty link instead of its `#` default). Elementor's base style (blue #375EFB background,
 * 12px 24px padding, 2px radius, no border) is applied first, then the element's classes.
 * Styles: background color (+hover/focus), color, typography, padding, border (+radius), box shadow.
 */
registerWidget('e-button', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'button');
  w.common();
  w.set('text', w.text('text', 'Click here'));
  const { value, approx } = P.link(w.prop('link'));
  w.set('link', value ?? { url: '', target: '', nofollow: false });
  if (approx) w.note(approx);
  w.consume('tag');
  applyStyles(
    w,
    {
      color: 'color',
      typography: 'typography',
      background: { id: 'bg_color', mode: 'color' },
      border: 'border',
      boxShadow: 'box_shadow',
      padding: 'padding',
      ignore: ['display'],
      props: {
        'text-align': (v) => (P.str(v) === 'center' ? true : 'Text alignment inside the button is not supported (Zadex centers button text).'),
      },
    },
    {
      background: { $$type: 'background', value: { color: { $$type: 'color', value: '#375EFB' } } },
      padding: { $$type: 'dimensions', value: { 'block-start': size(12), 'inline-end': size(24), 'block-end': size(12), 'inline-start': size(24) } },
      'border-radius': size(2),
      'border-width': size(0),
      'text-align': { $$type: 'string', value: 'center' },
    },
  );
  return w.finish();
});
