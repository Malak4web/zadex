import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { atomicWriter } from './writer';
import * as P from './props';
import { applyStyles } from './styles';

/**
 * Elementor v4 `e-paragraph` -> Zadex `text`. The paragraph (escaped-html, inline tags) is wrapped in `<p>` (tag
 * `p`, the default) or kept inline (tag `span`). A link on the whole paragraph is kept as an `<a>` around the text.
 * Styles: color (+hover), typography, text-align.
 */
registerWidget('e-paragraph', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'text');
  w.common();
  let text = w.text('paragraph', 'Type your paragraph here');
  const tag = w.text('tag', 'p');
  const { value, approx } = P.link(w.prop('link'));
  if (value) {
    const attrs = [`href="${escapeAttr(value.url)}"`];
    if (value.target) attrs.push(`target="${value.target}"`, 'rel="noopener"');
    text = `<a ${attrs.join(' ')}>${text}</a>`;
  }
  if (approx) w.note(approx);
  w.set('content', tag === 'span' ? text : `<p>${text}</p>`);
  applyStyles(w, { color: 'color', typography: 'typography', textAlign: { id: 'align', table: textAlign(ctx) } });
  return w.finish();
});

function escapeAttr(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
