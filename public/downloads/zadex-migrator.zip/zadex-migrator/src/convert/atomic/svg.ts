import { registerWidget } from '../registry';
import { atomicWriter } from './writer';
import * as P from './props';
import { applyStyles, type StyleSpec } from './styles';

const opacity: NonNullable<StyleSpec['props']>[string] = (value, v, ap) => {
  const s = P.size(value, ap.opts);
  if (!s || typeof s.size !== 'number') return true;
  const n = s.unit === '%' ? s.size / 100 : s.size;
  return ap.put('opacity', { size: Math.round(n * 1000) / 1000, unit: 'custom' }, v);
};

/**
 * Elementor v4 `e-svg` -> Zadex `svg` when the inline markup is available (media library SVG: the server sends
 * the sanitized markup in `media[id].svg`). An SVG known only by URL becomes a Zadex `image` showing that URL
 * (colors set on the SVG are lost). Elementor's default SVG box is 65 x 65 px.
 * Styles: width -> size, height, color, stroke color, opacity (+hover).
 */
registerWidget('e-svg', (el, ctx) => {
  const svgSrc = P.src(el.settings?.svg);
  const markup = svgSrc?.id ? ctx.svg({ id: svgSrc.id }) : undefined;
  const asImage = !markup && Boolean(svgSrc?.url) && ctx.hasWidget('image');
  const w = atomicWriter(el, ctx, asImage ? 'image' : 'svg');
  w.common();
  w.consume('svg');
  const { value, approx } = P.link(w.prop('link'));
  if (approx) w.note(approx);
  const base = { width: { $$type: 'size', value: { size: 65, unit: 'px' } }, height: { $$type: 'size', value: { size: 65, unit: 'px' } } };
  if (asImage) {
    w.set('image', { id: svgSrc!.id, url: svgSrc!.url, alt: svgSrc!.alt });
    w.set('size', 'full');
    if (value) {
      w.set('link_to', 'custom');
      w.set('link', value);
    }
    w.note('The SVG markup was not available; the SVG is shown as an image (colors set on it are lost).');
    w.status('partial');
    applyStyles(w, { width: 'width', height: 'height', ignore: ['display', 'color', 'stroke'], props: { opacity } }, base);
    return w.finish();
  }
  if (markup) w.set('svg', markup);
  else {
    w.note(svgSrc ? 'The SVG file could not be read; the Zadex default icon is used.' : 'The SVG was Elementor\'s default placeholder; the Zadex default icon is used.');
    w.status('partial');
  }
  if (value) w.set('link', value);
  applyStyles(
    w,
    {
      color: 'color',
      width: 'size',
      height: 'height',
      ignore: ['display'],
      props: {
        opacity,
        stroke: (val, v, ap) => {
          const s = P.unwrap(val);
          if (!P.isObj(s)) return true;
          const c = P.color(s.color, ap.opts);
          if (s.width !== undefined && s.width !== null) ap.dropProp('stroke-width', v, 'SVG stroke width has no Zadex control.');
          return c ? ap.put('stroke', c, v) : true;
        },
      },
    },
    base,
  );
  return w.finish();
});
