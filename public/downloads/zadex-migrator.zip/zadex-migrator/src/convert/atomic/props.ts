/**
 * Decoders for Elementor v4 ("atomic") typed props: `{"$$type": "<key>", "value": …}`.
 *
 * Every decoder takes the raw stored value (typed or, for a few legacy/base values, a bare string/number) and
 * returns the matching Zadex value (shapes: dev/reference/zadex-shapes.md) or `undefined` when the value is empty
 * or cannot be expressed. Global variables (`global-color-variable`, `global-font-variable`,
 * `global-size-variable`) are resolved through an optional resolver (the kit's `_elementor_global_variables`).
 * Pure functions: no context needed except `rtl` for logical sides and the variable resolver.
 */
import type { Dimensions, Slider, UrlValue } from '../values';

type Obj = Record<string, unknown>;
export const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Resolves a v4 global variable id (`e-gv-…`) to its stored value (color string, font family, size string). */
export type VariableResolver = (id: string) => unknown;

export interface DecodeOptions {
  rtl?: boolean;
  variable?: VariableResolver;
}

/** `$$type` of a typed value, or undefined for bare values. */
export function typeOf(v: unknown): string | undefined {
  return isObj(v) && typeof v.$$type === 'string' ? v.$$type : undefined;
}

/** Inner `value` of a typed prop (bare values pass through). */
export function unwrap(v: unknown): unknown {
  return isObj(v) && typeof v.$$type === 'string' ? v.value : v;
}

/** True when a stored prop holds nothing (null, '', [], `{value: null}`, `{value: []}`, `{value: ''}`). */
export function isEmptyProp(v: unknown): boolean {
  const inner = unwrap(v);
  if (inner === undefined || inner === null || inner === '') return true;
  if (Array.isArray(inner)) return inner.length === 0;
  if (isObj(inner) && Object.keys(inner).length === 0) return true;
  return false;
}

const VARIABLE_TYPES = new Set(['global-color-variable', 'global-font-variable', 'global-size-variable', 'global-custom-size-variable']);

/** True for a v4 global variable reference. */
export function isVariable(v: unknown): boolean {
  return VARIABLE_TYPES.has(typeOf(v) ?? '');
}

function resolveVariable(v: unknown, o: DecodeOptions): unknown {
  if (!isVariable(v)) return v;
  const id = unwrap(v);
  if (typeof id !== 'string' || !o.variable) return undefined;
  return o.variable(id);
}

/**
 * Text-like props: `string`, `escaped-html`, `html`, `url`, `html-v2` / `html-v3` (`{content, children}`, older
 * 4.x inline-editing formats). Numbers become strings.
 */
export function str(v: unknown): string | undefined {
  if (typeof v === 'string') return v;
  if (typeof v === 'number') return String(v);
  if (!isObj(v)) return undefined;
  const t = typeOf(v);
  const inner = v.value;
  if (t === 'html-v2' || t === 'html-v3') {
    if (isObj(inner)) return str(inner.content);
    return undefined;
  }
  if (typeof inner === 'string') return inner;
  if (typeof inner === 'number') return String(inner);
  return undefined;
}

export function num(v: unknown): number | undefined {
  const inner = unwrap(v);
  if (typeof inner === 'number') return Number.isFinite(inner) ? inner : undefined;
  if (typeof inner === 'string' && inner.trim() !== '') {
    const n = Number(inner);
    return Number.isFinite(n) ? n : undefined;
  }
  return undefined;
}

export function bool(v: unknown): boolean | undefined {
  const inner = unwrap(v);
  if (typeof inner === 'boolean') return inner;
  if (inner === 'true' || inner === 'yes' || inner === 1) return true;
  if (inner === 'false' || inner === '' || inner === 0) return false;
  return undefined;
}

/** `{$$type:'color', value:'#fff'}` (or a global color variable) -> CSS color string. */
export function color(v: unknown, o: DecodeOptions = {}): string | undefined {
  if (isVariable(v)) {
    const r = resolveVariable(v, o);
    return typeof r === 'string' && r !== '' ? r : undefined;
  }
  const inner = unwrap(v);
  return typeof inner === 'string' && inner.trim() !== '' ? inner.trim() : undefined;
}

/** Font family (`font-family` / `string` / global font variable) -> family name. */
export function fontFamily(v: unknown, o: DecodeOptions = {}): string | undefined {
  if (isVariable(v)) {
    const r = resolveVariable(v, o);
    return typeof r === 'string' && r !== '' ? r : undefined;
  }
  return str(v)?.trim() || undefined;
}

/**
 * Size prop `{$$type:'size', value:{size, unit}}` -> Zadex slider. `auto` -> `{size:'auto', unit:'custom'}`,
 * `custom` -> raw string, a bare CSS string (base styles) -> custom. A global size variable resolves to its
 * stored CSS value (custom).
 */
export function size(v: unknown, o: DecodeOptions = {}): Slider | undefined {
  if (isVariable(v)) {
    const r = resolveVariable(v, o);
    if (typeof r === 'string' && r.trim() !== '') return parseCssLength(r.trim());
    if (isObj(r)) return size({ $$type: 'size', value: r });
    return undefined;
  }
  if (typeof v === 'number') return { size: v, unit: 'px' };
  if (typeof v === 'string') return v.trim() === '' ? undefined : parseCssLength(v.trim());
  const inner = unwrap(v);
  if (!isObj(inner)) return undefined;
  const unit = typeof inner.unit === 'string' && inner.unit !== '' ? inner.unit : 'px';
  if (unit === 'auto') return { size: 'auto', unit: 'custom' };
  const raw = inner.size;
  if (raw === undefined || raw === null || raw === '') return undefined;
  if (unit === 'custom') return { size: String(raw), unit: 'custom' };
  const n = typeof raw === 'number' ? raw : Number(raw);
  if (!Number.isFinite(n)) return { size: String(raw), unit: 'custom' };
  return { size: n, unit };
}

/** `"12px"` -> `{12, px}`; anything else (calc(), var()) -> custom. */
export function parseCssLength(s: string): Slider {
  const m = s.match(/^(-?\d*\.?\d+)(px|%|em|rem|vw|vh|fr|deg|s|ms)?$/);
  if (m) return { size: Number(m[1]), unit: m[2] ?? 'px' };
  return { size: s, unit: 'custom' };
}

/** A Zadex slider as a CSS length (for building `custom` dimension sides). */
export function sliderCss(s: Slider): string {
  if (s.unit === 'custom') return String(s.size);
  return s.size === 0 ? '0' : `${s.size}${s.unit}`;
}

/** Shared by dimensions / border width / radius: 4 sides (any may be undefined) -> Zadex dimensions. */
function sidesToDimensions(sides: Array<Slider | undefined>, emptySide: number | '' = ''): Dimensions | undefined {
  if (sides.every((s) => s === undefined)) return undefined;
  const units = new Set(sides.filter((s): s is Slider => s !== undefined).map((s) => s.unit));
  const [top, right, bottom, left] = sides;
  if (units.size === 1 && !units.has('custom')) {
    const unit = [...units][0];
    const val = (s: Slider | undefined): number | string => (s === undefined ? emptySide : s.size);
    return { top: val(top), right: val(right), bottom: val(bottom), left: val(left), unit, linked: allSame(sides) };
  }
  // Mixed units or auto / custom sides: Zadex `custom` unit prints each side verbatim.
  const css = (s: Slider | undefined): string => (s === undefined ? (emptySide === '' ? '' : '0') : sliderCss(s));
  return { top: css(top), right: css(right), bottom: css(bottom), left: css(left), unit: 'custom', linked: allSame(sides) };
}

function allSame(sides: Array<Slider | undefined>): boolean {
  const j = sides.map((s) => JSON.stringify(s ?? null));
  return j.every((x) => x === j[0]);
}

/**
 * Padding / margin: `dimensions` with logical sides (`block-start`, `inline-end`, `block-end`, `inline-start`)
 * or a single `size` for all sides. Inline sides are physical right/left in LTR, swapped on RTL sites.
 */
export function dimensions(v: unknown, o: DecodeOptions = {}, emptySide: number | '' = ''): Dimensions | undefined {
  const t = typeOf(v);
  if (t === 'size' || isVariable(v) || typeof v === 'string' || typeof v === 'number') {
    const s = size(v, o);
    return s ? sidesToDimensions([s, s, s, s], emptySide) : undefined;
  }
  const inner = unwrap(v);
  if (!isObj(inner)) return undefined;
  const get = (k: string, legacy: string): Slider | undefined => size(inner[k] ?? inner[legacy], o);
  const top = get('block-start', 'top');
  const bottom = get('block-end', 'bottom');
  const inlineEnd = get('inline-end', 'right');
  const inlineStart = get('inline-start', 'left');
  const right = o.rtl ? inlineStart : inlineEnd;
  const left = o.rtl ? inlineEnd : inlineStart;
  return sidesToDimensions([top, right, bottom, left], emptySide);
}

/** Border width: `border-width-v2` / legacy `border-width` (logical sides) or a single size. */
export function borderWidth(v: unknown, o: DecodeOptions = {}): Dimensions | undefined {
  const t = typeOf(v);
  if (t === 'border-width-v2' || t === 'border-width') {
    const inner = unwrap(v);
    if (!isObj(inner)) return undefined;
    return dimensions({ $$type: 'dimensions', value: inner }, o, 0);
  }
  return dimensions(v, o, 0);
}

/**
 * Border radius: `border-radius-v2` / legacy `border-radius` with logical corners (`start-start` = top-left in
 * LTR, `start-end` = top-right, `end-start` = bottom-left, `end-end` = bottom-right) or a single size.
 * Zadex radius dimensions follow the CSS shorthand order: top = top-left, right = top-right,
 * bottom = bottom-right, left = bottom-left.
 */
export function borderRadius(v: unknown, o: DecodeOptions = {}): Dimensions | undefined {
  const t = typeOf(v);
  if (t === 'border-radius-v2' || t === 'border-radius') {
    const inner = unwrap(v);
    if (!isObj(inner)) return undefined;
    const c = (k: string): Slider | undefined => size(inner[k], o);
    const ss = c('start-start');
    const se = c('start-end');
    const es = c('end-start');
    const ee = c('end-end');
    const corners = o.rtl ? [se, ss, es, ee] : [ss, se, ee, es];
    return sidesToDimensions(corners, 0);
  }
  return dimensions(v, o, 0);
}

/** Gap: `layout-direction` `{row, column}` or a single size -> Zadex gap `{row, column, unit, linked}`. */
export function gap(v: unknown, o: DecodeOptions = {}): { row: number | string; column: number | string; unit: string; linked: boolean } | undefined {
  let row: Slider | undefined;
  let column: Slider | undefined;
  if (typeOf(v) === 'layout-direction') {
    const inner = unwrap(v);
    if (!isObj(inner)) return undefined;
    row = size(inner.row, o);
    column = size(inner.column, o);
  } else {
    row = column = size(v, o);
  }
  if (!row && !column) return undefined;
  const r = row ?? { size: 0, unit: column!.unit };
  const c = column ?? { size: 0, unit: r.unit };
  if (r.unit === c.unit && r.unit !== 'custom') return { row: r.size, column: c.size, unit: r.unit, linked: r.size === c.size };
  return { row: sliderCss(r), column: sliderCss(c), unit: 'custom', linked: false };
}

/** Zadex box shadow from a v4 `box-shadow` (array of `shadow`). Only the first shadow is kept (Zadex has one). */
export function boxShadow(v: unknown, o: DecodeOptions = {}): { value?: { x: number; y: number; blur: number; spread: number; color: string; inset: boolean }; extra: number } {
  const list = unwrap(v);
  const items = Array.isArray(list) ? list : typeOf(v) === 'shadow' ? [v] : [];
  const first = items[0];
  if (!first) return { extra: 0 };
  const s = unwrap(first);
  if (!isObj(s)) return { extra: items.length - 1 };
  const px = (x: unknown, d: number): number => {
    const sl = size(x, o);
    if (!sl || typeof sl.size !== 'number') return d;
    if (sl.unit === 'em' || sl.unit === 'rem') return sl.size * 16;
    return sl.size;
  };
  return {
    value: {
      x: px(s.hOffset, 0),
      y: px(s.vOffset, 0),
      blur: px(s.blur, 10),
      spread: px(s.spread, 0),
      color: color(s.color, o) ?? 'rgba(0, 0, 0, 1)',
      inset: str(s.position) === 'inset',
    },
    extra: items.length - 1,
  };
}

/**
 * Link `{destination: url | query{id,label}, isTargetBlank, tag}` -> Zadex url. A destination picked from the
 * site's content (query) is stored as a post id only: it becomes `/?p=<id>` (WordPress redirects it to the
 * permalink) and `approx` is set so the caller can note it.
 */
export function link(v: unknown): { value?: UrlValue; approx?: string } {
  const inner = unwrap(v);
  if (!isObj(inner)) return {};
  const dest = inner.destination;
  const target = bool(inner.isTargetBlank) ? '_blank' : '';
  const t = typeOf(dest);
  if (t === 'query') {
    const q = unwrap(dest);
    const id = isObj(q) ? num(q.id) : undefined;
    if (!id) return {};
    return { value: { url: `/?p=${id}`, target, nofollow: false }, approx: `The link pointed to post #${id}; it was kept as "/?p=${id}" (WordPress redirects it to the permalink).` };
  }
  const href = str(dest)?.trim();
  if (!href) return {};
  return { value: { url: href, target, nofollow: false } };
}

/** `image-src` `{id, url, alt}` / `svg-src` / `video-src` -> `{id, url, alt}` (plain). */
export function src(v: unknown): { id: number; url: string; alt: string } | undefined {
  const inner = unwrap(v);
  if (!isObj(inner)) return undefined;
  const id = num(inner.id) ?? 0;
  const url = str(inner.url)?.trim() ?? '';
  const alt = str(inner.alt) ?? '';
  if (!id && !url) return undefined;
  return { id, url, alt };
}

/** `image` `{src: image-src, size}` -> `{src, size}`. */
export function image(v: unknown): { src?: { id: number; url: string; alt: string }; size?: string } {
  const inner = unwrap(v);
  if (!isObj(inner)) return {};
  return { src: src(inner.src), size: str(inner.size) };
}

/** `classes` prop -> list of style ids. */
export function classes(v: unknown): string[] {
  const inner = unwrap(v);
  return Array.isArray(inner) ? inner.filter((x): x is string => typeof x === 'string' && x !== '') : [];
}

/** `attributes` (`[{$$type:'key-value', value:{key, value}}]`) -> Zadex `_attributes` text (`name|value` lines). */
export function attributes(v: unknown): string | undefined {
  const list = unwrap(v);
  if (!Array.isArray(list)) return undefined;
  const lines: string[] = [];
  for (const item of list) {
    const kv = unwrap(item);
    if (!isObj(kv)) continue;
    const key = str(kv.key)?.trim();
    if (!key) continue;
    lines.push(`${key}|${str(kv.value) ?? ''}`);
  }
  return lines.length ? lines.join('\n') : undefined;
}

export interface ZBackground {
  type: 'classic' | 'gradient';
  color?: string;
  image?: { id: number; url: string; alt: string };
  position?: string;
  size?: string;
  repeat?: string;
  attachment?: string;
  gradient?: { type: 'linear' | 'radial'; angle: number; stops: Array<{ color: string; position: number }> };
}

/**
 * v4 `background` `{color, background-overlay: [color | image | gradient layers], clip}` -> Zadex background.
 * Zadex has one layer: a gradient layer wins (its type drops the color), else the first image layer + color;
 * a color layer with no base color becomes the color. `notes` lists what could not be kept.
 */
export function background(v: unknown, o: DecodeOptions = {}): { value?: ZBackground; notes: string[] } {
  const notes: string[] = [];
  const inner = unwrap(v);
  if (!isObj(inner)) return { notes };
  let base = color(inner.color, o);
  const layersRaw = unwrap(inner['background-overlay']);
  const layers = Array.isArray(layersRaw) ? layersRaw : [];
  if (str(inner.clip)) notes.push('background-clip is not supported by Zadex.');
  const gradientLayer = layers.find((l) => typeOf(l) === 'background-gradient-overlay');
  const imageLayer = layers.find((l) => typeOf(l) === 'background-image-overlay');
  const colorLayer = layers.find((l) => typeOf(l) === 'background-color-overlay');
  if (layers.length > 1) notes.push('Only one background layer is kept (Zadex backgrounds have a single layer).');
  if (gradientLayer) {
    const g = unwrap(gradientLayer);
    if (isObj(g)) {
      const stopsRaw = unwrap(g.stops);
      const stops = (Array.isArray(stopsRaw) ? stopsRaw : [])
        .map((s) => unwrap(s))
        .filter(isObj)
        .map((s) => ({ color: color(s.color, o) ?? '', position: num(s.offset) ?? 0 }))
        .filter((s) => s.color !== '');
      if (stops.length >= 2) {
        if (base) notes.push('The background color under the gradient is not kept (Zadex gradients replace the color).');
        const type = str(g.type) === 'radial' ? 'radial' : 'linear';
        if (type === 'radial' && str(g.positions)) notes.push('Radial gradient position is not supported; it is centered.');
        return { value: { type: 'gradient', gradient: { type, angle: num(g.angle) ?? 180, stops } }, notes };
      }
    }
  }
  if (!base && colorLayer) {
    const c = unwrap(colorLayer);
    base = isObj(c) ? color(c.color, o) : undefined;
  } else if (colorLayer) {
    notes.push('A color overlay layer on top of the background color is not kept.');
  }
  const out: ZBackground = { type: 'classic' };
  if (base) out.color = base;
  if (imageLayer) {
    const il = unwrap(imageLayer);
    if (isObj(il)) {
      const img = image(il.image);
      if (img.src) out.image = img.src;
      const pos = il.position;
      if (typeOf(pos) === 'string') out.position = str(pos);
      else if (pos !== undefined && pos !== null) notes.push('Custom background position offsets are not supported.');
      const sz = il.size;
      if (typeOf(sz) === 'string') out.size = str(sz);
      else if (sz !== undefined && sz !== null) notes.push('Custom background size scale is not supported.');
      const rep = str(il.repeat);
      if (rep) out.repeat = rep;
      const att = str(il.attachment);
      if (att) out.attachment = att;
    }
  }
  if (!out.color && !out.image) return { notes };
  return { value: out, notes };
}
