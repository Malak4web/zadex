import { registerWidget } from '../registry';
import { atomicWriter } from './writer';
import * as P from './props';
import { applyStyles } from './styles';

/**
 * Elementor v4 `e-divider` -> Zadex `divider`. The atomic divider is a plain block (black background, 1px high,
 * 100% wide, start-aligned, no padding); the Zadex divider draws a line: background color -> line color,
 * height -> weight, width -> width. Zadex's 15px vertical gap is zeroed to match.
 */
registerWidget('e-divider', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'divider');
  w.common();
  w.set('style', 'solid');
  w.set('gap', { size: 0, unit: 'px' });
  w.set('align', 'flex-start');
  applyStyles(
    w,
    {
      width: 'width',
      height: 'weight',
      props: {
        background: (value, v, ap) => {
          const { value: bg } = P.background(value, ap.opts);
          if (!bg) return true;
          if (bg.type !== 'classic' || !bg.color) return 'Only a solid divider color is supported.';
          return ap.put('color', bg.color, v);
        },
      },
    },
    {
      background: { $$type: 'background', value: { color: { $$type: 'color', value: '#000' } } },
      height: { $$type: 'size', value: { size: 1, unit: 'px' } },
      width: { $$type: 'size', value: { size: 100, unit: '%' } },
    },
  );
  return w.finish();
});
