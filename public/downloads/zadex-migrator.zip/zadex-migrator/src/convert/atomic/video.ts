import { registerWidget } from '../registry';
import { atomicWriter, type AtomicWriter } from './writer';
import * as P from './props';
import { applyStyles, type StyleSpec } from './styles';

const RATIOS = ['16 / 9', '4 / 3', '1 / 1', '9 / 16', '21 / 9', '3 / 2'];

const SPEC: StyleSpec = {
  width: 'width',
  border: 'border',
  boxShadow: 'box_shadow',
  ignore: ['display', 'overflow'],
  props: {
    'aspect-ratio': (value, v, ap) => {
      const s = P.str(value)?.replace(/\s+/g, '');
      if (!s) return true;
      const m = s.match(/^(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/);
      const ratio = m ? `${m[1]} / ${m[2]}` : '';
      if (!RATIOS.includes(ratio)) return `Aspect ratio "${s}" has no Zadex option.`;
      return ap.put('aspect_ratio', ratio, v);
    },
  },
};

/** Booleans whose Zadex default differs from Elementor's are written explicitly. */
function flags(w: AtomicWriter, pairs: Array<[string, string, boolean]>): void {
  for (const [src, dst, def] of pairs) w.set(dst, w.flag(src, def));
}

/**
 * Elementor v4 `e-youtube` -> Zadex `video` (source youtube). Settings: source URL, start / end (strings),
 * autoplay, mute, loop, lazyload, player_controls, captions, privacy_mode, rel.
 */
registerWidget('e-youtube', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'video');
  w.common();
  w.set('source', 'youtube');
  w.set('youtube_url', w.text('source', 'https://www.youtube.com/watch?v=XHOmBV4js_E'));
  flags(w, [
    ['autoplay', 'autoplay', false],
    ['mute', 'mute', false],
    ['loop', 'loop', false],
    ['player_controls', 'controls', true],
    ['privacy_mode', 'privacy', false],
    ['lazyload', 'lazy', false],
  ]);
  const start = w.number('start');
  if (start !== undefined) w.set('start', start);
  const end = w.number('end');
  if (end !== undefined) w.set('end', end);
  if (w.flag('captions', false)) w.note('YouTube captions (cc_load_policy) are not supported by Zadex.');
  if (!w.flag('rel', true)) w.note('"Suggested videos from the same channel" (rel=0) is not supported by Zadex.');
  applyStyles(w, SPEC);
  return w.finish();
});

/**
 * Elementor v4 `e-self-hosted-video` -> Zadex `video` (source hosted). Settings: `source` (video-src {id,url}),
 * autoplay, mute, loop, controls, start_time / end_time, poster (when poster_enabled), preload, download,
 * playsinline.
 */
registerWidget('e-self-hosted-video', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'video');
  w.common();
  w.set('source', 'hosted');
  const src = P.src(w.prop('source'));
  const url = src?.url || (src?.id ? ctx.source.media?.[String(src.id)]?.url : '') || '';
  if (url) w.set('hosted_url', url);
  else {
    w.note('No video file was chosen.');
    w.status('partial');
  }
  flags(w, [
    ['autoplay', 'autoplay', false],
    ['mute', 'mute', false],
    ['loop', 'loop', false],
    ['controls', 'controls', true],
  ]);
  const start = w.number('start_time');
  if (start !== undefined) w.set('start', start);
  const end = w.number('end_time');
  if (end !== undefined) w.set('end', end);
  const posterOn = w.flag('poster_enabled', false);
  const poster = P.image(w.prop('poster'));
  if (posterOn && poster.src) {
    const media = ctx.media(poster.src);
    if (media) w.set('poster', media);
  }
  const preload = w.text('preload', 'metadata');
  if (preload !== 'metadata') w.note(`Video preload "${preload}" is not supported by Zadex.`);
  if (w.flag('download', false)) w.note('The download button option is not supported by Zadex.');
  w.consume('playsinline');
  applyStyles(w, { ...SPEC, ignore: ['display', 'overflow', 'max-width'] });
  return w.finish();
});
