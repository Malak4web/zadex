import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { atomicWriter } from './writer';
import * as P from './props';
import { applyStyles } from './styles';

/**
 * Elementor v4 `e-heading` -> Zadex `heading`. Settings: `title` (escaped-html), `tag` (h1-h6 | span), `link`.
 * Styles: color (+hover), typography, text-align; spacing / size / position go to the common Advanced controls.
 * Zadex headings have no background, border or shadow controls: those props are reported.
 */
registerWidget('e-heading', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'heading');
  w.common();
  w.set('text', w.text('title', 'This is a title'));
  w.set('tag', w.text('tag', 'h2'));
  const { value, approx } = P.link(w.prop('link'));
  if (value) w.set('link', value);
  if (approx) w.note(approx);
  applyStyles(w, { color: 'color', typography: 'typography', textAlign: { id: 'align', table: textAlign(ctx) } });
  return w.finish();
});
