/**
 * Writer for Elementor v4 atomic elements. Atomic settings are typed props (`{$$type, value}`) and the design
 * lives in style definitions, so this extends ElementWriter with:
 *  - typed reads (`prop`, `text`, `flag`, `number`) that mark settings as handled,
 *  - `drop()` for style props that could not be carried over (reported as `style:<prop>[::state][@bp]`),
 *  - `common()`: the atomic "Settings" extras every element has (`_cssid`, `attributes`, notices, display
 *    conditions),
 *  - empty typed props (`{value: []}`, `{value: null}`) are never reported as dropped.
 */
import { ElementWriter, type ConvertContext } from '../context';
import type { ElElement } from '../types';
import * as P from './props';

export class AtomicWriter extends ElementWriter {
  private extraDropped: string[] = [];
  readonly decodeOptions: P.DecodeOptions;

  constructor(el: ElElement, ctx: ConvertContext, type: string, id?: string) {
    super(el, ctx, type, el.widgetType ?? el.elType, id);
    this.decodeOptions = { rtl: Boolean(ctx.source.rtl), variable: variableResolver(ctx) };
  }

  /** Raw typed setting (marks it handled). */
  prop(key: string): unknown {
    return this.raw(key);
  }

  /** Text setting with Elementor's schema default when absent. */
  text(key: string, fallback = ''): string {
    const v = this.raw(key);
    if (v === undefined) return fallback;
    return P.str(v) ?? fallback;
  }

  flag(key: string, fallback: boolean): boolean {
    const v = this.raw(key);
    return v === undefined ? fallback : (P.bool(v) ?? fallback);
  }

  number(key: string): number | undefined {
    return P.num(this.raw(key));
  }

  drop(key: string): void {
    if (!this.extraDropped.includes(key)) this.extraDropped.push(key);
  }

  /** `_cssid` -> `_css_id`, `attributes` -> `_attributes`, editor notices ignored, display conditions reported. */
  common(): void {
    this.consume('classes', '_ally_notice', '_io_notice', '_google_api_key_notice');
    const cssId = P.str(this.raw('_cssid'))?.trim();
    if (cssId) this.set('_css_id', cssId);
    const attrs = P.attributes(this.raw('attributes'));
    if (attrs) this.set('_attributes', attrs);
    const conditions = this.el.settings?.['display-conditions'];
    if (conditions !== undefined && !P.isEmptyProp(conditions)) this.note('Display conditions (Elementor Pro) are not carried over.');
  }

  override dropped(): string[] {
    const settings = this.el.settings ?? {};
    const base = super.dropped().filter((k) => !(k in settings) || !P.isEmptyProp(settings[k]));
    return [...base, ...this.extraDropped];
  }
}

/** Resolver for v4 global variables from `source.globalVariables` (whole kit meta record or its `data` map). */
function variableResolver(ctx: ConvertContext): P.VariableResolver | undefined {
  const gv = ctx.source.globalVariables;
  if (!P.isObj(gv)) return undefined;
  const map = P.isObj(gv.data) ? gv.data : gv;
  return (id: string) => {
    const item = map[id];
    if (!P.isObj(item) || item.deleted) return undefined;
    return item.value;
  };
}

export function atomicWriter(el: ElElement, ctx: ConvertContext, type: string, id?: string): AtomicWriter {
  return new AtomicWriter(el, ctx, type, id);
}
