/**
 * Elementor v4 atomic layout elements -> Zadex containers.
 *  - `e-flexbox`  -> `container` (flex, row by default, padding 10px, no gap)
 *  - `e-div-block` -> `container` (block layout approximated by a column container, padding 10px)
 *  - `e-grid`     -> `grid` (3 columns / 1 on mobile, gap 20px, padding 10px)
 * Elementor's base styles (the element's built-in defaults) are written explicitly because Zadex containers have
 * different defaults (column direction, site gap, boxed width). Nested atomic containers are `width: auto` in
 * Elementor (content-sized inside a row), so they get `_width: auto` and zero inline margins in Zadex.
 */
import { registerElement } from '../registry';
import type { ConvertContext } from '../context';
import type { ElElement, ZElement } from '../types';
import { atomicWriter, type AtomicWriter } from './writer';
import * as P from './props';
import { StyleApplier, collectVariants, hasProp, type PropHandler, type StyleVariant } from './styles';

const CONTAINER_TAGS = new Set(['div', 'section', 'header', 'footer', 'main', 'article', 'aside', 'nav']);
const GRID_TAGS = new Set(['div', 'section', 'ul', 'article', 'aside']);
const ATOMIC_CONTAINERS = new Set(['e-flexbox', 'e-div-block', 'e-grid']);

/** Element types of the atomic containers being converted (innermost last); used for the nested-width rule. */
const parents: string[] = [];

export function insideAtomicContainer(): string | undefined {
  return parents[parents.length - 1];
}

/** Converts children with `type` pushed as the current atomic parent. */
export function convertChildren(ctx: ConvertContext, el: ElElement): ZElement[] {
  parents.push(el.elType);
  try {
    return ctx.convert(el.elements);
  } finally {
    parents.pop();
  }
}

const JUSTIFY: Record<string, string> = {
  start: 'flex-start',
  'flex-start': 'flex-start',
  center: 'center',
  end: 'flex-end',
  'flex-end': 'flex-end',
  'space-between': 'space-between',
  'space-around': 'space-around',
  'space-evenly': 'space-evenly',
};
const ALIGN: Record<string, string> = { start: 'flex-start', 'flex-start': 'flex-start', center: 'center', end: 'flex-end', 'flex-end': 'flex-end', stretch: 'stretch' };
const GRID_ALIGN: Record<string, string> = { start: 'start', 'flex-start': 'start', center: 'center', end: 'end', 'flex-end': 'end', stretch: 'stretch' };

/** Handler writing a string prop through a value table. */
export function tableHandler(id: string, table: Record<string, string>): PropHandler {
  return (value, v, ap) => {
    const s = P.str(value);
    if (!s) return true;
    if (!(s in table)) return `Value "${s}" of ${id} has no Zadex equivalent.`;
    return ap.put(id, table[s], v);
  };
}

/** Link + tag shared by the three containers. `a` / `button` tags become a div (the link is kept). */
function tagAndLink(w: AtomicWriter, allowed: Set<string>): void {
  const tag = w.text('tag', 'div');
  if (allowed.has(tag)) {
    if (tag !== 'div') w.set('tag', tag);
  } else if (tag !== 'a') {
    w.note(`HTML tag "${tag}" is not available on the Zadex element; a div is used.`);
  }
  const { value, approx } = P.link(w.prop('link'));
  if (value) {
    if (w.ctx.manifests[w.type]?.controls.some((c) => c.id === 'link')) w.set('link', value);
    else {
      w.drop('link');
      w.note('Zadex grids cannot be links; the link was dropped.');
    }
  }
  if (approx) w.note(approx);
}

/** `_width: auto` + zero inline margins for atomic containers nested in an atomic container (see file doc). */
function nestedWidth(w: AtomicWriter, variants: StyleVariant[]): void {
  if (!insideAtomicContainer()) return;
  const desktop = (v: StyleVariant): boolean => !v.bp && !v.state;
  if (!hasProp(variants, 'width', desktop)) w.set('_width', { size: 'auto', unit: 'custom' });
  if (!hasProp(variants, 'margin', desktop)) w.set('_margin', { top: 0, right: 0, bottom: 0, left: 0, unit: 'px', linked: true });
}

const size10 = { $$type: 'size', value: { size: 10, unit: 'px' } };
const FLEX_BASE = { display: { $$type: 'string', value: 'flex' }, 'flex-direction': { $$type: 'string', value: 'row' }, padding: size10 };
const BLOCK_BASE = { display: { $$type: 'string', value: 'block' }, padding: size10 };

function containerMapper(kind: 'flex' | 'block') {
  return (el: ElElement, ctx: ConvertContext): ZElement => {
    const w = atomicWriter(el, ctx, 'container');
    w.common();
    tagAndLink(w, CONTAINER_TAGS);
    w.set('width_preset', 'full');
    // Elementor base style: flex row (e-flexbox) / block (e-div-block), padding 10px; no gap.
    const variants = collectVariants(w, kind === 'flex' ? FLEX_BASE : BLOCK_BASE);
    w.set('gap', { row: 0, column: 0, unit: 'px', linked: true });
    nestedWidth(w, variants);
    const ap = new StyleApplier(w, {
      background: { id: 'background', mode: 'full' },
      border: 'border',
      boxShadow: 'box_shadow',
      minHeight: 'min_height',
      props: {
        display: (value, v, a) => {
          const s = P.str(value);
          if (s === 'none') return a.put('_hide', true, v);
          if (s === 'flex' || s === 'inline-flex') return 'flex-direction' in v.props ? true : a.put('direction', 'row', v);
          if (s === 'block') {
            if (!v.bp && !v.state) a.w.note('Block layout (e-div-block) is approximated by a column container.');
            return 'flex-direction' in v.props ? true : a.put('direction', 'column', v);
          }
          return `display "${s ?? ''}" has no Zadex container equivalent.`;
        },
        'flex-direction': tableHandler('direction', { row: 'row', column: 'column', 'row-reverse': 'row-reverse', 'column-reverse': 'column-reverse' }),
        'justify-content': tableHandler('justify', JUSTIFY),
        'align-items': tableHandler('align', ALIGN),
        'flex-wrap': tableHandler('wrap', { nowrap: 'nowrap', wrap: 'wrap' }),
        gap: (value, v, a) => {
          const g = P.gap(value, a.opts);
          return g ? a.put('gap', g, v) : true;
        },
        color: () => 'Zadex containers have no text color; set the color on the child widgets.',
      },
    });
    ap.apply(variants);
    const children = convertChildren(ctx, el);
    return w.finish(children);
  };
}

registerElement('e-flexbox', containerMapper('flex'));
registerElement('e-div-block', containerMapper('block'));

registerElement('e-grid', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'grid');
  w.common();
  tagAndLink(w, GRID_TAGS);
  // Elementor base style: 3 columns (1 on mobile), 2 rows of 1fr (not kept: Zadex rows are auto), gap 20px, padding 10px.
  const variants = collectVariants(w, { padding: size10 });
  w.set('columns', 3);
  w.set('columns', 1, { bp: 'mobile' });
  w.set('gap', { row: 20, column: 20, unit: 'px', linked: true });
  nestedWidth(w, variants);
  const track =
    (countId: string, customId: string | undefined): PropHandler =>
    (value, v, a) => {
      const t = P.typeOf(value);
      if (t === 'grid-track-size' || t === 'size') {
        const s = P.size(value, a.opts);
        if (!s) return true;
        if (s.unit === 'fr' && typeof s.size === 'number') return a.put(countId, Math.max(1, Math.round(s.size)), v);
        if (!customId) return `${countId}: only a number of tracks is supported.`;
        return a.put(customId, P.sliderCss(s), v);
      }
      const s = P.str(value)?.trim();
      if (!s) return true;
      if (!customId) return `Custom row template "${s}" has no Zadex equivalent.`;
      return a.put(customId, s, v);
    };
  const ap = new StyleApplier(w, {
    background: { id: 'background', mode: 'full' },
    border: 'border',
    boxShadow: 'box_shadow',
    minHeight: 'min_height',
    props: {
      display: (value, v, a) => {
        const s = P.str(value);
        if (s === 'none') return a.put('_hide', true, v);
        if (s === 'grid' || s === 'inline-grid') return true;
        return `display "${s ?? ''}" has no Zadex grid equivalent.`;
      },
      'grid-template-columns': track('columns', 'custom_columns'),
      'grid-template-rows': track('rows', undefined),
      'grid-auto-flow': tableHandler('auto_flow', { row: 'row', column: 'column', 'row dense': 'row dense', 'column dense': 'column dense', dense: 'row dense' }),
      'grid-auto-rows': (value, v, a) => {
        const s = P.size(value, a.opts);
        return s ? a.put('row_min_height', s, v) : true;
      },
      'align-items': tableHandler('align_items', GRID_ALIGN),
      'justify-items': tableHandler('justify_items', GRID_ALIGN),
      gap: (value, v, a) => {
        const g = P.gap(value, a.opts);
        return g ? a.put('gap', g, v) : true;
      },
      color: () => 'Zadex grids have no text color; set the color on the child widgets.',
    },
  });
  ap.apply(variants);
  const children = convertChildren(ctx, el);
  return w.finish(children);
});

export { ATOMIC_CONTAINERS };
