import { registerWidget } from '../registry';
import { atomicWriter } from './writer';
import * as P from './props';
import { applyStyles } from './styles';

/** Elementor image sizes -> Zadex image size options (thumbnail | medium | large | full). */
const SIZES: Record<string, string> = { thumbnail: 'thumbnail', medium: 'medium', medium_large: 'large', large: 'large', full: 'full' };

/**
 * Elementor v4 `e-image` -> Zadex `image`. Settings: `image` `{src:{id,url,alt}, size}`, `link`.
 * Styles: width / max-width / height, object-fit, opacity (+hover), border (+radius), box shadow.
 */
registerWidget('e-image', (el, ctx) => {
  const w = atomicWriter(el, ctx, 'image');
  w.common();
  const img = P.image(w.prop('image'));
  if (img.src) {
    const media = ctx.media(img.src);
    if (media) w.set('image', media);
    if (!img.src.id && img.src.alt) w.set('alt', img.src.alt);
  } else {
    w.note('The image was Elementor\'s placeholder (no image chosen); the Zadex image is empty.');
    w.status('partial');
  }
  const size = img.size ?? 'full';
  const mapped = SIZES[size];
  w.set('size', mapped ?? 'full');
  if (!mapped) w.note(`Image size "${size}" has no Zadex equivalent; the full size is used.`);
  else if (size === 'medium_large') w.note('Image size "medium_large" became "large".');
  const { value, approx } = P.link(w.prop('link'));
  if (value) {
    w.set('link_to', 'custom');
    w.set('link', value);
  }
  if (approx) w.note(approx);
  applyStyles(w, {
    width: 'width',
    height: 'height',
    maxWidth: 'max_width',
    border: 'border',
    boxShadow: 'box_shadow',
    ignore: ['display'],
    props: {
      'object-fit': (value, v, ap) => {
        const s = P.str(value);
        if (!s) return true;
        if (s === 'scale-down') return 'object-fit "scale-down" has no Zadex equivalent.';
        return ap.put('object_fit', s, v);
      },
      opacity: (value, v, ap) => {
        const s = P.size(value, ap.opts);
        if (!s || typeof s.size !== 'number') return true;
        const n = s.unit === '%' ? s.size / 100 : s.size;
        return ap.put('opacity', { size: Math.round(n * 1000) / 1000, unit: 'custom' }, v);
      },
    },
  });
  return w.finish();
});
