/**
 * Elementor v4 styles -> Zadex settings.
 *
 * Atomic elements carry their design in style definitions, not in settings:
 *  - local styles: `element.styles[<id>] = {id, label:'local', type:'class', variants:[{meta:{breakpoint, state}, props, custom_css}]}`
 *  - global classes: ids in the same `settings.classes` list (`g-xxxxxxx`), definitions in the kit's global classes
 *    (sent by the server as `SourceDocument.globalClasses`, same `{id,label,type,variants}` shape).
 * Every applied class is merged per (breakpoint, state) — global classes first (in `classes` order), the local
 * style last, so local values win like they do in Elementor. Global classes are INLINED into each element
 * (phase 1): Zadex global classes use a different, smaller control set (`u_*`).
 *
 * `applyStyles(w, spec)` then maps each CSS-like prop onto the target widget's Zadex controls. Every write is
 * checked against the Zadex manifest (control exists, responsive for breakpoints, state allowed); whatever cannot
 * be written is reported as dropped `style:<prop>[::state][@breakpoint]`.
 */
import type { BreakpointKey, ControlDef } from '../types';
import type { ElementState } from '../context';
import type { AtomicWriter } from './writer';
import * as P from './props';
import { isObj } from './props';
import type { Slider } from '../values';

type Obj = Record<string, unknown>;

/** Elementor v4 breakpoint ids (variant meta) -> Zadex breakpoint keys. `desktop` / null = base. */
const BREAKPOINTS: Record<string, BreakpointKey | undefined> = {
  desktop: undefined,
  widescreen: 'widescreen',
  laptop: 'laptop',
  tablet_extra: 'tablet_large',
  tablet: 'tablet',
  mobile_extra: 'mobile_large',
  mobile: 'mobile',
};
const STATES = new Set(['hover', 'focus', 'active']);

export interface StyleVariant {
  bp?: BreakpointKey;
  state?: ElementState;
  props: Obj;
}

/** Variant label used in dropped keys: `::hover@tablet`. */
export function variantSuffix(v: { bp?: BreakpointKey; state?: ElementState }): string {
  return `${v.state ? `::${v.state}` : ''}${v.bp ? `@${v.bp}` : ''}`;
}

/** Style definition (local or global) -> its variants, as stored. */
function definitionVariants(def: unknown): Obj[] {
  if (!isObj(def) || !Array.isArray(def.variants)) return [];
  return def.variants.filter(isObj);
}

/**
 * Merged variants of every class applied to the element (global classes inlined first, local styles last).
 * Unsupported breakpoints / states / custom CSS are reported through `drop` / `note`.
 */
export function collectVariants(w: AtomicWriter, base: Obj = {}): StyleVariant[] {
  const el = w.el;
  const ids = P.classes(el.settings?.classes);
  const local = isObj(el.styles) ? (el.styles as Obj) : {};
  const globals = w.ctx.source.globalClasses ?? {};
  const globalIds: string[] = [];
  const localIds: string[] = [];
  for (const id of ids) {
    if (Object.prototype.hasOwnProperty.call(local, id)) localIds.push(id);
    else globalIds.push(id);
  }
  // Local styles that exist but are not listed in `classes` are not rendered by Elementor either: ignore them.
  // Layers, lowest priority first: the element's base style (Elementor defaults Zadex does not share), global
  // classes (in `classes` order), local styles. A prop set by a higher layer at breakpoint B also beats lower
  // layers' values at narrower breakpoints (its rule is not inside their media query and comes later in the
  // cascade), so those lower values are removed.
  const merged = new Map<string, StyleVariant & { layer: Record<string, number> }>();
  let layer = 0;
  const put = (bp: BreakpointKey | undefined, state: ElementState | undefined, props: Obj): void => {
    for (const [prop, value] of Object.entries(props)) {
      for (const slot of merged.values()) {
        if (slot.state !== state || !(prop in slot.props) || slot.layer[prop] >= layer) continue;
        if (covers(bp, slot.bp)) {
          delete slot.props[prop];
          delete slot.layer[prop];
        }
      }
      const key = `${bp ?? ''}|${state ?? ''}`;
      const slot = merged.get(key) ?? { bp, state, props: {}, layer: {} };
      slot.props[prop] = value;
      slot.layer[prop] = layer;
      merged.set(key, slot);
    }
  };
  if (Object.keys(base).length) put(undefined, undefined, base);
  const add = (def: unknown, origin: string): void => {
    layer++;
    for (const variant of definitionVariants(def)) {
      const meta = isObj(variant.meta) ? variant.meta : {};
      const bpRaw = meta.breakpoint === null || meta.breakpoint === undefined ? 'desktop' : String(meta.breakpoint);
      const stateRaw = meta.state === null || meta.state === undefined ? '' : String(meta.state);
      const props = isObj(variant.props) ? variant.props : {};
      const hasProps = Object.keys(props).length > 0;
      const customCss = isObj(variant.custom_css) && typeof variant.custom_css.raw === 'string' && variant.custom_css.raw !== '';
      if (customCss) {
        w.drop(`style:custom_css${stateRaw ? `::${stateRaw}` : ''}${bpRaw !== 'desktop' ? `@${bpRaw}` : ''}`);
        w.note(`Custom CSS in ${origin} is not carried over (Zadex does not store custom CSS).`);
      }
      if (!hasProps) continue;
      if (!(bpRaw in BREAKPOINTS)) {
        for (const k of Object.keys(props)) w.drop(`style:${k}@${bpRaw}`);
        w.note(`Breakpoint "${bpRaw}" has no Zadex equivalent.`);
        continue;
      }
      if (stateRaw && !STATES.has(stateRaw)) {
        for (const k of Object.keys(props)) w.drop(`style:${k}::${stateRaw}`);
        w.note(`State "${stateRaw}" has no Zadex equivalent (Zadex supports hover, focus and active).`);
        continue;
      }
      put(BREAKPOINTS[bpRaw], (stateRaw || undefined) as ElementState | undefined, props);
    }
  };
  for (const id of globalIds) {
    const def = globals[id];
    if (def === undefined) {
      w.drop(`classes:${id}`);
      w.note(`Global class "${id}" was not found in the source data; its styles are missing.`);
      continue;
    }
    add(def, `global class "${isObj(def) && typeof def.label === 'string' ? def.label : id}"`);
  }
  if (globalIds.some((id) => globals[id] !== undefined)) w.note('Global classes were inlined into the element (phase 1: not converted to Zadex global classes).');
  for (const id of localIds) add(local[id], 'the element style');
  return [...merged.values()].filter((v) => Object.keys(v.props).length).map(({ bp, state, props }) => ({ bp, state, props }));
}

/** Width rank of a breakpoint (desktop = base). Widescreen is a min-width breakpoint above the base. */
const RANK: Record<string, number> = { mobile: 0, mobile_large: 1, tablet: 2, tablet_large: 3, laptop: 4, widescreen: 6 };

/** True when a rule at breakpoint `a` also applies at breakpoint `b` (desktop-first, widescreen min-width). */
function covers(a: BreakpointKey | undefined, b: BreakpointKey | undefined): boolean {
  if (a === b || a === undefined) return true;
  if (a === 'widescreen' || b === 'widescreen' || b === undefined) return false;
  return RANK[b] < RANK[a];
}

/* ------------------------------------------------------------------------------------------------------------ */

/** Handler for one CSS prop: return `false` / a string reason when it could not be written (reported dropped). */
export type PropHandler = (value: unknown, v: StyleVariant, ap: StyleApplier) => boolean | string | void;

export interface StyleSpec {
  /** Text color control. */
  color?: string;
  /** Typography control (font-family, font-size, font-weight, line-height, letter/word spacing, style, transform, decoration). */
  typography?: string;
  /** Text alignment control + value table (logical start/end). */
  textAlign?: { id: string; table: Record<string, string> };
  /** Background control; `color` = a color-only control (button bg). */
  background?: { id: string; mode: 'full' | 'color' };
  /** Border object control (style / width / color / radius). */
  border?: string;
  /** Radius-only dimensions control, used when the widget has no border object (or for radius only). */
  radius?: string;
  boxShadow?: string;
  /** Padding control (default the common `_padding`). */
  padding?: string;
  /** Size controls (default the common `_width`, `_height`, `_min_height`, `_max_width`). */
  width?: string;
  height?: string;
  minHeight?: string;
  maxWidth?: string;
  /** Per-prop handlers (layout props, widget specifics). They run before the generic table. */
  props?: Record<string, PropHandler>;
  /** Props consumed silently (e.g. values equal to the element's own base style). */
  ignore?: string[];
}

const TYPO_PROPS = ['font-family', 'font-size', 'font-weight', 'line-height', 'letter-spacing', 'word-spacing', 'font-style', 'text-transform', 'text-decoration'];
const BORDER_PROPS = ['border-width', 'border-color', 'border-style', 'border-radius'];

/** Applies merged variants to a writer according to a spec. */
export class StyleApplier {
  private controls: Record<string, ControlDef> = {};

  constructor(
    readonly w: AtomicWriter,
    readonly spec: StyleSpec,
  ) {
    const manifest = w.ctx.manifests[w.type];
    for (const c of w.ctx.env.commonControls ?? []) this.controls[c.id] = c;
    for (const c of manifest?.controls ?? []) this.controls[c.id] = c;
  }

  get opts(): P.DecodeOptions {
    return this.w.decodeOptions;
  }

  /**
   * Writes a Zadex value after checking the control exists, is responsive (for breakpoints) and accepts the
   * state. Returns a reason string when the write is not possible.
   */
  put(id: string, value: unknown, v: { bp?: BreakpointKey; state?: ElementState }): true | string {
    const c = this.controls[id];
    if (!c) return `Zadex "${this.w.type}" has no "${id}" control.`;
    if (v.bp && !c.responsive) return `Zadex "${this.w.type}" control "${id}" is not responsive.`;
    if (v.state && !(c.states ?? []).includes(v.state)) return `Zadex "${this.w.type}" control "${id}" has no ${v.state} state.`;
    if (Array.isArray(c.options) && c.options.length && (c.type === 'select' || c.type === 'choose') && !(c as { optionsFrom?: unknown }).optionsFrom) {
      const allowed = c.options.map((o) => (isObj(o) ? String(o.value) : String(o)));
      if (!allowed.includes(String(value))) return `Value "${String(value)}" is not a valid option of "${id}".`;
    }
    this.w.set(id, value, v);
    return true;
  }

  hasControl(id: string): boolean {
    return Boolean(this.controls[id]);
  }

  /** Records a prop that could not be carried over. */
  dropProp(prop: string, v: StyleVariant, reason?: string): void {
    this.w.drop(`style:${prop}${variantSuffix(v)}`);
    if (reason) this.w.note(reason);
  }

  apply(variants: StyleVariant[]): void {
    for (const v of variants) this.applyVariant(v);
  }

  private result(prop: string, v: StyleVariant, r: boolean | string | void): void {
    if (r === false) this.dropProp(prop, v);
    else if (typeof r === 'string') this.dropProp(prop, v, r);
  }

  private applyVariant(v: StyleVariant): void {
    const props = { ...v.props };
    const spec = this.spec;
    for (const k of spec.ignore ?? []) delete props[k];
    // Widget specific handlers first.
    for (const [k, handler] of Object.entries(spec.props ?? {})) {
      if (!(k in props)) continue;
      this.result(k, v, handler(props[k], v, this));
      delete props[k];
    }
    // Typography group.
    const typo = TYPO_PROPS.filter((k) => k in props);
    if (typo.length) {
      this.typography(typo.map((k) => [k, props[k]] as [string, unknown]), v);
      for (const k of typo) delete props[k];
    }
    // Border group.
    const border = BORDER_PROPS.filter((k) => k in props);
    if (border.length) {
      this.border(Object.fromEntries(border.map((k) => [k, props[k]])), v);
      for (const k of border) delete props[k];
    }
    for (const [k, value] of Object.entries(props)) this.result(k, v, this.generic(k, value, v));
  }

  private typography(entries: Array<[string, unknown]>, v: StyleVariant): void {
    const id = this.spec.typography;
    const t: Obj = {};
    const o = this.opts;
    for (const [k, value] of entries) {
      switch (k) {
        case 'font-family': {
          const f = P.fontFamily(value, o);
          if (f) t.family = f;
          break;
        }
        case 'font-size': {
          const s = P.size(value, o);
          if (s) t.size = s;
          break;
        }
        case 'font-weight': {
          const s = P.str(value);
          if (s) t.weight = s;
          break;
        }
        case 'line-height': {
          const s = P.size(value, o);
          if (s) t.lineHeight = s.unit === 'em' && typeof s.size === 'number' ? { size: s.size, unit: 'custom' } : s;
          break;
        }
        case 'letter-spacing': {
          const s = P.size(value, o);
          if (s) t.letterSpacing = s;
          break;
        }
        case 'word-spacing': {
          const s = P.size(value, o);
          if (s) t.wordSpacing = s;
          break;
        }
        case 'font-style':
        case 'text-transform':
        case 'text-decoration': {
          const s = P.str(value);
          if (s) t[k === 'font-style' ? 'style' : k === 'text-transform' ? 'transform' : 'decoration'] = s;
          break;
        }
      }
      if (P.isVariable(value) && !this.w.ctx.source.globalVariables) this.w.note('Global variables were not sent with the source; values bound to them are missing.');
    }
    const reason = !id ? `Zadex "${this.w.type}" has no typography control.` : Object.keys(t).length ? this.put(id, t, v) : true;
    if (reason !== true) for (const [k] of entries) this.dropProp(k, v, reason);
  }

  private border(b: Obj, v: StyleVariant): void {
    const o = this.opts;
    const out: Obj = {};
    const style = P.str(b['border-style']);
    const width = 'border-width' in b ? P.borderWidth(b['border-width'], o) : undefined;
    const colorV = 'border-color' in b ? P.color(b['border-color'], o) : undefined;
    const radius = 'border-radius' in b ? P.borderRadius(b['border-radius'], o) : undefined;
    if (style) out.style = style;
    if (width) out.width = width;
    if (colorV) out.color = colorV;
    const borderId = this.spec.border;
    // Radius goes into the dedicated radius control when the spec names one, else into the border object.
    if (radius && this.spec.radius) {
      const r = this.put(this.spec.radius, radius, v);
      if (r !== true) this.dropProp('border-radius', v, r);
    } else if (radius && borderId) out.radius = radius; else if ('border-radius' in b) this.dropProp('border-radius', v, `Zadex "${this.w.type}" has no border radius control.`);
    const lineKeys = ['border-width', 'border-color', 'border-style'].filter((k) => k in b);
    const keys = borderId && !this.spec.radius && 'border-radius' in b ? [...lineKeys, 'border-radius'] : lineKeys;
    if (!keys.length) return;
    if (!borderId) {
      for (const k of lineKeys) this.dropProp(k, v, `Zadex "${this.w.type}" has no border control.`);
      return;
    }
    if (!Object.keys(out).length) return;
    const r = this.put(borderId, out, v);
    if (r !== true) for (const k of keys) this.dropProp(k, v, r);
  }

  /** Generic CSS prop -> Zadex control table (common Advanced controls + spec targets). */
  private generic(prop: string, value: unknown, v: StyleVariant): boolean | string {
    const o = this.opts;
    const spec = this.spec;
    const sizeTo = (id: string | undefined): boolean | string => {
      if (!id) return `Zadex "${this.w.type}" has no control for ${prop}.`;
      const s = P.size(value, o);
      return s ? this.put(id, s, v) : true;
    };
    switch (prop) {
      case 'color': {
        if (!spec.color) return `Zadex "${this.w.type}" has no text color control.`;
        const c = P.color(value, o);
        if (!c) return P.isVariable(value) ? 'A global color variable could not be resolved.' : true;
        return this.put(spec.color, c, v);
      }
      case 'text-align': {
        if (!spec.textAlign) return `Zadex "${this.w.type}" has no text alignment control.`;
        const s = P.str(value);
        if (!s) return true;
        const mapped = spec.textAlign.table[s];
        if (mapped === undefined) return `Text alignment "${s}" has no Zadex equivalent.`;
        return this.put(spec.textAlign.id, mapped, v);
      }
      case 'background': {
        const { value: bg, notes } = P.background(value, o);
        for (const n of notes) this.w.note(n);
        if (!spec.background) return `Zadex "${this.w.type}" has no background control.`;
        if (!bg) return true;
        if (spec.background.mode === 'color') {
          if (bg.type !== 'classic' || !bg.color) return `Zadex "${this.w.type}" only has a background color (gradients / images are not supported).`;
          if (bg.image) this.w.note('The background image is not supported on this widget; only the color was kept.');
          return this.put(spec.background.id, bg.color, v);
        }
        if (bg.image) bg.image = this.w.ctx.media(bg.image) ?? bg.image;
        if (notes.length) this.w.status('partial');
        return this.put(spec.background.id, bg, v);
      }
      case 'box-shadow': {
        if (!spec.boxShadow) return `Zadex "${this.w.type}" has no box shadow control.`;
        const { value: sh, extra } = P.boxShadow(value, o);
        if (extra > 0) {
          this.w.note('Only the first box shadow is kept (Zadex has one shadow).');
          this.w.status('partial');
        }
        return sh ? this.put(spec.boxShadow, sh, v) : true;
      }
      case 'padding': {
        const d = P.dimensions(value, o, 0);
        return d ? this.put(spec.padding ?? '_padding', d, v) : true;
      }
      case 'margin': {
        const d = P.dimensions(value, o, '');
        return d ? this.put('_margin', d, v) : true;
      }
      case 'width':
        return sizeTo(spec.width ?? '_width');
      case 'height':
        return sizeTo(spec.height ?? '_height');
      case 'min-height':
        return sizeTo(spec.minHeight ?? '_min_height');
      case 'max-width':
        return sizeTo(spec.maxWidth ?? '_max_width');
      case 'opacity': {
        const s = P.size(value, o);
        if (!s || typeof s.size !== 'number') return true;
        const n = s.unit === '%' ? s.size / 100 : s.size;
        return this.put('_opacity', { size: Math.round(n * 1000) / 1000, unit: 'custom' }, v);
      }
      case 'z-index': {
        const n = P.num(value);
        return n === undefined ? true : this.put('_z_index', n, v);
      }
      case 'order': {
        const n = P.num(value);
        return n === undefined ? true : this.put('_order', n, v);
      }
      case 'position': {
        const s = P.str(value);
        if (!s) return true;
        return this.put('_position', s === 'static' ? '' : s, v);
      }
      case 'inset-block-start':
        return sizeTo('_top');
      case 'inset-block-end':
        return sizeTo('_bottom');
      case 'inset-inline-start':
        return sizeTo(o.rtl ? '_right' : '_left');
      case 'inset-inline-end':
        return sizeTo(o.rtl ? '_left' : '_right');
      case 'overflow': {
        const s = P.str(value);
        return s ? this.put('_overflow', s, v) : true;
      }
      case 'align-self': {
        const s = P.str(value);
        if (!s) return true;
        const table: Record<string, string> = { start: 'flex-start', 'flex-start': 'flex-start', center: 'center', end: 'flex-end', 'flex-end': 'flex-end', stretch: 'stretch' };
        if (!table[s]) return `align-self "${s}" has no Zadex equivalent.`;
        return this.put('_align_self', table[s], v);
      }
      case 'flex': {
        const f = P.unwrap(value);
        if (!isObj(f)) return true;
        const grow = P.num(f.flexGrow);
        const shrink = P.num(f.flexShrink);
        let ok: boolean | string = true;
        if (grow !== undefined) ok = this.put('_flex_grow', grow, v);
        if (shrink !== undefined && ok === true) ok = this.put('_flex_shrink', shrink, v);
        if (ok === true && f.flexBasis !== undefined && f.flexBasis !== null) {
          const basis = P.size(f.flexBasis, o);
          if (basis) this.dropProp('flex-basis', v, 'flex-basis has no Zadex control.');
        }
        return ok;
      }
      case 'grid-column':
      case 'grid-row': {
        const s = P.str(value)?.trim();
        if (!s) return true;
        const m = s.match(/^span\s+(\d+)$/);
        if (!m) return `${prop} "${s}" has no Zadex equivalent (only "span N" is supported).`;
        return this.put(prop === 'grid-column' ? '_col_span' : '_row_span', Number(m[1]), v);
      }
      case 'display': {
        const s = P.str(value);
        if (s === 'none') return this.put('_hide', true, v);
        return `display "${s ?? ''}" is not carried over.`;
      }
      default:
        return `"${prop}" has no Zadex equivalent.`;
    }
  }
}

/** Convenience: merges the element's classes and applies them with a spec. Returns the merged variants. */
export function applyStyles(w: AtomicWriter, spec: StyleSpec, base: Obj = {}): StyleVariant[] {
  const variants = collectVariants(w, base);
  new StyleApplier(w, spec).apply(variants);
  return variants;
}

/** Desktop/normal value of a prop across the merged variants (for layout decisions). */
export function baseProp(variants: StyleVariant[], prop: string): unknown {
  return variants.find((v) => !v.bp && !v.state)?.props[prop];
}

/** True when any variant sets the prop. */
export function hasProp(variants: StyleVariant[], prop: string, where: (v: StyleVariant) => boolean = () => true): boolean {
  return variants.some((v) => where(v) && prop in v.props);
}

export type { Slider };
