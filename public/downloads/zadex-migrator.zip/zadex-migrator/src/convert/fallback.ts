import type { ConvertContext } from './context';
import type { ElElement, ZElement } from './types';

/**
 * Elements without a mapper. When the server sent Elementor's rendered HTML for the element (Elementor active),
 * it is kept in a Zadex HTML widget so the content survives (styling that came from Elementor's CSS does not);
 * the user can swap it for a native Zadex widget later. Otherwise the element is skipped. Both are reported.
 * Unknown layout elements (elType other than widget) still convert their children so nested content is kept.
 */
export function fallback(el: ElElement, ctx: ConvertContext): ZElement[] {
  const sourceType = el.widgetType ?? el.elType;
  if (el.elType !== 'widget' && el.elements?.length) {
    const children = ctx.convert(el.elements);
    const id = ctx.idFor(el.id);
    ctx.record({ source: el.id, sourceType, status: 'partial', target: [id], targetType: 'container', dropped: [], notes: [`Unknown element "${sourceType}" converted to a plain container.`] });
    return [{ id, type: 'container', settings: { direction: 'column' }, children }];
  }
  const html = ctx.source.rendered?.[el.id];
  if (html && ctx.hasWidget('html')) {
    const id = ctx.idFor(el.id);
    ctx.record({ source: el.id, sourceType, status: 'fallback', target: [id], targetType: 'html', dropped: [], notes: [`"${sourceType}" has no Zadex equivalent; its rendered HTML was kept in an HTML widget.`] });
    return [{ id, type: 'html', settings: { html }, children: [] }];
  }
  ctx.record({ source: el.id, sourceType, status: 'skipped', target: [], dropped: [], notes: [`"${sourceType}" has no Zadex equivalent and was skipped.`] });
  return [];
}
