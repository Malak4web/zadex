import { ConvertContext } from './context';
import { getMapper } from './registry';
import { fallback } from './fallback';
import { convertPageSettings } from './page';
import { applyCommon } from './common';
import { templateTarget } from './templates';
import { convertPopupSettings } from './popup';
import { rewriteDocumentPopupLinks } from './popup-links';
import type { ConvertResult, ElElement, Report, ReportSummary, SourceDocument, ZElement, ZadexEnv } from './types';
import './mappers';

/**
 * Converts one Elementor document into a Zadex document. Pure: no network, no DOM. The Elementor data is never
 * modified. Unknown widgets go through the fallback (Elementor's own rendered HTML in a Zadex HTML widget when
 * the server sent it, else skipped) and every element gets a report entry.
 */
export function convertDocument(source: SourceDocument, env: ZadexEnv): ConvertResult {
  const ctx = new ConvertContext(source, env, dispatch);
  ctx.commonHandler = applyCommon;
  const elements = ctx.convert(source.elements);
  // Elementor popup action links anywhere in the finished settings -> Zadex popup links (src/convert/popup-links.ts).
  rewriteDocumentPopupLinks(elements, ctx, ctx.report.entries, (t) => ctx.note(t));
  // Popups keep their layout / triggers / rules in Zadex page settings `popup_*` (src/convert/popup.ts).
  const { pageSettings, template } = source.templateType === 'popup' ? { pageSettings: convertPopupSettings(source, (t) => ctx.note(t), ctx), template: '' } : convertPageSettings(source, ctx);
  // Elementor templates (Theme Builder parts, saved templates): where the draft goes in Zadex (src/convert/templates.ts).
  const target = source.postType === 'elementor_library' || source.templateType ? templateTarget(source, (t) => ctx.note(t)) : undefined;
  return {
    document: { version: 1, elements },
    pageSettings,
    template,
    report: ctx.report,
    summary: summarize(ctx.report),
    ...(target ? { target } : {}),
  };
}

function dispatch(el: ElElement, ctx: ConvertContext): ZElement[] {
  const key = el.elType === 'widget' ? `widget:${el.widgetType ?? ''}` : `el:${el.elType}`;
  const mapper = getMapper(key);
  if (!mapper) return fallback(el, ctx);
  const out = mapper(el, ctx);
  if (!out) return [];
  return Array.isArray(out) ? out : [out];
}

export function summarize(report: Report): ReportSummary {
  const s: ReportSummary = { elements: 0, converted: 0, partial: 0, fallback: 0, skipped: 0, score: 100 };
  for (const e of report.entries) {
    s.elements++;
    s[e.status]++;
  }
  if (s.elements) {
    const points = s.converted + s.partial * 0.75 + s.fallback * 0.25;
    s.score = Math.round((points / s.elements) * 100);
  }
  return s;
}

export { supportedWidgets } from './registry';
