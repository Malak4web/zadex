/**
 * Helpers shared by the Elementor Pro WooCommerce shop / site mappers (phase 5, W2: `woo-*.ts`). Not a mapper:
 * nothing is registered here. The WooCommerce guard itself is `wooGuard()` in `_woo.ts` (shared with W1).
 *
 * Key names and defaults verified against Elementor Pro 3.33.2 (dev/reference/elementor-pro-controls.json); real
 * defaults come from w.get(). Everything a mapper does not read is reported as dropped.
 */
import type { ElementState, ElementWriter } from '../context';
import { deviceKeys } from '../responsive';
import { dimensions, isBlank, slider } from '../values';
import { colorAlt, dimensionsAlt, typographyAlt } from './_marketing';
import { colorValue } from './_media-support';
import elementorDefaults from '../data/elementor-defaults.json';

const DEFAULTS = elementorDefaults as Record<string, Record<string, unknown>>;

/** Elementor Pro default of a control of the writer's source widget (even when the element stores the key). */
export function proDefault(w: ElementWriter, key: string): unknown {
  return DEFAULTS[w.sourceType]?.[key];
}

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Zadex WooCommerce widget that proves WooCommerce is active in Zadex (for mappers whose target is generic). */
export const WOO_PROBE = 'products';

/** True when the Zadex widget defines the control (some page widgets lack a few of the shared style controls). */
export function hasControl(w: ElementWriter, id: string): boolean {
  return Boolean(w.ctx.manifests[w.type]?.controls.some((c) => c.id === id));
}

/** First alternative key that is stored on the element (any device, or a global reference). */
function stored(w: ElementWriter, keys: string[]): string | undefined {
  return keys.find((k) => deviceKeys(k).some(([dk]) => w.has(dk)) || Boolean(w.globalRef(k)));
}

/**
 * Border from separate Elementor controls (Pro WooCommerce widgets mostly use a border type select + width
 * dimensions / slider + color + radius rather than a group): `<prefix>_border` / `<prefix>_type` (style),
 * `<prefix>_width` (dimensions or slider, responsive), color from `colorKeys` (first stored), `radiusKey`
 * (dimensions or slider, responsive). A Group_Control_Border named `<prefix>` stores `<prefix>_border`,
 * `<prefix>_width`, `<prefix>_color`, which this reads the same way. Writes a responsive Zadex border.
 */
export function borderParts(
  w: ElementWriter,
  dst: string,
  o: { prefix: string; colorKeys?: string[]; radiusKeys?: string[]; state?: ElementState; responsive?: boolean },
): void {
  const styleKey = stored(w, [`${o.prefix}_border`, `${o.prefix}_type`]);
  w.consume(`${o.prefix}_border`, `${o.prefix}_type`);
  const style = styleKey ? w.raw(styleKey) : undefined;
  const colorKeys = o.colorKeys ?? [`${o.prefix}_color`];
  const colorKey = stored(w, colorKeys);
  for (const k of colorKeys) w.consume(k);
  const color = colorKey ? colorValue(w, colorKey) : undefined;
  const radiusKeys = o.radiusKeys ?? [];
  const radiusKey = stored(w, radiusKeys) ?? radiusKeys[0];
  for (const k of radiusKeys) w.consumeResponsive(k);
  const responsive = o.responsive !== false;
  for (const [key, bp] of deviceKeys(`${o.prefix}_width`)) {
    const b: Obj = {};
    const sfx = key.slice(`${o.prefix}_width`.length);
    if (!bp && style === 'none') b.style = 'none';
    const width = sides(w.raw(key));
    const hasStyle = typeof style === 'string' && style !== '' && style !== 'none';
    if (width && style !== 'none') {
      b.style = hasStyle ? style : 'solid';
      b.width = width;
    }
    if (!bp && color && style !== 'none') {
      if (hasStyle) b.style = style;
      b.color = color;
    }
    if (radiusKey) {
      const r = sides(w.raw(radiusKey + sfx));
      if (r) b.radius = r;
    }
    if (!Object.keys(b).length) continue;
    if (bp && !responsive) {
      w.note(`${o.prefix}: per-device values are not supported by this Zadex control; the desktop value is used.`);
      continue;
    }
    w.set(dst, b, { bp, state: o.state });
  }
}

/** Elementor dimensions or a one-value slider -> Zadex dimensions. */
export function sides(v: unknown): ReturnType<typeof dimensions> {
  const d = dimensions(v);
  if (d) return d;
  const s = slider(v);
  if (!s) return undefined;
  return { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true };
}

/** Adds a hover color to the (non-responsive) hover border of a Zadex border control. */
export function hoverBorderColor(w: ElementWriter, dst: string, keys: string[]): void {
  const key = stored(w, keys);
  for (const k of keys) w.consume(k);
  const color = key ? colorValue(w, key) : undefined;
  if (color) w.set(dst, { color }, { state: 'hover' });
}

/**
 * Text settings Zadex does not have (section titles, button labels, field labels: Zadex prints WooCommerce's own
 * texts, which follow the site language). A text counts as custom when it is stored and differs from Pro's default
 * (`src/convert/data/elementor-defaults.json`); then a single note lists them and the element is partial.
 */
export function wooLabels(w: ElementWriter, keys: string[], what = 'WooCommerce\'s own texts are shown'): void {
  const changed: string[] = [];
  for (const k of keys) {
    const v = w.raw(k);
    if (isBlank(v)) continue;
    const def = proDefault(w, k);
    if (def !== undefined && JSON.stringify(def) === JSON.stringify(v)) continue;
    changed.push(k);
  }
  if (changed.length) {
    w.note(`Custom texts (${changed.join(', ')}) are not available in Zadex; ${what}.`);
    w.status('partial');
  }
}

/**
 * Style section shared by Elementor Pro's cart / checkout / my-account / purchase-summary widgets -> the shared
 * style controls of the Zadex page widgets (`heading_*`, `text_*`, `link_color`, `input_*`, `button_*`, `table_*`).
 * Only controls the Zadex widget defines are written. Keys verified against Elementor Pro 3.33.2 (alternatives are
 * the per-widget names):
 *  - section titles: `sections_title_color` + `sections_titles_typography` (cart / checkout),
 *    `typography_section_titles_color` + `section_titles_typography` (my-account), `titles_color` +
 *    `titles_typography` (purchase summary);
 *  - text: `sections_descriptions_color` / `_typography` (cart / checkout), `general_text_color` / `_typography`
 *    (my-account / purchase summary); links `links_normal_color` / `links_hover_color`;
 *  - form fields: `forms_field_typography`, `forms_fields_normal_color`, `forms_fields_normal_background` group
 *    (`_background_color`), `forms_fields_border` group + `forms_fields_border_radius`, `forms_fields_padding`;
 *  - buttons: `forms_button_typography`, `forms_buttons_normal_text_color` / `forms_buttons_hover_text_color`,
 *    backgrounds `forms_buttons_normal_background_color` (my-account `forms_buttons_background_color`) /
 *    `forms_buttons_hover_background_color`, border `forms_buttons_border_type` + `_width` + `_color` (my-account: a
 *    group `forms_buttons_border_border`), `forms_buttons_border_radius`, `forms_buttons_hover_border_color`,
 *    `forms_buttons_padding`;
 *  - tables: head `order_summary_title_color` (cart) / `tables_title_color` (my-account) /
 *    `order_details_titles_totals_color` (purchase summary); rows typography `order_summary_items_typography` /
 *    `tables_items_typography` / `order_details_items_typography`; dividers `order_summary_items_divider_color` /
 *    `tables_divider_border_color` / `order_details_border_color`.
 */
export function wooPageStyles(w: ElementWriter): void {
  const can = (id: string): boolean => hasControl(w, id);
  const color = (keys: string[], dst: string, state?: ElementState): void => {
    if (can(dst)) colorAlt(w, keys, dst, state);
  };
  const typo = (prefixes: string[], dst: string): void => {
    if (can(dst)) typographyAlt(w, prefixes, dst);
  };
  color(['sections_title_color', 'typography_section_titles_color', 'titles_color'], 'heading_color');
  typo(['sections_titles_typography', 'section_titles_typography', 'titles_typography'], 'heading_typography');
  color(['sections_descriptions_color', 'general_text_color'], 'text_color');
  typo(['sections_descriptions_typography', 'general_text_typography'], 'text_typography');
  color(['links_normal_color'], 'link_color');
  color(['links_hover_color'], 'link_color', 'hover');

  // Form fields.
  typo(['forms_field_typography'], 'input_typography');
  color(['forms_fields_normal_color'], 'input_color');
  color(['forms_fields_normal_background_color'], 'input_bg');
  // Background groups store their type (classic / gradient) next to the color: only the color is carried over.
  w.consume('forms_fields_normal_background_background', 'forms_buttons_normal_background_background', 'forms_buttons_background_background', 'forms_buttons_hover_background_background');
  if (can('input_border')) {
    borderParts(w, 'input_border', { prefix: 'forms_fields_border', colorKeys: ['forms_fields_border_color'], radiusKeys: ['forms_fields_border_radius'] });
  }
  if (can('input_padding')) dimensionsAlt(w, ['forms_fields_padding'], 'input_padding');

  // Buttons.
  typo(['forms_button_typography'], 'button_typography');
  color(['forms_buttons_normal_text_color'], 'button_color');
  color(['forms_buttons_hover_text_color'], 'button_color', 'hover');
  color(['forms_buttons_normal_background_color', 'forms_buttons_background_color'], 'button_bg');
  color(['forms_buttons_hover_background_color'], 'button_bg', 'hover');
  if (can('button_border')) {
    borderParts(w, 'button_border', { prefix: 'forms_buttons_border', colorKeys: ['forms_buttons_border_color'], radiusKeys: ['forms_buttons_border_radius'] });
    hoverBorderColor(w, 'button_border', ['forms_buttons_hover_border_color']);
  }
  if (can('button_padding')) dimensionsAlt(w, ['forms_buttons_padding'], 'button_padding');

  // Tables (order summary / order details / account tables).
  typo(['order_summary_items_typography', 'tables_items_typography', 'order_details_items_typography'], 'table_typography');
  color(['order_summary_items_divider_color', 'tables_divider_border_color', 'order_details_border_color'], 'table_border_color');
  color(['order_summary_title_color', 'tables_title_color', 'order_details_titles_totals_color'], 'table_head_color');
}

/** Checks a value is a plain Elementor setting object (exported for mappers reading nested values). */
export { isObj };
