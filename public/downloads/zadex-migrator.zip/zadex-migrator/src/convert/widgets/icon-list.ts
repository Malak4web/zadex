import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { bool, icon, isBlank, slider, url } from '../values';
import { describeIcon, isObj, itemIdFor, only, repeaterItems, single, withGlobalDefaults } from './_shared';

const DIVIDER_STYLES = ['solid', 'dashed', 'dotted', 'double'];

/** Elementor `icon-list` -> Zadex `icon-list` (repeater `icon_list` -> `items`). */
registerWidget('icon-list', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    icon_color: 'globals/colors?id=primary',
    text_color: 'globals/colors?id=secondary',
    icon_typography_typography: 'globals/typography?id=text',
    divider_color: 'globals/colors?id=text',
  });
  const w = ctx.writer(el, 'icon-list');
  const items = repeaterItems(w.get('icon_list')).map((item, i) => {
    const out: Record<string, unknown> = { _id: itemIdFor(ctx, el, item, i), text: String(item.text ?? '') };
    const raw = item.selected_icon;
    if (isObj(raw) && (!isBlank(raw.value) || raw.library === 'svg')) {
      const ic = icon(raw, raw.library === 'svg' ? ctx.svg(raw.value) : undefined);
      if (ic) out.icon = ic;
      else w.note(`Icon "${describeIcon(raw)}" is not available in Zadex.`);
    }
    if (!out.icon) out.icon = { library: '', value: '' };
    const link = url(item.link);
    if (link) out.link = link;
    if (isObj(item.__dynamic__)) w.note('Dynamic tags inside list items were replaced by their static values.');
    return out;
  });
  w.set('items', items);

  const view = String(w.get('view') ?? 'traditional');
  w.set('layout', view === 'inline' ? 'row' : 'column');
  if (w.raw('link_click') === 'inline') w.note('"Link: inline" is not carried over; the whole item is the link.');
  w.consume('link_click');
  w.slider('space_between', 'space_between');
  // Elementor's default spacing: none between stacked items, 8px margins (16px) between inline ones; Zadex: 10px.
  if (w.settings.space_between === undefined) w.set('space_between', { size: view === 'inline' ? 16 : 0, unit: 'px' });
  w.map('icon_align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));

  if (bool(w.get('divider'))) {
    w.set('divider', true);
    const style = String(w.get('divider_style') ?? 'solid');
    w.set('divider_style', DIVIDER_STYLES.includes(style) ? style : 'solid');
    single(w, 'divider_weight', 'divider_weight', (v) => slider(v));
    w.color('divider_color', 'divider_color');
    if (w.has('divider_width') || w.has('divider_height')) w.note('Divider width / height are not available in Zadex (the divider spans the item).');
  }
  w.consume('divider_style', 'divider_color', 'divider_*');

  w.color('icon_color', 'icon_color');
  w.color('icon_color_hover', 'icon_color_hover');
  w.consume('icon_color_hover_transition', 'text_color_hover_transition');
  w.slider('icon_size', 'icon_size');
  single(w, 'text_indent', 'icon_gap', (v) => slider(v));
  for (const k of ['icon_self_align', 'icon_self_vertical_align', 'icon_vertical_offset']) {
    if (w.has(k) && !(k === 'icon_vertical_offset' && slider(w.raw(k))?.size === 0)) w.note(`"${k}" is not available in Zadex.`);
    w.consumeResponsive(k);
  }
  w.typography('icon_typography', 'text_typography');
  w.color('text_color', 'text_color');
  w.color('text_color_hover', 'text_color_hover');
  return w.finish();
});
