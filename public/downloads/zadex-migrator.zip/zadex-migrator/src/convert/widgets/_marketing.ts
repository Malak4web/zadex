/**
 * Helpers shared by the Elementor Pro marketing widget mappers (slides, animated-headline, flip-box, call-to-action,
 * price-list, price-table, testimonial-carousel, reviews, countdown). Not a mapper: nothing is registered here.
 *
 * Verified against Elementor Pro 3.33.2 (dev/reference/elementor-pro-controls.json). `w.get()` returns the real Pro
 * defaults (src/convert/data/elementor-defaults.json); `val()` / `sw()` / `str()` remain for keys whose default
 * depends on another setting or for the WooCommerce mappers.
 */
import type { ConvertContext, ElementState, ElementWriter } from '../context';
import type { BreakpointKey } from '../types';
import { deviceKeys } from '../responsive';
import { bool, dimensions, num, slider, type Dimensions, type Slider } from '../values';
import { colorValue } from './_media-support';
import { desktopOnly as dropDeviceKeys } from './_shared';
import { isPlaceholder } from './image';

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Stored value of a key, or `fallback` (Elementor Pro's default) when the key is absent. Switches stored as '' stay ''. */
export function val(w: ElementWriter, key: string, fallback: unknown): unknown {
  const v = w.raw(key);
  return v === undefined || v === null ? fallback : v;
}

/** String content value with an Elementor Pro default. */
export function str(w: ElementWriter, key: string, fallback = ''): string {
  const v = val(w, key, fallback);
  return typeof v === 'string' ? v : typeof v === 'number' ? String(v) : fallback;
}

/** Switcher with an Elementor Pro default (`'yes'` -> true, stored `''` -> false). */
export function sw(w: ElementWriter, key: string, fallback: boolean): boolean {
  const v = w.raw(key);
  return v === undefined || v === null ? fallback : bool(v);
}

/** Item field of a repeater row with an Elementor Pro default. */
export function field(item: Obj, key: string, fallback = ''): string {
  const v = item[key];
  if (v === undefined || v === null) return fallback;
  return typeof v === 'string' ? v : typeof v === 'number' ? String(v) : fallback;
}

/** Positive integer from an Elementor number / select value. */
export function posInt(v: unknown): number | undefined {
  const n = num(v);
  return typeof n === 'number' && n > 0 ? Math.round(n) : undefined;
}

/** Elementor media value -> Zadex media (Elementor's placeholder image is ignored). */
export function mediaOf(ctx: ConvertContext, v: unknown): ReturnType<ConvertContext['media']> {
  return isPlaceholder(v) ? undefined : ctx.media(v);
}

/** Elementor vertical position (top / middle / bottom) -> flex alignment. */
export const VERTICAL: Record<string, string> = { top: 'flex-start', middle: 'center', center: 'center', bottom: 'flex-end' };

/** Elementor physical left / right -> logical start / end (RTL aware). */
export function logicalSide(ctx: ConvertContext, v: unknown, fallback: 'start' | 'end'): 'start' | 'end' {
  const rtl = Boolean(ctx.source.rtl);
  if (v === 'left' || v === 'start') return v === 'start' ? 'start' : rtl ? 'end' : 'start';
  if (v === 'right' || v === 'end') return v === 'end' ? 'end' : rtl ? 'start' : 'end';
  return fallback;
}

/** Elementor left / center / right (or start / end) -> Zadex start / center / end (RTL aware). */
export function logicalAlign(ctx: ConvertContext): Record<string, string> {
  const rtl = Boolean(ctx.source.rtl);
  return { left: rtl ? 'end' : 'start', center: 'center', right: rtl ? 'start' : 'end', start: 'start', end: 'end', justify: 'center' };
}

/** First key among alternatives that holds a value (desktop or global); the others are consumed. */
function pick(w: ElementWriter, keys: string[], present: (k: string) => boolean): string {
  const key = keys.find(present) ?? keys[0]!;
  for (const k of keys) if (k !== key) w.consumeResponsive(k);
  return key;
}

const anyDevice = (w: ElementWriter, base: string): boolean => deviceKeys(base).some(([k]) => w.has(k));

/** Color from the first of several alternative Elementor keys (Pro renamed some controls across versions). */
export function colorAlt(w: ElementWriter, keys: string[], dst: string, state?: ElementState): void {
  w.color(pick(w, keys, (k) => w.has(k) || Boolean(w.globalRef(k))), dst, state);
}

/** Typography group from the first of several alternative prefixes. */
export function typographyAlt(w: ElementWriter, prefixes: string[], dst: string, responsive = true): void {
  const prefix = prefixes.find((p) => w.has(`${p}_typography`) || Boolean(w.globalRef(`${p}_typography`))) ?? prefixes[0]!;
  for (const p of prefixes) if (p !== prefix) w.consume(`${p}_*`);
  w.typography(prefix, dst);
  if (!responsive) dropDeviceKeys(w, dst);
}

/** Responsive slider from the first of several alternative keys. */
export function sliderAlt(w: ElementWriter, keys: string[], dst: string, responsive = true, defaultUnit = 'px'): void {
  const key = pick(w, keys, (k) => anyDevice(w, k));
  for (const [k, bp] of deviceKeys(key)) {
    const s = slider(w.raw(k), defaultUnit);
    if (!s) continue;
    if (bp && !responsive) {
      w.note(`${k}: per-device values are not supported by this Zadex control; the desktop value is used.`);
      continue;
    }
    w.set(dst, s, { bp });
  }
}

/** Responsive dimensions from the first of several alternative keys. */
export function dimensionsAlt(w: ElementWriter, keys: string[], dst: string, responsive = true): void {
  const key = pick(w, keys, (k) => anyDevice(w, k));
  for (const [k, bp] of deviceKeys(key)) {
    const d = dimensions(w.raw(k));
    if (!d) continue;
    if (bp && !responsive) {
      w.note(`${k}: per-device values are not supported by this Zadex control; the desktop value is used.`);
      continue;
    }
    w.set(dst, d, { bp });
  }
}

/** Desktop slider value of a (possibly responsive) Elementor control; device values are noted. */
export function desktopSlider(w: ElementWriter, key: string, defaultUnit = 'px'): Slider | undefined {
  for (const [k, bp] of deviceKeys(key)) {
    if (bp && w.has(k)) w.note(`${k}: per-device values are not supported by this Zadex control; the desktop value is used.`);
    if (bp) w.raw(k);
  }
  return slider(w.raw(key), defaultUnit);
}

/** Elementor slider or dimensions value -> dimensions (a slider gives four equal sides). */
export function sidesOf(v: unknown): Dimensions | undefined {
  const d = dimensions(v);
  if (d) return d;
  const s = slider(v);
  if (!s) return undefined;
  return { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true };
}

/** Elementor duration in ms (number or slider) -> Zadex seconds slider. */
export function msToSeconds(v: unknown): Slider | undefined {
  const s = slider(v, 'ms');
  if (!s || typeof s.size !== 'number') return undefined;
  return { size: s.unit === 's' ? s.size : s.size / 1000, unit: 'custom' };
}

/** Elementor button size presets: [font size, vertical padding, horizontal padding, radius] in px. */
export const BUTTON_PRESETS: Record<string, [number, number, number, number]> = {
  xs: [13, 10, 20, 2],
  sm: [15, 12, 24, 3],
  md: [16, 15, 30, 4],
  lg: [18, 20, 40, 5],
  xl: [20, 25, 50, 6],
};

export interface ButtonKeys {
  /** Zadex control ids. */
  color: string;
  bg: string;
  border: string;
  typography: string;
  padding?: string;
  /** Zadex dimensions control for the radius (price-table); else the radius goes into the border value. */
  radius?: string;
  responsivePadding?: boolean;
  responsiveTypography?: boolean;
}

/**
 * Elementor Pro button style section (slides, flip-box, call-to-action, price-table): text / background / border
 * colors normal + hover, typography, border width + radius (sliders, or a border group `button_border_*`), padding.
 * Returns true when a background color was set (the Zadex "filled" skin then matches).
 */
export function buttonStyles(w: ElementWriter, z: ButtonKeys): boolean {
  typographyAlt(w, ['button_typography'], z.typography, z.responsiveTypography !== false);
  colorAlt(w, ['button_text_color', 'button_color'], z.color);
  colorAlt(w, ['button_hover_text_color', 'button_hover_color', 'button_text_color_hover', 'button_color_hover'], z.color, 'hover');
  colorAlt(w, ['button_background_color', 'button_bg_color'], z.bg);
  colorAlt(w, ['button_hover_background_color', 'button_background_hover_color', 'button_bg_color_hover'], z.bg, 'hover');
  const filled = typeof w.settings[z.bg] === 'string' && w.settings[z.bg] !== '';
  // Pro 3.33 button background groups (`button_background_*`, hover `button_hover_background_*` or, in the price
  // table, `button_background_hover_*`): classic color only; a gradient keeps its first color.
  for (const g of ['button_background', 'button_hover_background', 'button_background_hover']) {
    if (w.raw(`${g}_background`) === 'gradient') w.note(`The button ${g.includes('hover') ? 'hover ' : ''}gradient is not available in Zadex; its first color is used.`);
    w.consume(`${g}_background`, `${g}_color_b`, `${g}_color_stop`, `${g}_color_b_stop`, `${g}_gradient_type`, `${g}_gradient_angle`, `${g}_gradient_position`);
  }

  // Border: group control (`button_border_border`, `_width`, `_color`) or plain width / color controls.
  const border: Obj = {};
  if (w.has('button_border_border')) {
    w.border('button_border', z.border);
    Object.assign(border, isObj(w.settings[z.border]) ? (w.settings[z.border] as Obj) : {});
    dropDeviceKeys(w, z.border);
  } else {
    w.consume('button_border_border');
    const width = sidesOf(desktopOnlyRaw(w, 'button_border_width'));
    if (width) {
      border.style = 'solid';
      border.width = width;
    }
    const color = colorValue(w, 'button_border_color');
    if (color) border.color = color;
  }
  const radius = sidesOf(desktopOnlyRaw(w, 'button_border_radius'));
  if (radius) {
    if (z.radius) w.set(z.radius, radius);
    else border.radius = radius;
  }
  if (Object.keys(border).length) w.set(z.border, border);
  const hoverBorder = colorValue(w, 'button_hover_border_color');
  if (hoverBorder) w.set(z.border, { color: hoverBorder }, { state: 'hover' });

  if (z.padding) dimensionsAlt(w, ['button_padding', 'button_text_padding'], z.padding, z.responsivePadding !== false);
  else w.consume('button_padding*', 'button_text_padding*');
  w.consume('button_hover_animation', 'button_hover_transition_duration');
  return filled;
}

/** Desktop value of a possibly responsive control; device values are consumed and noted. */
function desktopOnlyRaw(w: ElementWriter, key: string): unknown {
  for (const [k, bp] of deviceKeys(key)) {
    if (bp && w.has(k)) w.note(`${k}: per-device values are not supported by this Zadex control; the desktop value is used.`);
    if (bp) w.raw(k);
  }
  return w.raw(key);
}

/**
 * Elementor's button size preset (`button_size`, default sm) written where the element sets nothing itself:
 * Zadex buttons have their own padding / font size, so the preset values keep the button the same size.
 */
export function buttonPreset(w: ElementWriter, size: string, z: { padding?: string; typography: string; border?: string; radius?: string }): void {
  const [font, padY, padX, rad] = BUTTON_PRESETS[size] ?? BUTTON_PRESETS.sm!;
  const typo = isObj(w.settings[z.typography]) ? (w.settings[z.typography] as Obj) : {};
  if (typo.size === undefined) w.set(z.typography, { ...typo, size: { size: font, unit: 'px' } });
  if (z.padding && w.settings[z.padding] === undefined) w.set(z.padding, { top: padY, right: padX, bottom: padY, left: padX, unit: 'px', linked: false });
  const corners = { top: rad, right: rad, bottom: rad, left: rad, unit: 'px', linked: true };
  if (z.radius) {
    if (w.settings[z.radius] === undefined) w.set(z.radius, corners);
  } else if (z.border) {
    const b = isObj(w.settings[z.border]) ? (w.settings[z.border] as Obj) : {};
    if (b.radius === undefined) w.set(z.border, { ...b, radius: corners });
  }
}

/* ---- Pro carousels (testimonial-carousel, reviews): ElementorPro\Modules\Carousel\Widgets\Base ---- */

const SMALLER: Array<{ suffix: string; bp: BreakpointKey }> = [
  { suffix: '_laptop', bp: 'laptop' },
  { suffix: '_tablet_extra', bp: 'tablet_large' },
  { suffix: '_tablet', bp: 'tablet' },
  { suffix: '_mobile_extra', bp: 'mobile_large' },
  { suffix: '_mobile', bp: 'mobile' },
];

/**
 * Slider settings of the Pro carousels (verified against Elementor Pro 3.33.2 `Carousel\Widgets\Base`):
 * `slides_per_view` R ('' = the frontend handler default per device: `d`), `slides_to_scroll` R ('' = 1),
 * `space_between` R (10px), `speed` (500), `show_arrows` (yes), `pagination` bullets|fraction|progressbar|''
 * (bullets), `autoplay` / `loop` / `pause_on_hover` / `pause_on_interaction` (yes), `autoplay_speed` (5000),
 * `lazyload`, `width` (carousel width); styles `arrows_size` (20px), `arrows_color`, `pagination_gap`,
 * `pagination_size`, `pagination_color_inactive`, `pagination_color`. The arrows sit outside the slides
 * (Pro narrows the swiper to `calc(95% - 40px)` and puts the arrows at the edges).
 */
export function carouselSettings(w: ElementWriter, d: { desktop: number; tablet: number; mobile: number }): void {
  const perView = (suffix: string): number | undefined => posInt(w.raw(`slides_per_view${suffix}`));
  w.set('slides_to_show', perView('') ?? d.desktop);
  perView('_widescreen');
  for (const { suffix, bp } of SMALLER) {
    const fallback = bp === 'tablet' ? d.tablet : bp === 'mobile' ? d.mobile : undefined;
    const value = perView(suffix) ?? fallback;
    if (value !== undefined) w.set('slides_to_show', value, { bp });
  }
  for (const [k, bp] of deviceKeys('slides_to_scroll')) {
    if (bp && w.has(k)) w.note(`${k}: per-device values are not supported by this Zadex control; the desktop value is used.`);
    if (bp) w.raw(k);
  }
  w.set('slides_to_scroll', posInt(w.raw('slides_to_scroll')) ?? 1);
  w.set('gap', desktopSlider(w, 'space_between') ?? slider(w.get('space_between')) ?? { size: 10, unit: 'px' });
  w.set('speed', posInt(w.get('speed')) ?? 500);

  const arrows = bool(w.get('show_arrows'));
  const pagination = String(w.get('pagination') ?? '');
  const dots = pagination !== '';
  if (pagination === 'fraction' || pagination === 'progressbar') w.note(`Pagination "${pagination}" is shown as dots in Zadex.`);
  w.set('arrows', arrows);
  w.set('dots', dots);

  const autoplay = bool(w.get('autoplay'));
  w.set('autoplay', autoplay);
  if (autoplay) {
    w.set('autoplay_speed', posInt(w.get('autoplay_speed')) ?? 5000);
    w.set('pause_on_hover', bool(w.get('pause_on_hover')));
    if (w.raw('pause_on_interaction') === '') w.note('Zadex always pauses autoplay after an interaction.');
  } else w.consume('autoplay_speed', 'pause_on_hover', 'pause_on_interaction');
  w.set('loop', bool(w.get('loop')));
  w.consume('lazyload', 'slides_name');
  for (const [k] of deviceKeys('width')) {
    const s = slider(w.raw(k), '%');
    if (s && typeof s.size === 'number') w.note(`The carousel width (${k}) is not carried over; set the Zadex element width instead.`);
  }

  // Navigation styles.
  if (arrows) w.set('arrow_position', 'outside');
  w.slider('arrows_size', 'arrow_size');
  w.color('arrows_color', 'arrow_color');
  const dotSize = desktopSlider(w, 'pagination_size');
  if (dotSize) w.set('dot_size', dotSize);
  w.color('pagination_color', 'dot_active_color');
  w.color('pagination_color_inactive', 'dot_color');
  const dotGap = desktopSlider(w, 'pagination_gap');
  if (dotGap) w.set('dots_spacing', dotGap);
}

/**
 * Slide box styles of the Pro carousels: `slide_background_color`, `slide_padding` (R), `slide_border_size` +
 * `slide_border_color`, `slide_border_radius` -> Zadex `<dst>_bg|_padding|_border|_radius`.
 */
export function slideBox(w: ElementWriter, dst: string, opts: { bg?: boolean; padding?: boolean } = {}): void {
  if (opts.bg !== false) w.color('slide_background_color', `${dst}_bg`);
  if (opts.padding !== false) w.dimensions('slide_padding', `${dst}_padding`);
  const width = sidesOf(desktopOnlyRaw(w, 'slide_border_size'));
  const color = colorValue(w, 'slide_border_color');
  if (width || color) {
    const b: Obj = { style: 'solid' };
    if (width) b.width = width;
    if (color) b.color = color;
    w.set(`${dst}_border`, b);
  }
  const radius = sidesOf(desktopOnlyRaw(w, 'slide_border_radius'));
  if (radius) w.set(`${dst}_radius`, radius);
}

export { isObj };
