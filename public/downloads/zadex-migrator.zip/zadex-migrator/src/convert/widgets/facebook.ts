import { registerWidget } from '../registry';
import { fallback } from '../fallback';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement } from '../types';
import { markPro } from './_pro';
import { facebookTarget, proNumber, proSwitch, proText, proVal } from './_pro-content';

/**
 * Elementor Pro Facebook widgets -> one Zadex `facebook` widget with the matching `embed` type. Keys and defaults verified
 * against Elementor Pro 3.33.2 (elementor-defaults.json). Zadex loads the Facebook SDK itself (lazily, near the viewport).
 */

function open(el: ElElement, ctx: ConvertContext, embed: string): ElementWriter {
  const w = ctx.writer(el, 'facebook');
  markPro(w);
  w.set('embed', embed);
  if (w.raw('color_scheme') === 'dark') w.note('The dark color scheme is no longer offered by Facebook plugins.');
  return w;
}

/**
 * `facebook-button`: `type` like|recommend (like), `layout` standard|button|button_count|box_count (standard), `size`
 * small|large (small), `color_scheme` light|dark, `show_share` (off), `show_faces`, `url_type` current_page|custom, `url`, `url_format`.
 */
registerWidget('facebook-button', (el, ctx) => {
  const w = open(el, ctx, 'like');
  const type = proText(w, 'type', 'like');
  w.set('like_action', type === 'recommend' ? 'recommend' : 'like');
  const layout = proText(w, 'layout', 'standard');
  w.set('like_layout', ['standard', 'button_count', 'box_count', 'button'].includes(layout) ? layout : 'standard');
  const size = proText(w, 'size', 'small');
  w.set('button_size', size === 'large' ? 'large' : 'small');
  w.set('like_share', proSwitch(w, 'show_share'));
  if (proSwitch(w, 'show_faces')) w.note('Showing friends\' faces is no longer offered by Facebook and was not carried over.');
  facebookTarget(w);
  return w.finish();
});

/** `facebook-comments`: `comments_number` (10), `order_by` social|reverse_time|time (social), `url_type`, `url`. */
registerWidget('facebook-comments', (el, ctx) => {
  const w = open(el, ctx, 'comments');
  const n = proNumber(proVal(w, 'comments_number', 10));
  w.set('num_posts', n !== undefined && n > 0 ? Math.round(n) : 10);
  const order = proText(w, 'order_by', 'social');
  w.set('order_by', order === 'time' ? 'time' : 'reverse_time');
  if (order === 'social') w.note('The "social" (most relevant) comment order was retired by Facebook; newest first is used.');
  facebookTarget(w);
  return w.finish();
});

/**
 * `facebook-embed`: `type` post|video|comment (post), `post_url`, `video_url`, `comment_url`, `include_parent`,
 * `show_text` (off), `video_allowfullscreen`, `video_autoplay`, `video_show_captions`. Comment embeds have no Zadex
 * equivalent: fallback (rendered HTML when available).
 */
registerWidget('facebook-embed', (el, ctx) => {
  const type = String(el.settings?.type ?? 'post');
  if (type === 'comment') {
    const out = fallback(el, ctx);
    const entry = ctx.report.entries.find((e) => e.source === el.id);
    entry?.notes.push('Embedded Facebook comments are not supported by the Zadex Facebook widget (posts, videos, pages, comments plugin, like and share are).');
    return out;
  }
  const isVideo = type === 'video';
  const w = open(el, ctx, isVideo ? 'video' : 'post');
  w.consume('type', 'comment_url', 'include_parent');
  if (isVideo) {
    w.set('video_url', proText(w, 'video_url', 'https://www.facebook.com/elemntor/videos/1683988961912056/'));
    w.set('show_text', proSwitch(w, 'show_text', false));
    w.set('allow_fullscreen', proSwitch(w, 'video_allowfullscreen', false));
    if (proSwitch(w, 'video_autoplay', false)) w.note('Video autoplay is not available on the Zadex Facebook widget.');
    if (proSwitch(w, 'video_show_captions', false)) w.note('Video captions are not available on the Zadex Facebook widget.');
    w.consume('post_url');
  } else {
    w.set('post_url', proText(w, 'post_url', 'https://www.facebook.com/elemntor/posts/2624214124556197'));
    w.set('show_text', proSwitch(w, 'show_text'));
    w.consume('video_url', 'video_allowfullscreen', 'video_autoplay', 'video_show_captions');
  }
  return w.finish();
});

/**
 * `facebook-page`: `url`, `tabs` (['timeline']), `small_header`, `show_cover` (yes), `show_facepile` (yes),
 * `show_cta` (yes), `height` slider (500px).
 */
registerWidget('facebook-page', (el, ctx) => {
  const w = open(el, ctx, 'page');
  w.set('page_url', proText(w, 'url', 'https://www.facebook.com/elemntor/'));
  const tabs = proVal(w, 'tabs', ['timeline']);
  const list = (Array.isArray(tabs) ? tabs : [tabs]).map(String).filter((t) => ['timeline', 'events', 'messages'].includes(t));
  w.set('tabs', list);
  w.set('small_header', proSwitch(w, 'small_header', false));
  w.set('hide_cover', !proSwitch(w, 'show_cover', true));
  w.set('show_facepile', proSwitch(w, 'show_facepile', true));
  if (!proSwitch(w, 'show_cta', true)) w.note('Hiding the call-to-action button is no longer offered by Facebook.');
  const h = proNumber(proVal(w, 'height', { unit: 'px', size: 500 }));
  w.set('height', h !== undefined && h > 0 ? Math.round(h) : 500);
  w.consume('height_*');
  return w.finish();
});
