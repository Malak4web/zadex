import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { only } from './_shared';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { flatColor } from './_woo-product';
import { typographyAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-short-description` -> Zadex `product-short-description`.
 * Verified against Elementor Pro 3.33.2: `text_align` (R; justify has no Zadex option, noted), `text_color`,
 * `text_typography_*` (no global defaults: the theme's text styles apply, as in Zadex).
 */
registerWidget('woocommerce-product-short-description', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-short-description');
  if (off) return off;
  const w = ctx.writer(source, 'product-short-description');
  markPro(w);
  w.map('text_align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  flatColor(w, ['text_color'], 'color');
  typographyAlt(w, ['text_typography'], 'typography');
  return w.finish();
});
