import { registerWidget } from '../registry';
import type { ElementWriter, Mapper } from '../context';
import { textAlign } from '../align';
import { only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { PRODUCTS_BASE_GLOBALS, flatColor, intResponsive, noteIfSet, productCardStyles } from './_woo-product';
import { posInt, sliderAlt, typographyAlt } from './_marketing';

/**
 * Product lists of the product page: Elementor Pro `woocommerce-product-related` -> Zadex `product-related`,
 * `woocommerce-product-upsell` -> Zadex `product-upsells` (same controls on both Zadex widgets).
 * Keys / defaults verified against Elementor Pro 3.33.2 (both extend `Products_Base`):
 *  - query: `posts_per_page` (related only, default 4; upsell shows every upsell, Zadex keeps its limit), `columns`
 *    (R, 4 / tablet 3 / mobile 2), `orderby` (date | title | price | popularity | rating | rand | menu_order, default
 *    date), `order` (desc);
 *  - heading: `show_heading` (yes), `heading_color` / `heading_typography` (global primary), `heading_text_align`,
 *    `heading_spacing`;
 *  - cards: the `Products_Base` style sections (see `productCardStyles`); the inherited `pagination_*` controls only
 *    show with `paginate`, which these widgets do not have (ignored).
 */
export function productList(zadexType: 'product-related' | 'product-upsells', orderbys: string[]): Mapper {
  return (source, ctx) => {
    const off = wooGuard(source, ctx, zadexType);
    if (off) return off;
    const el = withGlobalDefaults(source, ctx, {
      ...PRODUCTS_BASE_GLOBALS,
      heading_color: 'globals/colors?id=primary',
      heading_typography_typography: 'globals/typography?id=primary',
    });
    const w = ctx.writer(el, zadexType);
    markPro(w);

    if (zadexType === 'product-related') {
      const limit = posInt(w.get('posts_per_page')) ?? 4;
      w.set('limit', Math.min(24, limit));
      if (limit > 24) w.note(`Only 24 products are shown (Elementor: ${limit}).`);
    } else w.note('Elementor shows every upsell; Zadex shows up to 4 (change "Products" to show more).');
    intResponsive(w, 'columns', 'columns', 1, 8, { desktop: 4, tablet: 3, mobile: 2 });
    productOrder(w, orderbys);

    // Heading (Zadex keeps WooCommerce's default heading text, same as Elementor's).
    if (w.get('show_heading') !== 'yes') w.set('heading', '');
    flatColor(w, ['heading_color'], 'heading_color');
    typographyAlt(w, ['heading_typography'], 'heading_typography');
    sliderAlt(w, ['heading_spacing'], 'heading_spacing');
    noteIfSet(w, ['heading_text_align'], 'The heading alignment is not carried over.');
    w.consume('paginate', 'allow_order', 'show_result_count', 'pagination_*', 'show_pagination_border');

    productCardStyles(w, only(textAlign(ctx), ['left', 'center', 'right']));
    return w.finish();
  };
}

/** `orderby` / `order` (Pro defaults date / desc) limited to the orderings the Zadex widget offers. */
export function productOrder(w: ElementWriter, orderbys: string[], keys = { orderby: 'orderby', order: 'order' }): void {
  const orderby = String(w.get(keys.orderby) || 'date');
  if (orderbys.includes(orderby)) w.set('orderby', orderby);
  else w.note(`Order by "${orderby}" is not available on this Zadex widget; its default order is used.`);
  const order = String(w.get(keys.order) || 'desc').toLowerCase();
  w.set('order', order === 'asc' ? 'asc' : 'desc');
}

registerWidget('woocommerce-product-related', productList('product-related', ['rand', 'date', 'title', 'price', 'popularity', 'rating']));
