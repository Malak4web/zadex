import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { slider } from '../values';
import { desktopOnly, single, withGlobalDefaults } from './_shared';

/**
 * Elementor Pro `post-navigation` -> Zadex `post-navigation`. Verified against Pro 3.33.2
 * (`modules/theme-elements/widgets/post-navigation.php`; defaults via `w.get`): `show_label` (yes), `prev_label`
 * ("Previous"), `next_label` ("Next"), `show_arrow` (yes), `arrow_previous_icon` / `arrow_next_icon` (icons, default
 * fas fa-angle-left / right), `show_title` (yes), `show_borders` (yes), `in_same_term` (select2 list of post types)
 * + `<post_type>_taxonomy`. Styles: `label_color` (global text), `label_hover_color`, `label_typography` (global
 * secondary), `text_color` (title color, global secondary), `hover_color` (title hover), `title_typography` (global
 * secondary), `arrow_color`, `arrow_hover_color`, `arrow_size` R, `arrow_padding` (gap), `sep_color`,
 * `borders_width` R, `borders_spacing`.
 */
const DEFAULT_TAXONOMY: Record<string, string> = { post: 'category', product: 'product_cat' };

registerWidget('post-navigation', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    label_color: 'globals/colors?id=text',
    label_typography_typography: 'globals/typography?id=secondary',
    text_color: 'globals/colors?id=secondary',
    title_typography_typography: 'globals/typography?id=secondary',
  });
  const w = ctx.writer(el, 'post-navigation');
  markPro(w);
  const on = (key: string): boolean => w.get(key) === 'yes';
  w.set('show_label', on('show_label'));
  w.set('prev_label', String(w.get('prev_label') ?? 'Previous'));
  w.set('next_label', String(w.get('next_label') ?? 'Next'));
  w.set('show_title', on('show_title'));
  w.set('show_arrow', on('show_arrow'));
  const icon = (key: string): string => {
    const v = w.get(key);
    return v && typeof v === 'object' && 'value' in v ? String((v as { value: unknown }).value ?? '') : '';
  };
  const prev = icon('arrow_previous_icon');
  const next = icon('arrow_next_icon');
  if (prev !== 'fas fa-angle-left' || next !== 'fas fa-angle-right') w.note('The custom arrow icons are not carried over (Zadex uses its own arrows).');
  if (on('show_borders')) w.note('The separator borders between the links are not available in Zadex.');
  w.consume('sep_color', 'borders_width*', 'borders_spacing*');

  // Same term: a list of post types, each with its own `<post_type>_taxonomy`. Zadex has one switch + taxonomy.
  const same = w.raw('in_same_term');
  const types = (Array.isArray(same) ? same : typeof same === 'string' && same !== '' ? [same] : []).map(String);
  for (const k of Object.keys(w.el.settings ?? {})) if (k.endsWith('_taxonomy')) w.raw(k);
  w.set('same_term', types.length > 0);
  if (types.length) {
    const first = types[0];
    const taxonomy = w.raw(`${first}_taxonomy`);
    w.set('taxonomy', typeof taxonomy === 'string' && taxonomy !== '' ? taxonomy : (DEFAULT_TAXONOMY[first] ?? 'category'));
    if (types.length > 1) w.note(`"In same term" was set for several post types (${types.join(', ')}); Zadex uses one taxonomy (that of ${first}).`);
  }

  w.color('label_color', 'label_color');
  desktopOnly(w, 'label_color');
  w.typography('label_typography', 'label_typography');
  desktopOnly(w, 'label_typography');
  w.color('text_color', 'title_color');
  desktopOnly(w, 'title_color');
  w.color('hover_color', 'title_color_hover');
  desktopOnly(w, 'title_color_hover');
  w.typography('title_typography', 'title_typography');
  desktopOnly(w, 'title_typography');
  w.color('arrow_color', 'arrow_color');
  desktopOnly(w, 'arrow_color');
  single(w, 'arrow_size', 'arrow_size', (v) => slider(v));
  for (const k of ['label_hover_color', 'arrow_hover_color', 'arrow_padding']) if (w.has(k)) w.note(`"${k}" is not available on the Zadex post navigation.`);
  w.consume('label_hover_color', 'arrow_hover_color', 'arrow_padding*', 'label_hover_color_transition_duration', 'hover_color_transition_duration', 'arrow_hover_color_transition_duration');
  return w.finish();
});
