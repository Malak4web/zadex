import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { WOO_PROBE } from './_woo-shop';

/**
 * Elementor Pro `woocommerce-notices` (prints WooCommerce's notices where it is placed) -> Zadex `shortcode` with
 * WooCommerce's `[shop_messages]` shortcode (`wc_print_notices()`), since Zadex has no notices widget. Verified
 * against Elementor Pro 3.33.2: the widget has no controls of its own (notice styles live in the Site Settings
 * WooCommerce panel). Needs WooCommerce, so the guard probes a Zadex WooCommerce widget.
 */
registerWidget('woocommerce-notices', (source, ctx) => {
  const off = wooGuard(source, ctx, ['shortcode', WOO_PROBE]);
  if (off) return off;
  const w = ctx.writer(source, 'shortcode');
  markPro(w);
  w.set('shortcode', '[shop_messages]');
  w.note('WooCommerce notices are printed with the [shop_messages] shortcode; their styling comes from the theme / WooCommerce.');
  return w.finish();
});
