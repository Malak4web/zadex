import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { flatColor } from './_woo-product';
import { typographyAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-stock` -> Zadex `product-stock`.
 * Verified against Elementor Pro 3.33.2: `text_color` (selector `.stock`, every stock state) and `text_typography_*`
 * (no global defaults). Zadex colors each state separately, so the one color is written to in-stock, out-of-stock
 * and backorder.
 */
registerWidget('woocommerce-product-stock', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-stock');
  if (off) return off;
  const w = ctx.writer(source, 'product-stock');
  markPro(w);
  flatColor(w, ['text_color'], 'in_color');
  const color = w.settings.in_color;
  if (color !== undefined) {
    w.set('out_color', color);
    w.set('backorder_color', color);
  }
  typographyAlt(w, ['text_typography'], 'typography');
  return w.finish();
});
