/**
 * Helpers shared by the Elementor Pro "forms and site" mappers (form, login, search-form, search, nav-menu,
 * mega-menu). Not a mapper: nothing is registered here.
 *
 * Verified against Elementor Pro 3.33.2: `src/convert/data/elementor-defaults.json` holds Pro's real defaults, so
 * `w.get()` / `pget` / `pstr` / `pbool` honour them; see docs/ARCHITECTURE.md "Elementor Pro: forms and site".
 */
import type { ElementWriter } from '../context';
import { deviceKeys } from '../responsive';
import { dimensions, isBlank, slider, type Dimensions } from '../values';

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * Stored value, else Pro's real default (`w.get`), else `def` (for controls whose Pro default is empty). Marks the
 * key as handled.
 */
export function pget(w: ElementWriter, key: string, def: unknown): unknown {
  const v = w.get(key);
  return isBlank(v) ? def : v;
}

/** Stored string, else Pro's default, else `def`. */
export function pstr(w: ElementWriter, key: string, def = ''): string {
  const v = pget(w, key, def);
  return typeof v === 'string' || typeof v === 'number' ? String(v) : def;
}

/** Elementor switcher (`'yes'` / `'true'` on, `''` / `'no'` off), falling back to Pro's real default. */
export function pbool(w: ElementWriter, key: string): boolean {
  const v = w.get(key);
  return v === 'yes' || v === true || v === 'true';
}

/**
 * Elementor button size presets ([font size, vertical padding, horizontal padding, radius] in px), the same table as
 * the basic button mapper (`.elementor-button.elementor-size-*`).
 */
export const BUTTON_PRESETS: Record<string, [number, number, number, number]> = {
  xs: [13, 10, 20, 2],
  sm: [15, 12, 24, 3],
  md: [16, 15, 30, 4],
  lg: [18, 20, 40, 5],
  xl: [20, 25, 50, 6],
};

/**
 * Elementor form field size presets (`.elementor-field-textual.elementor-size-*`): [font size, vertical padding,
 * horizontal padding, radius] in px. From Elementor core's frontend.css (also used by the Pro form and login).
 */
export const FIELD_PRESETS: Record<string, [number, number, number, number]> = {
  xs: [13, 4, 12, 2],
  sm: [15, 5, 14, 3],
  md: [16, 6, 16, 4],
  lg: [18, 7, 20, 5],
  xl: [20, 8, 24, 6],
};

export function pxDims(top: number, right: number, bottom = top, left = right): Dimensions {
  return { top, right, bottom, left, unit: 'px', linked: top === right && right === bottom && bottom === left };
}

/** Merges defaults under an already written object value (stored fields win). */
export function mergeDefaults(w: ElementWriter, dst: string, defaults: Obj): void {
  const current = isObj(w.settings[dst]) ? (w.settings[dst] as Obj) : {};
  const out: Obj = { ...current };
  for (const [k, v] of Object.entries(defaults)) if (out[k] === undefined && v !== undefined) out[k] = v;
  if (Object.keys(out).length) w.set(dst, out);
}

/**
 * Two Elementor sliders (vertical + horizontal padding, responsive) -> one Zadex dimensions per breakpoint.
 * `defaults` ([vertical, horizontal] px) are used on desktop when neither slider is stored.
 */
export function paddingFromSliders(w: ElementWriter, vertical: string, horizontal: string, dst: string, defaults?: [number, number]): void {
  const v0 = defaults?.[0] ?? 0;
  const h0 = defaults?.[1] ?? 0;
  let lastV: number | string = v0;
  let lastH: number | string = h0;
  let unit = 'px';
  for (const [vKey, bp] of deviceKeys(vertical)) {
    const hKey = vKey.replace(vertical, horizontal);
    const v = slider(w.raw(vKey));
    const h = slider(w.raw(hKey));
    if (!v && !h) {
      if (!bp && defaults) w.set(dst, pxDims(v0, h0));
      continue;
    }
    if (v) lastV = v.size;
    if (h) lastH = h.size;
    unit = (v ?? h)!.unit;
    w.set(dst, { top: lastV, right: lastH, bottom: lastV, left: lastH, unit, linked: false }, { bp });
  }
}

/** Elementor dimensions value (desktop) or undefined. */
export function dimsOf(w: ElementWriter, key: string): Dimensions | undefined {
  return dimensions(w.raw(key));
}

/** Notes per-device values of a responsive Elementor control that feeds a non-responsive Zadex control. */
export function noteDeviceValues(w: ElementWriter, base: string, label: string): void {
  for (const [key, bp] of deviceKeys(base)) {
    if (bp && w.has(key)) {
      w.raw(key);
      w.note(`${label}: per-device values are not supported by this Zadex control; the desktop value is used.`);
    } else if (bp) w.raw(key);
  }
}

/**
 * Elementor `dropdown` / `breakpoint_selector` value (the device below which the menu collapses) -> Zadex `collapse`
 * (mobile|tablet|laptop|none). Extra breakpoints are approximated (noted).
 */
export function collapseBreakpoint(w: ElementWriter, value: string): string {
  switch (value) {
    case 'mobile':
    case 'tablet':
    case 'laptop':
    case 'none':
      return value;
    case 'mobile_extra':
      w.note('The menu collapses below "mobile extra" in Elementor; Zadex collapses it below "mobile".');
      return 'mobile';
    case 'tablet_extra':
      w.note('The menu collapses below "tablet extra" in Elementor; Zadex collapses it below "laptop".');
      return 'laptop';
    case 'widescreen':
      w.note('The menu collapses below "widescreen" in Elementor; Zadex collapses it below "laptop".');
      return 'laptop';
    default:
      return 'tablet';
  }
}

/** Elementor Pro horizontal item alignment (`left|center|right|justify`, newer `start|end`) -> flex values. */
export function menuAlign(rtl: boolean): Record<string, string> {
  return {
    left: rtl ? 'flex-end' : 'flex-start',
    start: 'flex-start',
    center: 'center',
    right: rtl ? 'flex-start' : 'flex-end',
    end: 'flex-end',
    justify: 'space-between',
    stretch: 'space-between',
    'space-between': 'space-between',
  };
}

export { isObj };
