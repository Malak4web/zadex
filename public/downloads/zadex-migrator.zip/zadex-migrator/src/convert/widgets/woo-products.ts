import { registerWidget } from '../registry';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement, ZElement } from '../types';
import { textAlign } from '../align';
import { only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { list, responsiveInt, toInt } from './_pro-posts';
import { colorAlt, posInt, sliderAlt, typographyAlt } from './_marketing';
import { PRODUCTS_BASE_GLOBALS, flatColor, intResponsive, noteIfSet, productCardStyles } from './_woo-product';
import { productOrder } from './woo-product-related';
import { wooGuard } from './_woo';

/**
 * Elementor Pro product grids -> Zadex `products` (`ProductsQuery` sources). Verified against Elementor Pro 3.33.2
 * (`Products` / `Archive_Products` / deprecated `Products_Deprecated`, `Archive_Products_Deprecated`, all on
 * `Products_Base`; query in `Classes\Products_Renderer`):
 *  - `woocommerce-products`: `columns` R (4 / 3 / 2), `rows` (4), `paginate` (''), `allow_order` / `show_result_count`
 *    ('' , only with paginate); query `query_post_type` product (default) | current_query | sale | featured | by_id |
 *    related_products | upsells | cross_sells, `query_posts_ids`, `query_include` terms / authors +
 *    `query_include_term_ids` (term_taxonomy ids of any product taxonomy) / `query_include_authors`, `query_exclude`
 *    current_post / manual_selection / terms / authors + `query_exclude_ids` / `query_exclude_term_ids`,
 *    `query_orderby` (date | title | price | popularity | rating | rand | menu_order), `query_order` (desc); related /
 *    upsells / cross-sells heading `products_title_show` ('') + `products_*_title_text` + `products_title_*` styles;
 *  - `wc-archive-products`: no columns / rows (WooCommerce's Customizer: 4 x 4), `paginate` hidden yes, `allow_order`
 *    / `show_result_count` yes, query current_query, `nothing_found_message` (+ color / typography);
 *  - `woocommerce-archive-products` (deprecated): like products with `paginate` yes, query current_query (hidden),
 *    `nothing_found_message`;
 *  - `wc-products` (deprecated, posts-style query): `classic_columns` ("4"), `posts_per_page` ("4"),
 *    `posts_post_type` product | by_id | current_query, `posts_posts_ids`, `posts_product_cat_ids`,
 *    `posts_product_tag_ids`, `posts_product_brand_ids`, `posts_authors`, `filter_by` '' | featured | sale, `orderby`
 *    / `order`, `exclude` + `exclude_ids`, `avoid_duplicates`;
 *  - styles: `Products_Base` (`productCardStyles`) + pagination `pagination_spacing`, `pagination_typography`,
 *    `pagination_link_color` (+ `_hover` / `_active`), border / padding / backgrounds (noted).
 * Related / upsell queries become the Zadex `product-related` / `product-upsells` widgets when available.
 */

/** Pro `query_orderby` values (the same names as Zadex `orderby`). */
const ORDERBY = ['date', 'title', 'price', 'popularity', 'rating', 'rand', 'menu_order'];

type Variant = 'products' | 'archive' | 'archive-deprecated' | 'deprecated';

function mapProducts(source: ElElement, ctx: ConvertContext, variant: Variant): ZElement[] | ZElement {
  const off = wooGuard(source, ctx, 'products');
  if (off) return off;
  if (variant === 'products') {
    const type = source.settings?.query_post_type;
    if (type === 'related_products' && ctx.hasWidget('product-related')) return productsAsList(source, ctx, 'product-related');
    if (type === 'upsells' && ctx.hasWidget('product-upsells')) return productsAsList(source, ctx, 'product-upsells');
  }
  const el = withGlobalDefaults(source, ctx, PRODUCTS_BASE_GLOBALS);
  const w = ctx.writer(el, 'products');
  markPro(w);

  // Layout.
  if (variant === 'archive') {
    w.set('columns', 4);
    w.set('rows', 4);
    w.consumeResponsive('columns');
    w.consume('rows');
    w.note('Elementor\'s Archive Products grid follows the WooCommerce Customizer columns / rows; Zadex uses 4 columns x 4 rows (change them on the widget).');
  } else if (variant === 'deprecated') {
    const columns = Math.min(8, Math.max(1, toInt(w.get('classic_columns')) ?? 4));
    const perPage = posInt(w.get('posts_per_page')) ?? 4;
    const rows = Math.min(20, Math.ceil(perPage / columns));
    w.set('columns', columns);
    w.set('rows', rows);
    if (rows * columns !== perPage) w.note(`Elementor showed ${perPage} products; Zadex shows ${columns} columns x ${rows} rows.`);
    w.consume('_skin');
  } else {
    responsiveInt(w, 'columns', 'columns', { desktop: 4, tablet: 3, mobile: 2 }, [1, 8]);
    const rows = toInt(w.get('rows')) ?? 4;
    if (rows > 20) w.note(`Rows ${rows}: Zadex shows at most 20 rows per page.`);
    w.set('rows', Math.min(20, rows));
  }

  const paginate = variant === 'archive' ? true : variant === 'deprecated' ? false : w.get('paginate') === 'yes';
  w.set('pagination', paginate);
  if (variant === 'archive') w.consume('paginate');
  if (paginate) {
    const order = w.get('allow_order') === 'yes';
    const count = w.get('show_result_count') === 'yes';
    if (order || count) w.set('show_result_count', true);
    if (order !== count) w.note('Zadex shows the result count and the sorting select together; Elementor had only one of them.');
  } else w.consume('allow_order', 'show_result_count');
  if (variant === 'archive' || variant === 'archive-deprecated') {
    const nothing = w.get('nothing_found_message');
    if (typeof nothing === 'string' && nothing !== '') w.set('empty_text', nothing);
    noteIfSet(w, ['nothing_found_color', 'nothing_found_typography_*'], 'The "nothing found" message styles are not carried over.');
  }
  w.consume('products_class', 'section_query', 'wc_notice_frontpage', 'wc_notice_wc_not_active', 'wc_notice_did_not_found');

  // Query.
  if (variant === 'archive' || variant === 'archive-deprecated') {
    w.set('source', 'current');
    w.consume('query_*');
  } else if (variant === 'deprecated') deprecatedQuery(w);
  else mapQuery(w);
  if (variant !== 'deprecated') noteIfSet(w, ['products_title_show', 'products_title_alignment', 'products_title_color', 'products_title_spacing', 'products_title_typography_*', 'products_related_products_title_text', 'products_upsells_title_text', 'products_cross_sells_title_text'], 'The related / upsells / cross-sells heading is not available in the Zadex Products widget.');

  productCardStyles(w, only(textAlign(ctx), ['left', 'center', 'right']));
  paginationStyles(w, paginate);
  return w.finish();
}

function mapQuery(w: ElementWriter): void {
  const type = String(w.get('query_post_type') || 'product');
  const include = list(w.raw('query_include'));
  const exclude = list(w.raw('query_exclude'));
  const terms = list(w.raw('query_include_term_ids'));
  const ids = list(w.raw('query_posts_ids'));
  let source = 'latest';
  switch (type) {
    case 'sale':
    case 'featured':
      source = type;
      break;
    case 'by_id':
      source = 'ids';
      w.set('ids', ids.join(', '));
      break;
    case 'current_query':
      source = 'current';
      break;
    case 'product':
      break;
    default:
      w.note(`Query "${type}" is not available in the Zadex Products widget; the latest products are shown (use the Zadex related / upsells widgets instead).`);
      w.status('partial');
  }
  const listQuery = ['related_products', 'upsells', 'cross_sells'].includes(type);
  if (include.includes('terms') && terms.length && type !== 'by_id' && type !== 'current_query' && !listQuery) {
    if (source === 'latest') {
      // Pro stores term_taxonomy ids of any product taxonomy; they are kept as product categories.
      source = 'category';
      w.set('categories', terms);
      w.note('Included terms were kept as product categories (Elementor stores term_taxonomy ids of any product taxonomy; product tags would need the "By tag" source, and ids may differ from term ids).');
    } else {
      w.note(`Zadex cannot combine "${source}" products with a term filter; the term filter was left out.`);
      w.status('partial');
    }
  }
  if (include.includes('authors') && list(w.raw('query_include_authors')).length) {
    w.note('Filtering products by author is not available in Zadex.');
    w.status('partial');
  }
  w.set('source', source);

  const excIds = list(w.raw('query_exclude_ids'));
  if (exclude.includes('manual_selection') && excIds.length) w.set('exclude', excIds.join(', '));
  if (exclude.includes('terms') && list(w.raw('query_exclude_term_ids')).length) {
    w.note('Excluding product terms is not available in Zadex.');
    w.status('partial');
  }
  if (exclude.includes('authors')) w.note('Excluding authors is not available in Zadex.');
  if (exclude.includes('current_post')) w.note('Zadex does not exclude the current product from the grid.');
  w.consume('query_include_authors', 'query_exclude_authors');

  if (type === 'current_query') w.consume('query_orderby', 'query_order');
  else writeOrder(w, 'query_orderby', 'query_order');
}

/** Deprecated `wc-products` (posts-style query group `posts_*`, `filter_by`, `orderby`, `exclude`). */
function deprecatedQuery(w: ElementWriter): void {
  const type = String(w.get('posts_post_type') || 'product');
  const filter = String(w.get('filter_by') ?? '');
  const cats = list(w.raw('posts_product_cat_ids'));
  const tags = list(w.raw('posts_product_tag_ids'));
  let source = 'latest';
  if (type === 'by_id') {
    source = 'ids';
    w.set('ids', list(w.raw('posts_posts_ids')).join(', '));
  } else if (type === 'current_query') source = 'current';
  else if (filter === 'sale' || filter === 'featured') {
    source = filter;
    if (cats.length || tags.length) {
      w.note(`Zadex cannot combine "${filter}" products with a category / tag filter; the filter was left out.`);
      w.status('partial');
    }
  } else if (cats.length) {
    source = 'category';
    w.set('categories', cats);
    if (tags.length) {
      w.note('Zadex filters by categories or tags, not both; the tag filter was left out.');
      w.status('partial');
    }
  } else if (tags.length) {
    source = 'tag';
    w.set('tags', tags);
  }
  if (type !== 'by_id') w.consume('posts_posts_ids');
  if (type === 'product' && list(w.raw('posts_product_brand_ids')).length) {
    w.note('Filtering products by brand is not available in Zadex.');
    w.status('partial');
  }
  if (type === 'product' && list(w.raw('posts_authors')).length) {
    w.note('Filtering products by author is not available in Zadex.');
    w.status('partial');
  }
  w.consume('posts_product_brand_ids', 'posts_authors', 'avoid_duplicates');
  w.set('source', source);
  const exclude = list(w.raw('exclude'));
  const excIds = list(w.raw('exclude_ids'));
  if (exclude.includes('manual_selection') && excIds.length) w.set('exclude', excIds.join(', '));
  if (exclude.includes('current_post')) w.note('Zadex does not exclude the current product from the grid.');
  writeOrder(w, 'orderby', 'order');
}

/** Pro order by / order (date / desc defaults) -> Zadex `orderby` / `order` (upper case). */
function writeOrder(w: ElementWriter, orderbyKey: string, orderKey: string): void {
  const orderby = String(w.get(orderbyKey) || 'date');
  if (ORDERBY.includes(orderby)) w.set('orderby', orderby);
  else {
    w.note(`Order by "${orderby}" is not available in Zadex; products are ordered by date.`);
    w.set('orderby', 'date');
  }
  w.set('order', String(w.get(orderKey) || 'desc').toUpperCase() === 'ASC' ? 'ASC' : 'DESC');
}

function paginationStyles(w: ElementWriter, paginate: boolean): void {
  if (!paginate) {
    w.consume('pagination_*', 'show_pagination_border');
    return;
  }
  sliderAlt(w, ['pagination_spacing'], 'pagination_spacing');
  typographyAlt(w, ['pagination_typography'], 'pagination_typography');
  colorAlt(w, ['pagination_link_color'], 'pagination_color');
  colorAlt(w, ['pagination_link_color_hover'], 'pagination_color', 'hover');
  colorAlt(w, ['pagination_link_color_active'], 'pagination_active');
  noteIfSet(w, ['pagination_border_color', 'pagination_padding', 'pagination_link_bg_color', 'pagination_link_bg_color_hover', 'pagination_link_bg_color_active'], 'The pagination border, padding and backgrounds are not carried over.');
  if (w.get('show_pagination_border') !== 'yes') w.note('Hiding the pagination border is not carried over.');
}

/**
 * `woocommerce-products` with a related / upsells query -> the Zadex `product-related` / `product-upsells` widget
 * (same WooCommerce lists): columns R, limit = columns x rows, `query_orderby` / `query_order`, heading
 * (`products_title_show`, default off; `products_*_title_text`; `products_title_*` styles), card styles.
 */
function productsAsList(source: ElElement, ctx: ConvertContext, zadexType: 'product-related' | 'product-upsells'): ZElement {
  const el = withGlobalDefaults(source, ctx, {
    ...PRODUCTS_BASE_GLOBALS,
    products_title_color: 'globals/colors?id=primary',
    products_title_typography_typography: 'globals/typography?id=primary',
  });
  const w = ctx.writer(el, zadexType);
  markPro(w);
  w.consume('query_post_type');
  const columns = posInt(w.get('columns')) ?? 4;
  const rows = posInt(w.get('rows')) ?? 4;
  w.set('limit', Math.min(24, columns * rows));
  intResponsive(w, 'columns', 'columns', 1, 8, { desktop: 4, tablet: 3, mobile: 2 });
  productOrder(w, zadexType === 'product-related' ? ['rand', 'date', 'title', 'price', 'popularity', 'rating'] : ['rand', 'date', 'title', 'price', 'menu_order'], { orderby: 'query_orderby', order: 'query_order' });
  const textKey = zadexType === 'product-related' ? 'products_related_products_title_text' : 'products_upsells_title_text';
  if (w.get('products_title_show') === 'yes') {
    const text = w.get(textKey);
    if (typeof text === 'string' && text !== '') w.set('heading', text);
    flatColor(w, ['products_title_color'], 'heading_color');
    typographyAlt(w, ['products_title_typography'], 'heading_typography');
    sliderAlt(w, ['products_title_spacing'], 'heading_spacing');
    noteIfSet(w, ['products_title_alignment'], 'The heading alignment is not carried over.');
  } else {
    w.set('heading', '');
    w.consume(textKey, 'products_title_*');
  }
  w.consume('products_related_products_title_text', 'products_upsells_title_text', 'products_cross_sells_title_text', 'query_*', 'paginate', 'allow_order', 'show_result_count', 'pagination_*', 'show_pagination_border');
  w.note(`Products widget with the "${zadexType === 'product-related' ? 'related products' : 'upsells'}" query became the Zadex ${zadexType} widget.`);
  productCardStyles(w, only(textAlign(ctx), ['left', 'center', 'right']));
  return w.finish();
}

registerWidget('woocommerce-products', (el, ctx) => mapProducts(el, ctx, 'products'));
registerWidget('wc-archive-products', (el, ctx) => mapProducts(el, ctx, 'archive'));
registerWidget('woocommerce-archive-products', (el, ctx) => mapProducts(el, ctx, 'archive-deprecated'));
registerWidget('wc-products', (el, ctx) => mapProducts(el, ctx, 'deprecated'));

