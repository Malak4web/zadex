import { registerWidget } from '../registry';
import { bool, num, url } from '../values';
import { iconOf } from './_media-support';
import { itemIdFor, repeaterItems, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { carouselSettings, desktopSlider, field, mediaOf, slideBox } from './_marketing';

type Obj = Record<string, unknown>;

const TWITTER = { value: 'fab fa-twitter', library: 'fa-brands' };

/** Font Awesome brand glyph -> Zadex review source. */
const SOURCES: Record<string, string> = {
  'fa-google': 'google',
  'fa-google-plus': 'google',
  'fa-google-plus-g': 'google',
  'fa-facebook': 'facebook',
  'fa-facebook-f': 'facebook',
  'fa-facebook-square': 'facebook',
  'fa-square-facebook': 'facebook',
  'fa-twitter': 'x',
  'fa-twitter-square': 'x',
  'fa-square-twitter': 'x',
  'fa-x-twitter': 'x',
  'fa-square-x-twitter': 'x',
};

/**
 * Elementor Pro `reviews` -> Zadex `reviews`. Verified against Elementor Pro 3.33.2: repeater `slides` {image,
 * name (John Doe), title (@username), rating (number 0-5, empty = no stars), selected_social_icon (default
 * Twitter), link, content}, the Pro carousel settings (`carouselSettings`; the base handler shows 3 / 2 / 1 slides per
 * view), `image_size_size`, styles: slide box (`slide_*`), header `header_background_color`, `content_gap` (header /
 * content gap), `show_separator` (on) + `separator_color` / `separator_size`, `name_*` (primary typography),
 * `title_*`, `content_*` (text typography), `image_size`, `image_gap`, `image_border_radius`, `icon_color`
 * default|custom + `icon_custom_color`, `icon_size`, `star_style`, `unmarked_star_style`, `star_size`, `star_space`,
 * `stars_color`, `stars_unmarked_color`, navigation.
 */
registerWidget('reviews', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    name_typography_typography: 'globals/typography?id=primary',
    content_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'reviews');
  markPro(w);
  const items = repeaterItems(w.get('slides'));
  if (!items.length) w.note('The reviews widget has no reviews.');
  let anySource = false;
  let unsupported = false;
  w.set(
    'slides',
    items.map((item, i) => {
      // Pro prints stars only for a non-empty rating (the repeater has no default rating).
      const rating = num(item.rating);
      const out: Obj = {
        _id: itemIdFor(ctx, el, item, i),
        name: field(item, 'name', 'John Doe'),
        title: field(item, 'title', '@username'),
        rating: typeof rating === 'number' ? Math.max(0, Math.min(5, rating)) : 0,
        content: field(item, 'content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.'),
      };
      const image = mediaOf(ctx, item.image);
      if (image) out.image = image;
      const rawIcon = item.selected_social_icon === undefined ? TWITTER : item.selected_social_icon;
      const glyph = rawIcon && typeof rawIcon === 'object' && typeof (rawIcon as Obj).value === 'string' ? ((rawIcon as Obj).value as string).split(/\s+/).find((p) => p.startsWith('fa-') && !/^fa-(solid|regular|brands)$/.test(p)) : undefined;
      if (glyph && SOURCES[glyph]) {
        out.source = SOURCES[glyph];
        anySource = true;
      } else {
        const ic = iconOf(ctx, rawIcon);
        if (ic) {
          out.source = 'custom';
          out.source_icon = ic;
          anySource = true;
        } else {
          out.source = 'none';
          if (rawIcon && typeof rawIcon === 'object' && (rawIcon as Obj).value) unsupported = true;
        }
      }
      const link = url(item.link);
      if (link) out.link = link;
      return out;
    }),
  );
  if (unsupported) w.note('Some review source icons are not available in Zadex; they were left out.');
  w.set('header_layout', 'inline');
  w.set('rating_position', 'header');
  w.set('show_image', true);
  w.set('show_source', anySource);
  const size = w.get('image_size_size');
  if (typeof size === 'string' && size !== 'full' && size !== '') w.note(`Image size "${size}" is not carried over (Zadex uses the image size control).`);
  w.consume('image_size_custom_dimension');

  carouselSettings(w, { desktop: 3, tablet: 2, mobile: 1 });

  // Review box / header.
  slideBox(w, 'review');
  if (w.has('header_background_color')) w.note('The review header background color is not available in Zadex.');
  w.consume('header_background_color');
  if (desktopSlider(w, 'content_gap')) w.note('The gap between the review header and its text is not available in Zadex.');
  const separator = bool(w.get('show_separator'));
  w.set('header_divider', separator);
  if (separator && (w.has('separator_color') || w.has('separator_size'))) w.note('The review separator color / size are not available in Zadex.');
  w.consume('separator_color', 'separator_size');

  // Header texts / image (Elementor's image gap = the Zadex header gap between image and name).
  w.color('name_color', 'name_color');
  w.typography('name_typography', 'name_typography');
  w.color('title_color', 'title_color');
  w.typography('title_typography', 'title_typography');
  const imageSize = desktopSlider(w, 'image_size');
  if (imageSize) w.set('image_size', imageSize);
  const imageGap = desktopSlider(w, 'image_gap');
  if (imageGap) w.set('header_gap', imageGap);
  const radius = desktopSlider(w, 'image_border_radius');
  if (radius) w.set('image_radius', radius);

  // Rating.
  if (w.get('star_style') === 'star_unicode') w.note('Unicode stars are shown as icon stars in Zadex.');
  if (w.get('unmarked_star_style') === 'outline') w.note('Outline unmarked stars are shown solid in Zadex (use the unmarked color).');
  const starSize = desktopSlider(w, 'star_size');
  if (starSize) w.set('star_size', starSize);
  const starGap = desktopSlider(w, 'star_space');
  if (starGap) w.set('star_spacing', starGap);
  w.color('stars_color', 'star_color');
  w.color('stars_unmarked_color', 'star_unmarked_color');

  // Content.
  w.color('content_color', 'content_color');
  w.typography('content_typography', 'content_typography');

  // Source icon.
  const custom = w.get('icon_color') === 'custom';
  w.set('source_colors', custom ? 'custom' : 'brand');
  if (custom) w.color('icon_custom_color', 'source_color');
  else w.consume('icon_custom_color');
  const iconSize = desktopSlider(w, 'icon_size');
  if (iconSize) w.set('source_size', iconSize);
  return w.finish();
});
