import type { ConvertContext } from '../context';
import type { ElElement, ZElement } from '../types';
import { PRO_NOTE } from './_pro';

/** Report note used whenever a WooCommerce widget cannot be mapped because Zadex hides its WooCommerce widgets. */
export const WOO_INACTIVE_NOTE = 'WooCommerce is not active in Zadex';

/**
 * Shared guard for every Elementor Pro WooCommerce mapper (phase 5, docs/ARCHITECTURE.md "WooCommerce (phase 5,
 * spec)"). Zadex omits its `requires: woocommerce` widgets from the manifest list when WooCommerce is not active on
 * the target site, so `ctx.hasWidget(zadexType)` is false there.
 *
 * Returns `null` when the Zadex widget is available (the mapper continues normally). Otherwise returns the fallback
 * result, like `fallback.ts`: Elementor's rendered HTML in a Zadex HTML widget when the server sent it, or nothing
 * (skipped). Both are recorded in the report with the note {@link WOO_INACTIVE_NOTE} (+ the Pro note).
 *
 * Usage: `const off = wooGuard(el, ctx, 'product-title'); if (off) return off;`
 */
export function wooGuard(el: ElElement, ctx: ConvertContext, zadexType: string | string[]): ZElement[] | null {
  const types = Array.isArray(zadexType) ? zadexType : [zadexType];
  if (types.every((t) => ctx.hasWidget(t))) return null;
  return wooFallback(el, ctx);
}

/** Fallback for a WooCommerce element whose Zadex target is unavailable (also usable directly by mappers). */
export function wooFallback(el: ElElement, ctx: ConvertContext, reason: string = WOO_INACTIVE_NOTE): ZElement[] {
  const sourceType = el.widgetType ?? el.elType;
  const html = ctx.source.rendered?.[el.id];
  if (html && ctx.hasWidget('html')) {
    const id = ctx.idFor(el.id);
    ctx.record({
      source: el.id,
      sourceType,
      status: 'fallback',
      target: [id],
      targetType: 'html',
      dropped: [],
      notes: [reason, `"${sourceType}": its rendered HTML was kept in an HTML widget.`, PRO_NOTE],
    });
    return [{ id, type: 'html', settings: { html }, children: [] }];
  }
  ctx.record({
    source: el.id,
    sourceType,
    status: 'skipped',
    target: [],
    dropped: [],
    notes: [reason, `"${sourceType}" was skipped.`, PRO_NOTE],
  });
  return [];
}
