import { registerWidget } from '../registry';
import { slider } from '../values';
import { markPro } from './_pro';
import { withGlobalDefaults } from './_shared';
import { colorOf, desktopSlider, dimsFrom, getBool, getInt, getStr, imageSizeName, list, mapQuery, ratioOption, responsiveGet, titleTag } from './_pro-posts';

const RATIOS = ['1 / 1', '4 / 3', '3 / 2', '16 / 9', '3 / 4'];
const SIZES = ['thumbnail', 'medium', 'medium_large', 'large', 'full'];
const TITLE_TAGS = ['h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span'];
const TRANSPARENT = 'rgba(0,0,0,0)';

/**
 * Elementor Pro `portfolio` -> Zadex `portfolio` (filterable post grid), verified against Pro 3.33.2: `columns`
 * R (3 / 2 / 1), `posts_per_page` (6), `thumbnail_size_size` (medium), `masonry`, `item_ratio` (0.66), `show_title`
 * (yes), `title_tag` (h3), `show_filter_bar` (off), `taxonomy`, query group `posts_*`; style `column_gap` /
 * `row_gap` (legacy `item_gap`; no default = 0), `border_radius`, overlay `color_background` (kit accent),
 * `color_title`, `typography_title_*` (kit primary), filter `color_filter` (kit text), `color_filter_active` (kit
 * primary), `typography_filter_*` (kit primary), `filter_item_spacing` (10px), `filter_spacing` (10px).
 * Pro's look (centered overlay text with 15px padding, no image zoom, plain-text filter items with an "All" item) is
 * written explicitly where Zadex differs.
 */
registerWidget('portfolio', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    color_background: 'globals/colors?id=accent',
    typography_title_typography: 'globals/typography?id=primary',
    color_filter: 'globals/colors?id=text',
    color_filter_active: 'globals/colors?id=primary',
    typography_filter_typography: 'globals/typography?id=primary',
  });
  const w = ctx.writer(el, 'portfolio');
  markPro(w);

  // Layout.
  responsiveGet(w, 'columns', 'columns', [1, 12]);
  const perPage = getInt(w, 'posts_per_page') ?? 6;
  w.set('image_size', imageSizeName(w, getStr(w, 'thumbnail_size_size') || 'medium', SIZES, 'medium'));
  w.consume('thumbnail_size_custom_dimension');
  if (getBool(w, 'masonry')) {
    w.note('Masonry is not available in the Zadex portfolio; items share one image ratio.');
    w.status('partial');
  }
  const ratio = ratioOption(w, w.get('item_ratio'), RATIOS, 'Item ratio');
  if (ratio) w.set('image_ratio', ratio);
  const showTitle = getBool(w, 'show_title');
  w.set('show_title', showTitle);
  if (showTitle) w.set('title_tag', titleTag(w, getStr(w, 'title_tag') || 'h3', TITLE_TAGS));
  else w.consume('title_tag');
  w.set('overlay', 'hover');
  w.set('overlay_align', 'center');
  w.set('overlay_padding', { top: 15, right: 15, bottom: 15, left: 15, unit: 'px', linked: true });
  w.set('item_hover', 'none');
  w.set('link', true);
  // An empty Pro portfolio query renders nothing.
  w.set('nothing_found', '');

  // Filter bar (off by default in Pro; it always starts with an "All" item).
  const showFilter = getBool(w, 'show_filter_bar');
  w.set('show_filter', showFilter);
  if (showFilter) {
    const tax = list(w.get('taxonomy'))[0];
    if (tax) w.set('filter_taxonomy', tax);
    w.set('show_all', true);
  } else w.consume('taxonomy');

  // Items: one Zadex gap (Pro: column / row gap, legacy `item_gap`; none set = no gap).
  const legacy = slider(w.raw('item_gap'));
  const col = slider(w.raw('column_gap')) ?? legacy ?? { size: 0, unit: 'px' };
  const row = slider(w.raw('row_gap')) ?? legacy ?? { size: 0, unit: 'px' };
  w.set('gap', col);
  if (row.size !== col.size || row.unit !== col.unit) w.note('Zadex uses one gap for rows and columns; the column gap is used.');
  dimsFrom(w, 'border_radius', 'item_radius');

  // Overlay (Pro CSS falls back to a translucent grey when the kit has no accent color).
  w.set('overlay_bg', colorOf(w, 'color_background') ?? 'rgba(105,114,125,0.8)');
  w.color('color_title', 'title_color');
  w.typography('typography_title', 'title_typography');

  // Filter bar style.
  if (showFilter) {
    w.color('color_filter', 'filter_color');
    w.color('color_filter_active', 'filter_active_color');
    w.typography('typography_filter', 'filter_typography');
    w.set('filter_bg', TRANSPARENT);
    w.set('filter_active_bg', TRANSPARENT);
    w.set('filter_border', { style: 'none' });
    w.set('filter_padding', { top: 8, right: 8, bottom: 8, left: 8, unit: 'px', linked: true });
    desktopSlider(w, 'filter_item_spacing', 'filter_gap');
    if (w.settings.filter_gap === undefined) w.set('filter_gap', { size: 10, unit: 'px' });
    desktopSlider(w, 'filter_spacing', 'filter_spacing');
    if (w.settings.filter_spacing === undefined) w.set('filter_spacing', { size: 10, unit: 'px' });
  } else {
    w.consume('color_filter*', 'typography_filter_*', 'filter_item_spacing*', 'filter_spacing*');
  }

  mapQuery(w, 'posts_', perPage);
  return w.finish();
});
