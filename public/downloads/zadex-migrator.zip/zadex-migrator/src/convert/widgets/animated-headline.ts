import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { bool, url } from '../values';
import { only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { desktopSlider, posInt } from './_marketing';

/** Elementor `marker` -> Zadex `shape` (approximations noted). */
const SHAPES: Record<string, string> = {
  circle: 'circle',
  curly: 'curly',
  underline: 'underline',
  double: 'double',
  double_underline: 'double',
  underline_zigzag: 'zigzag',
  diagonal: 'strikethrough',
  strikethrough: 'strikethrough',
  x: 'x',
};
const APPROX_SHAPES: Record<string, string> = { double_underline: 'double', diagonal: 'strikethrough' };
const ANIMATIONS = ['typing', 'clip', 'flip', 'swirl', 'blinds', 'drop-in', 'wave', 'slide'];
const TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'p', 'span'];

/**
 * Elementor Pro `animated-headline` -> Zadex `animated-headline`. Verified against Elementor Pro 3.33.2:
 * `headline_style` highlight|rotate, `marker` (circle), `animation_type` (typing; incl. slide-down), `before_text`,
 * `highlighted_text`, `rotating_text` (one line per word), `after_text`, `loop` (yes), `highlight_animation_duration`
 * (1200), `highlight_iteration_delay` (8000), `rotate_iteration_delay` (2500), `link`, `tag` (h3), `alignment`
 * (R, center); style `marker_color` (accent), `stroke_width` (Pro CSS 9), `above_content`, `rounded_edges`,
 * `title_color` / `words_color` (secondary), `title_typography` / `words_typography` (primary), typing selection
 * colors, text stroke / shadow groups. Real defaults come from `w.get()`.
 */
registerWidget('animated-headline', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    marker_color: 'globals/colors?id=accent',
    title_color: 'globals/colors?id=secondary',
    title_typography_typography: 'globals/typography?id=primary',
    words_color: 'globals/colors?id=secondary',
    words_typography_typography: 'globals/typography?id=primary',
  });
  const w = ctx.writer(el, 'animated-headline');
  markPro(w);
  const rotating = w.get('headline_style') === 'rotate';
  w.set('headline_type', rotating ? 'rotating' : 'highlighted');
  w.set('before_text', String(w.get('before_text') ?? ''));
  w.set('after_text', String(w.get('after_text') ?? ''));
  const loop = bool(w.get('loop'));
  w.set('loop', loop);

  if (rotating) {
    const anim = String(w.get('animation_type') || 'typing');
    const mapped = anim === 'slide-down' ? 'slide' : ANIMATIONS.includes(anim) ? anim : 'typing';
    if (mapped !== anim) w.note(`Rotating animation "${anim}" is not available in Zadex; "${mapped}" is used.`);
    w.set('animation', mapped);
    w.set('rotating_text', String(w.get('rotating_text') ?? '').replace(/\r\n?/g, '\n'));
    w.set('duration', Math.max(500, posInt(w.get('rotate_iteration_delay')) ?? 2500));
    // Elementor types / deletes letters every 150ms (frontend `typeLettersDelay`).
    if (mapped === 'typing') w.set('type_speed', 150);
    w.consume('marker', 'highlighted_text', 'highlight_animation_duration', 'highlight_iteration_delay');
  } else {
    const marker = String(w.get('marker') || 'circle');
    const shape = SHAPES[marker] ?? 'circle';
    if (APPROX_SHAPES[marker] || !SHAPES[marker]) w.note(`Highlight shape "${marker}" is not available in Zadex; "${shape}" is used.`);
    w.set('shape', shape);
    w.set('highlighted_text', String(w.get('highlighted_text') ?? ''));
    w.set('highlight_duration', Math.max(100, posInt(w.get('highlight_animation_duration')) ?? 1200));
    // Zadex redraws the highlight `duration` ms after it is drawn: Elementor's iteration delay (only used with loop).
    if (loop) w.set('duration', Math.max(500, posInt(w.get('highlight_iteration_delay')) ?? 8000));
    else w.consume('highlight_iteration_delay');
    w.consume('animation_type', 'rotating_text', 'rotate_iteration_delay');
  }

  const link = url(w.raw('link'));
  if (link) w.set('link', link);
  const tag = String(w.get('tag') || 'h3');
  w.set('tag', TAGS.includes(tag) ? tag : 'h3');
  w.map('alignment', 'align', only(textAlign(ctx), ['left', 'center', 'right']));

  // Shape style (Pro's stroke width is 9 when nothing is set, Zadex's too; edges are square unless rounded).
  if (!rotating) {
    w.color('marker_color', 'shape_color');
    const stroke = desktopSlider(w, 'stroke_width');
    if (stroke) w.set('stroke_width', stroke);
  } else w.consume('marker_color', 'stroke_width*');
  w.set('rounded', bool(w.get('rounded_edges')));
  w.set('shape_front', bool(w.get('above_content')));

  // Text.
  w.color('title_color', 'title_color');
  w.typography('title_typography', 'title_typography');
  w.color('words_color', 'words_color');
  w.typography('words_typography', 'words_typography');
  for (const k of ['highlighted_text_background_color', 'highlighted_text_color']) {
    if (w.has(k)) w.note('The typing selection colors are not available in Zadex.');
    w.consume(k);
  }
  for (const k of ['text_stroke_text_stroke_type', 'title_text_shadow_text_shadow_type', 'animated_text_stroke_text_stroke_type', 'animated_text_shadow_text_shadow_type']) {
    if (bool(w.raw(k))) w.note('Text stroke / text shadow of the headline are not available in Zadex.');
    w.consume(k.replace(/_type$/, ''), k.replace(/_text_stroke_type$/, '_stroke_color'));
  }
  for (const k of ['before_text', 'highlighted_text', 'rotating_text', 'after_text']) {
    if (w.dynamicRef(k)) w.note(`"${k}" was bound to a dynamic tag; the static value was kept.`);
  }
  return w.finish();
});
