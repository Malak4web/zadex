import { registerWidget } from '../registry';
import { bool, isBlank, slider, url } from '../values';
import { markPro } from './_pro';
import { isObj, itemIdFor, repeaterItems, withGlobalDefaults } from './_shared';
import { colorOf, getBool, getStr } from './_pro-posts';

/**
 * Elementor Pro `video-playlist` -> Zadex `video-playlist`, verified against Pro 3.33.2: `tabs` repeater {`type`
 * youtube (default) | vimeo | hosted | section, `youtube_url`, `vimeo_url`, `is_external_url` + `external_url` /
 * `hosted_url` (media), `title`, `duration`, `thumbnail`, `inner_tab_is_content_visible` + `inner_tab_content_1/2`},
 * `playlist_title` (Playlist), `playlist_title_tag`, `show_video_count` (yes), `show_duration` (yes),
 * `show_thumbnail` (yes), `autoplay_on_load`, `autoplay_next` (off), `show_watched_indication`, `lazy_load`,
 * `show_image_overlay`, `tabs_alignment` ("Video position" end = list first), `layout_height`; style
 * `playlist_name_*`, `videos_amount_*`, `normal_*` / `active_*` items (no hover state; active color #556068),
 * `section_*`, `inner_tab_*`. Pro's light list (white, 33% wide, #f1f2f3 active row) is written explicitly because
 * the Zadex list is dark.
 */
registerWidget('video-playlist', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    playlist_name_color: 'globals/colors?id=text',
    normal_color: 'globals/colors?id=text',
    normal_typography_typography: 'globals/typography?id=text',
    normal_duration_color: 'globals/colors?id=text',
    active_color: 'globals/colors?id=text',
    active_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'video-playlist');
  markPro(w);

  // Videos. Section rows (`type: section`) are headings inside the list: no Zadex equivalent.
  let sections = 0;
  let innerTabs = false;
  const videos: Array<Record<string, unknown>> = [];
  repeaterItems(w.raw('tabs')).forEach((item, i) => {
    const type = String(item.type ?? 'youtube');
    if (type === 'section') {
      sections++;
      return;
    }
    if (bool(item.inner_tab_is_content_visible)) innerTabs = true;
    let src = 'youtube';
    let link = '';
    if (type === 'vimeo') {
      src = 'vimeo';
      link = String(item.vimeo_url ?? '');
    } else if (type === 'hosted') {
      src = 'hosted';
      link = bool(item.is_external_url) ? url(item.external_url)?.url ?? '' : ctx.media(item.hosted_url)?.url ?? '';
    } else link = String(item.youtube_url ?? '');
    const thumb = ctx.media(isObj(item.thumbnail) ? item.thumbnail : undefined);
    videos.push({
      _id: itemIdFor(ctx, el, item, i),
      title: typeof item.title === 'string' ? item.title : 'Title',
      source: src,
      url: link,
      duration: typeof item.duration === 'string' ? item.duration : '',
      thumbnail: thumb ?? { id: 0, url: '', alt: '' },
    });
  });
  w.set('videos', videos);
  if (!videos.length) w.note('The playlist has no videos.');
  if (sections) {
    w.note(`${sections} section heading(s) of the playlist are not available in Zadex and were left out.`);
    w.status('partial');
  }
  if (innerTabs) {
    w.note('The per-video content tabs below the player are not available in Zadex.');
    w.status('partial');
  }
  w.consume('inner_tab_*', 'section_*');

  // List.
  w.set('heading', getStr(w, 'playlist_title'));
  w.consume('playlist_title_tag', 'tabs_direction');
  w.set('show_thumbnails', getBool(w, 'show_thumbnail'));
  w.set('show_duration', getBool(w, 'show_duration'));
  if (getBool(w, 'show_video_count')) w.note('The video count next to the heading is not available in Zadex.');
  // "Video position": end (default) puts the video after the list, i.e. the list at the start.
  w.set('list_position', getStr(w, 'tabs_alignment') === 'start' ? 'end' : 'start');
  w.set('list_width', { size: 33, unit: '%' });
  if (slider(w.raw('layout_height'))) w.note('A fixed playlist height is not available in Zadex; the player keeps a 16:9 ratio.');
  w.consume('layout_height*');

  // Playback.
  w.set('autoplay_next', getBool(w, 'autoplay_next'));
  if (getBool(w, 'autoplay_on_load')) w.note('Autoplay on page load is not available in Zadex.');
  if (getBool(w, 'show_image_overlay')) w.note('The image overlay shown before playback is not available in Zadex.');
  if (getBool(w, 'show_watched_indication')) w.note('The "watched" indication is not available in Zadex.');
  w.consume('lazy_load', 'image_overlay*', 'show_play_icon', 'play_icon', 'watched_icon');

  // Style: Pro's light list.
  const text = colorOf(w, 'normal_color');
  w.set('list_bg', colorOf(w, 'normal_background') ?? '#ffffff');
  w.set('item_bg', colorOf(w, 'normal_background') ?? '#ffffff');
  w.set('item_hover_bg', '#f1f2f3');
  w.set('item_active_bg', colorOf(w, 'active_background') ?? '#f1f2f3');
  w.set('item_color', text ?? '#1f2124');
  w.set('item_hover_color', text ?? '#1f2124');
  w.set('item_active_color', colorOf(w, 'active_color') ?? '#556068');
  w.set('duration_color', colorOf(w, 'normal_duration_color') ?? text ?? '#1f2124');
  w.set('heading_color', colorOf(w, 'playlist_name_color') ?? '#1f2124');
  w.typography('playlist_name_typography', 'heading_typography');
  w.typography('normal_typography', 'item_typography');
  if (!isBlank(w.raw('playlist_name_background'))) w.note('The playlist heading background color is not available in Zadex.');
  if (!isBlank(w.raw('normal_separator_style')) || !isBlank(w.raw('active_separator_style'))) w.note('Separators between playlist items are not available in Zadex.');
  w.consume(
    'videos_amount_*',
    'active_typography_*',
    'active_duration_*',
    'normal_duration_typography_*',
    'normal_icon_*',
    'active_icon_*',
    'normal_separator_*',
    'active_separator_*',
    'playlist_name_background',
  );
  return w.finish();
});
