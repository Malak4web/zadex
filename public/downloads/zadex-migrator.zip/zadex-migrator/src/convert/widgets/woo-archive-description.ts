import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { markPro } from './_pro';
import { colorAlt, typographyAlt } from './_marketing';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-archive-description` (the product category / tag description on shop archives) ->
 * Zadex `text` whose content is bound to the Zadex `archive-description` dynamic tag (`get_the_archive_description()`,
 * same source). Verified against Elementor Pro 3.33.2: `text_align` R (left | center | right | justify),
 * `text_color`, `text_typography` (no global defaults). The Zadex text widget does not need WooCommerce, so the
 * guard only checks the Zadex widget.
 */
registerWidget('woocommerce-archive-description', (source, ctx) => {
  const off = wooGuard(source, ctx, 'text');
  if (off) return off;
  const w = ctx.writer(source, 'text');
  markPro(w);
  w.set('content', { __dynamic: { tag: 'archive-description', settings: {}, before: '', after: '', fallback: '' } });
  w.map('text_align', 'align', textAlign(ctx));
  colorAlt(w, ['text_color'], 'color');
  typographyAlt(w, ['text_typography'], 'typography');
  return w.finish();
});
