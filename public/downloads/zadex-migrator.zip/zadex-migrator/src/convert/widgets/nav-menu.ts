import { registerWidget } from '../registry';
import type { ElementWriter } from '../context';
import { deviceKeys } from '../responsive';
import { isBlank, slider } from '../values';
import { only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { collapseBreakpoint, isObj, menuAlign, paddingFromSliders, pstr } from './_pro-site';

/**
 * Elementor Pro `nav-menu` -> Zadex `nav-menu`.
 *
 * Verified against Elementor Pro 3.33.2 (elementor-pro-controls.json, modules/nav-menu/widgets/nav-menu.php).
 * Elementor stores the menu SLUG in `menu` (a select of `wp_get_nav_menus()` slugs with `save_default`, so it is
 * always stored; the control only exists on sites with menus and is absent from the dump). Zadex needs the menu term
 * id (`render.php` casts it to int, `optionsFrom: "menus"` lists term ids), so the slug is resolved through
 * `source.menus` (slug -> id, sent by the source endpoint). Numeric values are kept.
 */

const POINTERS: Record<string, string> = {
  none: 'none',
  underline: 'underline',
  overline: 'overline',
  'double-line': 'underline',
  framed: 'underline',
  background: 'background',
  text: 'none',
};

/**
 * Submenu indicator: `submenu_icon` icon control (default `fas fa-caret-down`); menus saved with Pro < 3.0 may still
 * store the legacy `indicator` select (none | classic | chevron | angle | plus), which wins when present.
 */
function indicator(w: ElementWriter): string {
  const legacy = w.raw('indicator');
  const icon = w.get('submenu_icon');
  if (typeof legacy === 'string' && legacy !== '') {
    if (legacy === 'none') return 'none';
    if (legacy === 'plus') return 'plus';
    if (!['classic', 'chevron', 'angle'].includes(legacy)) w.note(`Submenu indicator "${legacy}" is shown as a chevron.`);
    return 'chevron';
  }
  if (isObj(icon)) {
    const v = String(icon.value ?? '');
    if (v === '' && icon.library !== 'svg') return 'none';
    if (/plus/.test(v)) return 'plus';
    if (!/(caret|chevron|angle)/.test(v)) w.note('The custom submenu icon is shown as a chevron.');
    return 'chevron';
  }
  return 'chevron';
}

registerWidget('nav-menu', (source, ctx) => {
  // Pro's global defaults (nav-menu.php `global` args).
  const el = withGlobalDefaults(source, ctx, {
    color_menu_item: 'globals/colors?id=text',
    color_menu_item_hover: 'globals/colors?id=accent',
    pointer_color_menu_item_hover: 'globals/colors?id=accent',
    menu_typography_typography: 'globals/typography?id=primary',
    dropdown_typography_typography: 'globals/typography?id=accent',
  });
  const w = ctx.writer(el, 'nav-menu');
  markPro(w);

  // Menu: slug -> term id.
  const menu = w.raw('menu');
  const slug = menu === undefined || menu === null ? '' : String(menu);
  const menus = ctx.source.menus;
  if (/^\d+$/.test(slug)) w.set('menu', slug);
  else if (slug && menus && menus[slug]) w.set('menu', String(menus[slug]));
  else {
    w.set('menu', '');
    if (slug) w.note(`Menu "${slug}" was not found on this site; choose the menu in the Zadex widget.`);
    else w.note('No menu was selected in Elementor (Elementor shows the first menu); choose the menu in the Zadex widget.');
    w.status('partial');
  }

  // Layout + alignment.
  const layout = pstr(w, 'layout', 'horizontal');
  w.set('layout', ['horizontal', 'vertical', 'dropdown'].includes(layout) ? layout : 'horizontal');
  w.map('align_items', 'align', only(menuAlign(Boolean(ctx.source.rtl)), ['flex-start', 'center', 'flex-end', 'space-between']));
  if (layout === 'vertical') w.consume('align_items*');

  // Pointer + animation.
  const pointer = pstr(w, 'pointer', 'underline');
  w.set('pointer', POINTERS[pointer] ?? 'underline');
  if (pointer === 'double-line') w.note('The double-line pointer is shown as an underline.');
  if (pointer === 'framed') w.note('The framed pointer is shown as an underline.');
  if (pointer === 'text') w.note('Text pointer animations are not available; only the hover color is kept.');
  const animKey = { framed: 'animation_framed', background: 'animation_background', text: 'animation_text' }[pointer] ?? 'animation_line';
  const anim = w.raw(animKey);
  w.consume('animation_line', 'animation_framed', 'animation_background', 'animation_text');
  if (typeof anim === 'string' && anim !== '' && anim !== 'none' && anim !== 'fade') w.note(`Pointer animation "${anim}" is not available in Zadex.`);

  w.set('indicator', indicator(w));

  // Mobile dropdown / toggle.
  const dropdown = pstr(w, 'dropdown', 'tablet');
  w.set('collapse', collapseBreakpoint(w, dropdown));
  w.set('panel', 'dropdown');
  // `toggle`: burger (default) | '' (no toggle: the dropdown is always open on mobile).
  const toggle = w.raw('toggle');
  if (toggle === '') w.note('Elementor shows the mobile dropdown without a toggle button; Zadex always shows the toggle.');
  if (w.raw('full_width') === 'yes') w.note('The full-width (stretched) mobile dropdown is not carried over.');
  // `toggle_align` left | center (default) | right.
  w.map('toggle_align', 'toggle_align', only(menuAlign(Boolean(ctx.source.rtl)), ['flex-start', 'center', 'flex-end']));
  // `text_align` aside (default) | center.
  if (w.raw('text_align') === 'center') w.note('Centered mobile dropdown text is not carried over.');
  for (const k of ['toggle_icon_normal', 'toggle_icon_active']) {
    const v = w.raw(k);
    if (isObj(v) && !isBlank(v.value)) w.note('Custom toggle icons are not available in Zadex.');
  }
  const toggleAnim = w.raw('toggle_icon_hover_animation');
  if (typeof toggleAnim === 'string' && toggleAnim !== '') w.note(`Toggle hover animation "${toggleAnim}" is not available in Zadex.`);

  // Main menu styles.
  w.typography('menu_typography', 'typography');
  w.color('color_menu_item', 'link_color');
  w.color('color_menu_item_hover', 'link_color_hover');
  w.color('color_menu_item_active', 'link_color_active');
  w.color('pointer_color_menu_item_hover', 'pointer_color');
  // With the background pointer the hover text color is `color_menu_item_hover_pointer_bg` (default #fff) and
  // `color_menu_item_hover` is inactive.
  if (pointer === 'background') w.color('color_menu_item_hover_pointer_bg', 'link_color_hover');
  else w.raw('color_menu_item_hover_pointer_bg');
  if (w.has('pointer_color_menu_item_active')) w.note('A separate active pointer color is not supported; the hover pointer color is used.');
  w.raw('pointer_color_menu_item_active');
  for (const [key, bp] of deviceKeys('pointer_width')) {
    const s = slider(w.raw(key));
    if (!s) continue;
    if (bp) w.note('Pointer width: per-device values are not supported by this Zadex control; the desktop value is used.');
    else w.set('pointer_width', s);
  }
  // Elementor: `.elementor-nav-menu--main .elementor-item { padding: 13px 20px }`.
  paddingFromSliders(w, 'padding_vertical_menu_item', 'padding_horizontal_menu_item', 'item_padding', [13, 20]);
  w.slider('menu_space_between', 'item_gap');
  if (w.has('border_radius_menu_item')) w.note('The menu item corner radius is not carried over.');
  w.consumeResponsive('border_radius_menu_item');
  if (layout === 'horizontal' && w.raw('nav_menu_divider') === 'yes') w.note('Dividers between menu items are not carried over.');
  w.consume('nav_menu_divider*');

  // Dropdown (submenus). Elementor's CSS defaults (widget-nav-menu.css): white panel, #33373d text, hover #3f444b / #fff.
  w.typography('dropdown_typography', 'sub_typography');
  w.color('color_dropdown_item', 'sub_color');
  w.color('color_dropdown_item_hover', 'sub_color_hover');
  w.color('background_color_dropdown_item', 'sub_bg');
  w.color('background_color_dropdown_item_hover', 'sub_bg_hover');
  const subDefaults: Record<string, string> = { sub_color: '#33373d', sub_color_hover: '#ffffff', sub_bg: '#ffffff', sub_bg_hover: '#3f444b' };
  for (const [k, v] of Object.entries(subDefaults)) if (w.settings[k] === undefined) w.set(k, v);
  for (const k of ['color_dropdown_item_active', 'background_color_dropdown_item_active']) {
    if (w.has(k)) w.note('Active dropdown item colors use the hover colors in Zadex.');
    w.raw(k);
  }
  // Mobile panel shares the dropdown colors in Elementor.
  if (typeof w.settings.sub_bg === 'string') w.set('panel_bg', w.settings.sub_bg);
  if (typeof w.settings.sub_color === 'string') w.set('panel_color', w.settings.sub_color);
  w.border('dropdown_border', 'sub_border', 'dropdown_border_radius');
  for (const k of Object.keys(w.settings)) if (k.startsWith('sub_border@')) delete w.settings[k];
  w.boxShadow('dropdown_box_shadow', 'sub_shadow');
  const hasSubPad = !isBlank(w.raw('padding_vertical_dropdown_item')) || !isBlank(w.raw('padding_horizontal_dropdown_item'));
  if (hasSubPad) {
    paddingFromSliders(w, 'padding_vertical_dropdown_item', 'padding_horizontal_dropdown_item', 'sub_padding');
    for (const k of Object.keys(w.settings)) if (k.startsWith('sub_padding@')) {
      delete w.settings[k];
      w.note('Dropdown padding: per-device values are not supported by this Zadex control; the desktop value is used.');
    }
  } else w.consume('padding_vertical_dropdown_item*', 'padding_horizontal_dropdown_item*');
  if (w.has('dropdown_top_distance')) w.note('The dropdown distance is not carried over.');
  w.consumeResponsive('dropdown_top_distance');
  if (w.has('dropdown_divider_border')) w.note('Dropdown item dividers are not carried over.');
  w.consume('dropdown_divider_*');

  // Toggle button.
  w.color('toggle_color', 'toggle_color');
  w.color('toggle_background_color', 'toggle_bg');
  for (const [key, bp] of deviceKeys('toggle_size')) {
    const s = slider(w.raw(key));
    if (s && !bp) w.set('toggle_size', s);
  }
  for (const k of ['toggle_color_hover', 'toggle_background_color_hover', 'toggle_border_width', 'toggle_border_radius']) {
    if (w.has(k)) w.note(`Toggle "${k}" is not supported by the Zadex menu toggle.`);
    w.raw(k);
  }
  return w.finish();
});
