import { registerWidget } from '../registry';
import { dimensions, slider } from '../values';
import { markPro, firstOf } from './_pro';
import { proSwitch, proText } from './_pro-content';
import { desktopOnly } from './_shared';

/**
 * Elementor Pro `progress-tracker` -> Zadex `reading-progress`. Keys verified against Elementor Pro 3.33.2 (defaults
 * from elementor-defaults.json): `type` horizontal|circular (horizontal), `relative_to`
 * entire_page|post_content|selector (entire_page), `selector`, `direction` ltr|rtl, `percentage` (no),
 * `percentage_position` rtl|ltr; style horizontal: `horizontal_color_*` (progress background group),
 * `horizontal_border_style|width|color|radius` (progress border), `horizontal_background_color_*` (tracker background
 * group), `horizontal_height`, `horizontal_tracker_border_style|width|color|radius`, `box_shadow_*`,
 * `horizontal_padding`; circular: `circular_size`, `circular_color`, `circular_width`, `circular_background_color`,
 * `circular_background_width`, `align`; `percentage_color`, `percentage_typography`, `percentage_text_shadow_*`.
 * Elementor shows the tracker where the widget sits (usually in a sticky header); the Zadex bar is pinned to the top of
 * the viewport.
 */
registerWidget('progress-tracker', (el, ctx) => {
  const w = ctx.writer(el, 'reading-progress');
  markPro(w);

  const type = proText(w, 'type', 'horizontal');
  const circular = type === 'circular';
  if (circular) {
    w.note('The circular progress tracker is not available in Zadex; a horizontal bar is used.');
    w.status('partial');
  }
  w.set('position', 'top');
  w.note('Elementor shows the tracker where the widget is placed; the Zadex bar is pinned to the top of the window.');

  const relative = proText(w, 'relative_to', 'entire_page');
  w.set('target', relative === 'selector' ? proText(w, 'selector').trim() : '');
  if (relative === 'post_content') {
    w.note('"Post content" progress follows the whole page in Zadex (set a target selector to restrict it).');
    w.status('partial');
  }
  w.consume('selector');
  const dir = w.raw('direction');
  if (typeof dir === 'string' && dir !== '' && dir !== (ctx.source.rtl ? 'rtl' : 'ltr')) w.note('The fill direction follows the site direction in Zadex.');

  const showPercent = proSwitch(w, 'percentage');
  w.set('show_percent', showPercent);
  if (showPercent && w.has('percentage_position')) w.note('The percentage position is not carried over.');
  w.consume('percentage_position');

  if (circular) {
    w.color('circular_color', 'bar_color');
    w.color('circular_background_color', 'track_color');
    const width = slider(w.raw('circular_width'));
    if (width) w.set('height', { size: width.size, unit: 'px' });
    w.consume('circular_*', 'align*');
  } else {
    w.color('horizontal_color_color', 'bar_color');
    w.color('horizontal_background_color_color', 'track_color');
    if (w.raw('horizontal_color_background') === 'gradient' || w.raw('horizontal_background_color_background') === 'gradient') {
      w.note('Gradient progress / tracker backgrounds are not available in Zadex; the first color is used.');
    }
    const h = slider(w.raw('horizontal_height'));
    if (h) w.set('height', { size: h.size, unit: 'px' });
    // Tracker (outer) radius, else the progress radius.
    const radius = dimensions(firstOf(w, 'horizontal_tracker_border_radius', 'horizontal_border_radius'));
    if (radius) w.set('radius', { size: radius.top, unit: 'px' });
    if (proText(w, 'horizontal_border_style', 'none') !== 'none' || proText(w, 'horizontal_tracker_border_style', 'none') !== 'none') w.note('Progress / tracker borders are not available in Zadex.');
    if (w.raw('box_shadow_box_shadow_type') === 'yes' || w.has('horizontal_padding')) w.note('The tracker shadow and padding are not available in Zadex.');
  }
  w.consumeResponsive('horizontal_height');
  if (showPercent) {
    w.color('percentage_color', 'percent_color');
    w.typography('percentage_typography', 'percent_typography');
    desktopOnly(w, 'percent_typography');
  } else w.consume('percentage_color', 'percentage_typography*');
  w.consume('circular_*', 'horizontal_*', 'box_shadow*', 'percentage_text_shadow_*', 'align');
  return w.finish();
});
