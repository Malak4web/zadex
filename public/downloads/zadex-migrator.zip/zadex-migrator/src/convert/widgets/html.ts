import { registerWidget } from '../registry';

/** Elementor `html` -> Zadex `html`. Zadex filters the code with wp_kses_post (no scripts, styles or handlers). */
registerWidget('html', (el, ctx) => {
  const w = ctx.writer(el, 'html');
  const html = String(w.get('html') ?? '');
  w.set('html', html);
  if (/<script[\s>]/i.test(html)) {
    w.note('The code contains <script> tags; Zadex removes scripts from HTML widgets when saving (wp_kses_post).');
    w.status('partial');
  }
  if (/<style[\s>]/i.test(html) || /\son[a-z]+\s*=/i.test(html) || /<iframe[\s>]/i.test(html)) {
    w.note('The code contains style tags, inline event handlers or iframes, which Zadex may filter out (wp_kses_post).');
    w.status('partial');
  }
  return w.finish();
});
