import { registerWidget } from '../registry';
import { bool, dimensions, isBlank, num, slider, url } from '../values';
import type { BreakpointKey } from '../types';
import { desktopOnly, galleryImages, imageSize, naturalRatio } from './_media-support';

const toInt = (v: unknown): number | undefined => {
  const n = num(v);
  return typeof n === 'number' && n > 0 ? Math.round(n) : undefined;
};

/** Device keys Elementor's carousel walks from large to small (widescreen is min-width and inherits desktop). */
const SMALLER: Array<{ suffix: string; bp: BreakpointKey }> = [
  { suffix: '_laptop', bp: 'laptop' },
  { suffix: '_tablet_extra', bp: 'tablet_large' },
  { suffix: '_tablet', bp: 'tablet' },
  { suffix: '_mobile_extra', bp: 'mobile_large' },
  { suffix: '_mobile', bp: 'mobile' },
];

/**
 * Elementor `image-carousel` (Swiper) -> Zadex `image-carousel`. Slides per view follow Elementor's runtime
 * defaults (3 on desktop, 2 on tablet, 1 on mobile unless set). Without custom spacing Elementor puts no gap
 * between slides. Images keep their natural ratio except the square-cropped thumbnail size.
 */
registerWidget('image-carousel', (el, ctx) => {
  const w = ctx.writer(el, 'image-carousel');
  w.consume('carousel_name', 'lazyload');
  const images = galleryImages(ctx, w.get('carousel'));
  w.set('images', images);
  if (!images.length) w.note('The carousel has no images.');
  const size = String(w.get('thumbnail_size') ?? 'thumbnail');
  w.set('image_size', imageSize(w, 'thumbnail_size'));
  w.set('ratio', size === 'thumbnail' ? '1/1' : naturalRatio(images, size));
  if (w.get('image_stretch') !== 'yes') w.note('Zadex stretches slide images to the slide width.');

  // Slides to show / scroll (Elementor runtime defaults made explicit).
  const desktop = toInt(w.get('slides_to_show')) ?? 3;
  w.set('slides_to_show', desktop);
  w.consume('slides_to_show_widescreen');
  for (const { suffix, bp } of SMALLER) {
    const v = toInt(w.raw(`slides_to_show${suffix}`));
    const fallback = bp === 'mobile' ? 1 : bp === 'tablet' ? (desktop === 1 ? 1 : 2) : undefined;
    const value = v ?? fallback;
    if (value !== undefined) w.set('slides_to_show', value, { bp });
  }
  w.set('slides_to_scroll', toInt(desktopOnly(w, 'slides_to_scroll')) ?? 1);
  w.consume('slides_to_scroll_widescreen');

  // Navigation.
  const nav = String(w.get('navigation') ?? 'both');
  w.set('arrows', nav === 'both' || nav === 'arrows');
  w.set('dots', nav === 'both' || nav === 'dots');

  // Links / captions.
  const linkTo = String(w.get('link_to') ?? 'none');
  w.set('link', ['none', 'file', 'custom'].includes(linkTo) ? linkTo : 'none');
  if (linkTo === 'custom') w.set('custom_link', url(w.get('link')) ?? { url: '', target: '', nofollow: false });
  else w.consume('link');
  if (linkTo === 'file' && w.get('open_lightbox') === 'no') w.note('Zadex opens file links of the carousel in its lightbox.');
  else w.consume('open_lightbox');
  const caption = String(w.get('caption_type') ?? '');
  w.set('captions', caption !== '');
  if (caption === 'title' || caption === 'description') {
    w.note(`Zadex shows the attachment caption, not the ${caption}.`);
    w.status('partial');
  }

  // Autoplay / motion.
  const autoplay = bool(w.get('autoplay'));
  w.set('autoplay', autoplay);
  if (autoplay) {
    w.set('pause_on_hover', bool(w.get('pause_on_hover')));
    const delay = toInt(w.get('autoplay_speed'));
    if (delay) w.set('autoplay_speed', delay);
    if (!bool(w.get('pause_on_interaction'))) w.note('Zadex always pauses autoplay after an interaction.');
  } else {
    w.consume('pause_on_hover', 'autoplay_speed', 'pause_on_interaction');
  }
  w.set('loop', bool(w.get('infinite')));
  const speed = toInt(w.get('speed'));
  if (speed) w.set('speed', speed);
  if (w.get('effect') === 'fade' && desktop === 1) {
    w.note('The fade effect is not available in Zadex; slides slide.');
    w.status('partial');
  } else w.consume('effect');
  if (w.get('direction') === 'rtl') w.note('The right-to-left slide direction follows the page direction in Zadex.');

  // Spacing between slides.
  if (w.get('image_spacing') === 'custom') {
    const gap = slider(desktopOnly(w, 'image_spacing_custom'));
    w.set('gap', gap ?? { size: 20, unit: 'px' });
  } else {
    w.consume('image_spacing_custom*');
    w.set('gap', { size: 0, unit: 'px' });
  }

  // Arrows and dots.
  if (w.get('arrows_position') === 'outside' && nav !== 'dots' && nav !== 'none') w.note('Arrows are placed inside the carousel in Zadex.');
  else w.consume('arrows_position');
  if (w.get('dots_position') === 'inside' && nav !== 'arrows' && nav !== 'none') w.note('Dots are placed below the carousel in Zadex.');
  else w.consume('dots_position');
  w.slider('arrows_size', 'arrow_size');
  w.color('arrows_color', 'arrow_color');
  const dotSize = slider(desktopOnly(w, 'dots_size'));
  if (dotSize) w.set('dot_size', dotSize);
  w.color('dots_color', 'dot_active_color');
  w.color('dots_inactive_color', 'dot_color');

  // Image.
  const radius = dimensions(desktopOnly(w, 'image_border_radius'));
  if (radius) w.set('image_radius', radius);
  const borderStyle = w.raw('image_border_border');
  if (!isBlank(borderStyle) && borderStyle !== 'none') {
    w.note('Image borders are not available on the Zadex carousel.');
    w.status('partial');
  }
  w.consume('image_border_border', 'image_border_color', 'image_border_width*');

  // Captions.
  w.color('caption_text_color', 'caption_color');
  w.typography('caption_typography', 'caption_typography');
  return w.finish();
});
