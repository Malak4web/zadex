import { registerWidget } from '../registry';
import { url } from '../values';
import { markPro } from './_pro';
import { paymentButton, proNumber, proSwitch, proText, proVal } from './_pro-content';

const TYPES: Record<string, string> = { checkout: 'buy', donation: 'donate', subscription: 'subscribe' };
const PERIODS: Record<string, string> = { days: 'D', weeks: 'W', months: 'M', years: 'Y' };
const CURRENCIES = ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY', 'CHF', 'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'NZD', 'SGD', 'HKD', 'MXN', 'BRL', 'ILS', 'CNY', 'MYR', 'PHP', 'THB', 'TWD'];

const money = (v: unknown): string | undefined => {
  const n = proNumber(v);
  return n !== undefined ? n.toFixed(2) : undefined;
};

/**
 * Elementor Pro `paypal-button` -> Zadex `paypal-button` (PayPal Standard form). Keys verified against Elementor Pro
 * 3.33.2: `merchant_account` simple|advanced (hidden, simple), `email`, `sdk_token` (advanced), `type`
 * checkout|donation|subscription (checkout), `product_name`, `product_sku`, `product_price` ("0.00", not for
 * donations), `donation_type` any|fixed (fixed) + `donation_amount` ("1"), `currency` (USD), `billing_cycle`
 * days|weeks|months|years (months), `auto_renewal` (yes), `quantity` (1), `shipping_price` (0), `tax_type`
 * ''|percentage + `tax_rate`, `redirect_after_success`, `sandbox_mode` (no) + `sandbox_email`, `open_in_new_window`
 * (yes), `custom_messages` + `error_message_global` / `error_message_payment`, plus the payment button controls
 * (`paymentButton()`).
 */
registerWidget('paypal-button', (el, ctx) => {
  const w = ctx.writer(el, 'paypal-button');
  markPro(w);

  const type = proText(w, 'type', 'checkout');
  w.set('type', TYPES[type] ?? 'buy');
  const sandbox = proSwitch(w, 'sandbox_mode');
  w.set('sandbox', sandbox);
  const live = proText(w, 'email').trim();
  const test = proText(w, 'sandbox_email').trim();
  const email = sandbox && test !== '' ? test : live;
  w.set('business', email);
  if (sandbox && test === '' && live !== '') w.note('No sandbox account email was set; the live account email is used in sandbox mode.');
  if (proText(w, 'merchant_account', 'simple') === 'advanced') {
    w.note('The PayPal SDK token (advanced merchant account) mode is not available; Zadex uses PayPal Standard with the account email.');
    w.status('partial');
  }
  if (email === '') w.note('No PayPal account email was set; add one before using the button.');
  w.consume('sdk_token');

  w.set('item_name', proText(w, 'product_name'));
  w.set('item_number', proText(w, 'product_sku'));
  if (type === 'donation') {
    const donation = proText(w, 'donation_type', 'fixed');
    if (donation === 'any') {
      w.set('amount', '');
      w.note('"Any amount" donation: no amount is sent, so the donor enters it on PayPal.');
    } else w.set('amount', money(proVal(w, 'donation_amount')) ?? '1.00');
    w.consume('product_price');
  } else {
    w.set('amount', money(proVal(w, 'product_price')) ?? '0.00');
    w.consume('donation_type', 'donation_amount');
  }
  const currency = proText(w, 'currency', 'USD').toUpperCase();
  w.set('currency', CURRENCIES.includes(currency) ? currency : 'USD');
  if (!CURRENCIES.includes(currency)) w.note(`Currency "${currency}" is not offered by the Zadex PayPal button; USD is used.`);

  if (type === 'checkout') {
    const qty = proNumber(proVal(w, 'quantity', 1));
    w.set('quantity', qty !== undefined && qty > 0 ? Math.round(qty) : 1);
    const shipping = proNumber(proVal(w, 'shipping_price'));
    if (shipping !== undefined && shipping > 0) {
      w.note('A fixed shipping price is not available in Zadex (shipping is set in the PayPal account).');
      w.status('partial');
    }
    if (proText(w, 'tax_type') === 'percentage') {
      w.note('The tax rate is not available in Zadex (taxes are set in the PayPal account).');
      w.status('partial');
    }
  }
  w.consume('quantity', 'shipping_price', 'tax_type', 'tax_rate');
  if (type === 'subscription') {
    w.set('period', PERIODS[proText(w, 'billing_cycle', 'months')] ?? 'M');
    w.set('period_count', 1);
    // Auto renewal on (Pro default) = bill until cancelled (0); off = a single cycle.
    w.set('billing_cycles', proSwitch(w, 'auto_renewal', true) ? 0 : 1);
  } else w.consume('billing_cycle', 'auto_renewal');

  w.set('new_tab', proSwitch(w, 'open_in_new_window', true));
  const success = url(w.raw('redirect_after_success'));
  if (success) w.set('return_url', success);
  if (proSwitch(w, 'custom_messages')) w.note('Custom error messages are not used by the Zadex PayPal button (PayPal shows its own).');
  w.consume('error_message_*');

  paymentButton(w, ctx);
  return w.finish();
});
