import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { dimensions, num, slider } from '../values';
import { deviceKeys } from '../responsive';
import { desktopOnly, galleryImages, imageSize, naturalRatio } from './_media-support';

/**
 * Elementor `image-gallery` (WordPress gallery shortcode) -> Zadex `gallery`. Elementor's stylesheet shows two
 * columns below 768px (one below 480px) whatever the desktop count, so one phone column is written unless the
 * page sets one. Elementor has no hover effect and keeps the natural image ratio (thumbnails are square crops).
 */
registerWidget('image-gallery', (el, ctx) => {
  const w = ctx.writer(el, 'gallery');
  const images = galleryImages(ctx, w.get('wp_gallery'));
  w.set('images', images);
  if (!images.length) w.note('The gallery has no images.');
  const size = String(w.get('thumbnail_size') ?? 'thumbnail');
  w.set('image_size', imageSize(w, 'thumbnail_size'));
  w.set('ratio', size === 'thumbnail' ? '1/1' : naturalRatio(images, size));
  w.set('hover_effect', 'none');

  // Columns (Elementor default 4, from w.get). Elementor's CSS forces 2 columns at 480-767px and 1 below 480px: Zadex's mobile
  // breakpoint covers both, so phones (below 480px) win: 1 column.
  let mobileSet = false;
  for (const [key, bp] of deviceKeys('gallery_columns')) {
    const n = num(bp ? w.raw(key) : w.get(key));
    if (typeof n !== 'number' || n < 1) continue;
    if (bp === 'mobile') mobileSet = true;
    w.set('columns', n, { bp });
  }
  if (!mobileSet) w.set('columns', 1, { bp: 'mobile' });

  // Links / order / captions.
  const link = String(w.get('gallery_link') ?? 'file');
  w.set('link', link === 'file' ? 'file' : 'none');
  if (link === 'attachment') {
    w.note('Links to attachment pages are not available in the Zadex gallery; images are not linked.');
    w.status('partial');
  }
  if (link === 'file' && w.get('open_lightbox') === 'no') w.note('Zadex opens file links of the gallery in its lightbox.');
  else w.consume('open_lightbox');
  if (w.get('gallery_rand') === 'rand') {
    w.note('Random image order is not available in Zadex; images keep their saved order.');
    w.status('partial');
  }
  const showCaption = w.get('gallery_display_caption') !== 'none';
  w.set('captions', showCaption ? 'caption' : 'none');

  // Spacing.
  if (w.get('image_spacing') === 'custom') {
    const s = slider(desktopOnly(w, 'image_spacing_custom'));
    const gap = typeof s?.size === 'number' ? s.size : 15;
    w.set('gap', { row: gap, column: gap, unit: s?.unit ?? 'px', linked: true });
  } else {
    w.consume('image_spacing_custom*');
    w.set('gap', { row: 10, column: 10, unit: 'px', linked: true });
  }

  // Image border / radius.
  w.border('image_border', 'image_border');
  const radius = dimensions(desktopOnly(w, 'image_border_radius'));
  if (radius) w.set('image_radius', radius);

  // Caption style.
  if (showCaption) {
    const align = String(desktopOnly(w, 'align') ?? 'center');
    const table = textAlign(ctx);
    const value = table[align];
    if (value && value !== 'justify') w.set('caption_align', value);
    else if (value === 'justify') w.note('Justified captions are not available in Zadex.');
    w.color('text_color', 'caption_color');
    w.typography('typography', 'caption_typography');
  } else {
    w.consume('align*', 'text_color', 'typography_*');
  }
  return w.finish();
});
