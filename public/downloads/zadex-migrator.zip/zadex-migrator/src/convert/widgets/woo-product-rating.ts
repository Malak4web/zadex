import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { only } from './_shared';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { flatColor, noteIfSet } from './_woo-product';
import { sliderAlt, typographyAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-rating` -> Zadex `product-rating`.
 * Verified against Elementor Pro 3.33.2: `star_color`, `empty_star_color`, `link_color`, `text_typography_*` (the
 * review link), `star_size` (slider, em), `space_between` (stars-to-link gap, em), `alignment` (R, left | center |
 * right | justify; justify spreads stars and link, no Zadex option).
 */
registerWidget('woocommerce-product-rating', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-rating');
  if (off) return off;
  const w = ctx.writer(source, 'product-rating');
  markPro(w);
  w.map('alignment', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  flatColor(w, ['star_color'], 'star_color');
  flatColor(w, ['empty_star_color'], 'empty_color');
  sliderAlt(w, ['star_size'], 'star_size', true, 'em');
  flatColor(w, ['link_color'], 'link_color');
  typographyAlt(w, ['text_typography'], 'link_typography');
  noteIfSet(w, ['space_between'], 'The space between the stars and the review link is not carried over.');
  return w.finish();
});
