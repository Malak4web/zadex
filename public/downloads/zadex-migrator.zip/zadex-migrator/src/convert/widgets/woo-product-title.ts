import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { url } from '../values';
import { HEADING_GLOBAL_DEFAULTS, headingStyle } from './heading';
import { desktopOnly, only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { dynamicTag, fixedSource, pickTag } from './_theme';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-product-title` -> Zadex `product-title`.
 * Verified against Elementor Pro 3.33.2: the widget extends the core Heading widget and stores the heading keys:
 * `title` (bound to the `woocommerce-product-title-tag` dynamic tag), `header_size` (Pro default h1, + div / span /
 * p), `link`, `align` (R, start | center | end | justify), `title_color` (global primary), `title_hover_color`,
 * `typography_*` (global primary), `text_shadow_*`, `text_stroke_*`, `size`, `blend_mode`. Defaults from `w.get()`.
 */
registerWidget('woocommerce-product-title', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-title');
  if (off) return off;
  const el = withGlobalDefaults(source, ctx, HEADING_GLOBAL_DEFAULTS);
  const w = ctx.writer(el, 'product-title');
  markPro(w);
  fixedSource(w, 'title', ['woocommerce-product-title-tag', 'post-title'], 'product title');
  w.set('tag', pickTag(w, String(w.get('header_size') || 'h1'), ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div']));

  // Zadex `link` links the title to the product; any Elementor link (static or dynamic) turns it on.
  const linkTag = dynamicTag(w, 'link');
  const link = url(w.raw('link'));
  if (linkTag || link?.url) {
    w.set('link', true);
    if (linkTag && ['post-url', 'woocommerce-product-url-tag'].includes(linkTag.name)) w.consumeDynamic('link');
    else w.note('The title link pointed elsewhere than the product; the Zadex title links to the product.');
  }
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  headingStyle(w, { color: 'color', typography: 'typography', textShadow: 'text_shadow' });
  desktopOnly(w, 'color');
  if (w.raw('text_stroke_text_stroke_type') === 'yes') w.note('The text stroke is not available on the Zadex product title.');
  w.consume('text_stroke_*');
  const blend = w.raw('blend_mode');
  if (typeof blend === 'string' && blend !== '') w.note(`Blend mode "${blend}" is not available on the Zadex product title.`);
  return w.finish();
});
