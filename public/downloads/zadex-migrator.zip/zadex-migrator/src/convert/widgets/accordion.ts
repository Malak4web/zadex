import { registerWidget } from '../registry';
import { convertCollapsible } from './_collapsible';

/**
 * Elementor classic `accordion` -> Zadex `accordion` (first item open, one open at a time: same as Elementor).
 * Details in _collapsible.ts.
 */
registerWidget('accordion', (el, ctx) => convertCollapsible(el, ctx, 'accordion'));
