import { registerWidget } from '../registry';
import { isBlank } from '../values';
import { markPro } from './_pro';
import { colorAlt, dimensionsAlt, typographyAlt } from './_marketing';
import { isObj, wooPageStyles } from './_woo-shop';
import { noteIfSet } from './_woo-product';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-my-account` -> Zadex `my-account` (WooCommerce's account page, same as Elementor).
 * Verified against Elementor Pro 3.33.2: `tabs` repeater (fixed rows: `field_key` dashboard | orders | downloads |
 * edit-address | edit-account | customer-logout, `field_label` = the default label, editable `tab_name` = the label
 * shown), `tabs_layout` vertical (default) | horizontal, `tabs_position`, `tabs_alignment`, `tabs_content_spacing`,
 * `customize_dashboard_check` / `customize_dashboard_select` (template id); tab styles `tabs_normal_color`,
 * `tabs_normal_background` group (`_color`), `tabs_hover_*`, `tabs_active_*`, `tabs_typography`, `tabs_padding`,
 * border / spacing / divider (noted), shared style section (`wooPageStyles`), table buttons (`tables_button_*`).
 */

/** Pro's default `tabs` rows (labels by key, in order). */
const DEFAULT_TABS: Array<[string, string]> = [
  ['dashboard', 'Dashboard'],
  ['orders', 'Orders'],
  ['downloads', 'Downloads'],
  ['edit-address', 'Addresses'],
  ['edit-account', 'Account Details'],
  ['customer-logout', 'Logout'],
];

registerWidget('woocommerce-my-account', (source, ctx) => {
  const off = wooGuard(source, ctx, 'my-account');
  if (off) return off;
  const w = ctx.writer(source, 'my-account');
  markPro(w);
  const layout = String(w.get('tabs_layout') || 'vertical');
  w.set('nav_position', layout === 'horizontal' ? 'top' : 'start');

  // A tab is renamed when its `tab_name` differs from its default label (`field_label`, else Pro's default row).
  const tabs = w.raw('tabs');
  if (Array.isArray(tabs)) {
    const defaults = new Map(DEFAULT_TABS);
    const renamed = tabs.filter((t, i) => {
      if (!isObj(t) || typeof t.tab_name !== 'string' || t.tab_name === '') return false;
      const def = typeof t.field_label === 'string' ? t.field_label : (defaults.get(String(t.field_key)) ?? DEFAULT_TABS[i]?.[1]);
      return t.tab_name !== def;
    });
    if (renamed.length) {
      w.note('Custom account menu labels are not available in Zadex; WooCommerce\'s own labels are shown.');
      w.status('partial');
    }
  }
  const dashboard = w.raw('customize_dashboard_select');
  if (w.get('customize_dashboard_check') === 'yes' || !isBlank(dashboard)) {
    w.note('The custom dashboard template is not carried over; WooCommerce\'s dashboard is shown.');
    w.status('partial');
  }
  noteIfSet(w, ['tabs_position', 'tabs_alignment', 'tabs_content_spacing'], 'The account menu position / alignment / spacing is not carried over.');

  colorAlt(w, ['tabs_normal_color'], 'nav_color');
  colorAlt(w, ['tabs_hover_color'], 'nav_color', 'hover');
  colorAlt(w, ['tabs_active_color'], 'nav_active_color');
  w.consume('tabs_normal_background_background', 'tabs_hover_background_background', 'tabs_active_background_background');
  colorAlt(w, ['tabs_normal_background_color'], 'nav_bg');
  colorAlt(w, ['tabs_hover_background_color'], 'nav_bg', 'hover');
  colorAlt(w, ['tabs_active_background_color'], 'nav_active_bg');
  typographyAlt(w, ['tabs_typography'], 'nav_typography');
  dimensionsAlt(w, ['tabs_padding'], 'nav_padding');
  noteIfSet(
    w,
    ['tabs_border_type', 'tabs_border_width', 'tabs_border_color', 'tabs_border_radius', 'tabs_hover_border_color', 'tabs_active_border_color', 'tabs_spacing', 'tabs_divider_color', 'tabs_divider_weight'],
    'The account menu borders / spacing / dividers are not carried over.',
  );
  wooPageStyles(w);
  return w.finish();
});
