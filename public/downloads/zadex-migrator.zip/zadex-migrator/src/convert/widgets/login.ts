import { registerWidget } from '../registry';
import { dimensions, isBlank, url } from '../values';
import { withGlobalDefaults } from './_shared';
import { colorRef } from '../globals';
import { markPro } from './_pro';
import { BUTTON_PRESETS, FIELD_PRESETS, isObj, mergeDefaults, noteDeviceValues, pbool, pstr, pxDims } from './_pro-site';

/**
 * Elementor Pro `login` -> Zadex `login`. Verified against Elementor Pro 3.33.2 (elementor-pro-controls.json and
 * modules/forms/widgets/login.php). Elementor renders with `get_settings_for_display()`, which nulls settings whose
 * control condition is not met: placeholders only exist while "Custom Label" is on, labels while labels are shown or
 * "Custom Label" is on.
 */
registerWidget('login', (source, ctx) => {
  // Pro's global defaults (login.php `global` args).
  const el = withGlobalDefaults(source, ctx, {
    links_color: 'globals/colors?id=text',
    label_color: 'globals/colors?id=text',
    label_typography_typography: 'globals/typography?id=text',
    field_text_color: 'globals/colors?id=text',
    field_typography_typography: 'globals/typography?id=text',
    button_background_color: 'globals/colors?id=accent',
    button_typography_typography: 'globals/typography?id=accent',
    message_color: 'globals/colors?id=text',
  });
  const w = ctx.writer(el, 'login');
  markPro(w);

  const custom = pbool(w, 'custom_labels');
  w.set('show_labels', pbool(w, 'show_labels'));
  // Labels: stored value or Pro's default (active while labels are shown or custom labels are on).
  w.set('user_label', pstr(w, 'user_label', 'Username or Email Address'));
  w.set('password_label', pstr(w, 'password_label', 'Password'));
  // Placeholders: inactive (no placeholder at all) unless custom labels are on; then stored or Pro's default.
  w.set('user_placeholder', custom ? String(w.get('user_placeholder') ?? '') : '');
  w.set('password_placeholder', custom ? String(w.get('password_placeholder') ?? '') : '');
  w.consume('user_placeholder', 'password_placeholder');
  w.set('button_text', pstr(w, 'button_text', 'Log In'));

  w.set('remember', pbool(w, 'show_remember_me'));
  w.set('remember_label', 'Remember Me');
  w.set('lost_password', pbool(w, 'show_lost_password'));
  w.set('lost_password_text', 'Lost your password?');
  // `show_register` is only registered when the site allows registration ("Anyone can register"; default on). It is
  // absent from the 3.33.2 dump (made on a site without registration), so its default is written here.
  const reg = w.raw('show_register');
  w.set('register', reg === undefined || reg === null ? true : reg === 'yes');
  w.set('register_text', 'Register');
  w.set('logged_in_message', pbool(w, 'show_logged_in_message'));
  w.set('logged_in_text', 'You are Logged in as {name}');
  w.set('logout_text', 'Logout');

  // Redirects (only when the switchers are on).
  const login = url(w.raw('redirect_url'));
  if (pbool(w, 'redirect_after_login') && login) w.set('redirect_login', login);
  const logout = url(w.raw('redirect_logout_url'));
  if (pbool(w, 'redirect_after_logout') && logout) w.set('redirect_logout', logout);

  // Button alignment (`start|center|end|stretch`, no default; older `left|center|right|justify`): only full width has
  // a Zadex equivalent.
  const align = pstr(w, 'align', '');
  w.set('button_width', align === 'justify' || align === 'stretch' ? 'full' : 'auto');
  if (align && !['justify', 'stretch', 'start', 'left'].includes(align)) w.note(`Button alignment "${align}" is not available in Zadex (start or full width only).`);
  noteDeviceValues(w, 'align', 'Button alignment');

  // Styles (row gap default 10px via `w.get`).
  w.slider('row_gap', 'form_gap');
  w.color('links_color', 'link_color');
  if (w.has('links_hover_color')) w.note('The link hover color is not supported by the Zadex login form.');
  w.raw('links_hover_color');
  w.color('label_color', 'label_color');
  w.typography('label_typography', 'label_typography');
  const spacing = w.raw('label_spacing');
  if (isObj(spacing) && !isBlank(spacing.size) && Number(spacing.size) !== 0) w.note('Label spacing is not carried over.');
  w.consumeResponsive('label_spacing');

  const size = pstr(w, 'input_size', 'sm');
  const [fs, py, px, radius] = FIELD_PRESETS[size] ?? FIELD_PRESETS.sm!;
  w.color('field_text_color', 'field_color');
  w.typography('field_typography', 'field_typography');
  mergeDefaults(w, 'field_typography', { size: { size: fs, unit: 'px' } });
  // Pro default #ffffff.
  w.color('field_background_color', 'field_bg');
  const ref = w.globalRef('field_border_color');
  const rawColor = w.raw('field_border_color');
  const borderColor = ref?.kind === 'colors' ? colorRef(ctx, ref.id) : typeof rawColor === 'string' && rawColor !== '' ? rawColor : undefined;
  w.set('field_border', {
    style: 'solid',
    width: dimensions(w.raw('field_border_width')) ?? pxDims(1, 1),
    color: borderColor ?? '#69727d',
    radius: dimensions(w.raw('field_border_radius')) ?? pxDims(radius, radius),
  });
  w.set('field_padding', pxDims(py, px));

  const bsize = pstr(w, 'button_size', 'sm');
  const [bfs, bpy, bpx, bradius] = BUTTON_PRESETS[bsize] ?? BUTTON_PRESETS.sm!;
  w.color('button_text_color', 'button_color');
  // Button background is a background group (`button_background_*`, classic | gradient; hover `button_background_hover_*`).
  w.color('button_background_color', 'button_bg');
  w.color('button_hover_color', 'button_color_hover');
  w.color('button_background_hover_color', 'button_bg_hover');
  for (const k of ['button_background_background', 'button_background_hover_background']) {
    if (w.raw(k) === 'gradient') w.note('The button gradient background became its first color (Zadex login buttons use a solid color).');
  }
  w.consume('button_background_*');
  w.typography('button_typography', 'button_typography');
  mergeDefaults(w, 'button_typography', { size: { size: bfs, unit: 'px' }, lineHeight: { size: 1, unit: 'custom' } });
  w.border('button_border', 'button_border', 'button_border_radius');
  for (const k of Object.keys(w.settings)) if (k.startsWith('button_border@')) delete w.settings[k];
  mergeDefaults(w, 'button_border', { radius: pxDims(bradius, bradius) });
  const pad = dimensions(w.raw('button_text_padding'));
  w.set('button_padding', pad ?? pxDims(bpy, bpx));
  noteDeviceValues(w, 'button_text_padding', 'Button padding');
  if (w.has('button_hover_border_color')) w.note('The button hover border color is not supported by the Zadex login form.');
  w.raw('button_hover_border_color');
  const anim = w.raw('button_hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Button hover animation "${anim}" is not available in Zadex.`);

  // Logged-in message.
  w.color('message_color', 'message_color');
  if (w.raw('message_typography_typography') === 'custom') w.note('The logged-in message typography is not carried over.');
  w.consume('message_typography_*');
  return w.finish();
});
