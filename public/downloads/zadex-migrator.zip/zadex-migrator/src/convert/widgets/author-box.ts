import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { deviceKeys } from '../responsive';
import { slider } from '../values';
import { desktopOnly, only, single, sliderRadius, withGlobalDefaults } from './_shared';
import { pickTag } from './_theme';

const LAYOUT: Record<string, string> = { '': 'row', left: 'row', right: 'row', above: 'column' };

/**
 * Elementor Pro `author-box` -> Zadex `author-box`. Verified against Pro 3.33.2 (defaults via `w.get`): `source`
 * current / custom (+ `author_avatar`, `author_name`, `author_bio`, `author_website`, `posts_url`), `show_avatar`,
 * `show_name`, `author_name_tag` (h4), `show_biography`, `link_to` ('' / website / posts_archive), `show_link`,
 * `link_text` ("All Posts"), `layout` ('' = left / above / right) R, `alignment` R, styles `image_size`,
 * `image_gap`, `image_border` + `image_border_color` / `image_border_width` / `image_border_radius`, `name_color`,
 * `name_typography`, `name_gap`, `bio_color`, `bio_typography`, `button_text_color` … (`image_border_color` default
 * #000; no width default: the browser's medium = 3px applies).
 */
registerWidget('author-box', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    name_color: 'globals/colors?id=secondary',
    name_typography_typography: 'globals/typography?id=primary',
    bio_color: 'globals/colors?id=text',
    bio_typography_typography: 'globals/typography?id=text',
    button_text_color: 'globals/colors?id=secondary',
  });
  const w = ctx.writer(el, 'author-box');
  markPro(w);
  const on = (key: string): boolean => w.get(key) === 'yes';
  if (w.get('source') === 'custom') {
    w.note('A custom author (name, avatar, biography typed in) is not available; the post author is shown.');
    w.status('partial');
  }
  w.consume('author_avatar', 'author_name', 'author_bio', 'author_website', 'posts_url', 'link_to');
  // `avatar_size` (number, default 300) is only the resolution asked from get_avatar(); the shown size is the
  // `image_size` slider below, so the value has no visible effect (real Pro data from V7 stores it).
  w.consume('avatar_size');
  if (w.get('link_to') === 'website') w.note('Linking the name / avatar to the author website is not available; they link to the author archive.');

  w.set('show_avatar', on('show_avatar'));
  w.set('show_name', on('show_name'));
  w.set('name_tag', pickTag(w, String(w.get('author_name_tag') ?? 'h4'), ['h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div'], { h1: 'h2', span: 'div' }));
  w.set('show_bio', on('show_biography'));
  const showLink = on('show_link');
  w.set('link_text', showLink ? String(w.get('link_text') ?? 'All Posts') : '');
  if (!showLink) w.raw('link_text');

  for (const [key, bp] of deviceKeys('layout')) {
    const v = bp ? w.raw(key) : String(w.get(key) ?? '');
    if (v === undefined) continue;
    const z = LAYOUT[String(v)];
    if (!z) continue;
    if (v === 'right') w.note('Avatar on the right is not available; it is shown on the left.');
    w.set('layout', z, { bp });
  }
  w.map('alignment', 'align', only(textAlign(ctx), ['left', 'center', 'right']));

  // Avatar (Elementor default 100px).
  single(w, 'image_size', 'avatar_size', (v) => slider(v));
  if (w.settings.avatar_size === undefined) w.set('avatar_size', { size: 100, unit: 'px' });
  single(w, 'image_gap', 'gap', (v) => slider(v));
  // `image_border` is a switcher with a color and a width slider (not a border group).
  if (on('image_border')) {
    const width = slider(w.raw('image_border_width')) ?? { size: 3, unit: 'px' }; // no Pro default: CSS medium
    const color = w.get('image_border_color');
    const s = width.size;
    w.set('avatar_border', {
      style: 'solid',
      width: { top: s, right: s, bottom: s, left: s, unit: width.unit, linked: true },
      ...(typeof color === 'string' && color !== '' ? { color } : {}),
    });
  }
  w.consume('image_border_color');
  w.consumeResponsive('image_border_width');
  sliderRadius(w, 'image_border_radius', 'avatar_border', false);
  desktopOnly(w, 'avatar_border');
  if (w.raw('image_vertical_align')) w.note('The avatar vertical alignment is not carried over.');
  w.consume('image_box_shadow_*', 'input_box_shadow_*');

  w.color('name_color', 'name_color');
  desktopOnly(w, 'name_color');
  w.typography('name_typography', 'name_typography');
  desktopOnly(w, 'name_typography');
  w.color('bio_color', 'bio_color');
  desktopOnly(w, 'bio_color');
  w.typography('bio_typography', 'bio_typography');
  desktopOnly(w, 'bio_typography');
  w.color('button_text_color', 'link_color');
  desktopOnly(w, 'link_color');
  w.consume('name_gap*', 'bio_gap*');
  for (const k of ['button_background_color', 'button_border_width', 'button_border_radius', 'button_text_padding', 'button_hover_color']) {
    if (w.has(k)) w.note(`"${k}" (link button style) is not available; the link is shown as a text link.`);
  }
  w.consume('button_*');
  return w.finish();
});
