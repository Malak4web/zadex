import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { iconValue, only, withGlobalDefaults } from './_shared';

const LINE_STYLES = ['solid', 'dashed', 'dotted', 'double'];
const LOOK: Record<string, string> = { line: 'none', line_text: 'text', line_icon: 'icon' };

/** Elementor `divider` -> Zadex `divider`. Pattern styles (zigzag, arrows …) become a solid line (noted). */
registerWidget('divider', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    color: 'globals/colors?id=secondary',
    text_color: 'globals/colors?id=secondary',
    typography_typography: 'globals/typography?id=secondary',
    primary_color: 'globals/colors?id=secondary',
  });
  const w = ctx.writer(el, 'divider');
  const style = String(w.get('style') ?? 'solid');
  if (LINE_STYLES.includes(style)) w.set('style', style);
  else if (style === 'none') {
    w.set('style', 'solid');
    w.set('weight', { size: 0, unit: 'px' });
    w.note('Divider style "none" is emulated with a zero-width line.');
  } else {
    w.set('style', 'solid');
    w.note(`Divider pattern "${style}" is not available in Zadex; a solid line is used.`);
    w.status('partial');
  }
  w.consume('separator_type', 'pattern_spacing_flag', 'pattern_round_flag');
  w.consumeResponsive('pattern_height');
  w.consumeResponsive('pattern_size');

  w.slider('width', 'width', undefined, '%');
  w.map('align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  w.slider('gap', 'gap');
  if (style !== 'none') w.slider('weight', 'weight');
  else w.consumeResponsive('weight');
  w.color('color', 'color');

  const look = String(w.get('look') ?? 'line');
  const element = LOOK[look] ?? 'none';
  w.set('element', element);
  if (element === 'text') {
    w.set('text', String(w.get('text') ?? ''));
    const tag = w.get('html_tag');
    if (tag && tag !== 'span') w.note(`Divider text tag "${String(tag)}" is not carried over (Zadex uses a span).`);
    w.color('text_color', 'element_color');
    w.typography('typography', 'element_typography');
    w.slider('text_spacing', 'element_gap');
    const align = w.get('text_align');
    if (align && align !== 'center') w.note(`Divider text alignment "${String(align)}" is not available in Zadex (the text is centered).`);
  } else w.consume('text', 'html_tag', 'text_color', 'text_align', 'typography_*', 'text_stroke_*');
  w.consumeResponsive('text_spacing');

  if (element === 'icon') {
    const ic = iconValue(w, 'icon');
    if (ic) w.set('icon', ic);
    w.color('primary_color', 'element_color');
    w.slider('icon_size', 'element_size');
    w.slider('icon_spacing', 'element_gap');
    const align = w.get('icon_align');
    if (align && align !== 'center') w.note(`Divider icon alignment "${String(align)}" is not available in Zadex (the icon is centered).`);
    const view = w.get('icon_view');
    if (view && view !== 'default') w.note(`Divider icon view "${String(view)}" is not available in Zadex.`);
  } else w.consume('icon', 'primary_color', 'icon_align', 'icon_view');
  w.consumeResponsive('icon_size');
  w.consumeResponsive('icon_spacing');
  w.consume('secondary_color', 'icon_padding', 'icon_border_width', 'border_radius', 'rotate');
  for (const k of ['secondary_color', 'icon_padding', 'icon_border_width', 'border_radius', 'rotate']) {
    if (element === 'icon' && w.has(k)) w.note(`Divider icon "${k}" is not available in Zadex.`);
  }
  return w.finish();
});
