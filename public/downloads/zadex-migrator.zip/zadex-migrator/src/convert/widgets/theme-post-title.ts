import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import type { Mapper } from '../context';
import { url } from '../values';
import { HEADING_GLOBAL_DEFAULTS, headingStyle } from './heading';
import { desktopOnly, only, withGlobalDefaults } from './_shared';
import { dynamicTag, fixedSource, pickTag } from './_theme';

/**
 * Elementor Pro `theme-post-title` / `theme-page-title` -> Zadex `post-title`. Both extend the Heading widget
 * (verified against Pro 3.33.2: `title` with the `post-title` / `page-title` tag as dynamic default, `header_size`
 * default h1 (Pro's real defaults via `w.get`), `link`, `align` start | center | end | justify, heading styles),
 * so the heading style helper is reused.
 */
const postTitle: Mapper = (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, HEADING_GLOBAL_DEFAULTS);
  const w = ctx.writer(el, 'post-title');
  markPro(w);
  const tag = fixedSource(w, 'title', ['post-title', 'page-title'], 'post title');
  if (tag?.name === 'page-title' && (tag.settings.include_context === 'yes' || tag.settings.show_home_title === 'yes')) {
    w.note('Page title: the archive context / home title options are not carried over.');
  }
  w.set('tag', pickTag(w, String(w.get('header_size') ?? 'h1'), ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div']));

  // Link: Elementor binds it to the post URL tag; Zadex `link` links the title to the post.
  const linkTag = dynamicTag(w, 'link');
  const link = url(w.raw('link'));
  if (linkTag || link) {
    w.set('link', true);
    if (linkTag?.name === 'post-url') w.consumeDynamic('link');
    else w.note('The title link pointed elsewhere than the post; the Zadex title links to the post.');
  }
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  headingStyle(w, { color: 'color', hover: { id: 'color_hover' }, typography: 'typography', textShadow: 'text_shadow' });
  desktopOnly(w, 'color');
  desktopOnly(w, 'color_hover');
  return w.finish();
};

registerWidget('theme-post-title', postTitle);
registerWidget('theme-page-title', postTitle);
