import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import type { ElementWriter, ElementState } from '../context';
import { slider } from '../values';
import { iconValue, only, seconds, single, withGlobalDefaults } from './_shared';

/**
 * Elementor size presets (padding / font size) -> closest Zadex preset:
 * xs 10px 20px / 13px, sm 12px 24px / 15px, md 15px 30px / 16px, lg 20px 40px / 18px, xl 25px 50px / 20px;
 * Zadex sm 8px 16px, md 12px 24px, lg 16px 32px, xl 20px 40px.
 */
const SIZES: Record<string, string> = { xs: 'sm', sm: 'md', md: 'lg', lg: 'xl', xl: 'xl' };
/**
 * Exact Elementor preset values ([font size, vertical padding, horizontal padding, radius] in px, plus
 * `.elementor-button{line-height:1}`), written where the element does not set its own: the Zadex presets differ
 * (font size relative to the theme, line height 1.2), so the closest preset alone changes the button size.
 */
const PRESETS: Record<string, [number, number, number, number]> = { xs: [13, 10, 20, 2], sm: [15, 12, 24, 3], md: [16, 15, 30, 4], lg: [18, 20, 40, 5], xl: [20, 25, 50, 6] };
const ICON_POSITION: Record<string, string> = { row: 'before', 'row-reverse': 'after', left: 'before', right: 'after' };

/**
 * Elementor background group on the button (`background_*` normal, `button_background_hover_*` hover). Zadex buttons
 * have a plain background color: classic colors carry over, gradients keep their first color (noted).
 */
export function buttonBackground(w: ElementWriter, prefix: string, state?: ElementState): void {
  const type = w.raw(`${prefix}_background`);
  w.color(`${prefix}_color`, 'bg_color', state);
  w.consume(`${prefix}_*`);
  if (type === 'gradient') {
    w.note('The button gradient background is not supported by the Zadex button; its first color is used.');
    w.status('partial');
  } else if (type && type !== 'classic') {
    w.note(`Button background type "${String(type)}" is not supported; only the color is kept.`);
    w.status('partial');
  }
  for (const k of ['image', 'video_link', 'slideshow_gallery']) {
    if (w.has(`${prefix}_${k}`)) {
      w.note('The button background image is not supported by the Zadex button.');
      w.status('partial');
    }
  }
}

/** Elementor `button` -> Zadex `button`. */
registerWidget('button', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    background_color: 'globals/colors?id=accent',
    typography_typography: 'globals/typography?id=accent',
  });
  const w = ctx.writer(el, 'button');
  w.set('text', String(w.get('text') ?? ''));
  if (w.dynamicRef('text')) w.note('The button text was bound to a dynamic tag; the static text was kept.');
  w.url('link', 'link');
  const size = String(w.get('size') ?? 'sm');
  w.set('size', SIZES[size] ?? 'md');
  if (size === 'xl') w.note('Elementor size "xl" is larger than the largest Zadex preset; set a padding to match it.');

  const ic = iconValue(w, 'selected_icon');
  if (ic) {
    w.set('icon', ic);
    w.map('icon_align', 'icon_position', ICON_POSITION);
    single(w, 'icon_indent', 'icon_gap', (v) => slider(v));
  } else w.consume('icon_align', 'icon_indent');

  const id = w.get('button_css_id');
  if (typeof id === 'string' && id !== '') w.set('button_id', id);

  w.map('align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end', 'stretch']));
  if (w.has('content_align')) {
    w.consume('content_align');
    w.note('Content alignment inside a full-width button is not carried over (Zadex centers it).');
  }

  w.typography('typography', 'typography');
  w.color('button_text_color', 'color');
  w.color('hover_color', 'color', 'hover');
  buttonBackground(w, 'background');
  buttonBackground(w, 'button_background_hover', 'hover');

  w.border('border', 'border', 'border_radius');
  w.color('button_hover_border_color', 'border', 'hover');
  const hoverBorder = w.settings['border::hover'];
  if (typeof hoverBorder === 'string') w.set('border', { color: hoverBorder }, { state: 'hover' });

  w.dimensions('text_padding', 'padding');

  // Elementor preset values the element does not override (desktop; device values cascade from them).
  const [fontSize, padY, padX, radius] = PRESETS[size] ?? PRESETS.sm!;
  const typo = (w.settings.typography ?? {}) as Record<string, unknown>;
  const typoDefaults: Record<string, unknown> = {};
  if (typo.size === undefined) typoDefaults.size = { size: fontSize, unit: 'px' };
  if (typo.lineHeight === undefined) typoDefaults.lineHeight = { size: 1, unit: 'custom' };
  if (Object.keys(typoDefaults).length) w.set('typography', { ...typo, ...typoDefaults });
  if (w.settings.padding === undefined) w.set('padding', { top: padY, right: padX, bottom: padY, left: padX, unit: 'px', linked: false });
  const border = (w.settings.border ?? {}) as Record<string, unknown>;
  if (border.radius === undefined) w.set('border', { ...border, radius: { top: radius, right: radius, bottom: radius, left: radius, unit: 'px', linked: true } });
  w.boxShadow('button_box_shadow', 'box_shadow');
  w.boxShadow('button_hover_box_shadow', 'box_shadow', 'hover');
  const t = seconds(w.raw('button_hover_transition_duration'));
  if (t) w.set('transition', t);

  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex button.`);
  const type = w.raw('button_type');
  if (typeof type === 'string' && type !== '') w.note(`Button type preset "${type}" is not carried over; its colors only apply when set explicitly.`);
  return w.finish();
});
