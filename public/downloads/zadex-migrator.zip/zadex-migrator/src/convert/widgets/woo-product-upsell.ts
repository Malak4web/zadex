import { registerWidget } from '../registry';
import { productList } from './woo-product-related';

/** Elementor Pro `woocommerce-product-upsell` -> Zadex `product-upsells` (shared mapper and assumptions: woo-product-related.ts). */
registerWidget('woocommerce-product-upsell', productList('product-upsells', ['rand', 'date', 'title', 'price', 'menu_order']));
