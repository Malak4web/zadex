import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { deviceKeys } from '../responsive';
import { slider } from '../values';
import { desktopOnly, repeaterItems, toNumber, withGlobalDefaults } from './_shared';
import { pickTag } from './_theme';

/**
 * Elementor Pro `sitemap` -> Zadex `sitemap`. Verified against Pro 3.33.2 (defaults via `w.get`): repeater
 * `sitemap_items` (default: Pages + Categories) {`sitemap_type_selector` post_type / taxonomy,
 * `sitemap_source_post_type` (page), `sitemap_source_taxonomy` (category), `sitemap_title`,
 * `sitemap_orderby_post_type` (post_date) / `sitemap_orderby_taxonomy` (name), `sitemap_order` (desc),
 * `sitemap_hide_empty` (yes), `sitemap_hierarchical` (no), `sitemap_depth` (0 = all)}; widget-level
 * `sitemap_exclude` [current_post, manual_selection] + `sitemap_exclude_ids`, `sitemap_password_protected`,
 * `sitemap_columns` R (4 / 2 / 1), `sitemap_title_tag` (h2), `sitemap_add_nofollow`; styles
 * `sitemap_title_color` (global primary), `sitemap_title_typography` (global primary), `sitemap_list_item_color`
 * (global text), `sitemap_list_item_typography` (global text), `sitemap_list_indent`, `sitemap_section_padding`,
 * bullets (`sitemap_bullet_color`, `sitemap_list_item_bullet_style`). No hover color and no column / row gap.
 * Zadex lists pages / posts / categories / tags with its own section titles.
 */

const SOURCES: Record<string, string> = { 'post_type:page': 'pages', 'post_type:post': 'posts', 'taxonomy:category': 'categories', 'taxonomy:post_tag': 'tags' };
/** Pro's column defaults (`default` / `tablet_default` / `mobile_default`). */
const COL_DEFAULTS: Record<string, string> = { '': '4', _tablet: '2', _mobile: '1' };
const SECTION_TITLES = ['Pages', 'Posts', 'Categories', 'Tags'];
/** Pro's per-item sort defaults. */
const ITEM_DEFAULTS: Record<string, string> = { sitemap_orderby_post_type: 'post_date', sitemap_orderby_taxonomy: 'name', sitemap_order: 'desc', sitemap_hide_empty: 'yes' };

registerWidget('sitemap', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    sitemap_title_color: 'globals/colors?id=primary',
    sitemap_title_typography_typography: 'globals/typography?id=primary',
    sitemap_list_item_color: 'globals/colors?id=text',
    sitemap_list_item_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'sitemap');
  markPro(w);

  const items = repeaterItems(w.get('sitemap_items'));
  const sources: string[] = [];
  // Depth 0 = every level (Zadex cannot list all levels flat like a non-hierarchical Elementor section).
  let depth = -1;
  let flat = false;
  let titled = false;
  let ordered = false;
  for (const item of items) {
    const type = String(item.sitemap_type_selector ?? 'post_type');
    const name = type === 'taxonomy' ? String(item.sitemap_source_taxonomy ?? 'category') : String(item.sitemap_source_post_type ?? 'page');
    const z = SOURCES[`${type}:${name}`];
    if (!z) {
      w.note(`Sitemap source "${name}" is not available (Zadex lists pages, posts, categories and tags).`);
      continue;
    }
    if (!sources.includes(z)) sources.push(z);
    if (item.sitemap_hierarchical === 'yes') {
      const d = toNumber(item.sitemap_depth) ?? 0;
      depth = depth === 0 || d === 0 ? 0 : Math.max(depth, d);
    } else {
      flat = true;
      depth = 0;
    }
    // Zadex prints the post type / taxonomy name, which matches Pro's default titles.
    if (typeof item.sitemap_title === 'string' && item.sitemap_title !== '' && !SECTION_TITLES.includes(item.sitemap_title)) titled = true;
    for (const [k, def] of Object.entries(ITEM_DEFAULTS)) {
      if (item[k] !== undefined && item[k] !== '' && item[k] !== def) ordered = true;
    }
  }
  w.set('sources', sources);
  w.set('depth', Math.max(0, Math.min(10, depth)));
  if (flat && sources.some((x) => x === 'pages' || x === 'categories')) w.note('Flat (non-hierarchical) sections are listed nested in Zadex.');
  // Elementor lists every item of a source; Zadex caps posts per source (max 500).
  w.set('posts_count', 500);
  w.set('show_titles', true);
  if (titled) w.note('Custom section titles are not carried over (Zadex uses the post type / taxonomy names).');
  if (ordered) w.note('The sort order / "hide empty" settings of the sitemap sections are not carried over.');
  const exclude = w.raw('sitemap_exclude');
  if (Array.isArray(exclude) ? exclude.length > 0 : typeof exclude === 'string' && exclude !== '') w.note('The sitemap exclusions (current post / manual selection) are not carried over.');
  w.consume('sitemap_exclude_ids');
  if (w.raw('sitemap_password_protected') === 'yes') w.note('"Protected posts" (password protected items) is not carried over.');

  w.set('title_tag', pickTag(w, String(w.get('sitemap_title_tag') ?? 'h2'), ['h2', 'h3', 'h4', 'h5', 'p'], { h1: 'h2', h6: 'h5', div: 'p', span: 'p' }));
  for (const [key, bp] of deviceKeys('sitemap_columns')) {
    const v = w.raw(key) ?? COL_DEFAULTS[key.slice('sitemap_columns'.length)];
    const n = toNumber(v);
    if (n === undefined) continue;
    const c = Math.min(4, Math.max(1, Math.round(n)));
    if (c !== n) w.note(`${n} columns are not available; ${c} are used.`);
    w.set('columns', String(c), { bp });
  }
  if (w.get('sitemap_add_nofollow') === 'yes') w.note('"Add nofollow" is not carried over.');

  for (const [key, bp] of deviceKeys('sitemap_column_gap')) {
    const s = slider(w.raw(key));
    if (s) w.set('gap', s, { bp });
  }
  w.consume('sitemap_row_gap*', 'sitemap_list_indent*', 'sitemap_section_padding*', 'sitemap_bullet_*', 'sitemap_list_item_bullet_style', 'sitemap_list_item_hover_color_transition');
  w.color('sitemap_title_color', 'title_color');
  desktopOnly(w, 'title_color');
  w.typography('sitemap_title_typography', 'title_typography');
  desktopOnly(w, 'title_typography');
  w.typography('sitemap_list_item_typography', 'typography');
  desktopOnly(w, 'typography');
  w.color('sitemap_list_item_color', 'link_color');
  desktopOnly(w, 'link_color');
  w.color('sitemap_list_item_hover_color', 'link_color_hover');
  desktopOnly(w, 'link_color_hover');
  return w.finish();
});
