import { registerWidget } from '../registry';
import { bool } from '../values';
import { colorValue, desktopOnly } from './_media-support';
import { itemIdFor, repeaterItems, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { carouselSettings, desktopSlider, field, logicalAlign, mediaOf, sidesOf, slideBox } from './_marketing';

type Obj = Record<string, unknown>;

const LAYOUT: Record<string, string> = { image_inline: 'inline', image_stacked: 'stacked', image_above: 'above', image_left: 'left', image_right: 'right' };

/**
 * Elementor Pro `testimonial-carousel` -> Zadex `testimonial-carousel`. Verified against Elementor Pro 3.33.2:
 * repeater `slides` {content, image, name (John Doe), title (CEO)}, `skin` default|bubble, `layout` (image_inline)
 * image_inline|image_stacked|image_above|image_left|image_right, `alignment` (R, center), the Pro carousel settings
 * (`carouselSettings`; the testimonial handler shows one slide per view on every device), `image_size_size`, styles:
 * slide box (`slide_*`, on the whole slide in both skins), bubble (`background_color`, `text_padding` 20px,
 * `border_radius`, `border` + `border_color` / `border_width`), `content_gap`, `content_color` (text) /
 * `content_typography` (text), `name_color` (text) / `name_typography` (primary), `title_color` (primary) /
 * `title_typography` (secondary), `image_size`, `image_gap`, `image_border` switch + `image_border_color` (#000) /
 * `image_border_width`, `image_border_radius`, navigation.
 */
registerWidget('testimonial-carousel', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    content_color: 'globals/colors?id=text',
    content_typography_typography: 'globals/typography?id=text',
    name_color: 'globals/colors?id=text',
    name_typography_typography: 'globals/typography?id=primary',
    title_color: 'globals/colors?id=primary',
    title_typography_typography: 'globals/typography?id=secondary',
  });
  const w = ctx.writer(el, 'testimonial-carousel');
  markPro(w);
  const items = repeaterItems(w.get('slides'));
  if (!items.length) w.note('The testimonial carousel has no slides.');
  w.set(
    'slides',
    items.map((item, i) => {
      const out: Obj = {
        _id: itemIdFor(ctx, el, item, i),
        content: field(item, 'content', ''),
        name: field(item, 'name', 'John Doe'),
        title: field(item, 'title', 'CEO'),
      };
      const image = mediaOf(ctx, item.image);
      if (image) out.image = image;
      return out;
    }),
  );
  const skin = w.get('skin') === 'bubble' ? 'bubble' : 'default';
  w.set('skin', skin);
  w.set('image_position', LAYOUT[String(w.get('layout'))] ?? 'inline');
  w.map('alignment', 'align', logicalAlign(ctx));
  const size = w.get('image_size_size');
  if (typeof size === 'string' && size !== 'full' && size !== '') w.note(`Image size "${size}" is not carried over (Zadex uses the image size control).`);
  w.consume('image_size_custom_dimension');

  carouselSettings(w, { desktop: 1, tablet: 1, mobile: 1 });

  // Slide box (the whole slide) and, in the bubble skin, the speech bubble.
  slideBox(w, 'slide');
  if (skin === 'bubble') {
    w.color('background_color', 'bubble_bg');
    const pad = sidesOf(desktopOnly(w, 'text_padding'));
    if (pad) w.set('bubble_padding', pad);
    if (sidesOf(w.raw('border_radius')) || bool(w.raw('border'))) w.note('The bubble border / radius are not available in Zadex.');
    w.consume('border_radius*', 'border', 'border_color', 'border_width');
  } else w.consume('background_color', 'text_padding*', 'border_radius*', 'border', 'border_color', 'border_width');

  // Texts.
  const gap = desktopSlider(w, 'content_gap');
  if (gap) w.set('content_gap', gap);
  w.color('content_color', 'content_color');
  w.typography('content_typography', 'content_typography');
  // Pro's CSS: `.elementor-widget-testimonial-carousel .elementor-testimonial__text{font-size:1.3em;font-style:italic;
  // line-height:1.5}`; unset fields are written so Zadex does not fall back to its smaller upright text (V7).
  const quote = (w.settings.content_typography ?? {}) as Record<string, unknown>;
  w.set('content_typography', { ...quote, size: quote.size ?? { size: 1.3, unit: 'em' }, style: quote.style ?? 'italic', lineHeight: quote.lineHeight ?? { size: 1.5, unit: 'custom' } });
  w.color('name_color', 'name_color');
  w.typography('name_typography', 'name_typography');
  w.color('title_color', 'title_color');
  w.typography('title_typography', 'title_typography');

  // Image.
  w.slider('image_size', 'image_size');
  if (desktopSlider(w, 'image_gap')) w.note('The image spacing is not available on the Zadex testimonial carousel.');
  if (bool(w.raw('image_border'))) {
    const b: Obj = { style: 'solid' };
    const width = sidesOf(w.raw('image_border_width'));
    if (width) b.width = width;
    const color = colorValue(w, 'image_border_color');
    if (color) b.color = color;
    w.set('image_border', b);
  } else w.consume('image_border_color', 'image_border_width');
  const radius = desktopSlider(w, 'image_border_radius');
  if (radius) w.set('image_radius', radius);
  return w.finish();
});
