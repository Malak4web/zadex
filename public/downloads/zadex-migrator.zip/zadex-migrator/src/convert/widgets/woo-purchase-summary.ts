import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { colorAlt, typographyAlt } from './_marketing';
import { borderParts, wooLabels, wooPageStyles } from './_woo-shop';
import { noteIfSet } from './_woo-product';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-purchase-summary` (order received / thank you page) -> Zadex `purchase-summary`.
 * Verified against Elementor Pro 3.33.2: `confirmation_message_active` (yes), `confirmation_message_text` (default
 * "Thank You. Your order has been received."), labels `payment_details_number` / `_date` / `_email` / `_total` /
 * `_payment`, section titles `bank_details_text`, `downloads_text`, `order_summary_text`, `billing_details_text`,
 * `shipping_details_text` (+ alignments), editor preview `preview_order_type` / `preview_order_custom`; styles
 * `confirmation_message_color` / `_typography`, `titles_*`, `general_text_*`, payment details
 * `payment_details_titles_color` / `_typography`, `payment_details_items_color` / `_typography`,
 * `payment_details_border_type` + `_width` (slider) + `_color`, order details `order_details_*` (shared section
 * `wooPageStyles`), bank details / sections box (noted, reported).
 */
registerWidget('woocommerce-purchase-summary', (source, ctx) => {
  const off = wooGuard(source, ctx, 'purchase-summary');
  if (off) return off;
  const w = ctx.writer(source, 'purchase-summary');
  markPro(w);
  if (w.get('confirmation_message_active') !== 'yes') {
    w.set('message', '');
    w.consume('confirmation_message_text');
  } else {
    const text = w.get('confirmation_message_text');
    w.set('message', typeof text === 'string' ? text : '');
  }
  wooLabels(w, [
    'payment_details_number',
    'payment_details_date',
    'payment_details_email',
    'payment_details_total',
    'payment_details_payment',
    'bank_details_text',
    'downloads_text',
    'order_summary_text',
    'billing_details_text',
    'shipping_details_text',
  ]);
  noteIfSet(
    w,
    ['confirmation_message_alignment', 'bank_details_alignment', 'downloads_alignment', 'order_summary_alignment', 'billing_details_alignment', 'shipping_details_alignment'],
    'Message / section title alignments are not carried over.',
  );
  w.consume('preview_order_type', 'preview_order_custom');
  colorAlt(w, ['confirmation_message_color'], 'message_color');
  typographyAlt(w, ['confirmation_message_typography'], 'message_typography');
  colorAlt(w, ['payment_details_titles_color'], 'overview_label');
  colorAlt(w, ['payment_details_items_color'], 'overview_value');
  typographyAlt(w, ['payment_details_items_typography', 'payment_details_titles_typography'], 'overview_typography');
  borderParts(w, 'overview_border', { prefix: 'payment_details_border' });
  wooPageStyles(w);
  return w.finish();
});
