import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { boxTitleTag, desktopOnly, only, single, sliderRadius, unitless, withGlobalDefaults } from './_shared';
import { boxPosition, VERTICAL_ALIGN } from './icon-box';
import { IMAGE_SIZES, isPlaceholder } from './image';

/** Elementor `image-box` -> Zadex `image-box`. */
registerWidget('image-box', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_color: 'globals/colors?id=primary',
    title_typography_typography: 'globals/typography?id=primary',
    description_color: 'globals/colors?id=text',
    description_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'image-box');
  const raw = w.get('image');
  const media = isPlaceholder(raw) ? undefined : ctx.media(raw);
  if (media) w.set('image', media);
  const size = String(w.get('thumbnail_size') ?? 'full');
  w.set('image_size', IMAGE_SIZES[size] ?? 'full');
  if (size === 'custom') w.note('Custom image dimensions are not supported; the full size is used.');
  w.consume('thumbnail_custom_dimension');

  w.set('title', String(w.get('title_text') ?? ''));
  w.set('description', String(w.get('description_text') ?? ''));
  if (w.dynamicRef('title_text') || w.dynamicRef('description_text')) w.note('Dynamic tags on the texts were replaced by their static text.');
  w.url('link', 'link');
  w.set('title_tag', boxTitleTag(w, w.get('title_size')));

  w.map('position', 'position', boxPosition(ctx));
  w.map('content_vertical_alignment', 'vertical_align', VERTICAL_ALIGN);
  // Elementor centers the image box content by default.
  if (!w.has('text_align')) w.set('text_align', 'center');
  w.map('text_align', 'text_align', only(textAlign(ctx), ['left', 'center', 'right']));
  w.slider('image_space', 'spacing');
  w.slider('image_size', 'image_width');
  const position = String(w.get('position') ?? 'top');
  if (position === 'top' && media) {
    w.note('In Zadex the image of a top-positioned image box starts at the content edge (Elementor centers it).');
  }
  if (w.has('image_height')) w.note('Image height / object fit are not available on the Zadex image box.');
  w.consumeResponsive('image_height');
  w.consume('image_object_fit', 'image_object_position');

  w.border('image_border', 'image_border');
  sliderRadius(w, 'image_border_radius', 'image_border', false);
  desktopOnly(w, 'image_border');
  single(w, 'image_opacity', 'image_opacity', unitless);
  single(w, 'image_opacity_hover', 'image_opacity', unitless, 'hover');
  const transition = unitless(w.raw('background_hover_transition'));
  if (transition) w.set('image_transition', transition);

  w.color('title_color', 'title_color');
  w.color('hover_title_color', 'title_color', 'hover');
  w.consume('hover_title_color_transition_duration');
  w.typography('title_typography', 'title_typography');
  w.slider('title_bottom_space', 'title_spacing');
  w.color('description_color', 'desc_color');
  w.typography('description_typography', 'desc_typography');

  if (w.has('image_box_shadow_box_shadow_type')) w.note('The image shadow is not available on the Zadex image box.');
  if (w.has('css_filters_css_filter') || w.has('css_filters_hover_css_filter')) w.note('CSS filters are not available on the Zadex image box.');
  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex image box.`);
  return w.finish();
});
