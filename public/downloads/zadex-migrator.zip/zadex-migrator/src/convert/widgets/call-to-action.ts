import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { bool, url } from '../values';
import { iconValue, only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { VERTICAL, buttonPreset, buttonStyles, desktopSlider, mediaOf, msToSeconds, sliderAlt, typographyAlt } from './_marketing';

const LAYOUT: Record<string, string> = { above: 'column', left: 'row', right: 'row-reverse' };
const TITLE_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'p'];
const IMAGE_ANIMATIONS = ['zoom-in', 'zoom-out', 'move-left', 'move-right', 'move-up', 'move-down'];
/** Pro `content_animation` (entrance / reaction / exit groups) -> Zadex hover animation. */
const CONTENT_ANIMATIONS: Record<string, string> = { grow: 'grow', shrink: 'shrink', 'move-up': 'move-up', 'move-down': 'move-down', 'fade-in': 'fade-in', 'enter-from-bottom': 'move-up', 'enter-from-top': 'move-down', 'enter-zoom-out': 'shrink', 'enter-zoom-in': 'grow' };
const APPROX_CONTENT = new Set(['enter-from-bottom', 'enter-from-top', 'enter-zoom-out', 'enter-zoom-in']);

/**
 * Elementor Pro `call-to-action` -> Zadex `call-to-action`. Verified against Elementor Pro 3.33.2: `skin`
 * classic|cover, `layout` (R) left|above|right|below, `bg_image` (+ `bg_image_size`), `graphic_element` none|image|icon,
 * `graphic_image`, `selected_icon`, `title`, `title_tag` (h2), `description`, `description_tag` (div), `button`,
 * `link`, `link_click` box|button, `ribbon_title`, `ribbon_horizontal_position`; style `image_min_width` /
 * `image_min_height` (R), `min-height` (R), `alignment` (center), `vertical_position`, `padding`; colors normal /
 * hover `content_bg_color`, `title_color`, `description_color`, `button_color` (text + border); hover effects
 * `content_animation` (grow, cover skin only), `content_animation_duration` (1000ms), `sequenced_animation`,
 * `transformation` (zoom-in: background image hover), `overlay_color` (+ `_hover`), `overlay_blend_mode`,
 * `effect_duration` (1500ms); graphic, title (primary typography), description (text), button (accent; sm), ribbon
 * (`ribbon_bg_color` accent, accent typography) styles.
 */
registerWidget('call-to-action', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_typography_typography: 'globals/typography?id=primary',
    description_typography_typography: 'globals/typography?id=text',
    button_typography_typography: 'globals/typography?id=accent',
    ribbon_bg_color: 'globals/colors?id=accent',
    ribbon_typography_typography: 'globals/typography?id=accent',
  });
  const w = ctx.writer(el, 'call-to-action');
  markPro(w);
  const skin = w.get('skin') === 'cover' ? 'cover' : 'classic';
  w.set('skin', skin);
  const image = mediaOf(ctx, w.raw('bg_image'));
  if (image) w.set('image', image);
  w.consume('bg_image_size', 'bg_image_custom_dimension');
  if (skin === 'classic') {
    w.set('image_position', 'column');
    w.map('layout', 'image_position', LAYOUT);
    sliderAlt(w, ['image_min_width'], 'image_width', true, '%');
    sliderAlt(w, ['image_min_height'], 'image_height');
  } else w.consume('layout*', 'image_min_width*', 'image_min_height*');

  // Graphic.
  let graphic = String(w.get('graphic_element') || 'none');
  if (graphic === 'icon') {
    const ic = iconValue(w, 'selected_icon');
    if (ic) w.set('icon', ic);
    else graphic = 'none';
    const view = String(w.get('icon_view') || 'default');
    if (view !== 'default') w.note(`Icon view "${view}" (stacked / framed) is not available on the Zadex call to action.`);
    w.consume('icon_shape', 'graphic_image', 'graphic_image_size', 'graphic_image_custom_dimension');
  } else if (graphic === 'image') {
    const g = mediaOf(ctx, w.raw('graphic_image'));
    if (g) w.set('graphic_image', g);
    else graphic = 'none';
    w.consume('graphic_image_size', 'graphic_image_custom_dimension', 'selected_icon', 'icon_view', 'icon_shape');
  } else {
    graphic = 'none';
    w.consume('selected_icon', 'icon_view', 'icon_shape', 'graphic_image', 'graphic_image_size', 'graphic_image_custom_dimension');
  }
  w.set('graphic', graphic);

  // Content.
  w.set('title', String(w.get('title') ?? ''));
  const tag = String(w.get('title_tag') || 'h2');
  w.set('title_tag', TITLE_TAGS.includes(tag) ? tag : 'div');
  if (!TITLE_TAGS.includes(tag)) w.note(`Title tag "${tag}" is not available in Zadex; "div" is used.`);
  w.set('description', String(w.get('description') ?? ''));
  const descTag = w.raw('description_tag');
  if (typeof descTag === 'string' && descTag !== '' && descTag !== 'div') w.note(`Description tag "${descTag}" is not carried over.`);
  w.set('button_text', String(w.get('button') ?? ''));
  w.set('link', url(w.raw('link')) ?? { url: '', target: '', nofollow: false });
  w.set('link_click', w.get('link_click') === 'box' ? 'box' : 'button');
  const ribbon = String(w.get('ribbon_title') ?? '');
  w.set('ribbon_title', ribbon);
  // No stored position = Pro's right ribbon (`elementor-ribbon` without `-left`).
  if (ribbon !== '') w.set('ribbon_position', w.get('ribbon_horizontal_position') === 'left' ? 'left' : 'right');
  else w.consume('ribbon_horizontal_position');

  // Box.
  w.slider('min-height', 'min_height');
  w.map('alignment', 'text_align', only(textAlign(ctx), ['left', 'center', 'right']));
  w.map('vertical_position', 'v_position', VERTICAL);
  w.dimensions('padding', 'padding');

  // Colors (normal / hover). `button_color` paints the button text and border.
  w.color('content_bg_color', 'content_bg');
  w.color('content_bg_color_hover', 'content_bg', 'hover');
  w.color('overlay_color', 'overlay_color');
  w.color('overlay_color_hover', 'overlay_color', 'hover');
  const blend = w.raw('overlay_blend_mode');
  if (typeof blend === 'string' && blend !== '' && blend !== 'normal') w.note(`Overlay blend mode "${blend}" is not available in Zadex.`);
  w.color('title_color', 'title_color');
  w.color('title_color_hover', 'title_color', 'hover');
  w.color('description_color', 'description_color');
  w.color('description_color_hover', 'description_color', 'hover');

  // Hover effects.
  const imgAnim = String(w.get('transformation') ?? '');
  w.set('image_animation', imgAnim === '' ? 'none' : IMAGE_ANIMATIONS.includes(imgAnim) ? imgAnim : 'none');
  if (imgAnim !== '' && !IMAGE_ANIMATIONS.includes(imgAnim)) w.note(`Image hover animation "${imgAnim}" is not available in Zadex.`);
  // The content animation only runs in the cover skin (default grow).
  const contentAnim = skin === 'cover' ? String(w.get('content_animation') ?? '') : '';
  if (skin !== 'cover') w.consume('content_animation', 'content_animation_duration', 'sequenced_animation');
  const zContent = CONTENT_ANIMATIONS[contentAnim];
  w.set('content_animation', zContent ?? 'none');
  if (contentAnim !== '' && (!zContent || APPROX_CONTENT.has(contentAnim))) w.note(`Content hover animation "${contentAnim}" is not available in Zadex${zContent ? `; "${zContent}" is used` : ''}.`);
  const duration = msToSeconds(w.get('effect_duration'));
  if (duration) w.set('hover_duration', duration);
  if (contentAnim !== '') {
    const cd = msToSeconds(w.get('content_animation_duration'));
    if (cd && duration && cd.size !== duration.size) w.note(`The content animation duration (${cd.size}s) differs from the image transition; Zadex uses one duration (${duration.size}s).`);
    if (bool(w.raw('sequenced_animation'))) w.note('Sequenced content animation is not available in Zadex.');
  }
  w.consume('animation_class');

  // Graphic styles.
  w.color('icon_primary_color', 'icon_color');
  w.slider('icon_size', 'icon_size');
  sliderAlt(w, ['graphic_image_width'], 'graphic_width', true, '%');
  sliderAlt(w, graphic === 'image' ? ['graphic_image_spacing', 'icon_spacing'] : ['icon_spacing', 'graphic_image_spacing'], 'graphic_spacing');

  // Title / description.
  w.typography('title_typography', 'title_typography');
  w.slider('title_spacing', 'title_spacing');
  w.typography('description_typography', 'description_typography');
  w.slider('description_spacing', 'description_spacing');

  // Button: Elementor's CTA button is outlined (transparent, 2px border) unless a background color is set.
  const size = String(w.get('button_size') || 'sm');
  const filled = buttonStyles(w, { color: 'button_color', bg: 'button_bg', border: 'button_border', typography: 'button_typography', padding: 'button_padding' });
  w.set('button_skin', filled ? 'filled' : 'outline');
  buttonPreset(w, size, { padding: 'button_padding', typography: 'button_typography', border: 'button_border' });
  // Pro's CSS colors when unset (widget-call-to-action.css): classic skin = content items, button text and border
  // #3f444b on a #f9fafa content box; cover skin = #fff (V7: Zadex showed its own white / theme colors).
  const ink = skin === 'cover' ? '#ffffff' : '#3f444b';
  for (const key of ['title_color', 'description_color', 'button_color'] as const) if (w.settings[key] === undefined) w.set(key, ink);
  if (skin === 'classic' && w.settings.content_bg === undefined) w.set('content_bg', '#f9fafa');
  const btnColor = typeof w.settings.button_color === 'string' ? (w.settings.button_color as string) : undefined;
  if (btnColor && !w.has('button_border_color')) {
    const b = (w.settings.button_border ?? {}) as Record<string, unknown>;
    if (b.color === undefined) w.set('button_border', { ...b, color: btnColor });
  }

  // Ribbon.
  w.color('ribbon_bg_color', 'ribbon_bg');
  w.color('ribbon_text_color', 'ribbon_color');
  typographyAlt(w, ['ribbon_typography'], 'ribbon_typography', false);
  if (desktopSlider(w, 'ribbon_distance')) w.note('The ribbon distance is not available in Zadex.');
  return w.finish();
});
