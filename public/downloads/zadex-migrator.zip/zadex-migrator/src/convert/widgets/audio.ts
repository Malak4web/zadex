import { registerWidget } from '../registry';
import { bool, url } from '../values';

/** Player options Zadex does not have (Elementor shows them by default). */
const UNSUPPORTED: Array<[string, string]> = [
  ['sc_liking', 'like button'],
  ['sc_download', 'download button'],
  ['sc_show_artwork', 'artwork'],
  ['sc_show_playcount', 'play count'],
];

/**
 * Elementor `audio` (SoundCloud embed) -> Zadex `soundcloud`. Elementor's player is 400px high in visual mode and
 * 200px in classic mode; Zadex defaults differ, so the height is written explicitly.
 */
registerWidget('audio', (el, ctx) => {
  const w = ctx.writer(el, 'soundcloud');
  w.set('url', url(w.get('link'))?.url ?? '');
  if (w.dynamicRef('link')) w.note('The SoundCloud link was bound to a dynamic tag; the static link was kept.');
  const visual = w.get('visual') === 'yes';
  w.set('visual', visual);
  w.set('height', { size: visual ? 400 : 200, unit: 'px' });
  w.set('autoplay', bool(w.get('sc_auto_play')));
  w.set('buying', bool(w.get('sc_buying')));
  w.set('sharing', bool(w.get('sc_sharing')));
  w.set('comments', bool(w.get('sc_show_comments')));
  w.set('show_user', bool(w.get('sc_show_user')));
  w.color('sc_color', 'color');
  for (const [key, label] of UNSUPPORTED) {
    if (key === 'sc_show_artwork' && visual) {
      w.consume(key);
      continue;
    }
    if (!bool(w.get(key))) {
      w.note(`Hiding the ${label} is not available in the Zadex SoundCloud player.`);
      w.status('partial');
    }
  }
  return w.finish();
});
