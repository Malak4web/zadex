import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { desktopOnly, only, withGlobalDefaults } from './_shared';

/**
 * Elementor Pro `theme-post-content` (the post body in single templates) -> Zadex `post-content`. No content keys
 * (the widget always prints the current post's `the_content`); style: `align` R, `text_color` (global text),
 * `typography` (global text). Verified against Pro 3.33.2 (same keys and global defaults).
 */
registerWidget('theme-post-content', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    text_color: 'globals/colors?id=text',
    typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'post-content');
  markPro(w);
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right', 'justify']));
  w.color('text_color', 'color');
  desktopOnly(w, 'color');
  w.typography('typography', 'typography');
  return w.finish();
});
