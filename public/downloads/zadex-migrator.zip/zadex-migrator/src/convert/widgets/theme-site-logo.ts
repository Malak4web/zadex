import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { dynamicValue } from '../dynamic';
import { url } from '../values';
import { IMAGE_SIZES, isPlaceholder } from './image';
import { desktopOnly, only, single, unitless } from './_shared';
import { dynamicTag, noDynamicData } from './_theme';

/**
 * Elementor Pro `theme-site-logo` -> Zadex `site-logo`. Extends the Image widget (verified against Pro 3.33.2, Pro's
 * own defaults via `w.get`): `image` with the `site-logo` tag as dynamic default, `image_size` (default full),
 * `link_to` none | file | custom | site_url (default `site_url` = the home URL; `custom` uses `link`),
 * `caption_source` none | attachment, `align` start | center | end.
 */
registerWidget('theme-site-logo', (source, ctx) => {
  const w = ctx.writer(source, 'site-logo');
  markPro(w);

  // Source: the site-logo tag (or the untouched default) = the Customizer logo; anything else = a custom image.
  const imgTag = dynamicTag(w, 'image');
  const raw = w.raw('image');
  if (imgTag?.name === 'site-logo' || (!imgTag && noDynamicData(w) && (raw === undefined || isPlaceholder(raw)))) {
    w.set('source', 'site');
    if (imgTag) w.consumeDynamic('image');
  } else {
    w.set('source', 'custom');
    const dyn = imgTag ? dynamicValue(w.dynamicRef('image'), 'image') : undefined;
    const media = isPlaceholder(raw) ? undefined : ctx.media(raw);
    if (dyn) {
      w.set('image', dyn.value);
      w.consumeDynamic('image');
      if (dyn.note) w.note(dyn.note);
    } else if (media) w.set('image', media);
    else w.set('source', 'site');
    if (imgTag && !dyn) w.note(`The logo was bound to the "${imgTag.name}" tag, which has no Zadex equivalent.`);
  }
  w.set('size', IMAGE_SIZES[String(w.get('image_size') ?? 'full')] ?? 'full');
  if (w.raw('image_custom_dimension')) w.note('Custom image dimensions are not supported; set a width / height instead.');

  // Link (Pro default `site_url`: the home URL; `custom` uses `link`, static or bound to a tag).
  const linkTo = String(w.get('link_to') ?? 'site_url');
  const linkTag = dynamicTag(w, 'link');
  const link = url(w.raw('link'));
  if (linkTo === 'none') w.set('link', 'none');
  else if (linkTo === 'file') {
    w.set('link', 'none');
    w.note('Linking the logo to the image file is not available; the link was removed.');
  } else if (linkTo === 'site_url') {
    w.set('link', 'home');
    if (linkTag) w.consumeDynamic('link');
  } else if (linkTag?.name === 'site-url') {
    w.set('link', 'home');
    if (linkTag) w.consumeDynamic('link');
  } else if (linkTag) {
    const dyn = dynamicValue(w.dynamicRef('link'), 'url');
    w.set('link', dyn ? 'custom' : 'home');
    if (dyn) {
      w.set('custom_link', dyn.value);
      w.consumeDynamic('link');
    } else w.note(`The logo link was bound to the "${linkTag.name}" tag, which has no Zadex equivalent; it links to the home page.`);
  } else if (link) {
    w.set('link', 'custom');
    w.set('custom_link', link);
  } else w.set('link', 'none');
  w.consume('open_lightbox');

  // Elementor centers images by default.
  const align = only(textAlign(ctx), ['left', 'center', 'right']);
  if (!w.has('align')) w.set('align', 'center');
  w.map('align', 'align', align);
  w.slider('width', 'width');
  w.slider('space', 'max_width');
  w.slider('height', 'height');
  single(w, 'opacity', 'opacity', unitless);
  single(w, 'opacity_hover', 'opacity', unitless, 'hover');
  w.border('image_border', 'border', 'image_border_radius');
  desktopOnly(w, 'border');
  if (w.raw('image_box_shadow_box_shadow_type') === 'yes') w.note('The logo shadow is not available in Zadex.');
  w.consume('image_box_shadow_*');
  if (w.raw('caption_source') && w.raw('caption_source') !== 'none') w.note('The logo caption is not available in Zadex.');
  w.consume('caption', 'caption_*', 'text_color');
  if (w.raw('hover_animation')) w.note('Hover animations are not available on the Zadex site logo.');
  return w.finish();
});
