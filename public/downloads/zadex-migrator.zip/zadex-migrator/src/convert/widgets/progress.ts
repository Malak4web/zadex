import { registerWidget } from '../registry';
import { bool, slider } from '../values';
import { desktopOnly, single, withGlobalDefaults } from './_shared';

/** Elementor `progress_type` presets -> their bar colors (Elementor's stylesheet). */
const TYPE_COLORS: Record<string, string> = { info: '#5bc0de', success: '#5cb85c', warning: '#f0ad4e', danger: '#d9534f' };

/** Elementor `progress` -> Zadex `progress-bar`. */
registerWidget('progress', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_color: 'globals/colors?id=primary',
    typography_typography: 'globals/typography?id=text',
    bar_color: 'globals/colors?id=primary',
  });
  const w = ctx.writer(el, 'progress-bar');
  const showTitle = bool(w.get('title_display'));
  w.set('title', showTitle ? String(w.get('title') ?? '') : '');
  if (!showTitle) w.consume('title');
  const tag = w.get('title_tag');
  if (showTitle && tag && tag !== 'span') w.note(`Title tag "${String(tag)}" is not carried over.`);
  const percent = slider(w.get('percent'), '%');
  w.set('percent', typeof percent?.size === 'number' ? Math.max(0, Math.min(100, percent.size)) : 50);
  w.set('show_percent', bool(w.get('display_percentage')));
  w.set('inner_text', String(w.get('inner_text') ?? ''));

  const type = String(w.get('progress_type') ?? '');
  const storedGlobals = source.settings?.__globals__;
  const globalBar = typeof storedGlobals === 'object' && storedGlobals !== null && (storedGlobals as Record<string, unknown>).bar_color;
  if (type && TYPE_COLORS[type] && !w.has('bar_color') && !globalBar) {
    w.note(`Progress type "${type}" is converted to its bar color.`);
    w.set('bar_color', TYPE_COLORS[type]);
    w.consume('bar_color');
  } else {
    w.color('bar_color', 'bar_color');
  }
  // Elementor's stylesheet: track #eee, 30px high, square corners; inner text 11px.
  w.color('bar_bg_color', 'bg_color');
  if (!w.settings.bg_color) w.set('bg_color', '#eeeeee');
  if (!w.has('bar_height')) w.set('height', { size: 30, unit: 'px' });
  w.slider('bar_height', 'height');
  if (!w.has('bar_border_radius')) w.set('radius', { size: 0, unit: 'px' });
  single(w, 'bar_border_radius', 'radius', (v) => slider(v));

  w.color('title_color', 'title_color');
  w.typography('typography', 'title_typography');
  w.color('bar_inline_color', 'inner_color');
  w.typography('bar_inner_typography', 'inner_typography');
  desktopOnly(w, 'inner_typography');
  return w.finish();
});
