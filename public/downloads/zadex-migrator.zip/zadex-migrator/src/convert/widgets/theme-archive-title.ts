import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { url } from '../values';
import { HEADING_GLOBAL_DEFAULTS, headingStyle } from './heading';
import { desktopOnly, only, withGlobalDefaults } from './_shared';
import { fixedSource, noDynamicData, pickTag } from './_theme';

/**
 * Elementor Pro `theme-archive-title` -> Zadex `archive-title`. Extends the Heading widget (verified against Pro
 * 3.33.2): `title` with the `archive-title` tag as dynamic default (tag setting `include_context`, default `yes` =
 * "Category: News"), `header_size` (Pro default h1, via `w.get`), heading styles.
 */
registerWidget('theme-archive-title', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, HEADING_GLOBAL_DEFAULTS);
  const w = ctx.writer(el, 'archive-title');
  markPro(w);
  const tag = fixedSource(w, 'title', ['archive-title'], 'archive title');
  // The context prefix ("Category:") is on unless the tag setting turns it off.
  const context = tag ? tag.settings.include_context : noDynamicData(w) ? 'yes' : undefined;
  w.set('show_prefix', context === undefined || context === 'yes');
  w.set('tag', pickTag(w, String(w.get('header_size') ?? 'h1'), ['h1', 'h2', 'h3', 'h4', 'p', 'div'], { h5: 'h4', h6: 'h4', span: 'div' }));
  if (url(w.raw('link'))) w.note('The archive title link is not available in Zadex.');
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  headingStyle(w, { color: 'color', typography: 'typography' });
  desktopOnly(w, 'color');
  return w.finish();
});
