import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { desktopOnly, only } from './_shared';
import { markPro } from './_pro';
import { colorAlt, typographyAlt } from './_marketing';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-breadcrumb` (prints `woocommerce_breadcrumb()`) -> Zadex `breadcrumbs`. Verified against
 * Elementor Pro 3.33.2: `text_color`, `link_color`, `text_typography`, `alignment` R (left | center | right); no hover
 * color. The Zadex widget does not need WooCommerce (it builds the trail itself), so the guard only checks the Zadex
 * widget. `source: zadex` (WooCommerce's breadcrumb ignores Yoast / Rank Math) with WooCommerce's "Home" label and
 * "/" separator; the trail differs slightly (Zadex: Home › Shop › product; WooCommerce: Home / category / product).
 */
registerWidget('woocommerce-breadcrumb', (source, ctx) => {
  const off = wooGuard(source, ctx, 'breadcrumbs');
  if (off) return off;
  const w = ctx.writer(source, 'breadcrumbs');
  markPro(w);
  w.set('source', 'zadex');
  w.set('home_label', 'Home');
  w.set('separator', '/');
  w.note('WooCommerce breadcrumb: Zadex builds its own trail (Home / Shop / product); WooCommerce lists the product category instead of the shop page.');
  w.map('alignment', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  typographyAlt(w, ['text_typography'], 'typography');
  colorAlt(w, ['text_color'], 'color');
  desktopOnly(w, 'color');
  colorAlt(w, ['link_color'], 'link_color');
  desktopOnly(w, 'link_color');
  return w.finish();
});
