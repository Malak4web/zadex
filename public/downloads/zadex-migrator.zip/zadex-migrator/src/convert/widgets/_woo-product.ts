/**
 * Helpers shared by the Elementor Pro WooCommerce product-page mappers (W1, `woo-product-*.ts`). Not a mapper.
 *
 * Control ids / defaults verified against Elementor Pro 3.33.2 (`dev/reference/elementor-pro-controls.json`, source
 * `elementor-pro/modules/woocommerce/widgets/*`). Real defaults are in `src/convert/data/elementor-defaults.json`, so
 * mappers read them with `w.get()`.
 */
import type { ElementState, ElementWriter } from '../context';
import type { BreakpointKey } from '../types';
import { deviceKeys } from '../responsive';
import { dimensions, isBlank, slider } from '../values';
import { colorValue } from './_media-support';
import { colorAlt, dimensionsAlt, posInt, sliderAlt, typographyAlt } from './_marketing';
import { desktopOnly } from './_shared';

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Color from the first stored of several keys into a non-responsive Zadex color control (device values noted). */
export function flatColor(w: ElementWriter, keys: string[], dst: string, state?: ElementState): void {
  colorAlt(w, keys, dst, state);
  desktopOnly(w, dst);
}

/** True when any device variant of any of the keys holds a value. */
export function anySet(w: ElementWriter, keys: string[]): boolean {
  return keys.some((k) => deviceKeys(k).some(([dk]) => w.has(dk)) || Boolean(w.globalRef(k)));
}

/**
 * Keys Zadex has no control for: consumed (with device variants; `prefix*` patterns allowed) and one note when any
 * of them holds a value. Returns whether a note was written.
 */
export function noteIfSet(w: ElementWriter, keys: string[], message: string): boolean {
  const plain = keys.filter((k) => !k.endsWith('*'));
  const prefixes = keys.filter((k) => k.endsWith('*')).map((k) => k.slice(0, -1));
  let set = anySet(w, plain);
  if (!set && prefixes.length) {
    const src = w.el.settings ?? {};
    set = Object.entries(src).some(([k, v]) => prefixes.some((p) => k.startsWith(p)) && !isBlank(v));
  }
  for (const k of plain) w.consumeResponsive(k);
  if (prefixes.length) w.consume(...prefixes.map((p) => `${p}*`));
  if (set) w.note(message);
  return set;
}

/** Writes `patch` merged into the current value of a border-type Zadex setting. */
function mergeBorder(w: ElementWriter, dst: string, patch: Obj, opts: { bp?: BreakpointKey; state?: ElementState } = {}): void {
  const cur = w.settings[makeLocalKey(dst, opts.state, opts.bp)];
  const current = isObj(cur) ? cur : {};
  w.set(dst, { ...current, ...patch }, { bp: opts.bp, state: opts.state });
}

function makeLocalKey(id: string, state?: string, bp?: string): string {
  return id + (state ? `::${state}` : '') + (bp ? `@${bp}` : '');
}

/**
 * Elementor border group (`<prefix>_border`, `_width`, `_color`) + radius dimensions key -> one Zadex border control
 * (responsive). The radius may also be a slider (some Pro versions).
 */
export function borderWithRadius(w: ElementWriter, prefix: string, radiusKey: string, dst: string, state?: ElementState): void {
  w.border(prefix, dst, undefined, state);
  for (const [key, bp] of deviceKeys(radiusKey)) {
    const v = w.raw(key);
    const d = dimensions(v);
    const s = d ? undefined : slider(v);
    const radius = d ?? (s && typeof s.size === 'number' ? { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true } : undefined);
    if (radius) mergeBorder(w, dst, { radius }, { bp, state });
  }
}

/**
 * Border built from separate keys (no group): a width dimensions key, a color key and a radius key, as several
 * Pro WooCommerce style sections store them (`box_border_width`, `box_border_color`, `box_border_radius`).
 */
export function looseBorder(w: ElementWriter, keys: { width?: string; color?: string; radius?: string }, dst: string, state?: ElementState): void {
  const patch: Obj = {};
  if (keys.width) {
    for (const [k, bp] of deviceKeys(keys.width)) {
      const d = dimensions(w.raw(k));
      if (!d) continue;
      if (bp) mergeBorder(w, dst, { style: 'solid', width: d }, { bp, state });
      else Object.assign(patch, { style: 'solid', width: d });
    }
  }
  if (keys.color) {
    const c = colorValue(w, keys.color);
    w.consumeResponsive(keys.color);
    if (c) patch.color = c;
  }
  if (Object.keys(patch).length) mergeBorder(w, dst, patch, { state });
  if (keys.radius) {
    for (const [k, bp] of deviceKeys(keys.radius)) {
      const v = w.raw(k);
      const d = dimensions(v);
      const s = d ? undefined : slider(v);
      const radius = d ?? (s && typeof s.size === 'number' ? { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true } : undefined);
      if (radius) mergeBorder(w, dst, { radius }, { bp, state });
    }
  }
}

/** Border color only (e.g. a hover border color) merged into a border control. */
export function borderColor(w: ElementWriter, keys: string[], dst: string, state?: ElementState): void {
  let color: string | undefined;
  for (const k of keys) {
    const c = colorValue(w, k);
    w.consumeResponsive(k);
    if (color === undefined && c) color = c;
  }
  if (color) mergeBorder(w, dst, { color }, { state });
}

/** Responsive integer clamped to [min, max] (columns, limits). Missing device values may take defaults. */
export function intResponsive(w: ElementWriter, src: string, dst: string, min: number, max: number, defaults: Partial<Record<string, number>> = {}): void {
  for (const [key, bp] of deviceKeys(src)) {
    const n = posInt(w.raw(key)) ?? (bp ? defaults[bp] : defaults.desktop);
    if (n === undefined) continue;
    const clamped = Math.min(max, Math.max(min, n));
    if (clamped !== n) w.note(`${key}: ${n} is outside the Zadex range ${min}-${max}; ${clamped} is used.`);
    w.set(dst, clamped, { bp });
  }
}

/**
 * Global defaults of the `Products_Base` style controls that have a Zadex equivalent (Elementor Pro 3.33.2 dump):
 * apply them with `withGlobalDefaults()` before opening the writer.
 */
export const PRODUCTS_BASE_GLOBALS: Record<string, string> = {
  title_color: 'globals/colors?id=primary',
  title_typography_typography: 'globals/typography?id=primary',
  price_color: 'globals/colors?id=primary',
  price_typography_typography: 'globals/typography?id=primary',
  old_price_color: 'globals/colors?id=primary',
  button_typography_typography: 'globals/typography?id=accent',
};

/**
 * Pro `Products_Base` style sections (related / upsell / products / archive products) -> Zadex product card
 * controls (`../plugin zadex/widgets/product-related/manifest.json`, same ids on product-upsells / products).
 * Keys verified against Elementor Pro 3.33.2 (`Products_Base::register_controls()`): `column_gap` (20px) / `row_gap`
 * (40px) R, `align` R, `image_border` group + `image_border_radius` R, `image_spacing` R, `title_color`,
 * `title_typography`, `title_spacing`, `star_color`, `empty_star_color`, `star_size` (em), `rating_spacing`,
 * `price_color`, `price_typography`, `old_price_color`, `old_price_typography`, button `button_text_color` /
 * `button_background_color`, hover `button_hover_color` / `button_hover_background_color` /
 * `button_hover_border_color`, `button_border` group + `button_border_radius`, `button_text_padding`,
 * `button_typography`, `button_spacing`, `automatically_align_buttons`, `view_cart_*`, box `box_border_width` R +
 * `box_border_radius` (slider) R + `box_border_color` (+`_hover`), `box_bg_color` (+`_hover`), `box_padding` R,
 * `box_shadow` / `box_shadow_hover` groups, sale flash `show_onsale_flash` (yes), `onsale_text_color`,
 * `onsale_text_background_color`, `onsale_typography`, `onsale_border_radius` (slider), size / position.
 */
export function productCardStyles(w: ElementWriter, cardAlign: Record<string, string>): void {
  // Grid gaps (Pro defaults 20 / 40px come from w.get()).
  for (const id of ['column_gap', 'row_gap']) {
    for (const [key, bp] of deviceKeys(id)) {
      const s = slider(bp ? w.raw(key) : w.get(key));
      if (s && typeof s.size === 'number') w.set(id, s, { bp });
    }
  }
  w.map('align', 'card_align', cardAlign);

  // Image
  borderWithRadius(w, 'image_border', 'image_border_radius', 'image_border');
  sliderAlt(w, ['image_spacing'], 'image_spacing');

  // Title
  flatColor(w, ['title_color'], 'title_color');
  typographyAlt(w, ['title_typography'], 'title_typography');

  // Rating
  flatColor(w, ['star_color'], 'rating_color');
  sliderAlt(w, ['star_size'], 'rating_size', true, 'em');

  // Price
  flatColor(w, ['price_color'], 'price_color');
  typographyAlt(w, ['price_typography'], 'price_typography');
  flatColor(w, ['old_price_color'], 'regular_color');

  // Button (normal / hover)
  flatColor(w, ['button_text_color'], 'button_color');
  flatColor(w, ['button_background_color'], 'button_bg');
  flatColor(w, ['button_hover_color'], 'button_color', 'hover');
  flatColor(w, ['button_hover_background_color'], 'button_bg', 'hover');
  borderWithRadius(w, 'button_border', 'button_border_radius', 'button_border');
  borderColor(w, ['button_hover_border_color'], 'button_border', 'hover');
  typographyAlt(w, ['button_typography'], 'button_typography');
  dimensionsAlt(w, ['button_text_padding'], 'button_padding');

  // Box (card): loose keys `box_border_width` / `box_border_color` / `box_border_radius` (slider).
  looseBorder(w, { width: 'box_border_width', color: 'box_border_color', radius: 'box_border_radius' }, 'card_border');
  borderColor(w, ['box_border_color_hover'], 'card_border', 'hover');
  flatColor(w, ['box_bg_color'], 'card_bg');
  flatColor(w, ['box_bg_color_hover'], 'card_bg', 'hover');
  dimensionsAlt(w, ['box_padding'], 'card_padding');
  w.boxShadow('box_shadow', 'card_shadow');
  w.boxShadow('box_shadow_hover', 'card_shadow', 'hover');

  // Sale flash (badge): `show_onsale_flash` (Pro default yes).
  const flash = w.get('show_onsale_flash');
  w.set('show_badge', flash === 'yes' || flash === true);
  flatColor(w, ['onsale_text_color'], 'badge_color');
  flatColor(w, ['onsale_text_background_color'], 'badge_bg');
  typographyAlt(w, ['onsale_typography'], 'badge_typography');
  looseBorder(w, { radius: 'onsale_border_radius' }, 'badge_border');

  noteIfSet(w, ['empty_star_color'], 'The empty star color is not available on the Zadex product cards.');
  noteIfSet(w, ['title_spacing', 'rating_spacing', 'button_spacing'], 'Spacing between the card title / rating / button is not carried over.');
  noteIfSet(w, ['old_price_typography_*'], 'The regular (crossed-out) price typography is not carried over; only its color.');
  noteIfSet(w, ['view_cart_color', 'view_cart_spacing', 'view_cart_typography_*'], 'The "View cart" link styles are not carried over.');
  noteIfSet(w, ['onsale_width', 'onsale_height', 'onsale_horizontal_position', 'onsale_distance'], 'The sale badge size / position is not carried over.');
  if (w.raw('automatically_align_buttons') === 'yes') w.note('"Automatically align buttons" is not available on the Zadex product cards.');
  w.consume('products_class', 'wc_style_warning');
}

export { isObj };
