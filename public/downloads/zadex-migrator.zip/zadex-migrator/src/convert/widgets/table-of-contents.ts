import { registerWidget } from '../registry';
import { deviceKeys } from '../responsive';
import { dimensions, slider } from '../values';
import { markPro } from './_pro';
import { proSwitch, proText, proVal } from './_pro-content';
import { boxTitleTag, desktopOnly, iconValue, isObj } from './_shared';

const LEVELS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];

/**
 * Elementor `minimized_on` ("minimize on this device and below": mobile|tablet|desktop; older data may hold a list or
 * another breakpoint) -> Zadex `collapse_on` devices.
 */
const MINIMIZED_ON: Record<string, string[]> = {
  widescreen: ['desktop', 'tablet', 'mobile'],
  desktop: ['desktop', 'tablet', 'mobile'],
  laptop: ['desktop', 'tablet', 'mobile'],
  tablet_extra: ['tablet', 'mobile'],
  tablet: ['tablet', 'mobile'],
  mobile_extra: ['mobile'],
  mobile: ['mobile'],
};

/** Font Awesome bullet glyph -> Zadex CSS marker (other icons use the `icon` marker). */
const MARKERS: Record<string, string> = { 'fa-circle': 'bullet', 'fa-dot-circle': 'circle', 'fa-square': 'square', 'fa-check': 'check', 'fa-minus': 'dash' };

/**
 * Elementor Pro `table-of-contents` -> Zadex `table-of-contents`. Keys verified against Elementor Pro 3.33.2
 * (defaults from elementor-defaults.json): content `title`, `html_tag` h2…h6|div (h4), `headings_by_tags` (h2…h6),
 * `container`, `exclude_headings_by_selector`, `marker_view` numbers|bullets (numbers), `icon` (fas fa-circle),
 * `no_headings_message`, `word_wrap`, `minimize_box` (yes), `expand_icon` / `collapse_icon`, `minimized_on`
 * mobile|tablet|desktop (tablet), `hierarchical_view` (yes), `collapse_subitems`; style `background_color`,
 * `border_color`, `loader_color`, `border_width`, `border_radius`, `header_separator_width`, `padding` (sliders),
 * `min_height` R, `box_shadow_*`, `header_text_align` start|center|end, `header_background_color`,
 * `header_text_color`, `header_typography`, `toggle_button_color`, `toggle_button_position`, `heading_gap`,
 * `max_height`, `list_typography`, `list_indent`, `item_text_color_*` / `item_text_underline_*` (normal, hover,
 * active), `item_text_hover_transition_duration`, `marker_color`, `marker_size`. Pro 3.33 has no TOC-specific sticky
 * controls: stickiness is the generic Advanced > Motion effects `sticky` (common.ts).
 */
registerWidget('table-of-contents', (el, ctx) => {
  const w = ctx.writer(el, 'table-of-contents');
  markPro(w);

  w.set('title', proText(w, 'title', 'Table of Contents'));
  w.set('title_tag', boxTitleTag(w, proText(w, 'html_tag', 'h4')));

  const tags = proVal(w, 'headings_by_tags', ['h2', 'h3', 'h4', 'h5', 'h6']);
  const levels = (Array.isArray(tags) ? tags : [tags]).map(String).filter((t) => LEVELS.includes(t));
  w.set('headings', levels.length ? levels : ['h2', 'h3', 'h4', 'h5', 'h6']);
  w.set('container', proText(w, 'container'));
  w.set('exclude', proText(w, 'exclude_headings_by_selector'));
  w.set('hierarchical', proSwitch(w, 'hierarchical_view', true));
  if (proSwitch(w, 'collapse_subitems')) {
    w.note('Collapsing sub-items is not available in Zadex; nested items are always shown.');
    w.status('partial');
  }
  if (proSwitch(w, 'word_wrap')) w.note('Word wrap (one line per item, ellipsis) is not available in Zadex; long items wrap.');

  // Markers: numbers or bullets with an icon (Pro default icon: fas fa-circle).
  const view = proText(w, 'marker_view', 'numbers');
  w.set('numbering', view === 'numbers');
  const rawIcon = w.get('icon');
  if (view !== 'numbers') {
    const value = isObj(rawIcon) && typeof rawIcon.value === 'string' ? rawIcon.value : '';
    const glyph = value.split(/\s+/).find((p) => p.startsWith('fa-') && !['fa-solid', 'fa-regular', 'fa-brands'].includes(p));
    if (glyph && MARKERS[glyph]) w.set('marker', MARKERS[glyph]);
    else if (isObj(rawIcon) && (value !== '' || rawIcon.library === 'svg')) {
      const ic = iconValue(w, 'icon');
      if (ic) {
        w.set('marker', 'icon');
        w.set('marker_icon', ic);
      } else w.set('marker', 'bullet');
    } else w.set('marker', 'none');
  }

  w.set('empty_text', proText(w, 'no_headings_message'));

  // Minimize box (Elementor: collapsed by default on tablet and below).
  const minimize = proSwitch(w, 'minimize_box', true);
  w.set('collapsible', minimize);
  if (minimize) {
    const on = proVal(w, 'minimized_on', 'tablet');
    const devices = new Set<string>();
    for (const d of Array.isArray(on) ? on : [on]) for (const z of MINIMIZED_ON[String(d)] ?? []) devices.add(z);
    w.set('collapse_on', devices.size ? ['desktop', 'tablet', 'mobile'].filter((d) => devices.has(d)) : ['mobile']);
    if (!isDefaultIcon(w.raw('expand_icon'), 'fa-chevron-down') || !isDefaultIcon(w.raw('collapse_icon'), 'fa-chevron-up')) {
      w.note('Custom expand / collapse icons are not carried over (Zadex shows its own toggle).');
    }
    if (proText(w, 'toggle_button_position', 'row') === 'row-reverse') w.note('The toggle button before the title is not available in Zadex (it is shown after).');
    if (w.has('heading_gap')) w.note('The gap between the title and the toggle is not available in Zadex.');
  }
  w.consume('minimized_on', 'expand_icon', 'collapse_icon', 'toggle_button_position');
  w.consumeResponsive('heading_gap');

  // Box.
  w.color('background_color', 'box_bg');
  const borderColor = w.raw('border_color');
  const borderWidth = slider(w.raw('border_width'));
  const radius = slider(w.raw('border_radius'));
  const border: Record<string, unknown> = {};
  if (borderWidth) {
    const n = borderWidth.size;
    border.style = 'solid';
    border.width = { top: n, right: n, bottom: n, left: n, unit: borderWidth.unit, linked: true };
  }
  if (typeof borderColor === 'string' && borderColor !== '') border.color = borderColor;
  if (radius) border.radius = { top: radius.size, right: radius.size, bottom: radius.size, left: radius.size, unit: radius.unit, linked: true };
  if (Object.keys(border).length) w.set('box_border', border);
  w.color('border_color', 'separator_color');
  w.consumeResponsive('border_width');
  w.consumeResponsive('border_radius');
  for (const [key, bp] of deviceKeys('padding')) {
    const v = w.raw(key);
    const s = slider(v);
    const d = s ? { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true } : dimensions(v);
    if (d) w.set('box_padding', d, { bp });
  }
  if (w.has('min_height')) w.note('The minimum box height is not available in Zadex.');
  w.consumeResponsive('min_height');
  w.boxShadow('box_shadow', 'box_shadow');
  w.slider('max_height', 'max_height');
  w.consume('loader_color');

  // Header.
  const headerAlign = proText(w, 'header_text_align', 'start');
  if (headerAlign !== 'start' && headerAlign !== '') w.note(`Title alignment "${headerAlign}" is not available in Zadex (the title starts the header).`);
  w.color('header_background_color', 'header_bg');
  w.color('header_text_color', 'title_color');
  w.typography('header_typography', 'title_typography');
  desktopOnly(w, 'title_typography');
  w.color('toggle_button_color', 'toggle_color');
  if (w.has('header_separator_width')) w.note('The header separator width is not available in Zadex (its color is kept).');
  w.consume('header_separator_width');

  // List.
  w.typography('list_typography', 'list_typography');
  desktopOnly(w, 'list_typography');
  w.slider('list_indent', 'indent', undefined, 'em');
  w.color('item_text_color_normal', 'link_color');
  w.color('item_text_color_hover', 'link_color_hover');
  w.color('item_text_color_active', 'active_color');
  w.color('marker_color', 'marker_color');
  if (w.has('marker_size')) w.note('The marker size is not available in Zadex.');
  if (w.raw('item_text_underline_normal') === 'yes' || w.raw('item_text_underline_active') === 'yes' || w.raw('item_text_underline_hover') === '') {
    w.note('Link underline settings (normal / hover / active) are not carried over.');
  }
  w.consume('marker_size', 'item_text_underline_normal', 'item_text_underline_hover', 'item_text_underline_active', 'item_text_hover_transition_duration');
  return w.finish();
});

/** True when an Elementor icon value is absent or still Pro's default glyph. */
function isDefaultIcon(v: unknown, glyph: string): boolean {
  return !isObj(v) || typeof v.value !== 'string' || v.value === '' || v.value.split(/\s+/).includes(glyph);
}
