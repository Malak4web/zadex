import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { isBlank } from '../values';
import { describeIcon, only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { colorAlt, dimensionsAlt, sliderAlt, typographyAlt } from './_marketing';
import { borderParts, hoverBorderColor, isObj } from './_woo-shop';
import { noteIfSet } from './_woo-product';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-menu-cart` -> Zadex `menu-cart`. Verified against Elementor Pro 3.33.2:
 * `icon` cart-light | cart-medium (default) | cart-solid | basket-* | bag-* | custom (+ `menu_icon_svg`),
 * `items_indicator` bubble (default) | plain | none, `hide_empty_indicator`, `show_subtotal` (yes), `alignment` R,
 * `cart_type` side-cart (default) | mini-cart, `open_cart` click (default) | mouseover, `side_cart_alignment` start |
 * end, `mini_cart_alignment` / `mini_cart_spacing`, `automatically_open_cart` ("no"), `automatically_update_cart`,
 * `close_cart_button_show` / `show_remove_icon` / `show_divider` / `view_cart_button_show` / `checkout_button_show`
 * (yes); style toggle `toggle_button_text_color` / `_icon_color` / `_background_color` / `_border_color` and their
 * `toggle_button_hover_*` variants, `toggle_button_border_width` / `_radius` (sliders), `toggle_button_padding`,
 * `toggle_button_typography` (global primary), `toggle_icon_size`, `items_indicator_text_color` /
 * `_background_color`; panel `background_color`, `border_type` (none) / `border_width` / `border_color` /
 * `border_radius`, `cart_padding`, `cart_box_shadow`, `product_title_color`; buttons `product_buttons_typography`
 * (both, global primary), `button_border_radius` (both, slider), view cart `view_cart_buttons_typography`,
 * `view_cart_button_text_color` / `_background_color` / `_hover_text_color` / `_hover_background` /
 * `_border_hover_color`, `view_cart_border` group, `view_cart_button_border_radius`, `view_cart_button_padding`;
 * checkout `checkout_button_*`, `checkout_border_*`, `view_checkout_button_*`, `cart_checkout_button_typography`.
 * Pro has no panel width / overlay color / "hide when empty" controls.
 */

/** Pro icon names -> the three Zadex icons (light / medium / solid weights are not distinguished). */
const ICONS: Record<string, string> = {
  'cart-light': 'cart',
  'cart-medium': 'cart',
  'cart-solid': 'cart',
  'basket-light': 'basket',
  'basket-medium': 'basket',
  'basket-solid': 'basket',
  'bag-light': 'bag',
  'bag-medium': 'bag',
  'bag-solid': 'bag',
};

registerWidget('woocommerce-menu-cart', (source, ctx) => {
  const off = wooGuard(source, ctx, 'menu-cart');
  if (off) return off;
  const el = withGlobalDefaults(source, ctx, {
    toggle_button_typography_typography: 'globals/typography?id=primary',
    product_buttons_typography_typography: 'globals/typography?id=primary',
  });
  const w = ctx.writer(el, 'menu-cart');
  markPro(w);

  const icon = String(w.get('icon') || 'cart-medium');
  const custom = w.get('menu_icon_svg');
  if (ICONS[icon]) w.set('icon', ICONS[icon]);
  else {
    w.set('icon', 'cart');
    const what = icon === 'custom' && isObj(custom) ? ` "${describeIcon(custom)}"` : ` "${icon}"`;
    w.note(`Cart icon${what} is not available in the Zadex Menu cart (bag, cart or basket); the cart icon is used.`);
    w.status('partial');
  }

  const indicator = String(w.get('items_indicator') || 'bubble');
  w.set('show_count', indicator !== 'none');
  if (indicator === 'plain') w.note('The plain items indicator is shown as a bubble in Zadex.');
  w.set('hide_empty_count', indicator !== 'none' && w.get('hide_empty_indicator') === 'yes');
  w.set('show_subtotal', w.get('show_subtotal') === 'yes');
  w.map('alignment', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));

  const type = String(w.get('cart_type') || 'side-cart');
  w.set('mode', type === 'mini-cart' ? 'dropdown' : 'offcanvas');
  if (w.get('open_cart') === 'mouseover') w.note('Opening the cart on hover is not available in Zadex; it opens on click.');
  if (type !== 'mini-cart') {
    const side = String(w.get('side_cart_alignment') || 'end');
    w.set('side', side === 'start' ? 'start' : 'end');
    w.set('open_on_add', w.get('automatically_open_cart') === 'yes');
    w.consume('mini_cart_alignment', 'mini_cart_spacing');
  } else {
    w.consume('side_cart_alignment', 'automatically_open_cart', 'buttons_position');
    noteIfSet(w, ['mini_cart_alignment', 'mini_cart_spacing'], 'The mini cart alignment / spacing is not carried over.');
  }
  w.consume('automatically_update_cart');
  const hidden = ['close_cart_button_show', 'show_remove_icon', 'show_divider', 'view_cart_button_show', 'checkout_button_show'].filter((k) => w.get(k) !== 'yes');
  if (hidden.length) {
    w.note(`Hiding cart parts (${hidden.join(', ')}) is not available in the Zadex Menu cart.`);
    w.status('partial');
  }

  // Toggle button.
  colorAlt(w, ['toggle_button_text_color', 'toggle_button_icon_color'], 'toggle_color');
  colorAlt(w, ['toggle_button_hover_text_color', 'toggle_button_hover_icon_color'], 'toggle_color', 'hover');
  colorAlt(w, ['toggle_button_background_color'], 'toggle_bg');
  colorAlt(w, ['toggle_button_hover_background_color'], 'toggle_bg', 'hover');
  borderParts(w, 'toggle_border', { prefix: 'toggle_button_border', colorKeys: ['toggle_button_border_color'], radiusKeys: ['toggle_button_border_radius'] });
  if (!isBlank(w.raw('toggle_button_hover_border_color'))) w.note('The toggle hover border color is not available in Zadex.');
  dimensionsAlt(w, ['toggle_button_padding'], 'toggle_padding');
  sliderAlt(w, ['toggle_icon_size'], 'icon_size');
  typographyAlt(w, ['toggle_button_typography'], 'subtotal_typography');
  colorAlt(w, ['items_indicator_text_color'], 'count_color');
  colorAlt(w, ['items_indicator_background_color'], 'count_bg');
  noteIfSet(w, ['toggle_icon_spacing', 'toggle_icon_position', 'items_indicator_distance', 'toggle_button_normal_box_shadow_*', 'toggle_button_hover_box_shadow_*'], 'Toggle icon spacing / position, indicator distance and toggle shadows are not carried over.');

  // Cart panel.
  colorAlt(w, ['background_color'], 'panel_bg');
  colorAlt(w, ['product_title_color'], 'panel_color');
  dimensionsAlt(w, ['cart_padding'], 'panel_padding');
  w.boxShadow('cart_box_shadow', 'panel_shadow');
  const borderType = w.get('border_type');
  w.consume('border_width', 'border_color', 'border_radius');
  if (typeof borderType === 'string' && borderType !== '' && borderType !== 'none') w.note('The cart panel border is not available in Zadex.');
  noteIfSet(w, ['border_radius'], 'The cart panel border radius is not available in Zadex.');

  // Mini cart buttons: Zadex styles both buttons alike, from the view cart button (checkout differences noted).
  typographyAlt(w, ['view_cart_buttons_typography', 'product_buttons_typography'], 'button_typography');
  colorAlt(w, ['view_cart_button_text_color'], 'button_color');
  colorAlt(w, ['view_cart_button_hover_text_color'], 'button_color', 'hover');
  colorAlt(w, ['view_cart_button_background_color'], 'button_bg');
  colorAlt(w, ['view_cart_button_hover_background'], 'button_bg', 'hover');
  borderParts(w, 'button_border', { prefix: 'view_cart_border', colorKeys: ['view_cart_border_color'], radiusKeys: ['view_cart_button_border_radius', 'button_border_radius'] });
  hoverBorderColor(w, 'button_border', ['view_cart_button_border_hover_color']);
  dimensionsAlt(w, ['view_cart_button_padding'], 'button_padding');
  const checkout = Object.keys(source.settings ?? {}).filter((k) => /^(checkout_button_(?!show|alignment|display)|checkout_border_|view_checkout_button_|cart_checkout_button_typography_)/.test(k) && !isBlank(source.settings[k]));
  w.consume('checkout_button_*', 'checkout_border_*', 'view_checkout_button_*', 'cart_checkout_button_typography_*');
  if (checkout.length) {
    w.note('Zadex styles the view cart and checkout buttons alike; the checkout button styles were left out.');
    w.status('partial');
  }
  noteIfSet(w, ['view_cart_button_alignment', 'buttons_layout', 'space_between_buttons', 'buttons_position'], 'The cart buttons layout / alignment is not carried over.');
  return w.finish();
});
