import { registerWidget } from '../registry';
import { fallback } from '../fallback';
import type { ConvertContext } from '../context';
import type { ElElement } from '../types';
import { PRO_NOTE, markPro } from './_pro';
import { resolveLibraryTemplate } from './template';

/**
 * Elementor Pro global widget instance (`widgetType: 'global'`, Pro 3.33.2 `Global_Widget`). The element has no
 * controls of its own: Pro saves `templateID` (an `elementor_library` post of type `widget` whose first element is the
 * real widget) and renders that template's widget with the template's settings.
 *
 * 1. The template was migrated to a Zadex library item (`source.libraryTemplates`): a Zadex `template` widget points at
 *    it, so the content stays shared.
 * 2. The server sent the template's widget (`source.globalWidgets[templateID]`, includes/Migration/Source.php): it is
 *    converted in place as a normal widget (a local copy). The note names the Zadex "Save as global widget…" action
 *    (element context menu) to share it again.
 * 3. Otherwise (template deleted / not readable): fallback (rendered HTML when sent, else skipped) with a note.
 */
registerWidget('global', (el, ctx) => {
  const templateId = el.templateID;
  const id = Number(templateId) || 0;

  const target = resolveLibraryTemplate(ctx, templateId);
  if (target) {
    const w = ctx.writer(el, 'template');
    markPro(w);
    w.set('template_id', target);
    w.note(`Elementor global widget #${id} points at its migrated Zadex library item.`);
    return w.finish();
  }

  const tpl = id ? ctx.source.globalWidgets?.[String(id)] : undefined;
  if (tpl && typeof tpl === 'object' && tpl.elType === 'widget' && typeof tpl.widgetType === 'string' && tpl.widgetType !== '' && tpl.widgetType !== 'global') {
    const copy: ElElement = { ...tpl, id: el.id, settings: { ...(tpl.settings ?? {}) }, elements: Array.isArray(tpl.elements) ? tpl.elements : [] };
    delete copy.templateID;
    const out = ctx.convert([copy]);
    addNotes(ctx, el.id, [
      PRO_NOTE,
      `Elementor global widget #${id} ("${tpl.widgetType}") was converted as a local copy. To share it across pages again, right-click it in Zadex and choose "Save as global widget…".`,
    ]);
    return out;
  }

  const out = fallback(el, ctx);
  addNotes(ctx, el.id, [
    PRO_NOTE,
    id
      ? `The content of Elementor global widget #${id} was not available (template missing or not readable), so it could not be converted.`
      : 'The Elementor global widget has no template id.',
  ]);
  return out;
});

/** Appends notes to the report entry of an element (the last one recorded for that source id). */
function addNotes(ctx: ConvertContext, source: string, notes: string[]): void {
  const entries = ctx.report.entries;
  for (let i = entries.length - 1; i >= 0; i--) {
    if (entries[i]!.source !== source) continue;
    for (const n of notes) if (!entries[i]!.notes.includes(n)) entries[i]!.notes.push(n);
    return;
  }
}
