import { registerWidget } from '../registry';

/** Elementor `spacer` -> Zadex `spacer` (`space` -> `height`, responsive). */
registerWidget('spacer', (el, ctx) => {
  const w = ctx.writer(el, 'spacer');
  w.slider('space', 'height');
  return w.finish();
});
