import { registerWidget } from '../registry';
import type { ConvertContext } from '../context';
import type { ElElement, ZElement } from '../types';

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * WordPress legacy widgets placed in Elementor (`wp-widget-<id_base>`, settings in `wp`). Only the two with a clear
 * Zadex equivalent are mapped; every other `wp-widget-*` goes to the fallback (rendered HTML when available).
 * The widget title (styled by the theme in Elementor) becomes a Zadex heading in front of the widget.
 */
function titleHeading(el: ElElement, ctx: ConvertContext, title: string): ZElement[] {
  if (title.trim() === '' || !ctx.hasWidget('heading')) return [];
  return [{ id: ctx.idFor(el.id, 'h'), type: 'heading', settings: { text: title.trim(), tag: 'h2' }, children: [] }];
}

registerWidget('wp-widget-search', (el, ctx) => {
  const w = ctx.writer(el, 'search-form');
  const wp = isObj(w.raw('wp')) ? (w.raw('wp') as Obj) : {};
  w.set('layout', 'button');
  w.set('placeholder', 'Search …');
  w.set('button_text', 'Search');
  const title = typeof wp.title === 'string' ? wp.title : '';
  const heading = titleHeading(el, ctx, title);
  if (heading.length) w.note('The widget title became a heading before the search form.');
  w.note('The WordPress search widget was styled by the theme; the Zadex search form uses its own style.');
  return [...heading, w.finish()];
});

registerWidget('wp-widget-nav_menu', (el, ctx) => {
  const w = ctx.writer(el, 'nav-menu');
  const wp = isObj(w.raw('wp')) ? (w.raw('wp') as Obj) : {};
  const menu = wp.nav_menu;
  w.set('menu', menu === undefined || menu === null ? '' : String(menu));
  if (menu === undefined || menu === '' || menu === 0 || menu === '0') w.note('No menu was selected in the WordPress widget.');
  // The legacy widget prints a plain vertical list with nested sub-lists.
  w.set('layout', 'vertical');
  w.set('pointer', 'none');
  w.set('collapse', 'none');
  const title = typeof wp.title === 'string' ? wp.title : '';
  const heading = titleHeading(el, ctx, title);
  if (heading.length) w.note('The widget title became a heading before the menu.');
  w.note('The WordPress menu widget was styled by the theme; submenus open as Zadex dropdowns instead of nested lists.');
  w.status('partial');
  return [...heading, w.finish()];
});
