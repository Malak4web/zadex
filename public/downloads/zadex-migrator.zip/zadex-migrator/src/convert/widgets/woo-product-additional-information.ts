import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { noteIfSet } from './_woo-product';
import { panelText } from './woo-product-data-tabs';

/**
 * Elementor Pro `woocommerce-product-additional-information` (the attributes table alone) -> Zadex
 * `product-data-tabs` with only the "Additional information" tab (Zadex has no standalone attributes widget; the
 * single tab title stays visible, noted). Verified against Elementor Pro 3.33.2: `show_heading` (default yes),
 * `heading_color`, `heading_typography_*`, `content_color`, `content_typography_*`.
 */
registerWidget('woocommerce-product-additional-information', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-data-tabs');
  if (off) return off;
  const w = ctx.writer(source, 'product-data-tabs');
  markPro(w);
  w.set('description', false);
  w.set('additional', true);
  w.set('reviews', false);
  w.note('Shown as product data tabs with only the "Additional information" tab (its tab title is visible).');
  panelText(w, ['content_color'], ['content_typography']);
  if (w.get('show_heading') !== 'yes') w.note('"Show heading" off is not carried over: WooCommerce prints the "Additional information" heading in the panel.');
  noteIfSet(w, ['heading_color', 'heading_typography_*'], 'The heading styles are not carried over.');
  return w.finish();
});
