import { registerWidget } from '../registry';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement } from '../types';
import { isBlank, slider } from '../values';
import { markPro } from './_pro';
import { repeaterItems, withGlobalDefaults } from './_shared';
import { colorOf, getBool, getInt, getStr, mapNothingFound, mapPagination, mapQuery, responsiveGet, responsiveSliderGet, toInt } from './_pro-posts';
import { loadMoreButtonDefaults, PAGINATION_GLOBALS } from './posts';

/**
 * Elementor Pro `loop-grid` / `loop-carousel`, verified against Pro 3.33.2. Their items are rendered by a loop item
 * template (`template_id`, an Elementor template post) that has to be converted on its own. When
 * `source.loopTemplates` maps that id to a Zadex loop-item template, the widget becomes a Zadex `loop-grid` /
 * `loop-carousel` using it; otherwise it falls back to a Zadex `posts` widget (classic skin) with the same query and
 * a similar layout, and the report says so.
 * Keys: `_skin` post (default) | product | post_taxonomy | product_taxonomy, `template_id`, `posts_per_page` (6),
 * query group `post_query_*` (product skin `product_query_*`); grid `columns` R (3 / 2 / 1), `masonry`,
 * `equal_height`, `column_gap` / `row_gap` R (none stored: Pro CSS 30px), `alternate_template` +
 * `alternate_templates` {`template_id`, `repeat_template`, `show_once` (yes), `column_span`, `static_position`},
 * pagination like posts, `enable_nothing_found_message`; carousel `slides_to_show` R (3 / 2 / 1),
 * `slides_to_scroll` (1), `equal_height` (yes), `image_spacing_custom` R (10px), `autoplay` (yes),
 * `autoplay_speed` (5000), `pause_on_hover` (yes), `infinite` (yes), `speed` (500), `direction`, `offset_sides`,
 * `arrows` (yes), `pagination` (bullets), style `arrows_size` (CSS 25px), `arrow_normal_color` (CSS
 * rgba(238,238,238,0.9)), `arrows_normal_background_color`, `arrows_position`, `dots_normal_color` (CSS #000),
 * `dots_hover_color`, `dots_size`.
 */

/** Zadex loop-item template id for an Elementor template id, or undefined when it was not converted yet. */
export function resolveLoopTemplate(ctx: ConvertContext, templateId: unknown): string | undefined {
  if (isBlank(templateId)) return undefined;
  // The server sends `Record<string, number>` (JSON object keys are strings); Elementor stores `template_id` as a
  // number or a numeric string, so both are looked up by their string form. Non-positive / non-numeric ids are ignored.
  const hit = ctx.source.loopTemplates?.[String(templateId).trim()];
  const id = Number(hit);
  return hit === undefined || hit === null || hit === '' || !Number.isInteger(id) || id <= 0 ? undefined : String(id);
}

/** Skin, posts per page, template id; returns the query prefix to use (undefined for taxonomy skins). */
function commonLoop(w: ElementWriter): { perPage: number; templateId: unknown; queryPrefix: string | undefined } {
  markPro(w);
  const skin = getStr(w, '_skin') || 'post';
  let queryPrefix: string | undefined = 'post_query_';
  if (skin === 'product') queryPrefix = 'product_query_';
  else if (skin !== 'post') {
    w.note(`The "${skin}" loop skin (a loop over terms) is not available in Zadex; posts are listed instead.`);
    w.status('partial');
    queryPrefix = undefined;
  }
  // Query groups of the other skins are ignored by Elementor too.
  for (const p of ['post_query_', 'product_query_', 'post_taxonomy_', 'product_taxonomy_']) if (p !== queryPrefix) w.consume(`${p}*`);
  return { perPage: getInt(w, 'posts_per_page') ?? 6, templateId: w.raw('template_id'), queryPrefix };
}

function fallbackNote(w: ElementWriter, templateId: unknown, kind: string): void {
  const id = isBlank(templateId) ? '' : ` ${String(templateId)}`;
  w.note(
    `The loop item template${id} has not been converted to Zadex yet: the ${kind} became a Zadex Posts widget with the same query. ` +
      `Convert the template, then replace this widget with a Zadex ${kind} that uses it.`,
  );
  w.status('partial');
}

function query(w: ElementWriter, prefix: string | undefined, perPage: number): void {
  if (prefix) mapQuery(w, prefix, perPage);
  else w.set('query_per_page', Math.min(100, Math.max(1, perPage)));
}

registerWidget('loop-grid', (source, ctx) => {
  const template = resolveLoopTemplate(ctx, source.settings?.template_id);
  const el = withGlobalDefaults(source, ctx, PAGINATION_GLOBALS);
  const w = ctx.writer(el, template ? 'loop-grid' : 'posts');
  const { perPage, templateId, queryPrefix } = commonLoop(w);
  responsiveGet(w, 'columns', 'columns', [1, 12]);
  // No stored gap = Pro CSS `var(--grid-column-gap, 30px)` / `var(--grid-row-gap, 30px)`.
  responsiveSliderGet(w, 'column_gap', 'column_gap', { size: 30, unit: 'px' });
  responsiveSliderGet(w, 'row_gap', 'row_gap', { size: 30, unit: 'px' });
  const masonry = getBool(w, 'masonry');
  w.set('masonry', masonry);
  if (!masonry) w.set('equal_height', getBool(w, 'equal_height'));
  else w.consume('equal_height');
  if (template) {
    w.set('template', template);
    alternates(w, ctx, el);
  } else {
    fallbackNote(w, templateId, 'loop grid');
    postsFallbackDefaults(w);
    if (getBool(w, 'alternate_template')) w.note('Alternate templates were not carried over.');
    w.consume('alternate_template', 'alternate_templates');
  }
  w.consume('edit_handle_selector');
  mapPagination(w, Boolean(ctx.source.rtl));
  loadMoreButtonDefaults(w);
  mapNothingFound(w);
  query(w, queryPrefix, perPage);
  return w.finish();
});

registerWidget('loop-carousel', (el, ctx) => {
  const template = resolveLoopTemplate(ctx, el.settings?.template_id);
  const w = ctx.writer(el, template ? 'loop-carousel' : 'posts');
  const { perPage, templateId, queryPrefix } = commonLoop(w);
  const gap = slider(w.get('image_spacing_custom')) ?? { size: 10, unit: 'px' };
  if (template) {
    w.set('template', template);
    responsiveGet(w, 'slides_to_show', 'slides_to_show', [1, 10], { desktop: 3, tablet: 2, mobile: 1 });
    w.set('slides_to_scroll', Math.min(10, getInt(w, 'slides_to_scroll') ?? 1));
    w.consume('slides_to_scroll_*');
    w.set('gap', gap);
    w.set('speed', Math.min(5000, getInt(w, 'speed') ?? 500));
    const autoplay = getBool(w, 'autoplay');
    w.set('autoplay', autoplay);
    if (autoplay) w.set('autoplay_speed', Math.min(30000, Math.max(500, getInt(w, 'autoplay_speed') ?? 5000)));
    else w.consume('autoplay_speed');
    if (autoplay && !getBool(w, 'pause_on_hover')) w.note('Zadex always pauses the loop carousel on hover.');
    w.set('loop', getBool(w, 'infinite'));
    const arrows = getBool(w, 'arrows');
    w.set('arrows', arrows);
    const pagination = getStr(w, 'pagination');
    w.set('dots', pagination !== '');
    if (pagination === 'fraction' || pagination === 'progressbar') w.note(`The "${pagination}" pagination is shown as dots in Zadex.`);
    if (arrows) {
      w.set('arrow_size', slider(w.raw('arrows_size')) ?? { size: 25, unit: 'px' });
      w.set('arrow_color', colorOf(w, 'arrow_normal_color') ?? 'rgba(238,238,238,0.9)');
      const bg = colorOf(w, 'arrows_normal_background_color');
      if (bg) w.set('arrow_bg', bg);
      if (getStr(w, 'arrows_position') === 'outside') w.note('Arrows outside the carousel are not available in the Zadex loop carousel.');
    }
    if (pagination === 'bullets') {
      // Pro bullets share one color; the inactive ones are drawn at Swiper's 20% opacity.
      const dot = colorOf(w, 'dots_normal_color');
      w.set('dot_active_color', dot ?? '#000000');
      if (!dot) w.set('dot_color', 'rgba(0,0,0,0.2)');
      if (slider(w.raw('dots_size'))) w.note('The dot size is not available in the Zadex loop carousel.');
    }
    if (getStr(w, 'direction') === 'rtl') w.note('A right-to-left slide direction is not available in Zadex.');
    alternates(w, ctx, el);
  } else {
    fallbackNote(w, templateId, 'loop carousel');
    w.note('The posts are shown in a grid with one column per visible slide (Zadex Posts has no carousel).');
    responsiveGet(w, 'slides_to_show', 'columns', [1, 12], { desktop: 3, tablet: 2, mobile: 1 });
    w.set('column_gap', gap);
    w.set('row_gap', gap);
    postsFallbackDefaults(w);
    w.consume('slides_to_scroll*', 'speed', 'autoplay*', 'pause_on_*', 'infinite', 'arrow*', 'pagination', 'dots_*', 'direction', 'alternate_template', 'alternate_templates');
  }
  if (getStr(w, 'offset_sides') !== 'none' && getStr(w, 'offset_sides') !== '') w.note('Partly visible side slides (offset) are not available in Zadex.');
  w.consume('direction', 'offset_sides', 'offset_width*', 'equal_height', 'image_spacing_custom*', 'navigation_*', 'arrows_*', 'arrow_hover_color', 'dots_*', 'fraction_*', 'typography_fraction_*', 'progressbar_*', 'edit_handle_selector');
  // Pro's loop carousel has no "nothing found" message: an empty query renders nothing.
  w.set('nothing_found', '');
  query(w, queryPrefix, perPage);
  return w.finish();
});

/** Classic posts skin parts that look closest to a typical loop item card (image, title, excerpt). */
function postsFallbackDefaults(w: ElementWriter): void {
  w.set('skin', 'classic');
  w.set('meta', []);
  w.set('show_read_more', false);
  w.set('image_hover', 'none');
}

/**
 * Pro alternate templates -> Zadex `alternates` (only those whose template was converted). `show_once` (default yes)
 * = only at item `repeat_template`; off = every `repeat_template` items. Static positions and column spans noted.
 */
function alternates(w: ElementWriter, ctx: ConvertContext, el: ElElement): void {
  if (!getBool(w, 'alternate_template')) {
    w.consume('alternate_templates');
    return;
  }
  const out: Array<Record<string, unknown>> = [];
  let missing = 0;
  repeaterItems(w.raw('alternate_templates')).forEach((item, i) => {
    const t = resolveLoopTemplate(ctx, item.template_id);
    const n = toInt(item.repeat_template);
    if (!t || n === undefined) {
      missing++;
      return;
    }
    const once = item.show_once === undefined || item.show_once === 'yes';
    if (item.static_position === 'yes') w.note('Static alternate template positions (not counted as posts) are not available in Zadex; the template replaces a post.');
    if (toInt(item.column_span) !== undefined && toInt(item.column_span)! > 1) w.note('Alternate templates spanning several columns are not available in Zadex.');
    const base = { _id: ctx.itemId(typeof item._id === 'string' ? item._id : `${el.id}a${i}`), template: t };
    if (once) out.push({ ...base, mode: 'positions', positions: String(n) });
    else out.push({ ...base, mode: 'every', nth: Math.min(50, n) });
  });
  if (out.length) w.set('alternates', out);
  if (missing) {
    w.note(`${missing} alternate template(s) have not been converted to Zadex yet (or have no position) and were left out.`);
    w.status('partial');
  }
}

