import type { ElementWriter } from '../context';

/**
 * Elementor Pro widgets are mapped from knowledge of the Pro data format: no Elementor Pro install was available to
 * read control ids / defaults from (docs/TASKS.md "Phase 2"). Every Pro mapper calls `markPro(w)` so the report
 * says so until the mapping is checked against real Pro exports.
 */
export const PRO_NOTE = 'Elementor Pro widget: mapping not yet verified against real Pro data.';

export function markPro(w: ElementWriter): void {
  w.note(PRO_NOTE);
}

/**
 * First stored key among alternatives (Elementor Pro renamed several controls across versions). Marks every
 * alternative as handled and returns the value of the first non-empty one, or undefined.
 */
export function firstOf(w: ElementWriter, ...keys: string[]): unknown {
  let found: unknown;
  for (const k of keys) {
    const v = w.raw(k);
    if (found === undefined && v !== undefined && v !== null && v !== '') found = v;
  }
  return found;
}
