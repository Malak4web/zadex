import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { deviceKeys } from '../responsive';
import { dimensions, slider } from '../values';
import { desktopOnly, only, toNumber, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { decodeEntities, pickTag } from './_theme';
import { postsCssDefaults } from './_pro-posts';

/**
 * Elementor Pro `archive-posts` -> Zadex `archive-posts`. Verified against Pro 3.33.2 (defaults via `w.get`): same
 * skins / keys as the Posts widget with an `archive_` prefix: `_skin` archive_classic (default) | archive_cards |
 * archive_full_content, then `<skin>_columns` R (3 / 2 / 1; not on full content), `<skin>_thumbnail` (classic top /
 * left / right / none, cards top / none), `<skin>_thumbnail_size_size` (medium), `<skin>_item_ratio` R (0.66),
 * `<skin>_show_title`, `<skin>_title_tag` (h3), `<skin>_meta_data` (date, comments; also author, time, modified),
 * `<skin>_show_excerpt`, `<skin>_excerpt_length` (25), `<skin>_show_read_more`, `<skin>_read_more_text`
 * ("Read More »"), `<skin>_column_gap` (30) / `<skin>_row_gap` (35). Box styles (`<skin>_box_*`) exist on the full
 * content skin only; the cards skin has `archive_cards_card_bg_color`, `_card_border_color`, sliders
 * `_card_border_width` / `_card_border_radius` / `_card_padding` (horizontal) / `_card_vertical_padding`, a
 * `_box_shadow_box_shadow_type` switcher (default yes) and Pro's stylesheet look (white, no border, 3px radius,
 * 20 / 30 padding, 10px shadow, 30px on hover), `_hover_effect` none | gradient. Load more button styles
 * (`button_*`, `text_padding`, `load_more_spacing`) are noted,
 * `_show_badge` (yes) and `_show_avatar` (return value "show-avatar"). Pagination: `pagination_type` (numbers) |
 * prev_next | numbers_and_prev_next | load_more_on_click | load_more_infinite_scroll, labels, `pagination_align`,
 * colors; `nothing_found_message`. Global defaults: title color secondary / typography primary, meta typography
 * secondary, excerpt typography text, read more color / typography accent.
 */

const RATIOS: Array<[string, number]> = [
  ['16 / 9', 9 / 16],
  ['3 / 2', 2 / 3],
  ['4 / 3', 3 / 4],
  ['1 / 1', 1],
];
const IMAGE_SIZES = ['thumbnail', 'medium', 'medium_large', 'large', 'full'];
const PAGINATION: Record<string, string> = { '': 'none', numbers: 'numbers', prev_next: 'prev_next', numbers_and_prev_next: 'both' };

registerWidget('archive-posts', (source, ctx) => {
  const skinRaw = String(source.settings?._skin ?? 'archive_classic');
  const skin = skinRaw === 'archive_cards' ? 'archive_cards' : skinRaw === 'archive_full_content' ? 'archive_full_content' : 'archive_classic';
  // The full content skin shares the classic keys (`archive_full_content_*`); it is approximated by the classic grid.
  const p = skin;
  // Kit global defaults of the Posts skins (Pro `skin-base.php`).
  const el = withGlobalDefaults(source, ctx, {
    [`${p}_title_color`]: 'globals/colors?id=secondary',
    [`${p}_title_typography_typography`]: 'globals/typography?id=primary',
    [`${p}_excerpt_typography_typography`]: 'globals/typography?id=text',
    [`${p}_read_more_color`]: 'globals/colors?id=accent',
  });
  const w = ctx.writer(el, 'archive-posts');
  markPro(w);
  w.raw('_skin');
  /** Stored switcher value, else Pro's default (`yes` / '' / a custom return value). */
  const on = (key: string): boolean => {
    const v = w.get(key);
    return typeof v === 'string' ? v !== '' && v !== 'no' : v === true;
  };
  const text = (key: string, def: string): string => {
    const v = w.get(key);
    return typeof v === 'string' || typeof v === 'number' ? String(v) : def;
  };
  if (skin === 'archive_full_content') w.note('The "Full content" skin is approximated by a grid of excerpts.');
  if (skinRaw !== skin && skinRaw !== '') w.note(`Skin "${skinRaw}" is approximated by the classic grid.`);

  // Columns (Pro defaults 3 / tablet 2 / mobile 1; the full content skin is a single column).
  const colDefaults: Record<string, string> = skin === 'archive_full_content' ? { '': '1', _tablet: '1', _mobile: '1' } : { '': '3', _tablet: '2', _mobile: '1' };
  for (const [key, bp] of deviceKeys(`${p}_columns`)) {
    const suffix = key.slice(`${p}_columns`.length);
    const v = w.raw(key);
    const n = toNumber(v ?? colDefaults[suffix]);
    if (n === undefined) continue;
    const c = Math.min(6, Math.max(1, Math.round(n)));
    if (c !== n) w.note(`${n} columns are not available; ${c} are used.`);
    w.set('columns', String(c), { bp });
  }
  // Gap: Zadex has one gap; Elementor column gap (30) / row gap (35).
  let gapSet = false;
  for (const [key, bp] of deviceKeys(`${p}_column_gap`)) {
    const s = slider(w.raw(key));
    if (s) {
      w.set('gap', s, { bp });
      gapSet = gapSet || !bp;
    }
  }
  if (!gapSet) w.set('gap', { size: 30, unit: 'px' });
  if (w.has(`${p}_row_gap`)) w.note('The row gap is not available separately; the column gap is used for both directions.');
  w.consumeResponsive(`${p}_row_gap`);
  if (on(`${p}_masonry`)) w.note('Masonry layout is not available; posts are shown in a regular grid.');

  // Image.
  // Full content: `archive_full_content_thumbnail` is a switcher (default off); the other skins a position select.
  const thumb = skin === 'archive_full_content' ? (on('archive_full_content_thumbnail') ? 'top' : 'none') : text(`${p}_thumbnail`, 'top');
  w.set('show_image', thumb !== 'none');
  if (thumb === 'left' || thumb === 'right') w.note(`Image position "${thumb}" is not available; the image is shown above the text.`);
  const size = text(`${p}_thumbnail_size_size`, 'medium');
  w.set('image_size', IMAGE_SIZES.includes(size) ? size : 'full');
  w.consume(`${p}_thumbnail_size_custom_dimension`);
  const ratio = slider(w.get(`${p}_item_ratio`) ?? { size: 0.66, unit: 'px' });
  if (ratio && typeof ratio.size === 'number' && ratio.size > 0) {
    const r = ratio.size;
    const best = RATIOS.reduce((a, b) => (Math.abs(b[1] - r) < Math.abs(a[1] - r) ? b : a));
    w.set('image_ratio', best[0]);
    if (Math.abs(best[1] - r) > 0.03) w.note(`Image ratio ${r} is approximated by ${best[0]}.`);
  }
  w.consumeResponsive(`${p}_item_ratio`);
  if (w.has(`${p}_image_width`)) w.note('The image width is not available (the image spans the card).');
  w.consumeResponsive(`${p}_image_width`);

  // Content.
  w.set('show_title', on(`${p}_show_title`));
  w.set('title_tag', pickTag(w, text(`${p}_title_tag`, 'h3'), ['h2', 'h3', 'h4', 'h5', 'h6', 'p'], { h1: 'h2', div: 'p', span: 'p' }));
  const metaRaw = w.get(`${p}_meta_data`) ?? ['date', 'comments'];
  const metaList = Array.isArray(metaRaw) ? metaRaw.map(String) : [];
  const meta: string[] = [];
  for (const m of metaList) {
    const z = m === 'modified' ? 'date' : m;
    if (['date', 'author', 'comments'].includes(z)) {
      if (!meta.includes(z)) meta.push(z);
    } else w.note(`Meta "${m}" is not available on the Zadex archive posts.`);
  }
  w.set('meta', meta);
  if (w.has(`${p}_meta_separator`)) w.note('The meta separator is not carried over.');
  w.consume(`${p}_meta_separator`);
  const showExcerpt = skin === 'archive_full_content' ? true : on(`${p}_show_excerpt`);
  w.set('show_excerpt', showExcerpt);
  const len = toNumber(w.get(`${p}_excerpt_length`) ?? 25);
  if (len !== undefined && len > 0) w.set('excerpt_length', len);
  const showMore = skin !== 'archive_full_content' && on(`${p}_show_read_more`);
  w.set('read_more', showMore ? decodeEntities(text(`${p}_read_more_text`, 'Read More »')) : '');
  w.consume(`${p}_open_new_tab`, `${p}_apply_to_custom_excerpt`, `${p}_read_more_alignment`);
  if (skin === 'archive_cards') {
    if (on('archive_cards_show_badge')) w.note('The cards skin taxonomy badge is not available.');
    if (on('archive_cards_show_avatar')) w.note('The cards skin author avatar is not available.');
    if (text('archive_cards_hover_effect', 'gradient') === 'gradient') w.note('The cards skin hover gradient is not available.');
    w.consume('archive_cards_badge_*', 'archive_cards_avatar_*', 'archive_cards_meta_border_color');
  }

  // Pagination.
  const pag = text('pagination_type', 'numbers');
  w.set('pagination', PAGINATION[pag] ?? 'numbers');
  if (!(pag in PAGINATION)) w.note(`Pagination "${pag}" (load more / infinite scroll) is approximated by page numbers.`);
  w.set('prev_text', decodeEntities(text('pagination_prev_label', '&laquo; Previous')));
  w.set('next_text', decodeEntities(text('pagination_next_label', 'Next &raquo;')));
  w.consume('pagination_page_limit', 'pagination_numbers_shorten', 'pagination_individual_handle', 'load_more_*');
  const palign = only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']);
  const pa = palign[text('pagination_align', 'center')];
  if (pa) w.set('pagination_align', pa);
  w.consumeResponsive('pagination_align');
  w.set('empty_text', text('nothing_found_message', 'It seems we can’t find what you’re looking for.'));
  w.consume('nothing_found_color', 'nothing_found_typography_*');

  // Load more button styles (`button_*`, `text_padding`, `load_more_spacing`): Zadex has no load more button.
  if (Object.keys(w.el.settings ?? {}).some((k) => k.startsWith('button_') && w.has(k))) w.note('The load more button styles are not carried over (Zadex paginates with page numbers).');
  w.consume('button_*', 'text', 'align', 'load_more_button_align', 'hover_color', 'background_color', 'border_*', 'text_padding');

  // Card.
  const toDims = (s: { size: number | string; unit: string }) => ({ top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true });
  if (skin === 'archive_cards') {
    // Pro's real cards look (stylesheet, written explicitly because the Zadex card differs): white card, no border,
    // 3px radius, text padded 20px / 30px, shadow 0 0 10px rgba(0,0,0,.15) (30px on hover) while the
    // `archive_cards_box_shadow_box_shadow_type` switcher is on (default yes).
    const bgColor = w.raw('archive_cards_card_bg_color');
    w.color('archive_cards_card_bg_color', 'card_bg');
    if (bgColor === undefined && w.settings.card_bg === undefined) w.set('card_bg', '#ffffff');
    desktopOnly(w, 'card_bg');
    for (const [key, bp] of deviceKeys('archive_cards_card_padding')) {
      const suffix = key.slice('archive_cards_card_padding'.length);
      const h = slider(w.raw(key));
      const v = slider(w.raw(`archive_cards_card_vertical_padding${suffix}`));
      if (bp && !h && !v) continue;
      const unit = h?.unit ?? v?.unit ?? 'px';
      w.set('card_padding', { top: v?.size ?? 20, right: h?.size ?? 30, bottom: v?.size ?? 20, left: h?.size ?? 30, unit, linked: false }, { bp });
    }
    w.consumeResponsive('archive_cards_card_vertical_padding');
    const bw = slider(w.raw('archive_cards_card_border_width'));
    const br = slider(w.raw('archive_cards_card_border_radius')) ?? { size: 3, unit: 'px' };
    const bc = w.raw('archive_cards_card_border_color');
    const border: Record<string, unknown> = bw && Number(bw.size) > 0 ? { style: 'solid', width: toDims(bw), ...(typeof bc === 'string' && bc !== '' ? { color: bc } : {}) } : { style: 'none' };
    border.radius = toDims(br);
    w.set('card_border', border);
    w.consume('archive_cards_card_border_*');
    if (on('archive_cards_box_shadow_box_shadow_type')) {
      w.set('card_shadow', { x: 0, y: 0, blur: 10, spread: 0, color: 'rgba(0,0,0,0.15)', inset: false });
      w.note('The cards shadow growing on hover (10px -> 30px) keeps its normal size in Zadex.');
    }
  } else {
    w.color(`${p}_box_bg_color`, 'card_bg');
    desktopOnly(w, 'card_bg');
    w.dimensions(`${p}_box_padding`, 'card_padding');
    const width = dimensions(w.raw(`${p}_box_border_width`));
    const radius = dimensions(w.raw(`${p}_box_border_radius`));
    const bc = w.raw(`${p}_box_border_color`);
    const border: Record<string, unknown> = {};
    if (width) {
      border.style = 'solid';
      border.width = width;
      if (typeof bc === 'string' && bc !== '') border.color = bc;
    }
    if (radius) border.radius = radius;
    if (Object.keys(border).length) w.set('card_border', border);
    w.consume(`${p}_box_border_*`);
    w.boxShadow(`${p}_box_shadow`, 'card_shadow');
  }
  if (w.has(`${p}_content_padding`)) w.note('The content padding is not available separately; use the card padding.');
  w.consumeResponsive(`${p}_content_padding`);
  if (w.has(`${p}_alignment`)) w.note('The text alignment of the posts is not available.');
  w.consume(`${p}_alignment`);

  // Texts.
  w.typography(`${p}_title_typography`, 'title_typography');
  w.color(`${p}_title_color`, 'title_color');
  desktopOnly(w, 'title_color');
  w.color(`${p}_title_color_hover`, 'title_color_hover');
  desktopOnly(w, 'title_color_hover');
  w.color(`${p}_meta_color`, 'meta_color');
  desktopOnly(w, 'meta_color');
  w.consume(`${p}_text_stroke_*`, `${p}_img_border_radius*`, `${p}_image_spacing*`, `${p}_thumbnail_filters_*`, `${p}_thumbnail_hover_filters_*`, `${p}_box_shadow_hover_*`, `${p}_box_bg_color_hover`, `${p}_box_border_color_hover`);
  w.consume(`${p}_meta_typography_*`, `${p}_meta_separator_color`, `${p}_meta_spacing`, `${p}_title_spacing`, `${p}_excerpt_spacing`, `${p}_read_more_spacing`);
  w.typography(`${p}_excerpt_typography`, 'excerpt_typography');
  desktopOnly(w, 'excerpt_typography');
  w.color(`${p}_excerpt_color`, 'excerpt_color');
  desktopOnly(w, 'excerpt_color');
  w.color(`${p}_read_more_color`, 'more_color');
  desktopOnly(w, 'more_color');
  w.consume(`${p}_read_more_typography_*`);
  if (skin !== 'archive_full_content') postsCssDefaults(w, skin === 'archive_cards' ? 'cards' : 'classic', ['title_typography', 'excerpt_typography', 'meta_color', 'excerpt_color']);
  w.color('pagination_color', 'pagination_color');
  desktopOnly(w, 'pagination_color');
  w.color('pagination_active_color', 'pagination_active_color');
  desktopOnly(w, 'pagination_active_color');
  w.consume('pagination_hover_color', 'pagination_typography_*', 'pagination_spacing', 'pagination_spacing_top');
  return w.finish();
});
