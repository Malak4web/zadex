import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { borderWithRadius, noteIfSet } from './_woo-product';
import { sliderAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-images` -> Zadex `product-images`.
 * Verified against Elementor Pro 3.33.2: `sale_flash` (switcher, default yes), image border group `image_border_*` +
 * `image_border_radius` (dimensions, R), `spacing` (gap between the main image and the thumbnails, R), thumbnails
 * border group `thumbs_border_*` + `thumbs_border_radius` (R), `spacing_thumbs` (gap between thumbnails, R). Zoom,
 * lightbox and slider come from the theme's WooCommerce support in Elementor; Zadex turns them on by default (kept).
 */
registerWidget('woocommerce-product-images', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-images');
  if (off) return off;
  const w = ctx.writer(source, 'product-images');
  markPro(w);
  w.set('sale_flash', w.get('sale_flash') === 'yes');
  borderWithRadius(w, 'image_border', 'image_border_radius', 'image_border');
  borderWithRadius(w, 'thumbs_border', 'thumbs_border_radius', 'thumbs_border');
  sliderAlt(w, ['spacing_thumbs'], 'thumbs_gap');
  noteIfSet(w, ['spacing'], 'The space between the main image and the thumbnails is not carried over.');
  return w.finish();
});
