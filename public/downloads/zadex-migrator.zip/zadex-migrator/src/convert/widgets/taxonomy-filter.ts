import { registerWidget } from '../registry';
import type { ConvertContext } from '../context';
import type { ElElement } from '../types';
import { dimensions, isBlank, slider } from '../values';
import { markPro } from './_pro';
import { colorOf, getBool, getStr } from './_pro-posts';
import { resolveLoopTemplate } from './loop';

/** Elementor `item_alignment_horizontal` -> Zadex `align`. */
const ALIGN: Record<string, string> = { start: 'flex-start', center: 'center', end: 'flex-end' };
const TRANSPARENT = 'rgba(0,0,0,0)';

/**
 * Zadex id the converter gives an Elementor element (same rule as `ConvertContext.idFor`, without reserving it:
 * the loop widget reserves its own id when it is converted). Duplicate Elementor ids would get a suffix there.
 */
function zadexIdOf(elementorId: string): string {
  const base = ('e' + elementorId.toLowerCase().replace(/[^a-z0-9]/g, '')).slice(0, 16);
  return base.length < 3 ? base.padEnd(3, '0') : base;
}

function findElement(elements: ElElement[] | undefined, id: string): ElElement | undefined {
  for (const el of elements ?? []) {
    if (el.id === id) return el;
    const hit = findElement(el.elements, id);
    if (hit) return hit;
  }
  return undefined;
}

/** True when the targeted Elementor loop widget converts to a Zadex loop (its loop item template is mapped). */
function targetIsZadexLoop(ctx: ConvertContext, id: string): boolean | undefined {
  const el = findElement(ctx.source.elements, id);
  if (!el) return undefined;
  if (el.widgetType !== 'loop-grid' && el.widgetType !== 'loop-carousel') return false;
  return resolveLoopTemplate(ctx, el.settings?.template_id) !== undefined;
}

/**
 * Elementor Pro `taxonomy-filter` (Loop Filter module, Pro 3.33.2) -> Zadex `loop-filter`. `selected_element` (the
 * Elementor id of the loop grid / carousel on the page) -> `target` (that loop's Zadex id), `taxonomy`,
 * `direction` horizontal | vertical -> `layout`, `item_alignment_horizontal` R start | center | end | stretch
 * (none = centered) -> `align`, `multiple_selection` (no) -> `multiple` (`logical_combination` AND noted: Zadex
 * matches any selected term), `show_first_item` (yes) / `first_item_title` (All) -> `show_all` / `all_text`;
 * `show_empty_items`, `show_child_taxonomy`, `number_of_taxonomies`, `horizontal_scroll` noted. Style:
 * `taxonomy_filter_items_space_between` -> `items_gap`, `taxonomy_filter_typography_*`,
 * `taxonomy_filter_{normal,hover,active}_text_color` / `_background_color` / `_border_*`,
 * `taxonomy_filter_border_radius`, `taxonomy_filter_padding`. Pro's plain text look (no box, 8px padding, 20px gap,
 * #69727d text, #0c0d0e hover / active) is written explicitly because Zadex draws pill buttons.
 */
registerWidget('taxonomy-filter', (el, ctx) => {
  const w = ctx.writer(el, 'loop-filter');
  markPro(w);

  // Target loop.
  const selected = getStr(w, 'selected_element');
  if (selected) {
    w.set('target', zadexIdOf(selected));
    const isLoop = targetIsZadexLoop(ctx, selected);
    if (isLoop === false) {
      w.note('The filtered loop was converted to a Zadex Posts widget (its loop item template is not converted yet), which the Zadex filter cannot target.');
      w.status('partial');
    } else if (isLoop === undefined) w.note('The filtered loop widget is not on this page; pick the loop in the Zadex filter settings.');
  } else {
    w.note('No loop widget was selected for this filter.');
    w.status('partial');
  }
  w.set('taxonomy', getStr(w, 'taxonomy') || 'category');

  // Behaviour.
  const multiple = getBool(w, 'multiple_selection');
  w.set('multiple', multiple);
  if (multiple && getStr(w, 'logical_combination') === 'AND') w.note('Zadex shows posts matching any selected term (Elementor: all selected terms).');
  w.consume('logical_combination');
  const showAll = getBool(w, 'show_first_item');
  w.set('show_all', showAll);
  if (showAll) w.set('all_text', getStr(w, 'first_item_title'));
  else w.consume('first_item_title');
  if (getBool(w, 'show_empty_items')) w.note('Showing terms without posts is not available in Zadex.');
  if (getBool(w, 'show_child_taxonomy')) w.note('Child terms are listed like the others in Zadex (no hierarchy depth).');
  if (!isBlank(w.raw('number_of_taxonomies'))) w.note('Limiting the number of terms is not available in Zadex.');
  if (getStr(w, 'horizontal_scroll') === 'enable') w.note('Horizontal scrolling of the filter is not available in Zadex; items wrap.');
  w.consume('child_taxonomy_depth', 'horizontal_scroll*');

  // Layout.
  const direction = getStr(w, 'direction') || 'horizontal';
  w.set('layout', direction === 'vertical' ? 'vertical' : 'horizontal');
  if (direction !== 'vertical') {
    for (const [key, bp] of [['item_alignment_horizontal', undefined], ['item_alignment_horizontal_tablet', 'tablet'], ['item_alignment_horizontal_mobile', 'mobile']] as const) {
      const v = String(w.raw(key) ?? '');
      if (v === 'stretch') w.note('Stretched filter items are not available in Zadex.');
      else if (ALIGN[v]) w.set('align', ALIGN[v], { bp });
      else if (!bp) w.set('align', 'center');
    }
  }
  w.consume('item_alignment_*', 'title_alignment_*');

  // Style.
  const gap = slider(w.raw('taxonomy_filter_items_space_between'));
  w.set('items_gap', gap ?? { size: 20, unit: 'px' });
  w.consume('taxonomy_filter_items_space_between_*');
  w.typography('taxonomy_filter_typography', 'typography');
  w.set('color', colorOf(w, 'taxonomy_filter_normal_text_color') ?? '#69727d');
  w.set('color', colorOf(w, 'taxonomy_filter_hover_text_color') ?? '#0c0d0e', { state: 'hover' });
  w.set('active_color', colorOf(w, 'taxonomy_filter_active_text_color') ?? '#0c0d0e');
  w.set('bg', colorOf(w, 'taxonomy_filter_normal_background_color') ?? TRANSPARENT);
  w.set('bg', colorOf(w, 'taxonomy_filter_hover_background_color') ?? TRANSPARENT, { state: 'hover' });
  w.set('active_bg', colorOf(w, 'taxonomy_filter_active_background_color') ?? TRANSPARENT);
  for (const s of ['normal', 'hover', 'active']) {
    const type = getStr(w, `taxonomy_filter_${s}_background_background`);
    if (type === 'gradient') w.note('Gradient filter item backgrounds are not available in Zadex; the first color is kept.');
  }
  w.consume('taxonomy_filter_normal_background_*', 'taxonomy_filter_hover_background_*', 'taxonomy_filter_active_background_*');
  // Border (normal state) + radius in one Zadex border value; hover / active borders noted.
  w.border('taxonomy_filter_normal_border', 'border', 'taxonomy_filter_border_radius');
  if (w.settings.border === undefined) w.set('border', { style: 'none' });
  else if ((w.settings.border as Record<string, unknown>).style === undefined) w.set('border', { ...(w.settings.border as Record<string, unknown>), style: 'none' });
  if (!isBlank(w.raw('taxonomy_filter_hover_border_border')) || !isBlank(w.raw('taxonomy_filter_active_border_border'))) {
    w.note('Different filter item borders on hover / when active are not available in Zadex.');
  }
  w.consume('taxonomy_filter_hover_border_*', 'taxonomy_filter_active_border_*');
  if (['normal', 'hover', 'active'].some((s) => getBool(w, `taxonomy_filter_${s}_box_shadow_box_shadow_type`))) w.note('Filter item shadows are not available in Zadex.');
  w.consume('taxonomy_filter_normal_box_shadow_*', 'taxonomy_filter_hover_box_shadow_*', 'taxonomy_filter_active_box_shadow_*');
  const pad = dimensions(w.raw('taxonomy_filter_padding'));
  w.set('padding', pad ?? { top: 8, right: 8, bottom: 8, left: 8, unit: 'px', linked: true });
  w.consume('taxonomy_filter_padding_*');
  return w.finish();
});
