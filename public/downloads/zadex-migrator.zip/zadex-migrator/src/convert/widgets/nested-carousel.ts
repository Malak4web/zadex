import { registerWidget } from '../registry';
import { deviceKeys } from '../responsive';
import { dimensions, isBlank, slider } from '../values';
import { markPro } from './_pro';
import { getBool, getStr, responsiveGet } from './_pro-posts';

/**
 * Elementor Pro `nested-carousel` (Pro 3.33.2: `carousel_items` titles + one child container per slide) -> Zadex
 * `grid` holding the converted slide containers. Zadex has no carousel that takes free content (its carousels take
 * images, posts or testimonials), so the slides are laid out side by side: `slides_to_show` R (no stored desktop
 * default: Pro's script uses 3 / 2 / 1) -> `columns`, `image_spacing_custom` R (10px) -> `gap`, `equal_height`
 * (yes) -> `align_items` stretch. Carousel behaviour (`autoplay`, `infinite`, `speed`, `arrows`, `pagination`,
 * offsets) and the per-slide `content_*` / `border_radius` styles are reported.
 */
registerWidget('nested-carousel', (el, ctx) => {
  const w = ctx.writer(el, 'grid');
  markPro(w);
  w.note('Zadex has no carousel for free content: the slides are shown side by side in a grid (one column per visible slide).');
  w.status('partial');

  responsiveGet(w, 'slides_to_show', 'columns', [1, 12], { desktop: 3, tablet: 2, mobile: 1 });
  for (const [key, bp] of deviceKeys('image_spacing_custom')) {
    const s = slider(!bp || bp === 'tablet' || bp === 'mobile' ? w.get(key) : w.raw(key));
    const g = s ?? (!bp ? { size: 10, unit: 'px' } : undefined);
    if (g) w.set('gap', { row: Number(g.size), column: Number(g.size), unit: g.unit, linked: true }, { bp });
  }
  w.set('align_items', getBool(w, 'equal_height') ? 'stretch' : 'start');

  const behaviour: string[] = [];
  if (getBool(w, 'autoplay')) behaviour.push('autoplay');
  if (getBool(w, 'arrows')) behaviour.push('arrows');
  if (getStr(w, 'pagination') !== '') behaviour.push('pagination');
  if (behaviour.length) w.note(`Carousel ${behaviour.join(', ')} ${behaviour.length > 1 ? 'are' : 'is'} not carried over.`);
  const styled = ['content_background_background', 'content_background_color', 'content_border_border', 'border_radius', 'content_padding'].some(
    (k) => !isBlank(w.raw(k)) && (k !== 'border_radius' && k !== 'content_padding' ? true : dimensions(w.raw(k)) !== undefined),
  );
  if (styled) w.note('The slide background, border and padding of the carousel were not carried over; style the slide containers instead.');
  w.consume(
    'carousel_name',
    'carousel_items',
    'slides_to_scroll*',
    'autoplay*',
    'pause_on_*',
    'infinite',
    'speed',
    'direction',
    'offset_*',
    'arrows*',
    'arrow_*',
    'navigation_*',
    'pagination',
    'dots_*',
    'fraction_*',
    'typography_fraction_*',
    'progressbar_*',
    'content_*',
    'border_radius*',
  );
  return w.finish(ctx.convert(el.elements));
});
