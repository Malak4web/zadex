import { registerWidget } from '../registry';

/** Elementor `read-more` (the "more" tag) -> Zadex `read-more` (`link_text` -> `text`). */
registerWidget('read-more', (el, ctx) => {
  const w = ctx.writer(el, 'read-more');
  w.set('text', String(w.get('link_text') ?? ''));
  return w.finish();
});
