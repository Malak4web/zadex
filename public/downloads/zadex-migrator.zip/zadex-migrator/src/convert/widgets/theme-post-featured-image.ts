import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { IMAGE_SIZES } from './image';
import { desktopOnly, only, withGlobalDefaults } from './_shared';
import { dynamicTag } from './_theme';

const OBJECT_FIT: Record<string, string> = { fill: 'fill', cover: 'cover', contain: 'contain', 'scale-down': 'contain' };

/**
 * Elementor Pro `theme-post-featured-image` -> Zadex `featured-image`. Extends the Image widget (verified against Pro
 * 3.33.2, Pro's own defaults via `w.get`: `image_size` large, `link_to` none, `caption_source` none): `image` with
 * the `post-featured-image` tag as dynamic default (its `fallback` setting = media used when the post has no
 * featured image), `link_to` none / file / custom (+ `link` bound to `post-url`), `align` start | center | end.
 */
registerWidget('theme-post-featured-image', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    text_color: 'globals/colors?id=text',
    caption_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'featured-image');
  markPro(w);
  w.raw('image'); // placeholder in the editor
  const tag = dynamicTag(w, 'image');
  if (tag?.name === 'post-featured-image') {
    w.consumeDynamic('image');
    const fallback = ctx.media(tag.settings.fallback);
    if (fallback) w.set('fallback', fallback);
  } else if (tag) w.note(`The image was bound to the "${tag.name}" tag; the Zadex widget always shows the featured image.`);

  w.set('size', IMAGE_SIZES[String(w.get('image_size') ?? 'large')] ?? 'large');
  if (w.raw('image_custom_dimension')) w.note('Custom image dimensions are not supported; set a width / height instead.');

  const linkTo = String(w.get('link_to') ?? 'none');
  const linkTag = dynamicTag(w, 'link');
  if (linkTo === 'file') w.set('link', 'file');
  else if (linkTo === 'custom') {
    w.set('link', 'post');
    if (linkTag?.name === 'post-url') w.consumeDynamic('link');
    else w.note('The image linked to a custom URL; the Zadex featured image links to the post.');
    w.raw('link');
  } else {
    w.set('link', 'none');
    w.raw('link');
  }
  w.consume('open_lightbox');

  const caption = String(w.get('caption_source') ?? 'none');
  w.set('caption', caption !== 'none');
  if (caption === 'custom') w.note('A custom caption is not available; the attachment caption is shown.');
  w.raw('caption');

  if (!w.has('align')) w.set('align', 'center'); // Elementor centers images
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  w.slider('width', 'width');
  w.slider('height', 'height');
  if (w.has('space')) w.note('Max width is not available on the Zadex featured image; use the width.');
  w.consumeResponsive('space');
  const fit = w.raw('object-fit');
  if (typeof fit === 'string' && OBJECT_FIT[fit]) w.set('object_fit', OBJECT_FIT[fit]);
  w.consumeResponsive('object-fit');
  w.consumeResponsive('object-position');
  w.border('image_border', 'border', 'image_border_radius');
  desktopOnly(w, 'border');
  w.boxShadow('image_box_shadow', 'shadow');
  if (w.has('opacity') || w.has('opacity_hover')) w.note('Image opacity is not available on the Zadex featured image.');
  w.consume('opacity*', 'background_hover_transition');
  if (w.raw('hover_animation')) w.note('Hover animations are not available on the Zadex featured image.');
  if (w.has('css_filters_css_filter') || w.has('css_filters_hover_css_filter')) w.note('CSS filters are not available on the Zadex featured image.');
  w.consume('css_filters_*');

  w.color('text_color', 'caption_color');
  desktopOnly(w, 'caption_color');
  w.typography('caption_typography', 'caption_typography');
  desktopOnly(w, 'caption_typography');
  if (w.has('caption_align') || w.has('caption_space')) w.note('Caption alignment / spacing are not available on the Zadex featured image.');
  w.consume('caption_align*', 'caption_space*', 'caption_background_color');
  return w.finish();
});
