import { registerWidget } from '../registry';
import { url } from '../values';
import { markPro } from './_pro';
import { paymentButton, proNumber, proSwitch, proText, proVal } from './_pro-content';

const CURRENCIES = ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY', 'CHF', 'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'NZD', 'SGD', 'HKD', 'MXN', 'BRL', 'ILS', 'INR', 'SAR', 'AED', 'EGP', 'MAD', 'TRY', 'ZAR', 'KRW'];

/**
 * Elementor Pro `stripe-button` -> Zadex `stripe-button` in Checkout mode (Elementor Pro also creates a Stripe Checkout
 * session with the secret key from its settings). Keys verified against Elementor Pro 3.33.2: `product_name`,
 * `stripe_product_price` ("0.00"), `stripe_currency` (USD, select2), `stripe_quantity` (1), `shipping_amount` (0),
 * `stripe_test_env_tax_rates_list` / `stripe_live_env_tax_rates_list` (Stripe tax rate ids), `redirect_after_success`,
 * `sandbox_mode` (no), `open_in_new_window` (yes), `custom_messages` + `error_message_global` ("Something went wrong") /
 * `error_message_payment`, plus the payment button controls (`paymentButton()`). `donation_type`, `donation_amount`,
 * `shipping_price` and `tax_rate` are inherited from the PayPal base but hidden (Stripe has no `type` control).
 */
registerWidget('stripe-button', (el, ctx) => {
  const w = ctx.writer(el, 'stripe-button');
  markPro(w);

  w.set('mode', 'checkout');
  w.note('The Stripe secret key is not migrated: set it in Zadex > Settings > Payments for the button to work.');
  w.set('product_name', proText(w, 'product_name'));
  w.set('product_description', '');
  const price = proNumber(proVal(w, 'stripe_product_price', '0.00'));
  w.set('amount', price !== undefined ? price.toFixed(2) : '0.00');
  const rawCurrency = proVal(w, 'stripe_currency', 'USD');
  const currency = String((Array.isArray(rawCurrency) ? rawCurrency[0] : rawCurrency) ?? 'USD').toUpperCase();
  w.set('currency', CURRENCIES.includes(currency) ? currency : 'USD');
  if (!CURRENCIES.includes(currency)) w.note(`Currency "${currency}" is not offered by the Zadex Stripe button; USD is used.`);
  const qty = proNumber(proVal(w, 'stripe_quantity', 1));
  w.set('quantity', qty !== undefined && qty > 0 ? Math.round(qty) : 1);

  const sandbox = proSwitch(w, 'sandbox_mode');
  const taxKey = sandbox ? 'stripe_test_env_tax_rates_list' : 'stripe_live_env_tax_rates_list';
  if (w.has(taxKey)) {
    w.note('The Stripe tax rate is not carried over (configure taxes in Stripe).');
    w.status('partial');
  }
  w.consume('stripe_test_env_tax_rates_list', 'stripe_live_env_tax_rates_list');
  if (sandbox) w.note('Elementor used the Stripe test environment: use test keys in Zadex > Settings > Payments.');
  const shipping = proNumber(proVal(w, 'shipping_amount'));
  if (shipping !== undefined && shipping > 0) {
    w.note('The Stripe shipping price is not carried over.');
    w.status('partial');
  }
  w.consume('donation_type', 'donation_amount', 'shipping_price', 'tax_rate', 'tax_type');
  if (proSwitch(w, 'open_in_new_window', true)) w.note('Opening Stripe Checkout in a new tab is not available in Zadex (it opens in the same tab).');

  const success = url(w.raw('redirect_after_success'));
  if (success) w.set('success_url', success);
  if (proSwitch(w, 'custom_messages')) {
    const msg = proText(w, 'error_message_global').trim();
    if (msg !== '') w.set('error_message', msg);
    if (w.has('error_message_payment')) w.note('The "Stripe not connected" message is not used by Zadex (one error message).');
  }
  w.consume('error_message_*');

  paymentButton(w, ctx);
  return w.finish();
});
