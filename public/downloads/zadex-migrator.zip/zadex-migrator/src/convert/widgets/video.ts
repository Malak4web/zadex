import { registerWidget } from '../registry';
import { fallback } from '../fallback';
import { bool, isBlank, num, url } from '../values';

/** Elementor `aspect_ratio` option -> Zadex `aspect_ratio` option. */
const RATIOS: Record<string, string> = {
  '169': '16 / 9',
  '219': '21 / 9',
  '43': '4 / 3',
  '32': '3 / 2',
  '11': '1 / 1',
  '916': '9 / 16',
};

/**
 * Elementor `video` -> Zadex `video` (YouTube, Vimeo, self hosted). Dailymotion and VideoPress embeds have no Zadex
 * source and go to the fallback (rendered HTML when available). The image overlay becomes the Zadex poster (click to
 * play facade); the overlay lightbox is not available and is reported.
 */
registerWidget('video', (el, ctx) => {
  // Decide the source before opening the writer (the fallback path must not reserve the element id).
  const s = el.settings ?? {};
  const type = String(s.video_type || 'youtube');
  const insertUrl = bool(s.insert_url);
  let hostedUrl = '';
  if (type === 'hosted' || type === 'videopress') {
    if (insertUrl) hostedUrl = type === 'hosted' ? url(s.external_url)?.url ?? '' : '';
    else hostedUrl = ctx.media(s.hosted_url)?.url ?? '';
  }
  if (type === 'dailymotion' || (type === 'videopress' && (insertUrl || hostedUrl === ''))) {
    const out = fallback(el, ctx);
    const entry = ctx.report.entries.find((e) => e.source === el.id);
    entry?.notes.push(`${type === 'dailymotion' ? 'Dailymotion' : 'VideoPress'} videos are not supported by the Zadex video widget.`);
    return out;
  }

  const w = ctx.writer(el, 'video');
  w.consume('video_type');
  const source = type === 'youtube' || type === 'vimeo' ? type : 'hosted';
  w.set('source', source);
  if (type === 'videopress') w.note('The VideoPress video was converted to a self-hosted video using its media file.');
  if (source === 'youtube') w.set('youtube_url', String(w.get('youtube_url') ?? ''));
  if (source === 'vimeo') w.set('vimeo_url', String(w.get('vimeo_url') ?? ''));
  if (source === 'hosted') {
    if (hostedUrl === '') w.note('The self-hosted video has no file.');
    w.set('hosted_url', hostedUrl);
  }
  w.consume('insert_url', 'external_url', 'hosted_url', 'videopress_url');
  if (w.dynamicRef('youtube_url') || w.dynamicRef('vimeo_url') || w.dynamicRef('hosted_url')) {
    w.note('The video URL was bound to a dynamic tag; the static URL was kept.');
  }

  // Playback options.
  w.set('autoplay', bool(w.get('autoplay')));
  w.set('mute', bool(w.get('mute')));
  w.set('loop', bool(w.get('loop')));
  if (source !== 'vimeo') w.set('controls', bool(w.get('controls')));
  else w.consume('controls');
  const start = num(w.get('start'));
  if (typeof start === 'number' && start > 0) w.set('start', start);
  const end = num(w.get('end'));
  if (typeof end === 'number' && end > 0 && source !== 'vimeo') w.set('end', end);
  if (source === 'youtube') w.set('privacy', bool(w.get('yt_privacy')));
  else w.consume('yt_privacy');
  if (source !== 'hosted') w.set('lazy', bool(w.get('lazy_load')));
  else w.consume('lazy_load');
  w.consume('play_on_mobile');

  // Image overlay -> poster (facade on embeds, poster attribute on hosted videos).
  const overlayOn = bool(w.get('show_image_overlay'));
  const overlay = overlayOn ? ctx.media(w.get('image_overlay')) : undefined;
  w.consume('image_overlay', 'image_overlay_size');
  const hostedPoster = source === 'hosted' ? ctx.media(w.get('poster')) : undefined;
  if (source !== 'hosted') w.consume('poster');
  const poster = overlay ?? hostedPoster;
  if (poster) w.set('poster', poster);
  if (overlay && hostedPoster) w.note('Both an image overlay and a poster were set; the overlay image is used as the poster.');

  if (overlay) {
    if (!bool(w.get('show_play_icon'))) {
      w.note('Zadex always shows a play icon on the poster.');
      w.status('partial');
    }
    const playIcon = w.get('play_icon');
    if (playIcon && typeof playIcon === 'object' && !isBlank((playIcon as Record<string, unknown>).value)) {
      w.note('The custom play icon was replaced by the Zadex play icon.');
    }
    w.color('play_icon_color', 'play_color');
    w.slider('play_icon_size', 'play_size');
    if (bool(w.get('lightbox'))) {
      w.note('The video lightbox is not available in Zadex; the video plays inline.');
      w.status('partial');
    }
  } else {
    w.consume('show_play_icon', 'play_icon', 'play_icon_color', 'lightbox', 'play_icon_size*');
  }

  w.map('aspect_ratio', 'aspect_ratio', RATIOS);
  return w.finish();
});
