import { registerWidget } from '../registry';
import { colorRef } from '../globals';
import { deviceKeys } from '../responsive';
import { isBlank, slider } from '../values';
import type { ZElement } from '../types';
import {
  backgroundColor,
  childSettings,
  classicBackground,
  dimsOrUndefined,
  dims,
  iconOf,
  isPlainContainer,
  kitContainerPadding,
  nestedChildren,
  repeaterItems,
  setDefault,
  withGlobalDefaults,
} from './_media-support';

/** Elementor `tabs_justify_*` -> Zadex `nav_align`; `stretch` becomes `nav_stretch`. */
const JUSTIFY: Record<string, string> = { start: 'flex-start', center: 'center', end: 'flex-end' };

/**
 * Elementor `nested-tabs` (v3.15+ "Tabs": repeater `tabs` for the titles, one child container per tab) -> Zadex
 * `tabs` with one `tab` per item. When every child container is plain (only Elementor's default `_title` /
 * `content_width`), its widgets go straight into the Zadex tab (a container itself); otherwise each container is
 * converted and kept inside its tab. Elementor's default look (centered headings, grey titles, accent active title,
 * 15px/35px padding, 10px gaps) is written explicitly.
 */
registerWidget('nested-tabs', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    tabs_title_background_color_hover_color: 'accent',
    tabs_title_background_color_active_color: 'accent',
    title_typography_typography: 'accent',
  });
  const w = ctx.writer(el, 'tabs');
  const items = repeaterItems(w, 'tabs');
  const containers = source.elements ?? [];

  // Direction.
  const direction = String(w.get('tabs_direction') ?? '');
  const vertical = ['inline-start', 'inline-end', 'start', 'end'].includes(direction);
  w.set('layout', vertical ? 'vertical' : 'horizontal');
  if (['block-end', 'bottom'].includes(direction)) w.note('Tabs below the content are placed above it in Zadex.');
  if (['inline-end', 'end'].includes(direction)) w.note('Tabs after the content are placed before it in Zadex.');
  for (const [key, bp] of deviceKeys('tabs_direction')) if (bp && !isBlank(w.raw(key))) w.note('Per-device tab directions are not supported by Zadex.');

  // Heading alignment (Elementor default: centered).
  const justifyKey = vertical ? 'tabs_justify_vertical' : 'tabs_justify_horizontal';
  w.consume(vertical ? 'tabs_justify_horizontal*' : 'tabs_justify_vertical*');
  for (const [key, bp] of deviceKeys(justifyKey)) {
    const v = String((bp ? w.raw(key) : w.get(key)) ?? '');
    if (v === 'stretch') {
      if (!bp) w.set('nav_stretch', true);
      else w.note('Per-device "stretch" tab alignment is not supported by Zadex.');
    } else if (JUSTIFY[v]) w.set('nav_align', JUSTIFY[v], { bp });
  }
  if (!vertical) setDefault(w, 'nav_align', 'center');

  // Gaps: between titles, and between the headings and the content.
  w.slider('tabs_title_space_between', 'nav_gap');
  setDefault(w, 'nav_gap', { size: 10, unit: 'px' });
  const spacing = slider(w.get('tabs_title_spacing'));
  const gap = typeof spacing?.size === 'number' ? spacing.size : 10;
  w.consumeResponsive('tabs_title_spacing');
  w.set('panel_padding', vertical ? dims(0, 0, 0, gap) : { top: gap, right: 0, bottom: 0, left: 0, unit: 'px', linked: false });

  // Title colors and backgrounds (Elementor defaults: secondary text on #f1f2f3, white on accent when hovered/active).
  const accent = colorRef(ctx, 'accent') ?? '#61ce70';
  w.color('title_text_color', 'title_color');
  w.color('title_text_color_hover', 'title_color_hover');
  w.color('title_text_color_active', 'title_color_active');
  setDefault(w, 'title_color', colorRef(ctx, 'secondary') ?? '#54595f');
  setDefault(w, 'title_color_hover', '#ffffff');
  setDefault(w, 'title_color_active', '#ffffff');
  const bg = backgroundColor(w, 'tabs_title_background_color', 'title');
  const bgHover = backgroundColor(w, 'tabs_title_background_color_hover', 'hovered title');
  const bgActive = backgroundColor(w, 'tabs_title_background_color_active', 'active title');
  w.set('title_bg', bg ?? '#f1f2f3');
  w.set('title_bg_hover', bgHover ?? accent);
  w.set('title_bg_active', bgActive ?? accent);
  w.typography('title_typography', 'title_typography');
  w.dimensions('padding', 'title_padding');
  setDefault(w, 'title_padding', dims(15, 35));

  // Title border (normal + active color); Zadex's underline is removed when Elementor has no border.
  w.border('tabs_title_border', 'title_border', 'tabs_title_border_radius');
  if (!w.settings.title_border || !(w.settings.title_border as Record<string, unknown>).style) {
    w.set('title_border', { ...((w.settings.title_border as Record<string, unknown>) ?? {}), style: 'none' });
  }
  w.color('tabs_title_border_active_color', 'title_border_color_active');

  // Content box -> panel.
  w.border('box_border', 'panel_border', 'box_border_radius');
  const boxBg = backgroundColor(w, 'box_background_color', 'content');
  if (boxBg) w.set('panel_background', classicBackground(boxBg));

  // Mobile accordion mode.
  const bpSelector = String(w.get('breakpoint_selector') ?? 'mobile');
  if (bpSelector !== 'none') w.note(`Elementor turns these tabs into an accordion on ${bpSelector}; Zadex keeps tabs on every device.`);
  w.consume('horizontal_scroll*');

  // Tabs.
  const flatten = containers.length > 0 && containers.every((c) => isPlainContainer(c));
  const boxPadding = dimsOrUndefined(w, 'box_padding');
  if (!flatten && boxPadding) w.note('The content padding applies to the kept content containers only through their own padding.');
  const activeIcons = items.some((it) => iconOf(ctx, it.tab_icon_active));
  if (activeIcons) w.note('Zadex tabs have one icon per tab; active-state icons were not kept.');
  const count = Math.max(items.length, containers.length);
  const children: ZElement[] = [];
  for (let i = 0; i < count; i++) {
    const item = items[i] ?? {};
    const container = containers[i];
    const tabId = ctx.idFor(source.id, 't' + (i + 1));
    const title = String(item.tab_title ?? container?.settings?._title ?? `Tab #${i + 1}`);
    const settings = childSettings({
      title,
      icon: iconOf(ctx, item.tab_icon),
      _css_id: typeof item.element_id === 'string' ? item.element_id : undefined,
      _padding: flatten ? boxPadding ?? kitContainerPadding(ctx) : undefined,
    });
    children.push({ id: tabId, type: 'tab', settings, children: nestedChildren(ctx, container, flatten, tabId, 'tab') });
  }
  return w.finish(children);
});
