import { registerWidget } from '../registry';
import type { ZElement } from '../types';
import {
  childSettings,
  classicBackground,
  colorValue,
  dims,
  repeaterItems,
  sliderBorder,
  textElement,
  withGlobalDefaults,
} from './_media-support';

/** Elementor `tabs_align_*` (logical) -> Zadex `nav_align` (flex, also logical). `stretch` is `nav_stretch`. */
const NAV_ALIGN: Record<string, string> = { start: 'flex-start', center: 'center', end: 'flex-end' };

/**
 * Elementor classic `tabs` (repeater of title + HTML content) -> Zadex `tabs` container with one `tab` per item,
 * each holding a Zadex `text` widget with the content. Elementor's look is made explicit where Zadex differs:
 * 20px/25px title padding, 20px panel padding, 1px #d5d8dc panel border, global colors / fonts of the kit.
 */
registerWidget('tabs', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    tab_color: 'primary',
    tab_active_color: 'accent',
    tab_typography_typography: 'primary',
    content_color: 'text',
    content_typography_typography: 'text',
  });
  const w = ctx.writer(el, 'tabs');
  const items = repeaterItems(w, 'tabs');

  // Layout.
  const vertical = w.get('type') === 'vertical';
  w.set('layout', vertical ? 'vertical' : 'horizontal');
  const alignKey = vertical ? 'tabs_align_vertical' : 'tabs_align_horizontal';
  w.consume(vertical ? 'tabs_align_horizontal' : 'tabs_align_vertical');
  const align = String(w.get(alignKey) ?? '');
  if (align === 'stretch') w.set('nav_stretch', true);
  else if (NAV_ALIGN[align]) w.set('nav_align', NAV_ALIGN[align]);

  // Titles.
  w.color('tab_color', 'title_color');
  w.color('tab_active_color', 'title_color_active');
  w.typography('tab_typography', 'title_typography');
  w.set('title_padding', dims(20, 25));
  w.set('title_padding', dims(10, 10), { bp: 'mobile' });

  // Panel: Elementor draws a 1px border (title + content) in `border_color`, default #d5d8dc.
  const border = sliderBorder(w, { top: true, right: true, bottom: true, left: true }, 1);
  if (border) w.set('panel_border', border);
  const bg = colorValue(w, 'background_color');
  if (bg) {
    w.set('title_bg_active', bg);
    w.set('panel_background', classicBackground(bg));
  }
  w.set('panel_padding', dims(20, 20));
  w.set('panel_padding', dims(10, 10), { bp: 'mobile' });

  // Content text styles (shared by every tab's text widget).
  const tw = ctx.writer(el, 'text', { id: 'unused' });
  tw.color('content_color', 'color');
  tw.typography('content_typography', 'typography');
  tw.textShadow('content_shadow', 'text_shadow');
  w.consume('content_color', 'content_typography_*', 'content_shadow_*');

  const children: ZElement[] = items.map((item, i) => {
    const tabId = ctx.idFor(source.id, 't' + (i + 1));
    const text = textElement(ctx.idFor(source.id, 'x' + (i + 1)), item.tab_content, tw.settings);
    return { id: tabId, type: 'tab', settings: childSettings({ title: String(item.tab_title ?? '') }), children: [text] };
  });
  if (w.dynamicRef('tabs')) w.note('Dynamic tags inside the tab items were not carried over.');
  return w.finish(children);
});
