import { registerWidget } from '../registry';
import { bool, slider } from '../values';
import { isObj, single } from './_shared';

/** Elementor path presets -> Zadex presets (`wave|arc|circle|line|custom`). */
const PATHS: Record<string, string> = { wave: 'wave', arc: 'arc', circle: 'circle', line: 'line', oval: 'circle', spiral: 'circle', custom: 'custom' };

/** First `<path d="…">` and the viewBox of an SVG file (Elementor's custom path is an uploaded SVG). */
export function svgPath(svg: string | undefined): { d: string; viewBox: string } | undefined {
  if (!svg) return undefined;
  const d = svg.match(/<path\b[^>]*\sd\s*=\s*"([^"]+)"/i)?.[1] ?? svg.match(/<path\b[^>]*\sd\s*=\s*'([^']+)'/i)?.[1];
  if (!d || !/^[MmZzLlHhVvCcSsQqTtAa0-9\s,.\-+eE]+$/.test(d)) return undefined;
  const vb = svg.match(/viewBox\s*=\s*["']([^"']+)["']/i)?.[1]?.trim().replace(/[\s,]+/g, ' ');
  return { d: d.trim(), viewBox: vb && /^-?\d+(\.\d+)?( -?\d+(\.\d+)?){3}$/.test(vb) ? vb : '0 0 500 100' };
}

/** Elementor `text-path` -> Zadex `text-path`. */
registerWidget('text-path', (el, ctx) => {
  const w = ctx.writer(el, 'text-path');
  w.set('text', String(w.get('text') ?? ''));
  if (w.dynamicRef('text')) w.note('The text was bound to a dynamic tag; the static text was kept.');
  const path = String(w.get('path') ?? 'wave');
  let preset = PATHS[path] ?? 'wave';
  if (path === 'oval' || path === 'spiral') {
    w.note(`Path "${path}" is not available in Zadex; a circle is used.`);
    w.status('partial');
  }
  if (path === 'custom') {
    const custom = svgPath(ctx.svg(w.raw('custom_path')));
    if (custom) {
      w.set('custom_path', custom.d);
      w.set('custom_viewbox', custom.viewBox);
    } else {
      preset = 'wave';
      w.note('The custom SVG path could not be read; the wave preset is used.');
      w.status('partial');
    }
  } else w.consume('custom_path');
  w.set('path', preset);
  w.url('link', 'link');

  const dir = w.get('text_path_direction');
  if (dir === 'rtl' || dir === 'ltr') w.set('direction', dir);
  else if (ctx.source.rtl) w.set('direction', 'rtl');
  const start = slider(w.get('start_point'), '%');
  if (start) w.set('start_offset', { size: start.size, unit: '%' });
  w.consumeResponsive('start_point');

  w.slider('size', 'max_width'); // Elementor "size" is the SVG width.
  w.typography('text_typography', 'typography');
  // Zadex has a separate font size control on the same element: mirror the typography sizes into it (Elementor
  // default 20px) so both agree.
  for (const [key, value] of Object.entries({ ...w.settings })) {
    const m = key.match(/^typography(@[a-z_]+)?$/);
    if (m && isObj(value) && isObj(value.size)) w.settings[`size${m[1] ?? ''}`] = value.size;
  }
  if (!w.settings.size) w.set('size', { size: 20, unit: 'px' });
  const ws = w.raw('word_spacing');
  if (slider(ws)) w.note('Word spacing is not carried over.');
  w.consumeResponsive('word_spacing');
  w.color('text_color_normal', 'color');
  w.color('text_color_hover', 'color', 'hover');
  w.consume('hover_transition', 'stroke_transition');

  if (bool(w.get('show_path'))) {
    w.color('stroke_color_normal', 'path_color');
    w.color('stroke_color_hover', 'path_color', 'hover');
    single(w, 'stroke_width_normal', 'path_width', (v) => slider(v));
    if (w.has('stroke_width_hover')) w.note('A hover path width is not available in Zadex.');
    if (w.has('path_fill_normal') || w.has('path_fill_hover')) w.note('The path fill color is not available in Zadex.');
  }
  w.consume('stroke_color_normal', 'stroke_color_hover', 'stroke_width_normal', 'stroke_width_hover', 'path_fill_normal', 'path_fill_hover');

  const align = w.raw('align');
  if (typeof align === 'string' && align !== '') w.note('The alignment of the curved text box is not carried over; use the Advanced tab alignment instead.');
  w.consumeResponsive('align');
  if (slider(w.raw('rotation'))) w.note('The rotation of the curved text is not carried over; use a transform in the Advanced tab.');
  w.consumeResponsive('rotation');
  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex text path.`);
  return w.finish();
});
