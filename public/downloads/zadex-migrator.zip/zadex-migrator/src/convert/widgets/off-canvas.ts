import { registerWidget } from '../registry';
import { deviceKeys } from '../responsive';
import { slider } from '../values';
import { firstOf, markPro } from './_pro';
import { proSwitch, proText } from './_pro-content';
import { seconds } from './_shared';

/**
 * Elementor Pro `off-canvas` (nested element) -> Zadex `off-canvas` container. Keys verified against Elementor Pro
 * 3.33.2 (defaults from elementor-defaults.json, CSS defaults from widget-off-canvas.css): `editing_mode`,
 * `off_canvas_name` (Off-Canvas), `horizontal_position` / `vertical_position` flex-start|center|flex-end R (CSS
 * default flex-start / flex-start: the panel sits at the start side), `width` R (CSS default 400px), `height`
 * fit-content|custom R (custom = 100vh) + `custom_height` R, `entrance_animation` / `exit_animation` R (Elementor
 * animation names; empty = none), `offcanvas_animation_duration` (1.5s), `is_not_close_on_overlay`,
 * `is_not_close_on_esc_overlay`, `prevent_scroll` (off), `wrapper_html_tag`; style background group `background_*`,
 * border group `border_*`, `border_radius`, `box_shadow_*`, `has_overlay` (yes), overlay background group
 * `overlay_background_*` (color rgba(0,0,0,.8)). The child container(s) become the panel's children.
 * Elementor opens the panel with an "Off-Canvas" link action (dynamic tag); Zadex has no button here (`trigger: none`)
 * and opens it from links to `#zx-off-canvas:<id>`.
 */
registerWidget('off-canvas', (el, ctx) => {
  const w = ctx.writer(el, 'off-canvas');
  markPro(w);

  w.set('trigger', 'none');
  w.note(`Links that opened this off-canvas with Elementor's action must point to "#zx-off-canvas:${w.id}" in Zadex.`);
  w.set('panel_label', proText(w, 'off_canvas_name', 'Off-Canvas') || 'Off-Canvas');
  w.consume('editing_mode');

  // Side: Elementor places the panel with flex alignment (horizontal start / center / end x vertical start / center /
  // end). Start / end columns become left / right panels (RTL aware), a centered column at the top / bottom becomes a
  // top / bottom panel; a centered box has no Zadex equivalent.
  const rtl = Boolean(ctx.source.rtl);
  const h = proText(w, 'horizontal_position', 'flex-start') || 'flex-start';
  const v = proText(w, 'vertical_position', 'flex-start') || 'flex-start';
  const start = rtl ? 'right' : 'left';
  const end = rtl ? 'left' : 'right';
  let side = h === 'flex-end' ? end : start;
  if (h === 'center') {
    if (v === 'flex-end') side = 'bottom';
    else if (v === 'flex-start') side = 'top';
    else {
      w.note('A centered off-canvas box (modal) is not available in Zadex; it opens as a side panel.');
      w.status('partial');
    }
  }
  if (h !== 'center' && v !== 'flex-start' && proText(w, 'height', 'custom') === 'fit-content') w.note('The vertical position of a fit-to-content panel is not carried over (Zadex panels are full height).');
  w.set('side', side);
  if (firstOf(w, 'horizontal_position_tablet', 'horizontal_position_mobile', 'vertical_position_tablet', 'vertical_position_mobile') !== undefined) w.note('Per-device panel positions are not available in Zadex; the desktop position is used.');
  w.consumeResponsive('horizontal_position');
  w.consumeResponsive('vertical_position');

  const vertical = side === 'top' || side === 'bottom';
  if (vertical) {
    const custom = proText(w, 'height', 'custom') === 'custom';
    let any = false;
    if (custom) {
      for (const [key, bp] of deviceKeys('custom_height')) {
        const s = slider(w.raw(key), 'vh');
        if (s) {
          w.set('size', s, { bp });
          any = true;
        }
      }
    }
    if (!any) {
      w.set('size', custom ? { size: 100, unit: 'vh' } : { size: 50, unit: 'vh' });
      if (!custom) w.note('A fit-to-content panel height is not available in Zadex; 50vh is used.');
    }
    if (w.has('width')) w.note('The panel width is not used for top / bottom panels in Zadex (full width).');
  } else {
    let any = false;
    for (const [key, bp] of deviceKeys('width')) {
      const s = slider(w.raw(key));
      if (s) {
        w.set('size', s, { bp });
        any = true;
      }
    }
    // Elementor's CSS default width is 400px (Zadex: 380px).
    if (!any) w.set('size', { size: 400, unit: 'px' });
    if (proText(w, 'height', 'custom') === 'fit-content' || w.has('custom_height')) w.note('The panel height is not used for side panels in Zadex (full height).');
  }
  w.consumeResponsive('width');
  w.consumeResponsive('height');
  w.consumeResponsive('custom_height');

  // Animation (Elementor: empty = no animation).
  const entrance = proText(w, 'entrance_animation');
  w.set('animation', entrance === '' || entrance === 'none' ? 'none' : /fade/i.test(entrance) ? 'fade' : /slide/i.test(entrance) ? 'slide' : 'fade');
  if (entrance !== '' && entrance !== 'none' && !/^(fade|slide)/i.test(entrance)) w.note(`Entrance animation "${entrance}" is approximated with a fade.`);
  const exit = w.raw('exit_animation');
  if (typeof exit === 'string' && exit !== '' && exit !== 'none' && !/fade|slide/i.test(exit)) w.note(`Exit animation "${exit}" is not carried over (Zadex reverses the entrance).`);
  w.consumeResponsive('entrance_animation');
  w.consumeResponsive('exit_animation');
  if (entrance !== '' && entrance !== 'none') {
    const duration = seconds(w.get('offcanvas_animation_duration'));
    if (duration && typeof duration.size === 'number') w.set('duration', Math.round(duration.size * 1000));
  }
  w.consumeResponsive('offcanvas_animation_duration');

  const overlay = proSwitch(w, 'has_overlay', true);
  w.set('overlay', overlay);
  w.set('close_on_overlay', !proSwitch(w, 'is_not_close_on_overlay'));
  if (proSwitch(w, 'is_not_close_on_esc_overlay')) w.note('Preventing the Escape key from closing the panel is not available in Zadex.');
  w.set('prevent_scroll', proSwitch(w, 'prevent_scroll'));
  // Elementor Pro has no built-in close button (a button inside the panel uses the "close off-canvas" action).
  w.set('close_button', true);
  w.note('Zadex adds its own close button to the panel; a close button placed inside the Elementor off-canvas is kept as content.');
  const tag = proText(w, 'wrapper_html_tag', 'div');
  if (tag !== 'div') w.note(`The panel HTML tag "${tag}" is not carried over.`);

  // Style.
  if (overlay) w.color('overlay_background_color', 'overlay_color');
  if (w.raw('overlay_background_background') === 'gradient' || w.has('overlay_background_image')) w.note('Only the overlay color is carried over (gradient / image overlays are not).');
  w.color('background_color', 'panel_bg');
  if (w.raw('background_background') === 'gradient' || w.has('background_image')) w.note('Only the panel background color is carried over (gradient / image backgrounds are not).');
  if (proText(w, 'border_border') !== '' && proText(w, 'border_border') !== 'none') w.note('The panel border is not available in Zadex.');
  if (w.has('border_radius')) w.note('The panel border radius is not available in Zadex.');
  w.boxShadow('box_shadow', 'panel_shadow');
  w.consume('overlay_*', 'background_*', 'border_*');
  w.consumeResponsive('border_radius');

  const children = ctx.convert(el.elements);
  return w.finish(children);
});

