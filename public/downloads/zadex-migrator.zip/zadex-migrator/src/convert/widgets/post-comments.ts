import { registerWidget } from '../registry';
import { markPro } from './_pro';

/**
 * Elementor Pro `post-comments` -> Zadex `comments`. Verified against Pro 3.33.2: `_skin` /
 * `skin_temp` (theme_comments: the theme's comments template), `source_type` current_post (default) / custom
 * (+ `source_custom` post id). Zadex `source: auto` uses the theme's comments.php like Elementor, with a built-in
 * fallback for block themes. No style controls in Elementor (the theme styles the comments).
 */
registerWidget('post-comments', (source, ctx) => {
  const w = ctx.writer(source, 'comments');
  markPro(w);
  w.consume('_skin', 'skin_temp');
  w.set('source', 'auto');
  if (w.get('source_type') === 'custom') {
    w.note('Comments of another post (custom source) are not available; the current post\'s comments are shown.');
    w.status('partial');
  }
  w.consume('source_custom');
  return w.finish();
});
