import { registerWidget } from '../registry';
import { textAlign } from '../align';
import type { ConvertContext } from '../context';
import { slider } from '../values';
import { boxTitleTag, dimsToSlider, iconValue, only, single, withGlobalDefaults } from './_shared';
import { iconColors, iconShape } from './icon';

/**
 * Elementor box position (logical `block-start|block-end|inline-start|inline-end`, older `top|left|right`) ->
 * Zadex flex direction (`column|row|row-reverse`). `row` follows the document direction, so physical left/right
 * swap on RTL sites. `block-end` (icon under the text) has no Zadex equivalent and becomes `column`.
 */
export function boxPosition(ctx: ConvertContext): Record<string, string> {
  const rtl = Boolean(ctx.source.rtl);
  return {
    'block-start': 'column',
    top: 'column',
    'block-end': 'column',
    'inline-start': 'row',
    'inline-end': 'row-reverse',
    left: rtl ? 'row-reverse' : 'row',
    right: rtl ? 'row' : 'row-reverse',
  };
}

export const VERTICAL_ALIGN: Record<string, string> = { top: 'flex-start', middle: 'center', bottom: 'flex-end' };

/** Elementor `icon-box` -> Zadex `icon-box`. */
registerWidget('icon-box', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    primary_color: 'globals/colors?id=primary',
    title_color: 'globals/colors?id=primary',
    title_typography_typography: 'globals/typography?id=primary',
    description_color: 'globals/colors?id=text',
    description_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'icon-box');
  const ic = iconValue(w, 'selected_icon');
  w.set('icon', ic ?? { library: '', value: '' });
  const view = String(w.get('view') ?? 'default');
  w.set('view', ['default', 'stacked', 'framed'].includes(view) ? view : 'default');
  if (view !== 'default') iconShape(w, String(w.get('shape') ?? 'circle'), 'border_radius', 'icon_border_radius');
  else w.consume('shape', 'border_radius');

  w.set('title', String(w.get('title_text') ?? ''));
  w.set('description', String(w.get('description_text') ?? ''));
  if (w.dynamicRef('title_text') || w.dynamicRef('description_text')) w.note('Dynamic tags on the texts were replaced by their static text.');
  w.url('link', 'link');
  w.set('title_tag', boxTitleTag(w, w.get('title_size')));

  w.map('position', 'position', boxPosition(ctx));
  for (const k of ['position', 'position_tablet', 'position_mobile']) {
    if (w.raw(k) === 'block-end') w.note('Icon below the text ("block-end") is not available in Zadex; the icon is placed above.');
  }
  w.map('content_vertical_alignment', 'vertical_align', VERTICAL_ALIGN);
  // Elementor centers the box content by default.
  if (!w.has('text_align')) w.set('text_align', 'center');
  w.map('text_align', 'text_align', only(textAlign(ctx), ['left', 'center', 'right']));
  w.slider('icon_space', 'spacing');

  iconColors(w, view, { color: 'icon_color', bg: 'icon_bg', border: 'icon_border_color' });
  w.consume('hover_icon_colors_transition_duration');
  if (!w.has('icon_size')) w.set('icon_size', { size: 50, unit: 'px' }); // Elementor .elementor-icon default
  w.slider('icon_size', 'icon_size');
  w.slider('icon_padding', 'icon_padding');
  single(w, 'rotate', 'icon_rotate', (v) => slider(v, 'deg'));
  const bw = dimsToSlider(w.raw('border_width'));
  if (bw) {
    if (bw.uneven) w.note('Icon border width: different values per side are not supported; one value was kept.');
    w.set('icon_border_width', bw.value);
  }
  w.consumeResponsive('border_width');

  w.color('title_color', 'title_color');
  w.color('hover_title_color', 'title_color', 'hover');
  w.consume('hover_title_color_transition_duration');
  w.typography('title_typography', 'title_typography');
  w.slider('title_bottom_space', 'title_spacing');
  w.color('description_color', 'desc_color');
  w.typography('description_typography', 'desc_typography');

  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex icon box.`);
  return w.finish();
});
