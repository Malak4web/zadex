import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { dynamicValue } from '../dynamic';
import type { ElementState, ElementWriter } from '../context';
import { withGlobalDefaults } from './_shared';

/** Global defaults of Elementor's heading style controls (also used by the Pro theme title widgets). */
export const HEADING_GLOBAL_DEFAULTS = {
  title_color: 'globals/colors?id=primary',
  typography_typography: 'globals/typography?id=primary',
};

/**
 * Style part of the Elementor heading, shared with the Pro theme title widgets that extend it (theme-post-title,
 * theme-page-title, theme-site-title, theme-archive-title): `title_color` (+ `title_hover_color`), `typography`
 * (Elementor's `.elementor-heading-title{line-height:1}` written underneath), `text_shadow`, `size` preset note.
 * `hover`: Zadex target of the hover color, or undefined when the target widget has none (noted).
 * `textShadow`: Zadex boxShadow control, or undefined when the target has none (noted).
 */
export function headingStyle(
  w: ElementWriter,
  t: { color: string; hover?: { id: string; state?: ElementState }; typography: string; textShadow?: string } = {
    color: 'color',
    hover: { id: 'color', state: 'hover' },
    typography: 'typography',
    textShadow: 'text_shadow',
  },
): void {
  w.color('title_color', t.color);
  if (t.hover) w.color('title_hover_color', t.hover.id, t.hover.state);
  else if (w.raw('title_hover_color')) w.note('The hover color is not available on this Zadex widget.');
  w.consume('title_hover_color_transition_duration');
  w.typography('typography', t.typography);
  // Elementor's stylesheet sets `.elementor-heading-title{line-height:1}`; Zadex headings use the theme's.
  const typo = (w.settings[t.typography] ?? {}) as Record<string, unknown>;
  if (typo.lineHeight === undefined) w.set(t.typography, { ...typo, lineHeight: { size: 1, unit: 'custom' } });
  if (t.textShadow) w.textShadow('text_shadow', t.textShadow);
  else {
    if (w.raw('text_shadow_text_shadow_type') === 'yes') w.note('The text shadow is not available on this Zadex widget.');
    w.consume('text_shadow_*');
  }
  const size = w.get('size');
  if (size && size !== 'default') w.note(`Elementor size preset "${String(size)}" is not carried over; set a font size instead.`);
}

/**
 * Elementor `heading` -> Zadex `heading`. Reference pattern for widget mappers:
 *  1. open a writer for the Zadex type,
 *  2. copy each Elementor control with the matching helper (responsive / color / typography …),
 *  3. note features Zadex cannot express (they are reported; unread keys are reported automatically),
 *  4. `finish()` (applies the shared Advanced-tab conversion and records the report entry).
 */
registerWidget('heading', (source, ctx) => {
  // Elementor paints an unstyled heading with the kit's primary color and primary typography.
  const el = withGlobalDefaults(source, ctx, HEADING_GLOBAL_DEFAULTS);
  const w = ctx.writer(el, 'heading');
  w.set('text', String(w.get('title') ?? ''));
  // Dynamic tag (src/convert/dynamic.ts): becomes a Zadex dynamic value when the tag has an equivalent.
  const dynRef = w.dynamicRef('title');
  const dyn = dynRef ? dynamicValue(dynRef, 'text') : undefined;
  if (dyn) {
    w.set('text', dyn.value);
    w.consumeDynamic('title');
    if (dyn.note) w.note(dyn.note);
  } else if (dynRef) w.note('The heading text was bound to a dynamic tag; the static text was kept.');
  w.set('tag', w.get('header_size'));
  w.url('link', 'link');
  w.map('align', 'align', textAlign(ctx));
  headingStyle(w);
  return w.finish();
});
