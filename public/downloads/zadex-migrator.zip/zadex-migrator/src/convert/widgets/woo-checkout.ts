import { registerWidget } from '../registry';
import type { ElementWriter } from '../context';
import { markPro } from './_pro';
import { isObj, proDefault, wooLabels, wooPageStyles } from './_woo-shop';
import { noteIfSet } from './_woo-product';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-checkout-page` -> Zadex `checkout` (WooCommerce's checkout form, same as Elementor).
 * Verified against Elementor Pro 3.33.2: `checkout_layout` two-column (default) | one-column, `sticky_right_column`
 * (+ offset), texts `billing_details_section_title`, `order_summary_section_title`, `coupon_section_title_text`,
 * `coupon_section_title_link_text`, `terms_conditions_message_text`, `terms_conditions_link_text` (+ alignments),
 * field repeaters `billing_details_form_fields` / `additional_information_form_fields` (items: `field_key`,
 * `field_label`, `label`, `placeholder`, `default`, `repeater_state`), `additional_information_active` (yes),
 * `coupon_section_display` (yes), the shared style section (`wooPageStyles`), `purchase_button_*` styles and the
 * per-section "customize" styles (dropped, reported).
 */

/** True when a checkout fields repeater changes a label / placeholder / default value of Pro's default rows. */
function fieldsChanged(w: ElementWriter, key: string): boolean {
  const rows = w.raw(key);
  if (!Array.isArray(rows)) return false;
  const defaults = proDefault(w, key);
  const byKey = new Map<string, Record<string, unknown>>();
  if (Array.isArray(defaults)) for (const d of defaults) if (isObj(d)) byKey.set(String(d.field_key), d);
  return rows.some((row, i) => {
    if (!isObj(row)) return false;
    const def = byKey.get(String(row.field_key)) ?? (Array.isArray(defaults) && isObj(defaults[i]) ? defaults[i] : {});
    const d = def as Record<string, unknown>;
    const differs = (f: string): boolean => typeof row[f] === 'string' && row[f] !== '' && row[f] !== (d[f] ?? '');
    return differs('label') || differs('placeholder') || differs('default');
  });
}

registerWidget('woocommerce-checkout-page', (source, ctx) => {
  const off = wooGuard(source, ctx, 'checkout');
  if (off) return off;
  const w = ctx.writer(source, 'checkout');
  markPro(w);
  const layout = String(w.get('checkout_layout') || 'two-column');
  w.set('layout', layout === 'one-column' ? 'stacked' : 'columns');
  if (w.get('sticky_right_column') === 'yes') w.note('The sticky right column is not available in Zadex.');
  w.consume('sticky_right_column_offset');
  wooLabels(
    w,
    ['billing_details_section_title', 'order_summary_section_title', 'coupon_section_title_text', 'coupon_section_title_link_text', 'terms_conditions_message_text', 'terms_conditions_link_text'],
    'WooCommerce\'s own texts and checkout fields are shown',
  );
  const fields = ['billing_details_form_fields', 'additional_information_form_fields'].filter((k) => fieldsChanged(w, k));
  if (fields.length) {
    w.note(`Custom checkout field labels / placeholders (${fields.join(', ')}) are not available in Zadex; WooCommerce's own fields are shown.`);
    w.status('partial');
  }
  if (w.get('additional_information_active') !== 'yes') w.note('Hiding the additional information section is not available in Zadex.');
  if (w.get('coupon_section_display') !== 'yes') {
    w.note('Hiding the coupon section is not available in Zadex.');
    w.status('partial');
  }
  noteIfSet(
    w,
    ['billing_details_alignment', 'order_summary_alignment', 'coupon_alignment', 'coupon_button_alignment', 'purchase_button_alignment'],
    'Section title / button alignments are not carried over.',
  );
  wooPageStyles(w);
  noteIfSet(w, ['purchase_button_*'], 'The "Place order" button styles are not carried over separately; Zadex styles every button alike.');
  return w.finish();
});
