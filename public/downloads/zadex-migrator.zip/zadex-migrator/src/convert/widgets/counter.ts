import { registerWidget } from '../registry';
import { bool, slider } from '../values';
import { single, toNumber, typographyWithDefaults, withGlobalDefaults } from './_shared';

/** Elementor `counter` -> Zadex `counter`. */
registerWidget('counter', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    number_color: 'globals/colors?id=primary',
    typography_number_typography: 'globals/typography?id=primary',
    title_color: 'globals/colors?id=secondary',
    typography_title_typography: 'globals/typography?id=secondary',
  });
  const w = ctx.writer(el, 'counter');
  w.set('start', toNumber(w.get('starting_number')) ?? 0);
  w.set('end', toNumber(w.get('ending_number')) ?? 100);
  w.set('duration', toNumber(w.get('duration')) ?? 2000);
  const sep = bool(w.get('thousand_separator'));
  const char = w.get('thousand_separator_char');
  w.set('separator', sep ? (typeof char === 'string' && char !== '' ? char : ',') : '');
  // Zadex defaults differ (suffix "+", a sample title): always write the Elementor values.
  w.set('prefix', String(w.get('prefix') ?? ''));
  w.set('suffix', String(w.get('suffix') ?? ''));
  w.set('title', String(w.get('title') ?? ''));
  for (const k of ['prefix', 'suffix', 'title', 'ending_number']) if (w.dynamicRef(k)) w.note(`"${k}" was bound to a dynamic tag; the static value was kept.`);

  const tag = w.get('title_tag');
  if (tag && tag !== 'div') w.note(`Title tag "${String(tag)}" is not carried over (Zadex uses a div).`);
  const pos = w.raw('title_position');
  if (typeof pos === 'string' && pos !== '' && pos !== 'after') w.note(`Title position "${pos}" is not available in Zadex (the title is below the number).`);
  w.consumeResponsive('title_position');
  for (const k of ['title_horizontal_alignment', 'title_vertical_alignment', 'number_position', 'number_alignment', 'number_gap']) {
    if (w.has(k)) w.note(`"${k}" is not available in Zadex.`);
    w.consumeResponsive(k);
  }
  w.consume('title_tag');
  single(w, 'title_gap', 'title_gap', (v) => slider(v));

  w.color('number_color', 'number_color');
  // Elementor's stylesheet: number 69px / 600 / line-height 1, title 19px / 400 / line-height 2.5.
  typographyWithDefaults(w, 'typography_number', 'number_typography', { size: { size: 69, unit: 'px' }, weight: '600', lineHeight: { size: 1, unit: 'custom' } });
  w.color('title_color', 'title_color');
  typographyWithDefaults(w, 'typography_title', 'title_typography', { size: { size: 19, unit: 'px' }, weight: '400', lineHeight: { size: 2.5, unit: 'custom' } });
  return w.finish();
});
