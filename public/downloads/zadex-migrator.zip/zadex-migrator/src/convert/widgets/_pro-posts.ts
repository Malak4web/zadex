/**
 * Helpers shared by the Elementor Pro posts / media mappers (P2: posts, portfolio, gallery, media-carousel,
 * video-playlist, loop-grid, loop-carousel). Not a mapper: nothing is registered here.
 *
 * Verified against Elementor Pro 3.33.2 (dev/reference/elementor-pro-controls.json): `w.get()` returns Pro's real
 * defaults (src/convert/data/elementor-defaults.json, device defaults such as `columns_tablet: "2"` included), so the
 * mappers read through `w.get()` / the `get*` helpers below. `pv()` / `pbool()` (explicit assumed defaults) are kept
 * for the WooCommerce mappers that still import them.
 */
import type { ElementWriter } from '../context';
import { deviceKeys } from '../responsive';
import { bool, dimensions, isBlank, num, slider, type Dimensions } from '../values';
import { firstOf } from './_pro';
import { colorValue } from './_media-support';

/**
 * Elementor Pro's posts CSS (widget-posts.css) for what the controls leave unset: title 18px (cards 21px), meta
 * 12px #adadad, excerpt 14px #777 line height 1.5em (cards 1.7), read more 12px (uppercase on cards). Zadex's posts
 * widget is larger by default, so unset fields are written (V7: real Pro blog / archive pages). Shared by `posts`
 * and `archive-posts`; only fields the element did not set are filled.
 */
export function postsCssDefaults(w: ElementWriter, skin: 'classic' | 'cards' | string, keys?: string[]): void {
  const ok = (key: string) => !keys || keys.includes(key);
  const fill = (key: string, add: Record<string, unknown>) => {
    if (!ok(key)) return;
    const cur = (w.settings[key] ?? {}) as Record<string, unknown>;
    const out = { ...cur };
    for (const [k, v] of Object.entries(add)) if (out[k] === undefined) out[k] = v;
    w.set(key, out);
  };
  const cards = skin === 'cards';
  fill('title_typography', { size: { size: cards ? 21 : 18, unit: 'px' } });
  fill('meta_typography', { size: { size: 12, unit: 'px' }, lineHeight: { size: 1.3, unit: 'em' } });
  fill('excerpt_typography', { size: { size: 14, unit: 'px' }, lineHeight: cards ? { size: 1.7, unit: 'custom' } : { size: 1.5, unit: 'em' } });
  fill('more_typography', cards ? { size: { size: 12, unit: 'px' }, transform: 'uppercase' } : { size: { size: 12, unit: 'px' } });
  if (ok('meta_color') && w.settings.meta_color === undefined) w.set('meta_color', '#adadad');
  if (ok('excerpt_color') && w.settings.excerpt_color === undefined) w.set('excerpt_color', '#777777');
}

type Obj = Record<string, unknown>;

/**
 * Stored Pro value or the given (assumed Elementor Pro) default when the key is absent. A stored `''` is kept (it is
 * a real choice for selects such as `pagination: ''` = none). Marks the key as handled.
 */
export function pv<T>(w: ElementWriter, key: string, def: T): unknown | T {
  const v = w.raw(key);
  return v === undefined || v === null ? def : v;
}

/** Pro switcher with an assumed default (`'yes'` / `''`). */
export function pbool(w: ElementWriter, key: string, def: boolean): boolean {
  const v = w.raw(key);
  return v === undefined || v === null ? def : bool(v);
}

/** Stored value or Pro's real default, as a string ('' when absent). */
export function getStr(w: ElementWriter, key: string): string {
  const v = w.get(key);
  return v === undefined || v === null ? '' : String(v);
}

/** Pro switcher: stored value or Pro's real default (`'yes'`, `'show-avatar'` … = on; `''` / `'no'` = off). */
export function getBool(w: ElementWriter, key: string): boolean {
  return bool(w.get(key));
}

/** Positive integer from the stored value or Pro's real default. */
export function getInt(w: ElementWriter, key: string): number | undefined {
  return toInt(w.get(key));
}

/** Decodes the few HTML entities Pro stores in text defaults (`&laquo; Previous`, `Next &raquo;`). */
export function decodeText(s: string): string {
  const map: Record<string, string> = { laquo: '«', raquo: '»', amp: '&', nbsp: ' ', quot: '"', lt: '<', gt: '>', hellip: '…', rsquo: '’', lsquo: '‘' };
  return s
    .replace(/&#(\d+);/g, (_, n: string) => String.fromCharCode(Number(n)))
    .replace(/&([a-z]+);/g, (m, name: string) => map[name] ?? m);
}

/**
 * Responsive number control read with Pro's real defaults: desktop / tablet / mobile fall back to the control's
 * default / `tablet_default` / `mobile_default` (in elementor-defaults.json); other devices only when stored.
 * Returns the desktop value.
 */
export function responsiveGet(w: ElementWriter, src: string, dst: string, clamp: [number, number] = [1, 12], fallback?: { desktop?: number; tablet?: number; mobile?: number }): number | undefined {
  let desktop: number | undefined;
  for (const [key, bp] of deviceKeys(src)) {
    let n = toInt(!bp || bp === 'tablet' || bp === 'mobile' ? w.get(key) : w.raw(key));
    if (n === undefined && fallback) n = !bp ? fallback.desktop : bp === 'tablet' ? fallback.tablet : bp === 'mobile' ? fallback.mobile : undefined;
    if (n === undefined) continue;
    n = Math.min(clamp[1], Math.max(clamp[0], n));
    if (!bp) desktop = n;
    w.set(dst, n, { bp });
  }
  return desktop;
}

/** Responsive slider read with Pro's real defaults (desktop / tablet / mobile), `fallback` when Pro has none. */
export function responsiveSliderGet(w: ElementWriter, src: string, dst: string, fallback?: { size: number; unit: string }): void {
  for (const [key, bp] of deviceKeys(src)) {
    const s = slider(!bp || bp === 'tablet' || bp === 'mobile' ? w.get(key) : w.raw(key));
    if (s) w.set(dst, s, { bp });
    else if (!bp && fallback) w.set(dst, fallback);
  }
}

/** Positive integer, or undefined. */
export function toInt(v: unknown): number | undefined {
  const n = num(v);
  return typeof n === 'number' && n > 0 ? Math.round(n) : undefined;
}

/** Elementor select2 multiple value as a list of strings (accepts arrays, comma strings, numbers). */
export function list(v: unknown): string[] {
  if (Array.isArray(v)) return v.map((x) => String(x).trim()).filter((x) => x !== '');
  if (typeof v === 'number') return [String(v)];
  if (typeof v === 'string') return v.split(',').map((x) => x.trim()).filter((x) => x !== '');
  return [];
}

/**
 * Responsive number control with Elementor's `tablet_default` / `mobile_default` made explicit (e.g. posts columns
 * 3 / 2 / 1): device values the page did not store get the default when one is given.
 */
export function responsiveInt(
  w: ElementWriter,
  src: string,
  dst: string,
  defaults: { desktop?: number; tablet?: number; mobile?: number },
  clamp: [number, number] = [1, 12],
): number | undefined {
  let desktop: number | undefined;
  for (const [key, bp] of deviceKeys(src)) {
    let n = toInt(w.raw(key));
    if (n === undefined) {
      if (!bp) n = defaults.desktop;
      else if (bp === 'tablet') n = defaults.tablet;
      else if (bp === 'mobile') n = defaults.mobile;
    }
    if (n === undefined) continue;
    n = Math.min(clamp[1], Math.max(clamp[0], n));
    if (!bp) desktop = n;
    w.set(dst, n, { bp });
  }
  return desktop;
}

/** Responsive slider; the desktop value falls back to `def` (an Elementor default Zadex does not share). */
export function responsiveSlider(w: ElementWriter, src: string, dst: string, def?: { size: number; unit: string }): void {
  for (const [key, bp] of deviceKeys(src)) {
    const s = slider(w.raw(key));
    if (s) w.set(dst, s, { bp });
    else if (!bp && def) w.set(dst, def);
  }
}

/** Non-responsive Zadex slider from a (possibly responsive) Elementor slider: desktop value, devices noted. */
export function desktopSlider(w: ElementWriter, src: string, dst: string): void {
  for (const [key, bp] of deviceKeys(src)) {
    const v = w.raw(key);
    if (isBlank(v)) continue;
    if (bp) {
      w.note(`Per-device values of ${src} are not supported by the Zadex widget; the desktop value is used.`);
      continue;
    }
    const s = slider(v);
    if (s) w.set(dst, s);
  }
}

/** A slider (one size for every side) or a dimensions value -> Zadex dimensions. */
export function sliderOrDims(v: unknown): Dimensions | undefined {
  const d = dimensions(v);
  if (d) return d;
  const s = slider(v);
  if (!s) return undefined;
  return { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true };
}

/** Writes a Zadex dimensions control from an Elementor slider / dimensions (desktop; devices only if responsive). */
export function dimsFrom(w: ElementWriter, src: string, dst: string, responsive = false): void {
  for (const [key, bp] of deviceKeys(src)) {
    const v = w.raw(key);
    if (isBlank(v)) continue;
    if (bp && !responsive) {
      w.note(`Per-device values of ${src} are not supported by the Zadex widget; the desktop value is used.`);
      continue;
    }
    const d = sliderOrDims(v);
    if (d) w.set(dst, d, { bp });
  }
}

/** A color (honours `__globals__`), returned without writing. */
export function colorOf(w: ElementWriter, key: string): string | undefined {
  return colorValue(w, key);
}

/** First color found among alternative key names (Pro renamed some controls). Marks all of them as handled. */
export function colorFirst(w: ElementWriter, ...keys: string[]): string | undefined {
  let found: string | undefined;
  for (const k of keys) {
    const c = colorOf(w, k);
    if (found === undefined && c) found = c;
  }
  return found;
}

/** Writes the first typography group found among alternative prefixes. */
export function typographyFirst(w: ElementWriter, dst: string, ...prefixes: string[]): void {
  for (const p of prefixes) {
    if (w.settings[dst] === undefined) w.typography(p, dst);
    else w.consume(`${p}_*`);
  }
}

/**
 * Elementor Pro image ratio slider (height / width, e.g. `{size: 0.66}` = padding-bottom 66%) -> the closest Zadex
 * ratio option ("3 / 2"…). Notes when the closest option is more than 5% off.
 */
export function ratioOption(w: ElementWriter, v: unknown, options: string[], label: string): string | undefined {
  const s = slider(v);
  const n = s && typeof s.size === 'number' ? s.size : undefined;
  if (n === undefined || n <= 0) return undefined;
  let best: string | undefined;
  let diff = Infinity;
  for (const o of options) {
    const m = o.match(/^(\d+)\s*\/\s*(\d+)$/);
    if (!m) continue;
    const r = Number(m[2]) / Number(m[1]);
    const d = Math.abs(r - n) / n;
    if (d < diff) {
      diff = d;
      best = o;
    }
  }
  if (best && diff > 0.05) w.note(`${label} ${n} has no exact Zadex ratio; "${best}" is used.`);
  return best;
}

/** Elementor image size names -> Zadex options that include `medium_large` (posts, portfolio, gallery-pro). */
export function imageSizeName(w: ElementWriter, size: unknown, allowed: string[], fallback: string): string {
  const s = String(size ?? '');
  if (allowed.includes(s)) return s;
  if (s === '1536x1536' || s === '2048x2048') return allowed.includes('full') ? 'full' : fallback;
  if (s === 'medium_large') return allowed.includes('large') ? 'large' : fallback;
  if (s === 'custom') {
    w.note('Custom image dimensions are not available in Zadex; the "large" size is used.');
    return allowed.includes('large') ? 'large' : fallback;
  }
  if (s !== '') w.note(`Image size "${s}" is not available in Zadex; "${fallback}" is used.`);
  return fallback;
}

/** Elementor title tags -> Zadex posts / portfolio tag options (h1 -> h2; span / div per the target list). */
export function titleTag(w: ElementWriter, v: unknown, allowed: string[]): string {
  const tag = String(v || 'h3');
  if (allowed.includes(tag)) return tag;
  const out = tag === 'h1' ? 'h2' : allowed.includes('div') ? 'div' : allowed.includes('span') ? 'span' : 'p';
  w.note(`Title tag "${tag}" is not available in Zadex; "${out}" is used.`);
  return out;
}

/** Elementor Pro `pagination_type` -> Zadex loop pagination option. */
export const PAGINATION: Record<string, string> = {
  '': 'none',
  numbers: 'numbers',
  prev_next: 'prev_next',
  numbers_and_prev_next: 'numbers_prev_next',
  load_more_on_click: 'load_more',
  load_more_infinite_scroll: 'infinite',
};

/**
 * Pagination section shared by Pro posts / loop grid (Pro 3.33.2 keys): `pagination_type` ('' default),
 * `pagination_prev_label` / `pagination_next_label` (posts `&laquo; Previous` / `Next &raquo;`, loop grid
 * `Previous` / `Next`: read with `w.get()`, entities decoded), `pagination_page_limit` (5), `pagination_align`
 * (center), style `pagination_typography_*` (kit secondary font by default), `pagination_color`,
 * `pagination_hover_color`, `pagination_active_color`, `pagination_spacing` (10px between numbers: no Zadex
 * equivalent), `pagination_spacing_top` (space above). Load more button (`load_more_on_click`): `text` (Load More),
 * `align` (posts) / `load_more_button_align` (loop grid), `typography_*` (kit accent font), `button_text_color`,
 * `background_color` (kit accent) + `button_background_hover_color`, `hover_color`, `border_*`, `border_radius`,
 * `text_padding`, `load_more_spacing`.
 */
export function mapPagination(w: ElementWriter, rtl: boolean): void {
  const type = getStr(w, 'pagination_type');
  const zp = PAGINATION[type] ?? 'none';
  if (!(type in PAGINATION)) w.note(`Pagination "${type}" is not available in Zadex; no pagination is shown.`);
  w.set('pagination', zp);
  if (zp === 'prev_next' || zp === 'numbers_prev_next') {
    w.set('prev_text', decodeText(getStr(w, 'pagination_prev_label')));
    w.set('next_text', decodeText(getStr(w, 'pagination_next_label')));
  } else w.consume('pagination_prev_label', 'pagination_next_label');
  if (zp === 'load_more') {
    const text = getStr(w, 'text');
    w.set('load_more_text', text !== '' ? text : 'Load More');
  } else w.consume('text');
  if ((zp === 'numbers' || zp === 'numbers_prev_next' || zp === 'prev_next') && !isBlank(w.raw('pagination_page_limit'))) {
    w.note('The pagination page limit is not available in Zadex.');
  }
  w.consume('pagination_page_limit', 'pagination_numbers_shorten', 'load_more_spinner', 'load_more_spinner_color', 'load_more_no_posts_custom_message', 'load_more_no_posts_message_switcher', 'load_more_no_posts_message_*');
  w.consume('pagination_individual_divider', 'pagination_individual_handle', 'pagination_load_type', 'auto_scroll', 'auto_scroll_offset', 'selected_icon', 'icon_align', 'icon_indent', 'button_css_id', 'hover_animation', 'button_hover_transition_duration', 'content_align');

  if (zp === 'none' || zp === 'infinite') {
    w.consume('pagination_align*', 'pagination_typography_*', 'pagination_color', 'pagination_hover_color', 'pagination_active_color', 'pagination_spacing*');
    consumeLoadMoreButton(w);
    return;
  }
  const table: Record<string, string> = {
    left: rtl ? 'flex-end' : 'flex-start',
    right: rtl ? 'flex-start' : 'flex-end',
    start: 'flex-start',
    end: 'flex-end',
    center: 'center',
    justify: 'center',
  };
  if (zp === 'load_more') {
    w.consume('pagination_align*', 'pagination_typography_*', 'pagination_color', 'pagination_hover_color', 'pagination_active_color', 'pagination_spacing*');
    const align = String(firstOf(w, 'load_more_button_align', 'align') ?? 'center');
    if (align === 'justify') w.note('A full-width load more button is not available in Zadex; it is centered.');
    w.set('pagination_align', table[align] ?? 'center');
    w.consume('align_tablet', 'align_mobile', 'align_laptop', 'align_widescreen', 'align_tablet_extra', 'align_mobile_extra', 'load_more_button_align_*');
    w.typography('typography', 'pagination_typography');
    w.color('button_text_color', 'pagination_color');
    const hover = colorOf(w, 'hover_color');
    if (hover) w.set('pagination_color', hover, { state: 'hover' });
    const bg = colorOf(w, 'background_color');
    if (bg) w.set('pagination_bg', bg);
    const bgHover = colorOf(w, 'button_background_hover_color');
    if (bgHover) w.set('pagination_bg', bgHover, { state: 'hover' });
    w.consume('background_*', 'button_background_hover_*', 'button_box_shadow_*', 'button_hover_box_shadow_*', 'button_hover_border_color');
    w.border('border', 'pagination_border', 'border_radius');
    const pad = dimensions(w.raw('text_padding'));
    if (pad) w.set('pagination_padding', pad);
    w.consume('text_padding_*');
    // Pro CSS: `margin-top: var(--load-more—spacing, 30px)` above the button.
    w.set('pagination_spacing', slider(w.raw('load_more_spacing')) ?? { size: 30, unit: 'px' });
    return;
  }
  consumeLoadMoreButton(w);
  const align = getStr(w, 'pagination_align') || 'center';
  if (table[align]) w.set('pagination_align', table[align]);
  w.consume('pagination_align_tablet', 'pagination_align_mobile');
  w.typography('pagination_typography', 'pagination_typography');
  w.color('pagination_color', 'pagination_color');
  const hover = colorOf(w, 'pagination_hover_color');
  if (hover) w.set('pagination_color', hover, { state: 'hover' });
  w.color('pagination_active_color', 'pagination_active_color');
  const s = slider(w.raw('pagination_spacing_top'));
  if (s) w.set('pagination_spacing', s);
  if (!isBlank(w.raw('pagination_spacing'))) w.note('The space between pagination items is not available in Zadex.');
}

/** Marks the load more button style keys (used only by `load_more_on_click`) as handled. */
function consumeLoadMoreButton(w: ElementWriter): void {
  w.consume('align', 'align_*', 'load_more_button_align*', 'typography_*', 'button_text_color', 'hover_color', 'background_*', 'button_background_hover_*', 'button_box_shadow_*', 'button_hover_box_shadow_*', 'button_hover_border_color', 'border_border', 'border_width*', 'border_color', 'border_radius*', 'text_padding*', 'load_more_spacing*', 'text_shadow_*');
}

/**
 * "Nothing found" message. Posts / portfolio / loop carousel have no such control in Pro 3.33.2 (an empty query
 * renders nothing), so `nothing_found` is cleared; the loop grid has `enable_nothing_found_message` (off) +
 * `nothing_found_message_text`, `nothing_found_message_color`, `nothing_found_message_typography_*`.
 */
export function mapNothingFound(w: ElementWriter): void {
  if (!getBool(w, 'enable_nothing_found_message')) {
    w.set('nothing_found', '');
    w.consume('nothing_found_message_*');
    return;
  }
  w.set('nothing_found', getStr(w, 'nothing_found_message_text'));
  w.set('empty_color', colorOf(w, 'nothing_found_message_color') ?? '#1f2124');
  w.typography('nothing_found_message_typography', 'empty_typography');
  w.consume('nothing_found_message_align', 'nothing_found_message_html_tag', 'nothing_found_message_space_from_top*', 'nothing_found_message_space_from_bottom*');
}

/** Elementor Pro `<prefix>orderby` values (posts: post_*, products: date / title / price …) -> Zadex `query_orderby`. */
const ORDERBY: Record<string, string> = {
  post_date: 'date',
  date: 'date',
  post_title: 'title',
  title: 'title',
  menu_order: 'menu_order',
  modified: 'modified',
  comment_count: 'comment_count',
  rand: 'rand',
};

/** Elementor Pro `<prefix>select_date` values -> Zadex `query_date` (quarter has no equivalent). */
const DATES: Record<string, string> = { anytime: 'any', today: 'day', week: 'week', month: 'month', year: 'year', exact: 'custom' };

/** Product query sources (loop `product_query_post_type`) that Zadex can only approximate with all products. */
const PRODUCT_SOURCES = ['sale', 'featured', 'upsells', 'cross_sells'];

/**
 * Elementor Pro query group (Group_Control_Query / Related, Pro 3.33.2) -> Zadex shared query group (`query_*`,
 * `../plugin zadex/widgets/_common/query.json`). `prefix` is the group name + `_`: `posts_` (posts / portfolio),
 * `post_query_` (loop grid / carousel, post skin), `product_query_` (loop product skin). Keys: `post_type`
 * (post | page | product | by_id | current_query | related; products: product | sale | featured | by_id |
 * current_query | related_products | upsells | cross_sells), `posts_ids`, `include` (terms, authors) +
 * `include_term_ids` / `include_authors`, `related_taxonomies` (under include terms), `exclude` (current_post,
 * manual_selection, terms, authors) + `exclude_ids` / `exclude_term_ids` / `exclude_authors`, `avoid_duplicates`,
 * `offset` (0), `related_fallback` (fallback_none), `fallback_ids`, `select_date` (anytime; quarter noted),
 * `date_before` / `date_after`, `orderby` (post_date), `order` (desc), `ignore_sticky_posts` (yes, post type `post`
 * only), `query_id`. `perPage` is the widget's own `posts_per_page` / `<skin>_posts_per_page`.
 */
export function mapQuery(w: ElementWriter, prefix: string, perPage: number | undefined): void {
  const k = (name: string): string => prefix + name;
  let postType = getStr(w, k('post_type')) || 'post';
  if (PRODUCT_SOURCES.includes(postType)) {
    w.note(`The "${postType}" product source is not available in Zadex; all products are queried.`);
    w.status('partial');
    postType = 'product';
  }
  if (postType === 'related_products') postType = 'related';
  if (postType === 'by_id') {
    w.set('query_source', 'manual');
    w.set('query_ids', list(w.raw(k('posts_ids'))).join(', '));
  } else if (postType === 'current_query') {
    w.set('query_source', 'current');
  } else if (postType === 'related') {
    w.set('query_source', 'related');
    const tax = list(w.raw(k('related_taxonomies')));
    if (tax.length) w.set('query_related_by', tax[0]);
    if (tax.length > 1) w.note('Related posts by several taxonomies: Zadex uses the first one.');
    const fb = getStr(w, k('related_fallback'));
    if (fb !== '' && fb !== 'fallback_none') w.note('The related posts fallback is not available in Zadex.');
    w.consume(k('fallback_ids'));
  } else {
    w.set('query_source', 'post_type');
    w.set('query_post_type', postType);
  }
  if (postType !== 'by_id') w.consume(k('posts_ids'));
  if (postType !== 'related') w.consume(k('related_taxonomies'), k('related_fallback'), k('fallback_ids'));

  // Include / exclude (not shown by Pro for manual selection / current query).
  const include = list(w.raw(k('include')));
  const exclude = list(w.raw(k('exclude')));
  const incTerms = list(w.raw(k('include_term_ids')));
  const excTerms = list(w.raw(k('exclude_term_ids')));
  const incAuthors = list(w.raw(k('include_authors')));
  const excAuthors = list(w.raw(k('exclude_authors')));
  const excIds = list(w.raw(k('exclude_ids')));
  if (postType !== 'by_id' && postType !== 'current_query') {
    const related = postType === 'related';
    if (!related && include.includes('terms') && incTerms.length) w.set('query_terms', incTerms.join(', '));
    if (!related && include.includes('authors') && incAuthors.length) w.set('query_authors', incAuthors.join(', '));
    if (exclude.includes('terms') && excTerms.length) w.set('query_exclude_terms', excTerms.join(', '));
    if (!related && exclude.includes('authors') && excAuthors.length) w.set('query_exclude_authors', excAuthors.join(', '));
    if (exclude.includes('manual_selection') && excIds.length) w.set('query_exclude_ids', excIds.join(', '));
    if ((!related && include.includes('terms') && incTerms.length) || (exclude.includes('terms') && excTerms.length)) {
      // Elementor stores bare term ids of any taxonomy; Zadex matches bare ids against `query_taxonomy` (category).
      w.note('Term ids were kept as category terms; terms of other taxonomies need a "taxonomy:id" prefix in the Zadex query.');
    }
    // Pro's `exclude` has no default: the current post is excluded only when chosen (Zadex defaults to excluding it).
    w.set('query_exclude_current', exclude.includes('current_post'));
  } else w.set('query_exclude_current', false);
  const plain = postType !== 'by_id' && postType !== 'current_query' && postType !== 'related';
  if (plain && bool(w.raw(k('avoid_duplicates')))) w.set('query_avoid_duplicates', true);

  // Date.
  if (postType !== 'by_id' && postType !== 'current_query') {
    const date = getStr(w, k('select_date')) || 'anytime';
    if (date in DATES) {
      if (DATES[date] !== 'any') w.set('query_date', DATES[date]);
      if (date === 'exact') {
        const after = w.raw(k('date_after'));
        const before = w.raw(k('date_before'));
        if (typeof after === 'string' && after) w.set('query_date_after', after.slice(0, 10));
        if (typeof before === 'string' && before) w.set('query_date_before', before.slice(0, 10));
      } else w.consume(k('date_after'), k('date_before'));
    } else {
      w.note(`Date range "${date}" is not available in Zadex; all dates are shown.`);
      w.status('partial');
      w.consume(k('date_after'), k('date_before'));
    }
  } else w.consume(k('select_date'), k('date_after'), k('date_before'));

  // Order (Pro hides it for the current query).
  if (postType !== 'current_query') {
    const orderby = getStr(w, k('orderby')) || 'post_date';
    if (ORDERBY[orderby]) w.set('query_orderby', ORDERBY[orderby]);
    else w.note(`Order by "${orderby}" is not available in Zadex; posts are ordered by date.`);
    w.set('query_order', getStr(w, k('order')).toUpperCase() === 'ASC' ? 'ASC' : 'DESC');
  } else w.consume(k('orderby'), k('order'));
  const offset = plain ? toInt(w.get(k('offset'))) : undefined;
  if (offset) w.set('query_offset', Math.min(100, offset));
  else w.consume(k('offset'));
  if (perPage !== undefined) w.set('query_per_page', Math.min(100, Math.max(1, perPage)));
  // `ignore_sticky_posts` (default yes) only applies to the `post` post type in Pro.
  if (postType === 'post') w.set('query_ignore_sticky', getBool(w, k('ignore_sticky_posts')));
  else w.consume(k('ignore_sticky_posts'));
  const queryId = w.raw(k('query_id'));
  if (!isBlank(queryId)) {
    w.note(`The custom query id "${String(queryId)}" (a PHP filter hook in Elementor) is not carried over.`);
    w.status('partial');
  }
  w.consume(k('query_args'), k('related_query_args'));
}

/** Elementor `left|right|start|end|center` -> Zadex flex alignment. */
export function flexOf(v: unknown, rtl: boolean): string | undefined {
  const t: Record<string, string> = {
    left: rtl ? 'flex-end' : 'flex-start',
    right: rtl ? 'flex-start' : 'flex-end',
    start: 'flex-start',
    end: 'flex-end',
    center: 'center',
    'flex-start': 'flex-start',
    'flex-end': 'flex-end',
  };
  return t[String(v ?? '')];
}

/** Zadex border value from a width (slider or dimensions) + color; undefined when no width is set. */
export function borderFrom(width: unknown, color: string | undefined, style = 'solid'): Obj | undefined {
  const d = sliderOrDims(width);
  if (!d) return undefined;
  const out: Obj = { style, width: d };
  if (color) out.color = color;
  return out;
}
