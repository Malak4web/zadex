import { registerWidget } from '../registry';
import { flexAlign, textAlign } from '../align';
import { isObj, only, single, unitless, withGlobalDefaults } from './_shared';
import { dynamicValue } from '../dynamic';

/** WordPress image sizes Zadex offers (`thumbnail|medium|large|full`); others map to the closest one. */
export const IMAGE_SIZES: Record<string, string> = {
  thumbnail: 'thumbnail',
  medium: 'medium',
  medium_large: 'large',
  large: 'large',
  '1536x1536': 'full',
  '2048x2048': 'full',
  full: 'full',
  custom: 'full',
};

const OBJECT_FIT: Record<string, string> = { fill: 'fill', cover: 'cover', contain: 'contain', 'scale-down': 'contain' };

/** True for Elementor's placeholder image (a widget dropped without choosing an image). */
export function isPlaceholder(v: unknown): boolean {
  return isObj(v) && !Number(v.id) && typeof v.url === 'string' && /\/placeholder\.png$/.test(v.url);
}

/** Elementor `image` -> Zadex `image`. */
registerWidget('image', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    text_color: 'globals/colors?id=text',
    caption_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'image');
  const raw = w.get('image');
  const media = isPlaceholder(raw) ? undefined : ctx.media(raw);
  // Dynamic tag (src/convert/dynamic.ts): becomes a Zadex dynamic value when the tag has an image equivalent.
  const dynRef = w.dynamicRef('image');
  const dyn = dynRef ? dynamicValue(dynRef, 'image') : undefined;
  if (dyn) {
    w.set('image', dyn.value);
    w.consumeDynamic('image');
    if (dyn.note) w.note(dyn.note);
  } else if (media) w.set('image', media);
  else w.note('No image was selected in Elementor.');
  if (dynRef && !dyn) w.note('The image was bound to a dynamic tag; the static image was kept.');

  const size = String(w.get('image_size') ?? 'large');
  w.set('size', IMAGE_SIZES[size] ?? 'large');
  if (size === 'custom') {
    const dim = w.raw('image_custom_dimension');
    const d = isObj(dim) ? `${String(dim.width ?? '')}x${String(dim.height ?? '')}` : '';
    w.note(`Custom image dimensions (${d}) are not supported; the full size is used (set a width / height instead).`);
  } else w.consume('image_custom_dimension');

  // Elementor centers images by default (`.elementor-widget-image { text-align: center }`).
  const align = only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']);
  if (!w.has('align')) w.set('align', 'center');
  w.map('align', 'align', align);

  const captionSource = String(w.get('caption_source') ?? 'none');
  w.set('caption_source', ['none', 'attachment', 'custom'].includes(captionSource) ? captionSource : 'none');
  if (captionSource === 'custom') w.set('caption', String(w.get('caption') ?? ''));
  else w.consume('caption');

  const linkTo = String(w.get('link_to') ?? 'none');
  w.set('link_to', ['none', 'file', 'custom'].includes(linkTo) ? linkTo : 'none');
  if (linkTo === 'custom') w.url('link', 'link');
  else w.consume('link');
  const lightbox = w.get('open_lightbox');
  if (linkTo === 'file') w.set('lightbox', lightbox !== 'no');

  w.slider('width', 'width');
  w.slider('space', 'max_width');
  w.slider('height', 'height');
  w.map('object-fit', 'object_fit', OBJECT_FIT);
  if (w.raw('object-fit') === 'scale-down') w.note('Object fit "scale-down" is approximated with "contain".');
  const pos = w.get('object-position');
  if (typeof pos === 'string' && pos !== '' && pos !== 'center center') w.note(`Object position "${pos}" is not carried over (Zadex centers the image).`);
  w.consumeResponsive('object-position');

  single(w, 'opacity', 'opacity', unitless);
  single(w, 'opacity_hover', 'opacity', unitless, 'hover');
  w.border('image_border', 'border', 'image_border_radius');
  w.boxShadow('image_box_shadow', 'box_shadow');
  const transition = unitless(w.raw('background_hover_transition')); // seconds
  if (transition) w.set('transition', transition);

  w.map('caption_align', 'caption_align', only(textAlign(ctx), ['left', 'center', 'right']));
  w.color('text_color', 'caption_color');
  w.typography('caption_typography', 'caption_typography');
  w.slider('caption_space', 'caption_spacing');

  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex image.`);
  if (w.has('css_filters_css_filter') || w.has('css_filters_hover_css_filter')) {
    w.note('CSS filters (blur, brightness, contrast, saturation, hue) are not available on the Zadex image.');
  }
  return w.finish();
});
