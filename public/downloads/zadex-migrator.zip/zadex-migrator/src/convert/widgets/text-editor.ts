import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { bool } from '../values';
import { toNumber, withGlobalDefaults } from './_shared';

const BLOCK_TAG = /<(p|div|h[1-6]|ul|ol|li|table|blockquote|pre|figure|section|article|hr|dl|address)[\s>/]/i;

/**
 * Elementor runs `wpautop` on the editor content when it renders; content saved without paragraphs (plain text
 * with line breaks) gets them here so it looks the same in Zadex (whose richtext is printed as is).
 */
export function autop(html: string): string {
  const text = html.replace(/\r\n?/g, '\n').trim();
  if (text === '' || BLOCK_TAG.test(text)) return text;
  return text
    .split(/\n\s*\n/)
    .map((p) => `<p>${p.trim().replace(/\n/g, '<br>\n')}</p>`)
    .join('\n');
}

/** Elementor `text-editor` -> Zadex `text`. */
registerWidget('text-editor', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    text_color: 'globals/colors?id=text',
    typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'text');
  const content = autop(String(w.get('editor') ?? ''));
  w.set('content', content);
  if (w.dynamicRef('editor')) w.note('The text was bound to a dynamic tag; the static text was kept.');
  if (/\[[a-z][\w-]*[\s\]]/i.test(content)) w.note('The text contains shortcodes; Zadex prints rich text as is, use a Shortcode widget for them.');

  const dropCap = bool(w.get('drop_cap'));
  if (dropCap) w.set('drop_cap', true);
  const capStyles = Object.keys(el.settings ?? {}).filter((k) => k.startsWith('drop_cap_') && w.has(k));
  w.consume('drop_cap_*');
  if (dropCap && capStyles.length) {
    w.note(`Drop cap styles (${capStyles.join(', ')}) are not carried over; the Zadex drop cap style is used.`);
    w.status('partial');
  }
  w.responsive('text_columns', 'columns', (v) => toNumber(v));
  w.slider('column_gap', 'column_gap');
  w.map('align', 'align', textAlign(ctx));
  w.color('text_color', 'color');
  w.color('link_color', 'link_color');
  w.color('link_hover_color', 'link_color', 'hover');
  w.consume('link_hover_color_transition_duration');
  w.typography('typography', 'typography');
  w.slider('paragraph_spacing', 'paragraph_spacing');
  w.textShadow('text_shadow', 'text_shadow');
  return w.finish();
});
