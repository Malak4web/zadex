import { registerWidget } from '../registry';
import type { ElementWriter } from '../context';
import { colorRef } from '../globals';
import { dimensions, isBlank, num, slider } from '../values';
import { iconValue, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { isObj, noteDeviceValues, pbool, pstr } from './_pro-site';

/**
 * Elementor Pro search widgets, verified against Elementor Pro 3.33.2 (elementor-pro-controls.json,
 * modules/theme-elements/widgets/search-form.php, modules/search/widgets/search.php).
 *  - `search-form` ("Search Form"): skin classic | minimal | full_screen -> Zadex `search-form`.
 *  - `search` ("Search", 3.2x+): a search form whose optional live results render a Loop template
 *    (`live_results` + `template_id`) -> Zadex `search` (instant results, own result list) when live results are on
 *    with a template, else Zadex `search-form` (both submit to the WordPress search page).
 */

function colorOf(w: ElementWriter, key: string): string | undefined {
  const ref = w.globalRef(key);
  const v = w.raw(key);
  if (ref?.kind === 'colors') return colorRef(w.ctx, ref.id);
  return typeof v === 'string' && v !== '' ? v : undefined;
}

/** A stored slider with a size (empty Elementor sliders are `{unit, size: ''}`). */
function hasSize(v: unknown): boolean {
  return isObj(v) && !isBlank(v.size);
}

/* ---------------- search-form ---------------- */

/**
 * Search form input border: "Border Size" is the dimensions control `button_border_width` (sic, applies to the
 * container), color `input_border_color`, radius the `border_radius` slider (Pro default 3px).
 */
function searchFormBorder(w: ElementWriter): void {
  const width = dimensions(w.raw('button_border_width'));
  const color = colorOf(w, 'input_border_color');
  const radius = slider(w.get('border_radius'));
  noteDeviceValues(w, 'button_border_width', 'Input border size');
  noteDeviceValues(w, 'border_radius', 'Input border radius');
  const b: Record<string, unknown> = {};
  if (width) {
    const any = [width.top, width.right, width.bottom, width.left].some((v) => Number(v) > 0);
    b.style = any ? 'solid' : 'none';
    b.width = width;
  }
  if (color) {
    b.style ??= 'solid';
    b.color = color;
  }
  if (radius && typeof radius.size === 'number') b.radius = { top: radius.size, right: radius.size, bottom: radius.size, left: radius.size, unit: radius.unit, linked: true };
  if (Object.keys(b).length) w.set('input_border', b);
}

registerWidget('search-form', (source, ctx) => {
  // Pro's global defaults (search-form.php `global` args).
  const el = withGlobalDefaults(source, ctx, {
    input_typography_typography: 'globals/typography?id=text',
    input_text_color: 'globals/colors?id=text',
    button_typography_typography: 'globals/typography?id=text',
    button_background_color: 'globals/colors?id=secondary',
  });
  const w = ctx.writer(el, 'search-form');
  markPro(w);
  const skin = pstr(w, 'skin', 'classic');
  const buttonType = pstr(w, 'button_type', 'icon');
  w.set('placeholder', pstr(w, 'placeholder', 'Search...'));
  w.set('button_text', pstr(w, 'button_text', 'Search'));
  if (skin === 'full_screen') w.set('layout', 'fullscreen');
  else if (skin === 'minimal') {
    w.set('layout', 'icon');
    w.note('The minimal skin (icon inside the input) is shown with an icon button in Zadex.');
  } else w.set('layout', buttonType === 'text' ? 'button' : 'icon');
  // `icon`: search (default) | arrow.
  if (skin === 'classic' && buttonType === 'icon' && pstr(w, 'icon', 'search') === 'arrow') w.note('The arrow button icon is shown as a search icon.');
  w.consume('icon');

  // Input height: `size` slider (default 50px; inactive on the full screen skin).
  if (skin !== 'full_screen') {
    const s = slider(w.get('size'));
    if (s && s.unit === 'px') w.set('input_height', s);
    noteDeviceValues(w, 'size', 'Input height');
  } else w.consumeResponsive('size');

  w.typography('input_typography', 'input_typography');
  w.color('input_text_color', 'input_color');
  w.color('input_background_color', 'input_bg');
  searchFormBorder(w);
  for (const k of ['input_text_color_focus', 'input_background_color_focus', 'input_border_color_focus']) {
    if (w.has(k)) w.note('Focus colors of the search input are not supported by the Zadex search form.');
    w.raw(k);
  }
  if (w.raw('input_box_shadow_box_shadow_type') === 'yes' || w.raw('input_box_shadow_focus_box_shadow_type') === 'yes') w.note('The input box shadow is not supported by the Zadex search form.');
  w.consume('input_box_shadow_*');
  w.typography('button_typography', 'button_typography');
  w.color('button_text_color', 'button_color');
  w.color('button_background_color', 'button_bg');
  w.color('button_text_color_hover', 'button_color_hover');
  w.color('button_background_color_hover', 'button_bg_hover');
  if (hasSize(w.raw('button_width'))) w.note('The button width is not carried over.');
  w.consumeResponsive('button_width');

  // Icon sizes: classic button icon `icon_size`, minimal `icon_size_minimal`, full screen toggle `toggle_icon_size`.
  const iconKey = skin === 'minimal' ? 'icon_size_minimal' : skin === 'full_screen' ? 'toggle_icon_size' : 'icon_size';
  const is = slider(w.raw(iconKey));
  if (is && is.unit === 'px' && typeof is.size === 'number') w.set('icon_size', is);
  w.consumeResponsive('icon_size');
  w.consumeResponsive('icon_size_minimal');
  w.consumeResponsive('toggle_icon_size');

  if (skin === 'full_screen') {
    w.color('toggle_color', 'button_color');
    w.color('toggle_color_hover', 'button_color_hover');
    w.color('toggle_background_color', 'button_bg');
    w.color('toggle_background_color_hover', 'button_bg_hover');
    w.color('overlay_background_color', 'overlay_bg');
    for (const k of ['toggle_border_width', 'toggle_border_radius', 'toggle_size', 'toggle_align']) {
      const v = w.raw(k);
      if (k === 'toggle_align' ? !isBlank(v) && v !== 'center' : hasSize(v)) w.note(`Full-screen toggle "${k}" is not supported by the Zadex search form.`);
      w.consumeResponsive(k);
    }
  } else w.consume('toggle_*', 'overlay_background_color');
  return w.finish();
});

/* ---------------- search (3.2x+) ---------------- */

/** `search_query_post_type` (any | post | page | product | e-floating-buttons) -> Zadex post types. */
function postTypes(w: ElementWriter): string[] {
  const t = pstr(w, 'search_query_post_type', 'any');
  if (t === 'any') return [];
  if (['post', 'page', 'product'].includes(t)) return [t];
  w.note(`Search results limited to "${t}" are not available in Zadex; all content types are searched.`);
  return [];
}

registerWidget('search', (source, ctx) => {
  // Live results need a Loop template; without one Elementor shows no results dropdown.
  const s0 = source.settings ?? {};
  const live = s0.live_results === 'yes' && !isBlank(s0.template_id);
  const w = ctx.writer(source, live ? 'search' : 'search-form');
  markPro(w);
  w.consume('live_results', 'template_id');
  if (live) w.note('The Elementor Loop template of the live results is not used; Zadex shows its own result list (title, type, thumbnail).');

  w.set('placeholder', pstr(w, 'search_input_placeholder_text', 'Type to start searching...'));
  // Submit button: hidden when the search is triggered by the Enter key only; text (default "Search") and/or icon.
  const trigger = pstr(w, 'submit_trigger', 'click_submit');
  const text = trigger === 'key_enter' ? '' : pstr(w, 'submit_button_text', '');
  const icon = trigger === 'key_enter' ? undefined : iconValue(w, 'icon_submit', true);
  w.consume('submit_button_text', 'icon_submit', 'icon_submit_position');
  if (text) w.set('button_text', text);
  if (text && icon) w.note('The submit button shows its text only (Zadex buttons have text or an icon).');

  if (live) {
    w.set('button', trigger === 'key_enter' ? 'none' : text ? 'text' : 'icon');
    const limit = num(w.get('number_of_items'));
    if (typeof limit === 'number' && limit > 0) w.set('limit', Math.min(20, Math.round(limit)));
    const min = num(w.get('minimum_search_characters'));
    if (typeof min === 'number' && min >= 0) w.set('min_chars', Math.round(min));
    w.set('post_types', postTypes(w));
    if (!pbool(w, 'enable_nothing_found_message')) w.note('The "nothing found" message cannot be hidden in Zadex.');
    else {
      const msg = pstr(w, 'nothing_found_message_text', '');
      if (msg) w.set('no_results_text', msg);
    }
    const cols = num(w.raw('number_of_columns'));
    if (typeof cols === 'number' && cols > 1) w.note('Live results in columns are shown as one list in Zadex.');
    w.consume('nothing_found_message_html_tag', 'equal_height', 'enable_loader');
    // Results box.
    w.color('results_background_color', 'results_bg');
    w.consume('results_background_*');
    w.border('results_border_type', 'results_border', 'results_border_radius');
    for (const k of Object.keys(w.settings)) if (k.startsWith('results_border@')) delete w.settings[k];
    w.boxShadow('results_box_shadow', 'results_shadow');
    w.slider('results_max_height', 'results_max_height');
  } else {
    if (trigger === 'key_enter') w.note('The search had no submit button (Enter key only); Zadex shows an icon button.');
    w.set('layout', text ? 'button' : 'icon');
    const types = postTypes(w);
    if (types.length) w.set('post_type', types[0]);
    w.consume('minimum_search_characters', 'number_of_items', 'number_of_columns', 'equal_height', 'enable_loader', 'enable_nothing_found_message', 'nothing_found_message_*', 'results_*');
  }
  if (!isBlank(w.raw('icon_search'))) w.note('The search icon inside the input is not available in Zadex.');
  w.consume('icon_clear', 'autocomplete');
  for (const k of ['search_query_include', 'search_query_exclude', 'search_query_posts_ids']) {
    if (w.has(k)) w.note('Search query filters (include / exclude) are not available in Zadex.');
  }
  const date = w.raw('search_query_select_date');
  if (!isBlank(date) && date !== 'anytime') w.note('The search date filter is not available in Zadex.');
  w.consume('search_query_*', 'pagination_*', 'page_limit_settings');

  // Input (background / border groups: `search_field_background_normal_*`, `search_field_border_normal_*`).
  w.typography('search_field_typography', 'input_typography');
  w.color('search_field_input_text_color_normal', 'input_color');
  w.color('search_field_background_normal_color', 'input_bg');
  w.consume('search_field_background_normal_*');
  w.border('search_field_border_normal', 'input_border', 'search_field_border_radius');
  for (const k of Object.keys(w.settings)) if (k.startsWith('input_border@')) delete w.settings[k];
  for (const k of ['placeholder_color', 'search_field_input_text_color_focus', 'search_field_background_focus_color', 'search_field_border_focus_border']) {
    if (w.has(k)) w.note('Placeholder and focus styles of the search input are not supported by Zadex.');
    w.raw(k);
  }
  w.consume('search_field_background_focus_*', 'search_field_border_focus_*');
  // Submit button (background groups `submit_background_normal_*` / `submit_background_hover_*`).
  w.typography('submit_typography', 'button_typography');
  w.color('submit_text_color_normal', 'button_color');
  w.color('submit_background_normal_color', 'button_bg');
  w.color('submit_text_color_hover', 'button_color_hover');
  w.color('submit_background_hover_color', 'button_bg_hover');
  w.consume('submit_background_normal_*', 'submit_background_hover_*');
  return w.finish();
});
