import { registerWidget } from '../registry';
import { bool, slider } from '../values';
import { iconValue, single } from './_shared';

const TYPES = ['info', 'success', 'warning', 'danger'];

/** Elementor `alert` -> Zadex `alert`. */
registerWidget('alert', (el, ctx) => {
  const w = ctx.writer(el, 'alert');
  const type = String(w.get('alert_type') ?? 'info');
  w.set('type', TYPES.includes(type) ? type : 'info');
  w.set('title', String(w.get('alert_title') ?? ''));
  w.set('description', String(w.get('alert_description') ?? ''));
  if (w.dynamicRef('alert_title') || w.dynamicRef('alert_description')) w.note('Dynamic tags on the texts were replaced by their static text.');
  const dismiss = bool(w.get('show_dismiss'));
  w.set('dismiss', dismiss);
  if (dismiss && iconValue(w, 'dismiss_icon', true)) w.note('The custom dismiss icon is not carried over (Zadex uses its own close icon).');
  w.consume('dismiss_icon');

  w.color('background', 'bg_color');
  w.color('border_color', 'border_color');
  single(w, 'border_left-width', 'accent_width', (v) => slider(v));
  w.color('title_color', 'title_color');
  w.typography('alert_title', 'title_typography');
  w.color('description_color', 'desc_color');
  w.typography('alert_description', 'desc_typography');
  if (dismiss) {
    w.color('dismiss_icon_normal_color', 'dismiss_color');
    w.color('dismiss_icon_hover_color', 'dismiss_color', 'hover');
  }
  w.consume('dismiss_icon_hover_transition_duration');
  return w.finish();
});
