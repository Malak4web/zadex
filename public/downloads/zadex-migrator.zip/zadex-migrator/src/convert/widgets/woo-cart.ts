import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { wooLabels, wooPageStyles } from './_woo-shop';
import { noteIfSet } from './_woo-product';
import { wooGuard } from './_woo';

/**
 * Elementor Pro `woocommerce-cart` -> Zadex `cart` (WooCommerce's cart, same as Elementor). Verified against
 * Elementor Pro 3.33.2: `cart_layout` two-column (default) | one-column, `sticky_right_column` (+ offset),
 * `update_cart_automatically`, `section_coupon_display` (yes), `additional_template_switch` / `_select`, texts
 * `update_cart_button_text`, `apply_coupon_button_text`, `totals_section_title`, `update_shipping_button_text`,
 * `checkout_button_text` (+ alignments), the shared style section (`wooPageStyles`), the cart's own checkout button
 * styles (`checkout_button_*`) and the per-section "customize" styles (dropped, reported).
 */
registerWidget('woocommerce-cart', (source, ctx) => {
  const off = wooGuard(source, ctx, 'cart');
  if (off) return off;
  const w = ctx.writer(source, 'cart');
  markPro(w);
  const layout = String(w.get('cart_layout') || 'two-column');
  w.set('layout', layout === 'one-column' ? 'stacked' : 'columns');
  if (w.get('sticky_right_column') === 'yes') w.note('The sticky right column is not available in Zadex.');
  w.consume('sticky_right_column_offset');
  if (w.get('update_cart_automatically') === 'yes') w.note('Updating the cart automatically is not available in Zadex; the Update cart button is shown.');
  if (w.get('section_coupon_display') !== 'yes') {
    w.note('Hiding the coupon form is not available in Zadex.');
    w.status('partial');
  }
  if (w.get('additional_template_switch') === 'active' || w.raw('additional_template_select')) {
    w.note('The additional template below the cart is not carried over.');
    w.status('partial');
  }
  wooLabels(w, ['update_cart_button_text', 'apply_coupon_button_text', 'totals_section_title', 'update_shipping_button_text', 'checkout_button_text']);
  noteIfSet(
    w,
    ['update_cart_button_alignment', 'apply_coupon_button_alignment', 'totals_section_title_alignment', 'update_shipping_button_alignment', 'checkout_button_alignment'],
    'Button / title alignments are not carried over.',
  );
  wooPageStyles(w);
  noteIfSet(
    w,
    ['checkout_button_normal_text_color', 'checkout_button_hover_text_color', 'checkout_button_normal_background_*', 'checkout_button_hover_background_*', 'checkout_button_border_*', 'checkout_button_hover_border_color', 'checkout_button_padding', 'checkout_button_typography_*', 'checkout_button_text_shadow_*', 'checkout_button_hover_transition_duration', 'checkout_button_hover_animation'],
    'The "Proceed to checkout" button styles are not carried over separately; Zadex styles every button alike.',
  );
  return w.finish();
});
