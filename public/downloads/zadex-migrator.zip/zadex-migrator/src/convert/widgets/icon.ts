import { registerWidget } from '../registry';
import { textAlign } from '../align';
import type { ElementWriter } from '../context';
import { slider } from '../values';
import { dimsToSlider, iconValue, only, single, withGlobalDefaults } from './_shared';

export interface IconTargets {
  color: string;
  bg: string;
  border: string;
}

/**
 * Elementor icon colors depend on the view: default -> primary is the glyph color; stacked -> primary is the
 * background and secondary the glyph; framed -> primary is the glyph + border, secondary the background.
 * `prefix` is '' for icon / icon-box (`primary_color`, `hover_primary_color` …).
 */
export function iconColors(w: ElementWriter, view: string, t: IconTargets): void {
  const pairs: Array<[string, string, 'hover' | undefined]> = [
    ['primary_color', 'secondary_color', undefined],
    ['hover_primary_color', 'hover_secondary_color', 'hover'],
  ];
  for (const [primary, secondary, state] of pairs) {
    if (view === 'stacked') {
      w.color(primary, t.bg, state);
      w.color(secondary, t.color, state);
    } else if (view === 'framed') {
      w.color(primary, t.color, state);
      w.color(primary, t.border, state);
      w.color(secondary, t.bg, state);
    } else {
      w.color(primary, t.color, state);
      w.consume(secondary);
    }
  }
}

/** Elementor `shape` (square | rounded | circle) -> Zadex `shape` (circle | square) + radius for "rounded". */
export function iconShape(w: ElementWriter, shape: string, radiusKey: string, zadexRadius: string): void {
  w.set('shape', shape === 'circle' ? 'circle' : 'square');
  const radius = dimsToSlider(w.raw(radiusKey));
  if (radius) {
    if (radius.uneven) w.note('Icon border radius: different values per corner are not supported; one value was kept.');
    w.set(zadexRadius, radius.value);
  } else if (shape === 'rounded') {
    w.set(zadexRadius, { size: 10, unit: '%' }); // Elementor: .elementor-shape-rounded .elementor-icon { border-radius: 10% }
  }
  if (radius && shape === 'circle') w.set('shape', 'square'); // Zadex only applies a custom radius to square icons.
}

/** Elementor `icon` -> Zadex `icon`. */
registerWidget('icon', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, { primary_color: 'globals/colors?id=primary' });
  const w = ctx.writer(el, 'icon');
  const ic = iconValue(w, 'selected_icon');
  w.set('icon', ic ?? { library: '', value: '' });
  const view = String(w.get('view') ?? 'default');
  w.set('view', ['default', 'stacked', 'framed'].includes(view) ? view : 'default');
  if (view !== 'default') iconShape(w, String(w.get('shape') ?? 'circle'), 'border_radius', 'border_radius');
  else w.consume('shape', 'border_radius');
  w.url('link', 'link');
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));

  iconColors(w, view, { color: 'color', bg: 'bg_color', border: 'border_color' });
  w.slider('size', 'size');
  if (w.has('fit_to_size')) {
    w.consume('fit_to_size');
    w.note('"Fit to size" for SVG icons is not carried over.');
  }
  w.slider('icon_padding', 'padding');
  single(w, 'rotate', 'rotate', (v) => slider(v, 'deg'));
  const bw = dimsToSlider(w.raw('border_width'));
  if (bw) {
    if (bw.uneven) w.note('Icon border width: different values per side are not supported; one value was kept.');
    w.set('border_width', bw.value);
  }
  w.consumeResponsive('border_width');
  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex icon.`);
  return w.finish();
});
