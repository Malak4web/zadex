import { getMapper, registerWidget } from '../registry';
import type { ConvertContext } from '../context';
import type { ElElement, ZElement } from '../types';
import { isBlank } from '../values';
import { PRO_NOTE, markPro } from './_pro';
import { toInt } from './_pro-posts';
import { wooGuard } from './_woo';
import { WOO_PROBE } from './_woo-shop';
import { typographyAlt } from './_marketing';

/**
 * Elementor Pro `wc-add-to-cart` (an Elementor button that adds a chosen product to the cart). Verified against
 * Elementor Pro 3.33.2 (`Add_To_Cart` extends the classic button widget, `link` hidden): `product_id`, `show_quantity`
 * (''), `quantity` (1), `layout` ('' | stacked | auto, with the quantity field), plus every button control, with Pro's
 * defaults `text` "Add to Cart", `size` sm and `selected_icon` `fas fa-shopping-cart`.
 *
 * - A chosen product -> Zadex `button` (all button settings converted by the `button` mapper) linking to
 *   WooCommerce's `?add-to-cart=<id>&quantity=<n>` URL. That adds simple products without JavaScript; variable
 *   products redirect to their page. The quantity field is not available on a button (noted).
 * - No product -> Zadex `add-to-cart` (the current product's form, e.g. in a product template) with the button
 *   styles copied onto its `button_*` controls.
 */
registerWidget('wc-add-to-cart', (source, ctx) => {
  const off = wooGuard(source, ctx, ['add-to-cart', WOO_PROBE]);
  if (off) return off;
  const settings = { ...(source.settings ?? {}) };
  const productId = toInt(settings.product_id);
  const showQty = settings.show_quantity === 'yes';
  const qty = toInt(settings.quantity) ?? 1;

  if (productId === undefined) return currentProduct(source, ctx, showQty);

  delete settings.product_id;
  delete settings.show_quantity;
  delete settings.quantity;
  if (settings.text === undefined) settings.text = 'Add to Cart';
  if (settings.selected_icon === undefined) settings.selected_icon = { value: 'fas fa-shopping-cart', library: 'fa-solid' };
  settings.link = { url: `?add-to-cart=${productId}${qty > 1 ? `&quantity=${qty}` : ''}`, is_external: '', nofollow: '' };
  const button = getMapper('widget:button');
  if (!button) return currentProduct(source, ctx, showQty);
  const asButton: ElElement = { ...source, widgetType: 'button', settings };
  const out = button(asButton, ctx);
  const entry = [...ctx.report.entries].reverse().find((e) => e.source === source.id);
  if (entry) {
    entry.sourceType = 'wc-add-to-cart';
    entry.notes.push(
      `The button links to WooCommerce's add-to-cart URL for product ${productId}${qty > 1 ? ` (quantity ${qty})` : ''}; variable products open their product page.`,
      PRO_NOTE,
    );
    if (showQty) {
      entry.notes.push('The quantity field is not available on a Zadex button.');
      entry.status = 'partial';
    }
  }
  return out as ZElement | ZElement[] | null;
});

/** No chosen product: Zadex `add-to-cart` of the current product, Elementor button styles -> `button_*`. */
function currentProduct(source: ElElement, ctx: ConvertContext, showQty: boolean): ZElement {
  const w = ctx.writer(source, 'add-to-cart');
  markPro(w);
  w.raw('product_id');
  w.note('No product was chosen: the Zadex Add to cart widget shows the current product\'s form (use it in a product template).');
  w.status('partial');
  w.set('show_quantity', showQty);
  w.raw('show_quantity');
  if (!isBlank(w.raw('quantity'))) w.note('The default quantity is not available in Zadex.');
  const text = w.get('text');
  if (typeof text === 'string' && text !== '') w.set('button_text', text);
  if (showQty) w.set('layout', w.get('layout') === 'stacked' ? 'stacked' : 'inline');
  else w.consume('layout');
  typographyAlt(w, ['typography'], 'button_typography');
  w.color('button_text_color', 'button_color');
  w.color('hover_color', 'button_color', 'hover');
  w.color('background_color', 'button_bg');
  w.color('button_background_hover_color', 'button_bg', 'hover');
  w.consume('background_background', 'button_background_hover_background');
  w.border('border', 'button_border', 'border_radius');
  const hover = w.raw('button_hover_border_color');
  if (typeof hover === 'string' && hover !== '') w.set('button_border', { color: hover }, { state: 'hover' });
  w.dimensions('text_padding', 'button_padding');
  w.consume('view'); // icon, size preset, alignment, hover animation: no Zadex equivalent, reported as dropped
  return w.finish();
}
