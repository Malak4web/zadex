import { registerWidget } from '../registry';
import type { ConvertContext } from '../context';
import { deviceKeys } from '../responsive';
import { dimensions, icon, isBlank, slider, url } from '../values';
import { markPro, firstOf } from './_pro';
import { proNumber, proText, proVal, wysiwygToTextarea } from './_pro-content';
import { desktopOnly, isObj, itemIdFor, repeaterItems } from './_shared';

/** Elementor `hotspot_animation` (CSS class) -> Zadex animation. */
const ANIMATIONS: Record<string, string> = { 'e-hotspot--soft-beat': 'pulse', 'e-hotspot--expand': 'ripple', 'e-hotspot--overlay': 'ripple', '': 'none' };

/** Physical Elementor tooltip side -> logical Zadex position. */
function tooltipSide(ctx: ConvertContext, v: unknown): string {
  const rtl = Boolean(ctx.source.rtl);
  switch (String(v ?? 'top')) {
    case 'bottom':
      return 'bottom';
    case 'left':
      return rtl ? 'end' : 'start';
    case 'right':
      return rtl ? 'start' : 'end';
    default:
      return 'top';
  }
}

const clamp = (n: number) => Math.round(Math.max(0, Math.min(100, n)) * 10) / 10;
const TOOLTIP_DEFAULT = 'Add Your Tooltip Text Here';

/**
 * Elementor Pro `hotspot` -> Zadex `hotspot`. Keys verified against Elementor Pro 3.33.2 (defaults from
 * elementor-defaults.json): `image`, `image_size`, `image_custom_dimension`; repeater `hotspot` {`hotspot_label`,
 * `hotspot_link`, `hotspot_icon`, `hotspot_icon_position` start|end, `hotspot_icon_spacing`, `hotspot_custom_size` +
 * `hotspot_width` / `hotspot_height`, `hotspot_tooltip_content` (wysiwyg, "Add Your Tooltip Text Here"),
 * `hotspot_horizontal` left|right + `hotspot_offset_x` (50%), `hotspot_vertical` top|bottom + `hotspot_offset_y` (50%),
 * `hotspot_tooltip_position` (switch) + `hotspot_position` right|bottom|left|top, `hotspot_tooltip_width`,
 * `hotspot_tooltip_text_wrap`}; `hotspot_animation` e-hotspot--soft-beat|e-hotspot--expand|e-hotspot--overlay|''
 * (expand), `hotspot_sequenced_animation` (+ duration), `tooltip_position` R (top), `tooltip_trigger`
 * mouseenter|click|none R (click), `tooltip_animation` (+ duration); image style `align`, `width`, `space` (max
 * width), `height`, `object-fit`, `opacity` (+ hover), CSS filters, `image_border_*`, `image_border_radius`,
 * `image_box_shadow_*`; hotspot style `style_hotspot_color`, `style_hotspot_size`, `style_typography`,
 * `style_hotspot_width` / `_height`, `style_hotspot_box_color`, `style_hotspot_padding`, `style_hotspot_border_radius`,
 * shadow; tooltip style `style_tooltip_text_color`, `style_tooltip_typography`, `style_tooltip_align`,
 * `style_tooltip_width` (min width), `style_tooltip_max_width`, `style_tooltip_padding`, `style_tooltip_color` (box
 * color), `style_tooltip_border_radius`, shadow.
 */
registerWidget('hotspot', (el, ctx) => {
  const w = ctx.writer(el, 'hotspot');
  markPro(w);

  const image = ctx.media(w.raw('image'));
  w.set('image', image ? { id: image.id, url: image.url, alt: image.alt } : { id: 0, url: '', alt: '' });
  if (!image) w.note('The hotspot image is empty (Elementor showed a placeholder).');
  w.consume('image_size', 'image_custom_dimension');

  const globalSide = tooltipSide(ctx, proVal(w, 'tooltip_position', 'top'));
  if (firstOf(w, 'tooltip_position_tablet', 'tooltip_position_mobile', 'tooltip_trigger_tablet', 'tooltip_trigger_mobile')) {
    w.note('Per-device tooltip position / trigger are not available in Zadex; the desktop values are used.');
  }
  w.consumeResponsive('tooltip_position');
  let labels = false;
  let unsupportedIcons = false;
  let itemExtras = false;
  // Pro's default is one item stored as an empty PHP array (`[[]]`): empty lists count as an item with defaults.
  const rawItems = proVal(w, 'hotspot', [{}]);
  const list = repeaterItems(Array.isArray(rawItems) ? rawItems.map((it) => (Array.isArray(it) && it.length === 0 ? {} : it)) : rawItems);
  const items = list.map((item, i) => {
    const label = typeof item.hotspot_label === 'string' ? item.hotspot_label : '';
    if (label !== '') labels = true;
    const rawIcon = item.hotspot_icon;
    let ic = isObj(rawIcon) ? icon(rawIcon, rawIcon.library === 'svg' ? ctx.svg(rawIcon.value) : undefined) : undefined;
    if (isObj(rawIcon) && rawIcon.value && !ic) unsupportedIcons = true;
    if (!ic) ic = { library: '', value: '' };
    const ox = proNumber(item.hotspot_offset_x) ?? 50;
    const oy = proNumber(item.hotspot_offset_y) ?? 50;
    const x = item.hotspot_horizontal === 'right' ? 100 - ox : ox;
    const y = item.hotspot_vertical === 'bottom' ? 100 - oy : oy;
    const custom = item.hotspot_tooltip_position === 'yes';
    if (item.hotspot_custom_size === 'yes' || item.hotspot_icon_position === 'end' || !isBlank(item.hotspot_tooltip_width) || item.hotspot_tooltip_text_wrap === 'yes') itemExtras = true;
    return {
      _id: itemIdFor(ctx, el, item, i),
      label,
      icon: ic,
      x: clamp(x),
      y: clamp(y),
      tooltip: wysiwygToTextarea(item.hotspot_tooltip_content === undefined ? TOOLTIP_DEFAULT : item.hotspot_tooltip_content),
      link: url(item.hotspot_link) ?? { url: '', target: '', nofollow: false },
      position: custom ? tooltipSide(ctx, item.hotspot_position) : globalSide,
    };
  });
  w.set('hotspots', items);
  w.set('show_label', labels);
  if (unsupportedIcons) w.note('Some hotspot icons use a library Zadex does not ship and were left empty.');
  if (itemExtras) w.note('Per-hotspot custom size, icon after the label, tooltip width and text wrap are not available in Zadex.');

  const trigger = proText(w, 'tooltip_trigger', 'click');
  w.set('trigger', trigger === 'mouseenter' ? 'hover' : 'click');
  if (trigger === 'none') {
    w.note('Always-visible tooltips are not available in Zadex; they open on click.');
    w.status('partial');
  }
  w.consumeResponsive('tooltip_trigger');
  const anim = proText(w, 'hotspot_animation', 'e-hotspot--expand');
  w.set('animation', ANIMATIONS[anim] ?? 'pulse');
  if (anim === 'e-hotspot--overlay') w.note('The "overlay" hotspot animation is approximated with "ripple".');
  if (w.raw('hotspot_sequenced_animation') === 'yes') w.note('Sequenced hotspot entrance is not available in Zadex.');
  const tipAnim = w.raw('tooltip_animation');
  if (typeof tipAnim === 'string' && tipAnim !== '' && tipAnim !== 'e-hotspot--fade-in-out') w.note(`Tooltip animation "${tipAnim}" is not carried over.`);
  w.consume('hotspot_sequenced_animation*', 'tooltip_animation*');

  // Image (Pro's image style controls: `width` %, `space` = max width, `height`).
  w.slider('width', 'image_width', undefined, '%');
  if (!w.has('width')) {
    for (const [key, bp] of deviceKeys('space')) {
      const s = slider(w.raw(key), '%');
      if (s) w.set('image_width', s, { bp });
    }
    if (w.has('space')) w.note('The image max width was used as its width.');
  }
  w.consumeResponsive('space');
  const radius = dimensions(w.raw('image_border_radius'));
  if (radius) w.set('image_radius', radius);
  w.consumeResponsive('image_border_radius');
  if (firstOf(w, 'align', 'height', 'opacity', 'opacity_hover', 'image_border_border', 'object-fit')) w.note('Image alignment, height, opacity and border are not available on the Zadex hotspot.');
  if (w.raw('image_box_shadow_box_shadow_type') === 'yes' || w.raw('css_filters_css_filter') === 'custom') w.note('Image shadow and CSS filters are not available on the Zadex hotspot.');
  w.consume('align*', 'height*', 'object-fit', 'object-position', 'opacity*', 'background_hover_transition', 'image_border_*', 'image_box_shadow*', 'css_filters_*', 'caption_*');

  // Points.
  w.color('style_hotspot_color', 'point_color');
  w.color('style_hotspot_box_color', 'point_bg');
  w.slider('style_hotspot_size', 'point_size');
  w.typography('style_typography', 'label_typography');
  desktopOnly(w, 'label_typography');
  if (firstOf(w, 'style_hotspot_width', 'style_hotspot_height', 'style_hotspot_padding', 'style_hotspot_border_radius', 'style_hotspot_box_shadow_box_shadow_type')) w.note('Hotspot width / height, padding, radius and shadow are not carried over.');
  w.consume('style_hotspot_*');

  // Tooltip.
  w.color('style_tooltip_text_color', 'tooltip_color');
  w.color('style_tooltip_color', 'tooltip_bg');
  w.typography('style_tooltip_typography', 'tooltip_typography');
  desktopOnly(w, 'tooltip_typography');
  for (const [key, bp] of deviceKeys('style_tooltip_width')) {
    const s = slider(w.raw(key));
    if (s) w.set('tooltip_width', { size: s.size, unit: 'px' }, { bp });
  }
  if (firstOf(w, 'style_tooltip_align', 'style_tooltip_max_width', 'style_tooltip_padding', 'style_tooltip_border_radius', 'style_tooltip_box_shadow_box_shadow_type')) w.note('Tooltip alignment, max width, padding, radius and shadow are not carried over.');
  w.consume('style_tooltip_*');
  return w.finish();
});
