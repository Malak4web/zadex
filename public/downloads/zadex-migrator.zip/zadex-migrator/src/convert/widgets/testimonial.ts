import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { url } from '../values';
import { dimsToSlider, only, withGlobalDefaults } from './_shared';
import { isPlaceholder } from './image';

/** Elementor `testimonial` -> Zadex `testimonial`. */
registerWidget('testimonial', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    content_content_color: 'globals/colors?id=text',
    content_typography_typography: 'globals/typography?id=text',
    name_text_color: 'globals/colors?id=primary',
    name_typography_typography: 'globals/typography?id=primary',
    job_text_color: 'globals/colors?id=secondary',
    job_typography_typography: 'globals/typography?id=secondary',
  });
  const w = ctx.writer(el, 'testimonial');
  w.set('content', String(w.get('testimonial_content') ?? ''));
  const raw = w.get('testimonial_image');
  const media = isPlaceholder(raw) ? undefined : ctx.media(raw);
  if (media) w.set('image', media);
  w.consume('testimonial_image_size', 'testimonial_image_custom_dimension');
  w.set('name', String(w.get('testimonial_name') ?? ''));
  w.set('role', String(w.get('testimonial_job') ?? ''));
  for (const k of ['testimonial_content', 'testimonial_name', 'testimonial_job', 'testimonial_image']) {
    if (w.dynamicRef(k)) w.note(`"${k}" was bound to a dynamic tag; the static value was kept.`);
  }
  if (url(w.raw('link'))) w.note('The testimonial link (on the name and image) is not available in Zadex.');
  w.consume('link');

  // Elementor shows the image in the meta row next to the name ("aside") or stacked above the name ("top"),
  // both below the content: Zadex "inside" is that meta row.
  const position = String(w.get('testimonial_image_position') ?? 'aside');
  w.set('image_position', 'inside');
  if (media && position === 'top') w.note('Image position "top" (stacked above the name) is shown beside the name in Zadex.');
  w.map('testimonial_alignment', 'align', only(textAlign(ctx), ['left', 'center', 'right']));

  if (media && !w.has('image_size')) w.set('image_size', { size: 60, unit: 'px' }); // Elementor default 60px
  w.slider('image_size', 'image_size');
  const radius = dimsToSlider(w.raw('image_border_radius'));
  if (radius) {
    if (radius.uneven) w.note('Image border radius: different values per corner are not supported; one value was kept.');
    w.set('image_radius', radius.value);
  }
  w.consumeResponsive('image_border_radius');
  if (w.has('image_border_border')) w.note('The image border is not available on the Zadex testimonial.');

  w.color('content_content_color', 'content_color');
  w.typography('content_typography', 'content_typography');
  // Elementor's quote is 1.3em, upright (`.elementor-testimonial-content{font-size:1.3em}`); Zadex's is 1.125em italic.
  const quote = (w.settings.content_typography ?? {}) as Record<string, unknown>;
  w.set('content_typography', { ...quote, size: quote.size ?? { size: 1.3, unit: 'em' }, style: quote.style ?? 'normal' });
  w.color('name_text_color', 'name_color');
  w.typography('name_typography', 'name_typography');
  w.color('job_text_color', 'role_color');
  w.typography('job_typography', 'role_typography');
  return w.finish();
});
