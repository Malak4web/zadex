/**
 * Helpers shared by the media / interactive widget mappers (video, carousels, galleries, tabs, accordions).
 * Not a mapper: nothing is registered here.
 */
import { makeKey } from '@zadex/editor/core/settings';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement, ElSettings, Settings, ZElement } from '../types';
import { deviceKeys } from '../responsive';
import { colorRef, defaultTypography } from '../globals';
import { autop } from './text-editor';
import { dimensions, icon as iconValue, isBlank, num, type Dimensions, type IconValue } from '../values';

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * Elementor widgets declare global defaults on some controls (`'global' => ['default' => Global_Colors::COLOR_PRIMARY]`):
 * when the user never touched the control, the kit global applies. This returns a copy of the element whose
 * `__globals__` also holds those defaults (only for keys without a stored value or explicit global, and only when
 * the global resolves, so no "global not found" noise). The Elementor data itself is never modified.
 * Keys are control ids (`tab_color`) or typography group ids (`tab_typography_typography`); values are Elementor
 * global ids (`primary`, `accent`, `text`…). Same rules as the basic widgets' helper.
 */
export function withGlobalDefaults(el: ElElement, ctx: ConvertContext, defaults: Record<string, string>): ElElement {
  const settings = el.settings ?? {};
  const current = isObj(settings.__globals__) ? (settings.__globals__ as Obj) : {};
  const added: Obj = {};
  const typo = new Set<string>();
  for (const [key, id] of Object.entries(defaults)) {
    const typography = key.endsWith('_typography');
    // Typography defaults apply field by field under a custom typography (see `defaultTypography`).
    if (Object.prototype.hasOwnProperty.call(current, key) || (!typography && !isBlank(settings[key]))) continue;
    if (typography ? !ctx.typographyPreset(id) : !colorRef(ctx, id)) continue;
    added[key] = `globals/${typography ? 'typography' : 'colors'}?id=${id}`;
    if (typography) typo.add(key);
  }
  if (!Object.keys(added).length) return el;
  const out: ElSettings = { ...settings, __globals__: { ...current, ...added } };
  if (typo.size) defaultTypography.set(out, typo);
  return { ...el, settings: out };
}

/** Writes `value` to a Zadex key only when the mapper did not write one (Elementor's CSS default made explicit). */
export function setDefault(w: ElementWriter, id: string, value: unknown): void {
  if (!Object.prototype.hasOwnProperty.call(w.settings, id)) w.set(id, value);
}

/**
 * Value of a responsive Elementor control for a Zadex control that is not responsive: the desktop value (with the
 * Elementor default) is returned; device values are consumed and noted.
 */
export function desktopOnly(w: ElementWriter, src: string): unknown {
  const v = w.get(src);
  for (const [key, bp] of deviceKeys(src)) {
    if (bp && !isBlank(w.raw(key))) w.note(`Per-device values of ${src} are not supported by the Zadex widget; the desktop value is used.`);
  }
  return v;
}

/** Desktop dimensions value of a (possibly responsive) Elementor dimensions control, or undefined when empty. */
export function dimsOrUndefined(w: ElementWriter, key: string): Dimensions | undefined {
  return dimensions(desktopOnly(w, key));
}

/** Zadex media list from an Elementor gallery control value (`[{id, url}]`). */
export function galleryImages(ctx: ConvertContext, v: unknown): NonNullable<ReturnType<ConvertContext['media']>>[] {
  if (!Array.isArray(v)) return [];
  const out: NonNullable<ReturnType<ConvertContext['media']>>[] = [];
  for (const item of v) {
    const m = ctx.media(item);
    if (m) out.push(m);
  }
  return out;
}

const RATIOS: Array<[string, number]> = [['1/1', 1], ['4/3', 4 / 3], ['3/2', 3 / 2], ['16/9', 16 / 9], ['3/4', 3 / 4]];

/**
 * Zadex `ratio` for "natural image ratio" galleries / carousels. Zadex's "Original" (`auto`) breaks with WordPress'
 * lazy `sizes="auto"` images (core's `contain-intrinsic-size: 3000px 1500px` makes them 1500px tall), so when every
 * image (at the shown size, from the media details) has the same ratio and Zadex lists it, that ratio is used.
 */
export function naturalRatio(images: NonNullable<ReturnType<ConvertContext['media']>>[], size: string): string {
  let found: string | undefined;
  for (const img of images) {
    const s = img.sizes?.[size];
    const wd = s?.width ?? img.width;
    const ht = s?.height ?? img.height;
    if (!wd || !ht) return 'auto';
    const hit = RATIOS.find(([, r]) => Math.abs(wd / ht - r) / r < 0.01);
    if (!hit || (found && found !== hit[0])) return 'auto';
    found = hit[0];
  }
  return found ?? 'auto';
}

/** Elementor image size names -> Zadex `image_size` options (thumbnail|medium|large|full). */
export const IMAGE_SIZES: Record<string, string> = {
  thumbnail: 'thumbnail',
  medium: 'medium',
  medium_large: 'large',
  large: 'large',
  '1536x1536': 'full',
  '2048x2048': 'full',
  full: 'full',
  custom: 'large',
};

/** Maps an Elementor image size and returns the Zadex size; notes sizes Zadex approximates. */
export function imageSize(w: ElementWriter, key: string): string {
  const size = String(w.get(key) ?? 'thumbnail');
  if (size === 'custom') {
    w.consume(`${key.replace(/_size$/, '')}_custom_dimension`);
    w.note('Custom image dimensions are not available in Zadex; the "large" size is used.');
  }
  return IMAGE_SIZES[size] ?? 'large';
}

/** Elementor icon control value -> Zadex icon (SVG uploads resolved through the media map). */
export function iconOf(ctx: ConvertContext, v: unknown): IconValue | undefined {
  const value = isObj(v) ? v.value : undefined;
  return iconValue(v, ctx.svg(value));
}

/**
 * A Zadex `text` widget holding repeater wysiwyg content (classic tabs / accordion / toggle); Elementor runs
 * `wpautop` on it, so the text-editor mapper's `autop` is applied. `styles` are shared text settings.
 */
export function textElement(id: string, html: unknown, styles: Settings = {}): ZElement {
  return { id, type: 'text', settings: { content: autop(typeof html === 'string' ? html : ''), ...styles }, children: [] };
}

/** Plain settings object for a synthetic child element (tab, accordion-item) built with `makeKey`. */
export function childSettings(values: Record<string, unknown>): Settings {
  const out: Settings = {};
  for (const [id, v] of Object.entries(values)) if (v !== undefined && v !== '') out[makeKey(id)] = v;
  return out;
}

/** Repeater items of a control (falls back to Elementor's default items when the key is absent). */
export function repeaterItems(w: ElementWriter, key: string): ElSettings[] {
  const v = w.get(key);
  return Array.isArray(v) ? v.filter(isObj) : [];
}

/**
 * Elementor's classic tabs / accordion / toggle use one width slider + one color for their borders.
 * Returns a Zadex border value (sides from the slider, `#d5d8dc` like Elementor's stylesheet when no color is set).
 */
export function sliderBorder(
  w: ElementWriter,
  sides: { top: boolean; right: boolean; bottom: boolean; left: boolean },
  defaultWidth: number | undefined,
): Obj | undefined {
  const width = w.get('border_width');
  const size = isObj(width) ? num(width.size) : undefined;
  const px = typeof size === 'number' ? size : defaultWidth;
  const color = colorValue(w, 'border_color') ?? '#d5d8dc';
  if (px === undefined) return undefined;
  if (px === 0) return { style: 'none', radius: zeroDims() };
  const unit = isObj(width) && typeof width.unit === 'string' && width.unit ? width.unit : 'px';
  return {
    style: 'solid',
    width: { top: sides.top ? px : 0, right: sides.right ? px : 0, bottom: sides.bottom ? px : 0, left: sides.left ? px : 0, unit, linked: false },
    color,
    radius: zeroDims(),
  };
}

export function zeroDims(): Obj {
  return { top: 0, right: 0, bottom: 0, left: 0, unit: 'px', linked: true };
}

export function dims(top: number, right: number, bottom = top, left = right): Obj {
  return { top, right, bottom, left, unit: 'px', linked: top === right && right === bottom && bottom === left };
}

/** A color control value (honours `__globals__`), without writing it. Marks the key as handled. */
export function colorValue(w: ElementWriter, key: string): string | undefined {
  const ref = w.globalRef(key);
  if (ref?.kind === 'colors') {
    w.consume(key);
    return colorRef(w.ctx, ref.id);
  }
  const v = w.get(key);
  return typeof v === 'string' && v !== '' ? v : undefined;
}

/**
 * Elementor background group reduced to a color (`<prefix>_background: classic` + `<prefix>_color`). Gradients and
 * images are noted (the color is still used). Returns undefined when no color is set.
 */
export function backgroundColor(w: ElementWriter, prefix: string, label: string): string | undefined {
  const type = w.raw(`${prefix}_background`);
  const color = colorValue(w, `${prefix}_color`);
  if (type && type !== 'classic') w.note(`The ${label} background is a ${String(type)}; only its color was kept.`);
  if (!type && !w.globalRef(`${prefix}_color`) && isBlank(w.raw(`${prefix}_color`))) return undefined;
  return color;
}

/** Zadex `background` value holding a plain color. */
export function classicBackground(color: string | undefined): Obj | undefined {
  return color ? { type: 'classic', color } : undefined;
}

/** Settings keys that make an Elementor child container "plain" (nothing worth keeping as its own Zadex element). */
const PLAIN_CONTAINER_KEYS = new Set(['_title', 'content_width', '__globals__', '__dynamic__', '_element_cache', 'presetTitle', 'presetIcon']);

/** True when a nested-tabs / nested-accordion child container carries no settings of its own. */
export function isPlainContainer(c: ElElement | undefined): boolean {
  if (!c || c.elType !== 'container') return false;
  for (const [k, v] of Object.entries(c.settings ?? {})) {
    if (PLAIN_CONTAINER_KEYS.has(k) || isBlank(v)) continue;
    if (isObj(v) && Object.keys(v).length === 0) continue;
    return false;
  }
  return true;
}

/** Kit container padding (Elementor `container_padding`, default 10px) as a Zadex dimensions value. */
export function kitContainerPadding(ctx: ConvertContext): Obj {
  const p = ctx.source.kit?.container_padding;
  if (isObj(p)) {
    const sides = ['top', 'right', 'bottom', 'left'].map((s) => num(p[s]));
    if (sides.some((s) => s !== undefined)) {
      const [top, right, bottom, left] = sides.map((s) => (s === undefined ? 0 : s));
      return { top, right, bottom, left, unit: typeof p.unit === 'string' && p.unit ? p.unit : 'px', linked: p.isLinked === true };
    }
  }
  return dims(10, 10);
}

/**
 * Children of a nested widget item (one Elementor child container per tab / accordion item). When every child
 * container is plain, its children are lifted into the Zadex tab / accordion-item (which are containers themselves)
 * and the container gets a report entry pointing at that item; otherwise the container is converted as-is and kept
 * as the only child.
 */
export function nestedChildren(ctx: ConvertContext, container: ElElement | undefined, flatten: boolean, targetId: string, targetType: string): ZElement[] {
  if (!container) return [];
  if (!flatten) return ctx.convert([container]);
  const children = ctx.convert(container.elements);
  ctx.record({
    source: container.id,
    sourceType: container.elType,
    status: 'converted',
    target: [targetId],
    targetType,
    dropped: [],
    notes: [`The content container was merged into the Zadex ${targetType}.`],
  });
  return children;
}
