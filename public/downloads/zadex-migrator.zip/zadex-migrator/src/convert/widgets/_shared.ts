import type { ConvertContext, ElementState, ElementWriter } from '../context';
import type { ElElement, ElSettings } from '../types';
import { colorRef, defaultTypography } from '../globals';
import { deviceKeys } from '../responsive';
import { dimensions, icon, isBlank, num, slider, type IconValue, type Slider } from '../values';

/**
 * Small helpers shared by the widget mappers (src/convert/widgets/*). Pure, no side effects except on the writer.
 */

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * Elementor controls with a global default (`'global' => ['default' => Global_Colors::COLOR_PRIMARY]`) render with
 * that kit value when the element stores nothing for them. Returns a copy of the element whose `__globals__`
 * carries those defaults, so `w.color()` / `w.typography()` pick them up like a user-chosen global. Only added when
 * the control is empty, has no `__globals__` entry (an empty entry means the user detached the global) and the
 * global resolves (Zadex global or kit value), so documents without a kit convert exactly as before.
 * Typography is the exception: Elementor prints the default as a widget-type rule under the element's own rule, so
 * a custom typography without a family / weight still gets the global's; the reference is added unless a global is
 * already chosen and the element's own fields win (`defaultTypography`, read by `ElementWriter.typography`).
 *
 * `defaults`: Elementor key -> `globals/colors?id=<id>` | `globals/typography?id=<id>` (typography: the
 * `<prefix>_typography` key).
 */
export function withGlobalDefaults(el: ElElement, ctx: ConvertContext, defaults: Record<string, string>): ElElement {
  const settings: ElSettings = el.settings ?? {};
  const current = isObj(settings.__globals__) ? settings.__globals__ : {};
  const added: Obj = {};
  const typo = new Set<string>();
  for (const [key, ref] of Object.entries(defaults)) {
    const m = ref.match(/^globals\/(colors|typography)\?id=(.+)$/);
    if (!m) continue;
    if (m[1] === 'typography') {
      // Typography defaults apply field by field under a custom typography (see `defaultTypography`).
      if (Object.prototype.hasOwnProperty.call(current, key)) continue;
    } else if (!isBlank(settings[key]) || Object.prototype.hasOwnProperty.call(current, key)) continue;
    const ok = m[1] === 'colors' ? colorRef(ctx, m[2]) !== undefined : ctx.typographyPreset(m[2]) !== undefined;
    if (ok) {
      added[key] = ref;
      if (m[1] === 'typography') typo.add(key);
    }
  }
  if (!Object.keys(added).length) return el;
  const out: ElSettings = { ...settings, __globals__: { ...current, ...added } };
  if (typo.size) defaultTypography.set(out, typo);
  return { ...el, settings: out };
}

/** Keeps only the table entries whose target value is one of `allowed` (the Zadex control's options). */
export function only(table: Record<string, string>, allowed: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(table)) if (allowed.includes(v)) out[k] = v;
  return out;
}

/** Elementor duration slider (`{unit: 's'|'ms', size}`) -> Zadex seconds slider (`{size, unit: 'custom'}`). */
export function seconds(v: unknown): Slider | undefined {
  const s = slider(v, 's');
  if (!s || typeof s.size !== 'number') return undefined;
  return { size: s.unit === 'ms' ? s.size / 1000 : s.size, unit: 'custom' };
}

/** Elementor opacity slider (0..1, unit px) -> Zadex unitless slider. */
export function unitless(v: unknown): Slider | undefined {
  const s = slider(v);
  return s ? { size: s.size, unit: 'custom' } : undefined;
}

/** Elementor dimensions -> one Zadex slider (first non-zero side). `uneven` tells whether sides differed. */
export function dimsToSlider(v: unknown): { value: Slider; uneven: boolean } | undefined {
  const d = dimensions(v);
  if (!d) return undefined;
  const sides = [d.top, d.right, d.bottom, d.left];
  const uneven = new Set(sides.map(String)).size > 1;
  const pick = sides.find((s) => s !== 0) ?? 0;
  return { value: { size: pick, unit: d.unit }, uneven };
}

/** Copies a responsive Elementor dimensions control into a responsive Zadex slider (first side). */
export function dimsAsSlider(w: ElementWriter, src: string, dst: string, label: string, state?: ElementState): void {
  for (const [key, bp] of deviceKeys(src)) {
    const r = dimsToSlider(w.raw(key));
    if (!r) continue;
    if (r.uneven) w.note(`${label}: different values per side are not supported; one value was kept.`);
    w.set(dst, r.value, { bp, state });
  }
}

/**
 * Responsive Elementor control -> non-responsive Zadex control: the desktop value is copied (Elementor default
 * when absent), device values are reported as not carried over.
 */
export function single(w: ElementWriter, src: string, dst: string, convert: (v: unknown) => unknown = (v) => v, state?: ElementState): void {
  for (const [key, bp] of deviceKeys(src)) {
    if (!bp) {
      const v = w.get(key);
      if (!isBlank(v)) w.set(dst, convert(v), { state });
      continue;
    }
    if (w.has(key)) w.note(`${key}: per-device values are not supported by this Zadex control; the desktop value is used.`);
    w.raw(key);
  }
}

/** Removes per-device keys a group helper wrote for a non-responsive Zadex control (noted). */
export function desktopOnly(w: ElementWriter, dst: string): void {
  for (const key of Object.keys(w.settings)) {
    if (key.startsWith(`${dst}@`) || key.startsWith(`${dst}::`) && key.includes('@')) {
      delete w.settings[key];
      w.note(`${dst}: per-device values are not supported by this Zadex control; the desktop value is used.`);
    }
  }
}

/** Elementor radius slider (one value) -> the `radius` of a Zadex border value (all four corners). */
export function sliderRadius(w: ElementWriter, src: string, dst: string, responsive = true): void {
  for (const [key, bp] of deviceKeys(src)) {
    const s = slider(w.raw(key));
    if (!s) continue;
    if (bp && !responsive) {
      w.note(`${key}: per-device values are not supported by this Zadex control; the desktop value is used.`);
      continue;
    }
    const zkey = bp ? `${dst}@${bp}` : dst;
    const current = isObj(w.settings[zkey]) ? (w.settings[zkey] as Obj) : {};
    w.set(dst, { ...current, radius: { top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true } }, { bp });
  }
}

/** Elementor icon control -> Zadex icon (SVG uploads use the inline markup the server sent). Notes unsupported icons. */
export function iconValue(w: ElementWriter, key: string, raw = false): IconValue | undefined {
  const v = raw ? w.raw(key) : w.get(key);
  if (!isObj(v) || (isBlank(v.value) && v.library !== 'svg')) return undefined;
  const out = icon(v, v.library === 'svg' ? w.ctx.svg(v.value) : undefined);
  if (!out) w.note(`Icon "${describeIcon(v)}" (${String(v.library ?? '')}) is not available in Zadex.`);
  return out;
}

export function describeIcon(v: unknown): string {
  if (!isObj(v)) return '';
  if (typeof v.value === 'string') return v.value;
  if (isObj(v.value) && typeof v.value.url === 'string') return v.value.url;
  return '';
}

/**
 * Typography group plus Elementor's own stylesheet defaults (e.g. the counter number is 69px / 600 in
 * Elementor's CSS). The defaults go under the converted desktop value, so stored values always win.
 */
export function typographyWithDefaults(w: ElementWriter, prefix: string, dst: string, defaults: Obj): void {
  w.typography(prefix, dst);
  const current = isObj(w.settings[dst]) ? (w.settings[dst] as Obj) : {};
  w.set(dst, { ...defaults, ...current });
}

/** Number from an Elementor number / text / select value (`'3'` -> 3); undefined when empty or not numeric. */
export function toNumber(v: unknown): number | undefined {
  const n = num(v);
  return typeof n === 'number' ? n : undefined;
}

/** Elementor repeater value as a list of objects (missing / malformed -> []). */
export function repeaterItems(v: unknown): Obj[] {
  return Array.isArray(v) ? v.filter(isObj) : [];
}

/** Stable Zadex repeater item id: from the Elementor `_id`, else derived from the element id + index. */
export function itemIdFor(ctx: ConvertContext, el: ElElement, item: Obj, index: number): string {
  return ctx.itemId(!isBlank(item._id) ? item._id : `${el.id}${index}`);
}

/** Heading tags Zadex box widgets accept (`h2…h6|div|p`): h1 -> h2, span -> div (noted). */
export function boxTitleTag(w: ElementWriter, v: unknown): string {
  const tag = String(v ?? 'h3');
  if (['h2', 'h3', 'h4', 'h5', 'h6', 'div', 'p'].includes(tag)) return tag;
  const out = tag === 'h1' ? 'h2' : 'div';
  w.note(`Title tag "${tag}" is not available in Zadex; "${out}" is used.`);
  return out;
}

export { isObj };
