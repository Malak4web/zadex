import { registerWidget } from '../registry';
import { convertCollapsible } from './_collapsible';

/**
 * Elementor classic `toggle` -> Zadex `toggle` (all items closed on load, several open at once: same as Elementor).
 * Details in _collapsible.ts.
 */
registerWidget('toggle', (el, ctx) => convertCollapsible(el, ctx, 'toggle'));
