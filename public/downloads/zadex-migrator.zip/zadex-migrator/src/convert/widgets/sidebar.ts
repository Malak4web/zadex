import { registerWidget } from '../registry';

/**
 * Elementor `sidebar` -> Zadex `sidebar`. Both store the registered widget-area id; the Zadex control lists the
 * site's sidebars at runtime (`optionsFrom: sidebars`), so any id is kept as is.
 */
registerWidget('sidebar', (el, ctx) => {
  const w = ctx.writer(el, 'sidebar');
  const id = String(w.get('sidebar') ?? '');
  w.set('sidebar', id);
  if (id === '') w.note('No widget area was selected in Elementor.');
  return w.finish();
});
