import { registerWidget } from '../registry';
import { slider, url } from '../values';
import { itemIdFor, repeaterItems, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { desktopSlider, field, mediaOf, sidesOf } from './_marketing';

type Obj = Record<string, unknown>;

const SEPARATORS = ['dotted', 'dashed', 'solid', 'double', 'none'];
const VALIGN: Record<string, string> = { top: 'top', center: 'center', bottom: 'bottom' };

/**
 * Elementor Pro `price-list` -> Zadex `price-list`. Verified against Elementor Pro 3.33.2: repeater `price_list`
 * {price, title, item_description, image, link (default '#')}; `title_tag` (span), `description_tag` (p),
 * `image_size_size` (thumbnail); style `vertical_align` top|center|bottom, `row_gap` (R, 20px), `image_spacing`
 * (20px), `content_spacing`, `heading_color` / `heading_typography` (item title, primary / primary), `price_color` /
 * `price_typography` (primary / primary), `description_color` / `description_typography` (text / text),
 * `separator_style` (dotted), `separator_weight` (2px), `separator_color` (secondary), `separator_spacing`,
 * `border_radius` (image). Elementor lays every item out as "title ..... price" with the description below (Zadex
 * `inline`, image at the start).
 */
registerWidget('price-list', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    heading_color: 'globals/colors?id=primary',
    heading_typography_typography: 'globals/typography?id=primary',
    price_color: 'globals/colors?id=primary',
    price_typography_typography: 'globals/typography?id=primary',
    description_color: 'globals/colors?id=text',
    description_typography_typography: 'globals/typography?id=text',
    separator_color: 'globals/colors?id=secondary',
  });
  const w = ctx.writer(el, 'price-list');
  markPro(w);
  const items = repeaterItems(w.get('price_list'));
  if (!items.length) w.note('The price list has no items.');
  w.set(
    'items',
    items.map((item, i) => {
      const out: Obj = {
        _id: itemIdFor(ctx, el, item, i),
        title: field(item, 'title', ''),
        price: field(item, 'price', ''),
        description: field(item, 'item_description', ''),
      };
      const image = mediaOf(ctx, item.image);
      if (image) out.image = image;
      // Repeater default link is '#' (Pro wraps the item in a link only when the URL is not empty).
      const link = url(item.link === undefined ? { url: '#' } : item.link);
      if (link) out.link = link;
      return out;
    }),
  );
  for (const [key, def] of [['title_tag', 'span'], ['description_tag', 'p']] as const) {
    const tag = w.raw(key);
    if (typeof tag === 'string' && tag !== '' && tag !== def) w.note(`Price list ${key.replace('_', ' ')} "${tag}" is not carried over.`);
  }
  w.set('layout', 'inline');
  const sep = String(w.get('separator_style') || 'dotted');
  w.set('separator', SEPARATORS.includes(sep) ? sep : 'dotted');
  w.set('image_position', 'start');
  w.set('vertical_align', VALIGN[String(w.get('vertical_align'))] ?? 'top');

  // Items (Elementor puts 20px between items by default).
  w.slider('row_gap', 'item_gap');

  // Texts.
  w.color('heading_color', 'title_color');
  w.typography('heading_typography', 'title_typography');
  w.color('price_color', 'price_color');
  w.typography('price_typography', 'price_typography');
  w.color('description_color', 'description_color');
  w.typography('description_typography', 'description_typography');
  const descGap = desktopSlider(w, 'content_spacing');
  if (descGap) w.set('description_gap', descGap);

  // Separator (Pro: 2px when nothing is set).
  if (sep !== 'none') {
    const weight = desktopSlider(w, 'separator_weight') ?? slider(w.get('separator_weight'));
    if (weight) w.set('separator_weight', weight);
    w.color('separator_color', 'separator_color');
    const spacing = desktopSlider(w, 'separator_spacing');
    if (spacing) w.set('separator_spacing', spacing);
  } else w.consume('separator_weight*', 'separator_color', 'separator_spacing*');

  // Image (Pro: 20px spacing).
  const size = String(w.get('image_size_size') || 'thumbnail');
  if (size !== 'thumbnail') w.note(`Image size "${size}" is not carried over; set the Zadex image size to match.`);
  w.consume('image_size_custom_dimension');
  const radius = sidesOf(w.raw('border_radius'));
  if (radius) w.set('image_radius', radius);
  const gap = desktopSlider(w, 'image_spacing') ?? slider(w.get('image_spacing'));
  if (gap) w.set('image_gap', gap);
  for (const k of ['text_stroke_text_stroke_type']) {
    if (w.raw(k) === 'yes') w.note('The title text stroke is not available in Zadex.');
    w.consume(k, 'text_stroke_text_stroke*', 'text_stroke_stroke_color');
  }
  return w.finish();
});
