import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { slider, url } from '../values';
import { describeIcon, desktopOnly, isObj, itemIdFor, only, repeaterItems } from './_shared';

/** Font Awesome glyph (without `fa-`) -> Zadex network. Variants (`-f`, `-square`, `-alt` …) are stripped first. */
const NETWORKS: Record<string, string> = {
  facebook: 'facebook',
  'facebook-messenger': 'facebook',
  twitter: 'x-twitter',
  'x-twitter': 'x-twitter',
  instagram: 'instagram',
  linkedin: 'linkedin',
  'linkedin-in': 'linkedin',
  youtube: 'youtube',
  tiktok: 'tiktok',
  pinterest: 'pinterest',
  'pinterest-p': 'pinterest',
  whatsapp: 'whatsapp',
  telegram: 'telegram',
  'telegram-plane': 'telegram',
  snapchat: 'snapchat',
  'snapchat-ghost': 'snapchat',
  threads: 'threads',
  reddit: 'reddit',
  'reddit-alien': 'reddit',
  github: 'github',
  dribbble: 'dribbble',
  behance: 'behance',
  vimeo: 'vimeo',
  'vimeo-v': 'vimeo',
  twitch: 'twitch',
  discord: 'discord',
  spotify: 'spotify',
  medium: 'medium',
  'medium-m': 'medium',
  tumblr: 'tumblr',
  flickr: 'flickr',
  envelope: 'email',
  'envelope-open': 'email',
  at: 'email',
  rss: 'rss',
  globe: 'website',
  link: 'website',
  home: 'website',
  house: 'website',
};

/** Elementor social icon value (`fab fa-facebook-f`) -> Zadex network id, or undefined when unknown. */
export function networkFor(iconValue: unknown): string | undefined {
  const value = isObj(iconValue) && typeof iconValue.value === 'string' ? iconValue.value : '';
  const glyph = value.split(/\s+/).find((p) => p.startsWith('fa-') && !['fa-brands', 'fa-solid', 'fa-regular'].includes(p));
  if (!glyph) return undefined;
  let name = glyph.slice(3);
  for (let i = 0; i < 3; i++) {
    if (NETWORKS[name]) return NETWORKS[name];
    const stripped = name.replace(/-(square|circle|alt|f|official|plane|sign)$/, '');
    if (stripped === name) break;
    name = stripped;
  }
  return NETWORKS[name];
}

/** Elementor hover animations Zadex offers (others fall back to the closest). */
const ANIMATIONS: Record<string, string> = {
  grow: 'grow',
  'pulse-grow': 'grow',
  'grow-rotate': 'grow',
  pop: 'grow',
  shrink: 'shrink',
  'pulse-shrink': 'shrink',
  push: 'shrink',
  sink: 'shrink',
  rotate: 'rotate',
  float: 'float',
  bob: 'float',
  pulse: 'pulse',
};

/** Elementor `social-icons` -> Zadex `social-icons`. */
registerWidget('social-icons', (el, ctx) => {
  const w = ctx.writer(el, 'social-icons');
  let customItemColors = false;
  const items = repeaterItems(w.get('social_icon_list')).map((item, i) => {
    const network = networkFor(item.social_icon);
    if (!network) w.note(`Social icon "${describeIcon(item.social_icon)}" has no Zadex network; "website" is used.`);
    const out: Record<string, unknown> = { _id: itemIdFor(ctx, el, item, i), network: network ?? 'website' };
    const link = url(item.link);
    out.link = link ?? { url: '', target: '', nofollow: false };
    if (item.item_icon_color === 'custom') customItemColors = true;
    return out;
  });
  w.set('items', items);
  if (customItemColors) w.note('Per-icon custom colors are not available in Zadex; the widget colors are used.');

  const shape = String(w.get('shape') ?? 'rounded');
  w.set('shape', ['rounded', 'square', 'circle'].includes(shape) ? shape : 'rounded');
  const columns = w.get('columns');
  if (columns !== undefined && columns !== '' && columns !== '0') w.note('A fixed number of columns is not available in Zadex (icons flow in one row and wrap).');
  w.consumeResponsive('columns');
  w.map('align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));

  const scheme = w.get('icon_color') === 'custom' ? 'custom' : 'official';
  w.set('scheme', scheme);
  if (scheme === 'custom') {
    w.color('icon_primary_color', 'icon_bg');
    w.color('icon_secondary_color', 'icon_color');
    w.color('hover_primary_color', 'icon_bg', 'hover');
    w.color('hover_secondary_color', 'icon_color', 'hover');
  } else w.consume('icon_primary_color', 'icon_secondary_color', 'hover_primary_color', 'hover_secondary_color');

  // Elementor defaults: --icon-size 25px, --icon-padding .5em, column gap 5px.
  if (!w.has('icon_size')) w.set('size', { size: 25, unit: 'px' });
  w.slider('icon_size', 'size');
  if (!w.has('icon_padding')) w.set('padding', { size: 0.5, unit: 'em' });
  w.slider('icon_padding', 'padding', undefined, 'em');
  w.slider('icon_spacing', 'spacing');
  const rowGap = slider(w.get('row_gap'));
  if (rowGap && rowGap.size !== 0) w.note('A separate row gap is not available in Zadex (spacing is used for both).');
  w.consumeResponsive('row_gap');

  w.border('image_border', 'border', 'border_radius');
  desktopOnly(w, 'border');
  w.color('hover_border_color', 'border', 'hover');
  const hoverBorder = w.settings['border::hover'];
  if (typeof hoverBorder === 'string') w.set('border', { color: hoverBorder }, { state: 'hover' });

  const anim = String(w.raw('hover_animation') ?? '');
  w.set('hover_animation', anim === '' ? 'none' : (ANIMATIONS[anim] ?? 'grow'));
  if (anim !== '' && !ANIMATIONS[anim]) w.note(`Hover animation "${anim}" is approximated with "grow".`);
  return w.finish();
});
