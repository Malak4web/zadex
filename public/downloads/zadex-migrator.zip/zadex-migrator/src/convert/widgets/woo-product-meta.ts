import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { flatColor, noteIfSet } from './_woo-product';
import { sliderAlt, typographyAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-meta` -> Zadex `product-meta`.
 * Verified against Elementor Pro 3.33.2: `view` (table | stacked | inline, default inline), `space_between` (R),
 * `divider` (switcher, default off) + `divider_style` / `divider_weight` / `divider_width` / `divider_height` /
 * `divider_color`, `text_color`, `text_typography_*`, `link_color`, `link_typography_*`, captions
 * (`category_caption_single` / `_plural`, `tag_caption_single` / `_plural`, `sku_caption`, `sku_missing_caption`).
 */
registerWidget('woocommerce-product-meta', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-meta');
  if (off) return off;
  const w = ctx.writer(source, 'product-meta');
  markPro(w);
  const view = String(w.get('view') || 'inline');
  if (view === 'inline') w.set('view', 'inline');
  else {
    w.set('view', 'stacked');
    if (view === 'table') w.note('The "table" view became "stacked" (labels and values are not aligned in columns).');
    else if (view !== 'stacked') w.note(`View "${view}" has no Zadex equivalent; "stacked" is used.`);
  }
  sliderAlt(w, ['space_between'], 'gap');
  flatColor(w, ['text_color'], 'color');
  typographyAlt(w, ['text_typography'], 'typography');
  flatColor(w, ['link_color'], 'link_color');
  typographyAlt(w, ['link_typography'], 'link_typography');

  // Dividers (Pro default off): Zadex has none.
  const divider = w.get('divider') === 'yes';
  w.consume('divider_*');
  if (divider) w.note('The dividers between meta items are not carried over.');
  noteIfSet(
    w,
    ['category_caption_single', 'category_caption_plural', 'tag_caption_single', 'tag_caption_plural', 'sku_caption', 'sku_missing_caption'],
    'Custom captions (SKU / category / tag labels) are not carried over; Zadex uses WooCommerce\'s translated labels.',
  );
  return w.finish();
});
