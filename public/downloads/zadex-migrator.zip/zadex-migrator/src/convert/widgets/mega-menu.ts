import { registerWidget } from '../registry';
import { deviceKeys } from '../responsive';
import { isBlank, slider, url } from '../values';
import type { ConvertContext } from '../context';
import type { ElElement, ZElement } from '../types';
import { only, withGlobalDefaults } from './_shared';
import { childSettings, isPlainContainer, kitContainerPadding, nestedChildren, repeaterItems } from './_media-support';
import { markPro } from './_pro';
import { collapseBreakpoint, isObj, menuAlign, pstr } from './_pro-site';

/**
 * Elementor Pro `mega-menu` (nested "Menu" widget: repeater `menu_items` for the titles, one child container per item
 * for its dropdown content) -> Zadex `mega-menu` with one `mega-menu-item` per item.
 *
 * Verified against Elementor Pro 3.33.2 (elementor-pro-controls.json, modules/mega-menu/widgets/mega-menu.php):
 * `menu_items` default = Item #1..#3; item fields `item_title`, `item_link` (url object; very old data: a string),
 * `item_dropdown_content` (default "no": the child container is only rendered when it is "yes"), `item_icon`,
 * `item_icon_active`, `element_id`. Background groups are `<prefix>_background` + `<prefix>_color`
 * (e.g. `menu_item_title_background_color_hover_color`, `content_background_color_color`). Like nested tabs, plain
 * child containers are merged into the Zadex item (a container itself); styled ones are kept as the item's only child.
 */

/** Elementor's CSS defaults (widget-mega-menu.css): title color #1f2124 (normal / hover), padding 0.5rem 1rem. */
const TITLE_COLOR = '#1f2124';

registerWidget('mega-menu', (source, ctx) => {
  // Pro's global default: title typography = accent (mega-menu.php `global` args).
  const el = withGlobalDefaults(source, ctx, { menu_item_title_typography_typography: 'globals/typography?id=accent' });
  const w = ctx.writer(el, 'mega-menu');
  markPro(w);
  const items = repeaterItems(w, 'menu_items');
  const containers = source.elements ?? [];

  // Layout: `item_layout` horizontal (default) | dropdown (vertical, always toggled).
  const layout = pstr(w, 'item_layout', 'horizontal');
  if (layout === 'dropdown') w.note('The "dropdown" item layout (vertical menu) is shown as a horizontal mega menu in Zadex.');
  const openOn = pstr(w, 'open_on', 'hover');
  w.set('open_on', openOn === 'click' ? 'click' : 'hover');
  w.set('collapse', collapseBreakpoint(w, pstr(w, 'breakpoint_selector', 'tablet')));
  // Dropdown width: `content_width` full_width (default) | fit_to_content.
  const width = pstr(w, 'content_width', 'full_width');
  w.set('dropdown_width', width === 'fit_to_content' ? 'boxed' : 'full');
  if (width === 'fit_to_content') w.note('"Fit to content" dropdowns use the Zadex boxed dropdown width.');
  w.raw('content_horizontal_position');
  // `item_position_horizontal` start | center | end | stretch (stretch = titles grow, space-between).
  if (layout === 'horizontal') w.map('item_position_horizontal', 'align', only(menuAlign(Boolean(ctx.source.rtl)), ['flex-start', 'center', 'flex-end', 'space-between']));
  else w.consumeResponsive('item_position_horizontal');
  w.consume('item_position_dropdown');
  const hscroll = w.raw('horizontal_scroll');
  if (hscroll === 'enable') w.note('Horizontal scrolling of the menu items is not available in Zadex.');
  w.consumeResponsive('horizontal_scroll');

  // Item titles.
  w.typography('menu_item_title_typography', 'typography');
  w.color('menu_item_title_text_color_normal', 'item_color');
  w.color('menu_item_title_text_color_hover', 'item_color_hover');
  if (w.settings.item_color === undefined) w.set('item_color', TITLE_COLOR);
  if (w.settings.item_color_hover === undefined) w.set('item_color_hover', TITLE_COLOR);
  if (w.has('menu_item_title_text_color_active')) w.note('Active item colors use the hover colors in Zadex.');
  w.raw('menu_item_title_text_color_active');
  w.color('menu_item_title_background_color_hover_color', 'item_bg_hover');
  if (w.has('menu_item_title_background_color_color')) w.note('The item background color (normal state) is not supported by the Zadex mega menu.');
  if (w.raw('menu_item_title_background_color_hover_background') === 'gradient') w.note('The item hover gradient became its first color.');
  w.consume('menu_item_title_background_color_*');
  w.dimensions('menu_item_title_padding', 'item_padding');
  if (w.settings.item_padding === undefined) w.set('item_padding', { top: 0.5, right: 1, bottom: 0.5, left: 1, unit: 'em', linked: false });
  w.slider('menu_item_title_space_between', 'item_gap');
  for (const [key, bp] of deviceKeys('menu_item_title_distance_from_content')) {
    const s = slider(bp ? w.raw(key) : w.get(key));
    if (s && !bp) w.set('dropdown_offset', s);
    else if (s) w.note('Dropdown distance: per-device values are not supported by this Zadex control; the desktop value is used.');
  }
  for (const k of ['menu_item_title_box_border_border', 'menu_item_title_box_border_hover_border', 'menu_item_title_box_border_active_border']) {
    const v = w.raw(k);
    if (!isBlank(v) && v !== 'none') w.note('Item title borders are not carried over.');
  }
  w.consume('menu_item_title_box_border_*', 'menu_item_title_border_radius*');
  if (w.raw('menu_divider') === 'yes') w.note('Dividers between menu items are not carried over.');
  w.consume('menu_divider*');
  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Item hover animation "${anim}" is not available in Zadex.`);

  // Dropdown box (`content_background_color_*` group, `content_border_*`, `content_shadow_*`, `content_padding`).
  w.color('content_background_color_color', 'dropdown_bg');
  const bgType = w.raw('content_background_color_background');
  if (bgType && bgType !== 'classic') w.note('The dropdown background gradient / image is not supported; only its color was kept.');
  w.consume('content_background_color_*');
  w.border('content_border', 'dropdown_border', 'content_border_radius');
  for (const k of Object.keys(w.settings)) if (k.startsWith('dropdown_border@')) delete w.settings[k];
  w.boxShadow('content_shadow', 'dropdown_shadow');

  // Toggle (`menu_toggle_icon_color_normal`, `style_menu_toggle_icon_size` default 20px).
  w.color('menu_toggle_icon_color_normal', 'toggle_color');
  const tSize = slider(w.get('style_menu_toggle_icon_size'));
  if (tSize && tSize.unit === 'px' && typeof tSize.size === 'number') w.set('toggle_size', { ...tSize, size: Math.min(64, Math.max(16, tSize.size)) });
  w.consumeResponsive('style_menu_toggle_icon_size');
  for (const k of ['menu_toggle_icon_normal', 'menu_toggle_icon_active']) {
    const v = w.raw(k);
    if (isObj(v) && !isBlank(v.value)) w.note('Custom toggle icons are not available in Zadex.');
  }

  // Items.
  const flatten = containers.length > 0 && containers.every((c) => isPlainContainer(c));
  const contentPadding = w.raw('content_padding');
  w.consumeResponsive('content_padding');
  if (flatten) {
    if (contentPadding) w.dimensions('content_padding', 'dropdown_padding');
    else w.set('dropdown_padding', kitContainerPadding(ctx));
  } else w.set('dropdown_padding', { top: 0, right: 0, bottom: 0, left: 0, unit: 'px', linked: true });

  const count = Math.max(items.length, containers.length);
  const children: ZElement[] = [];
  let icons = false;
  for (let i = 0; i < count; i++) {
    const item = items[i] ?? {};
    const container = containers[i];
    const id = ctx.idFor(source.id, 'm' + (i + 1));
    const hasContent = Boolean(container && (container.elements ?? []).length);
    // Pro renders the dropdown only when `item_dropdown_content` is "yes" (repeater field default "no").
    const hasDropdown = item.item_dropdown_content === 'yes' || item.item_dropdown_content === true;
    if ((isObj(item.item_icon) && !isBlank(item.item_icon.value)) || (isObj(item.item_icon_active) && !isBlank(item.item_icon_active.value))) icons = true;
    const settings = childSettings({
      title: String(item.item_title ?? container?.settings?._title ?? 'Item Title'),
      link: url(item.item_link),
      has_dropdown: hasDropdown,
      _css_id: typeof item.element_id === 'string' && item.element_id ? item.element_id : undefined,
    });
    let kids: ZElement[] = [];
    if (hasDropdown) kids = nestedChildren(ctx, container, flatten, id, 'mega-menu-item');
    else {
      if (hasContent) w.note(`Item "${String(item.item_title ?? i + 1)}" has dropdown content but its dropdown is off; the content was not carried over.`);
      // Pro keeps one child container per item even without a dropdown (never rendered): report it and its
      // content so nothing disappears silently from the report.
      if (container) recordUnused(ctx, container, id);
    }
    children.push({ id, type: 'mega-menu-item', settings, children: kids });
  }
  if (icons) w.note('Menu item icons are not available on Zadex mega menu items.');
  if (count === 0) w.note('The menu has no items.');
  return w.finish(children);
});

/**
 * Reports the child container of an item without dropdown: empty -> converted (Pro renders nothing either),
 * with content -> skipped, recursively.
 */
function recordUnused(ctx: ConvertContext, el: ElElement, itemId: string): void {
  const empty = !(el.elements ?? []).length;
  ctx.record({
    source: el.id,
    sourceType: el.elType === 'widget' ? String(el.widgetType ?? 'widget') : el.elType,
    status: empty && el.elType !== 'widget' ? 'converted' : 'skipped',
    target: empty && el.elType !== 'widget' ? [itemId] : [],
    targetType: empty && el.elType !== 'widget' ? 'mega-menu-item' : undefined,
    dropped: [],
    notes: [empty && el.elType !== 'widget' ? 'Empty dropdown container of a menu item without dropdown (Elementor does not render it either).' : 'Content of a menu item whose dropdown is off (Elementor does not render it): not carried over.'],
  });
  for (const child of el.elements ?? []) recordUnused(ctx, child, itemId);
}
