import { registerWidget } from '../registry';
import type { Mapper } from '../context';
import { textAlign } from '../align';
import { isBlank, slider } from '../values';
import { only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { list, responsiveInt, toInt } from './_pro-posts';
import { colorAlt, typographyAlt } from './_marketing';
import { wooGuard } from './_woo';
import { deviceKeys } from '../responsive';

/**
 * Elementor Pro `wc-categories` (Product Categories, WooCommerce `[product_categories]` shortcode) -> Zadex
 * `product-categories`. Verified against Elementor Pro 3.33.2: `columns` R (4 / 3 / 2), `number` ("4"), `source`
 * '' (show all) | by_id | by_parent | current_subcategories, `categories` (term ids), `parent` ('0' = top level),
 * `hide_empty` (''), `orderby` name | slug | description | count (name), `order` (desc); style `column_gap` /
 * `row_gap` R (20 / 40px), `align` R, `image_border_*`, `image_spacing`, `title_color` (global primary),
 * `title_typography` (global primary), `count_color`, `count_typography` (global primary).
 * `woocommerce-product-categories` does not exist in Pro 3.33.2 (not in the control dump); it stays registered as a
 * harmless alias of the same mapper for exports from unknown versions.
 */
const ORDERBY: Record<string, string> = { name: 'name', count: 'count' };

const mapper: Mapper = (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-categories');
  if (off) return off;
  const el = withGlobalDefaults(source, ctx, {
    title_color: 'globals/colors?id=primary',
    title_typography_typography: 'globals/typography?id=primary',
    count_typography_typography: 'globals/typography?id=primary',
  });
  const w = ctx.writer(el, 'product-categories', { sourceType: 'wc-categories' });
  markPro(w);

  responsiveInt(w, 'columns', 'columns', { desktop: 4, tablet: 3, mobile: 2 }, [1, 8]);
  const limit = toInt(w.get('number')) ?? 4;
  w.set('limit', Math.min(100, limit));

  const src = String(w.get('source') ?? '');
  const parent = String(w.get('parent') ?? '0');
  const ids = list(w.raw('categories'));
  if (src === 'by_id') {
    w.set('source', 'ids');
    w.set('ids', ids);
  } else if (src === 'by_parent' && parent !== '0' && parent !== '') {
    w.set('source', 'top');
    w.note(`Subcategories of category ${parent} are not available in Zadex; the top-level categories are shown.`);
    w.status('partial');
  } else if (src === 'current_subcategories') {
    w.set('source', 'top');
    w.note('"Current subcategories" is not available in Zadex; the top-level categories are shown.');
    w.status('partial');
  } else {
    w.set('source', 'top');
    if (src === '') w.note('"Show all" categories: Zadex shows the top-level categories (subcategories are left out).');
  }
  if (src !== 'by_id') w.consume('categories');
  if (src !== 'by_parent') w.consume('parent');

  // Pro's hide_empty default is '' (empty categories shown); Zadex defaults to hiding them.
  w.set('hide_empty', w.get('hide_empty') === 'yes');
  const orderby = String(w.get('orderby') || 'name');
  if (ORDERBY[orderby]) w.set('orderby', ORDERBY[orderby]);
  else {
    w.note(`Order by "${orderby}" is not available in Zadex; categories are ordered by name.`);
    w.set('orderby', 'name');
  }
  if (String(w.get('order')).toLowerCase() === 'desc') w.note('Elementor sorted the categories in descending order (its default); Zadex has no sort direction and uses WooCommerce\'s ascending order.');

  // Style. Zadex has one gap: the column gap (Pro default 20px) is used, a different row gap is noted.
  for (const [key, bp] of deviceKeys('column_gap')) {
    const s = slider(bp ? w.raw(key) : w.get(key));
    if (s && typeof s.size === 'number') w.set('gap', s, { bp });
  }
  for (const [key] of deviceKeys('row_gap')) if (!isBlank(w.raw(key))) w.note('Zadex uses one gap for rows and columns; the row gap was left out.');
  w.map('align', 'card_align', only(textAlign(ctx), ['left', 'center', 'right']));
  // Zadex has no image border / spacing on category cards: left to the dropped list (reported).
  colorAlt(w, ['title_color'], 'title_color');
  typographyAlt(w, ['title_typography'], 'title_typography');
  colorAlt(w, ['count_color'], 'count_color');
  typographyAlt(w, ['count_typography'], 'count_typography');
  return w.finish();
};

registerWidget('wc-categories', mapper);
registerWidget('woocommerce-product-categories', mapper);
