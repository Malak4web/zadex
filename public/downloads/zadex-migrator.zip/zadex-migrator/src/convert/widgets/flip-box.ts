import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { convertBackground } from '../background';
import { bool, dimensions, slider, url } from '../values';
import { iconValue, only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { VERTICAL, buttonPreset, buttonStyles, desktopSlider, mediaOf } from './_marketing';
import { deviceKeys } from '../responsive';

const DIRECTIONS = ['left', 'right', 'up', 'down'];

/**
 * Elementor Pro `flip-box` -> Zadex `flip-box`. Verified against Elementor Pro 3.33.2: front `graphic_element`
 * none|image|icon (icon), `image`, `image_size`, `selected_icon` (fas fa-star), `title_text_a`, `description_text_a`;
 * back `title_text_b`, `description_text_b`, `button_text`, `link`, `link_click` box|button (button); `title_tag`
 * (h3), `description_tag` (div), `flip_effect` (flip) flip|slide|push|zoom-in|zoom-out|fade, `flip_direction` (up),
 * `flip_3d`; style `height`, `border_radius`, `background_a|b` groups, `background_overlay_a|b`, `padding_a|b`,
 * `alignment_a|b` (center), `vertical_position_a|b`, `border_a|b` groups, `shadow_a|b` box shadows, icon / image
 * styles, `title_color_a|b` / `title_typography_a|b` (primary), `description_color_a|b` /
 * `description_typography_a|b` (text), button (accent typography, `button_size` sm). Elementor's stylesheet gives
 * the box a 280px height, no radius, 35px padding, front #1abc9c / back #4054b2 and white text; those are written
 * where nothing is stored (Zadex's own defaults differ). Elementor's back side has no graphic (Zadex: none).
 */
registerWidget('flip-box', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_typography_a_typography: 'globals/typography?id=primary',
    description_typography_a_typography: 'globals/typography?id=text',
    title_typography_b_typography: 'globals/typography?id=primary',
    description_typography_b_typography: 'globals/typography?id=text',
    button_typography_typography: 'globals/typography?id=accent',
  });
  const w = ctx.writer(el, 'flip-box');
  markPro(w);

  // Front.
  let graphic = String(w.get('graphic_element') || 'none');
  if (graphic === 'icon') {
    const ic = iconValue(w, 'selected_icon');
    if (ic) w.set('front_icon', ic);
    else graphic = 'none';
    const view = String(w.get('icon_view') || 'default');
    if (view !== 'default') w.note(`Icon view "${view}" (stacked / framed) is not available on the Zadex flip box.`);
    w.consume('icon_shape', 'image', 'image_size', 'image_custom_dimension');
  } else if (graphic === 'image') {
    const image = mediaOf(ctx, w.raw('image'));
    if (image) w.set('front_image', image);
    else {
      graphic = 'none';
      w.note('No image was selected for the flip box front.');
    }
    w.consume('image_size', 'image_custom_dimension', 'selected_icon', 'icon_view', 'icon_shape');
  } else {
    graphic = 'none';
    w.consume('selected_icon', 'icon_view', 'icon_shape', 'image', 'image_size', 'image_custom_dimension');
  }
  w.set('front_graphic', graphic);
  w.set('front_title', String(w.get('title_text_a') ?? ''));
  w.set('front_description', String(w.get('description_text_a') ?? ''));

  // Back.
  w.set('back_graphic', 'none');
  w.set('back_title', String(w.get('title_text_b') ?? ''));
  w.set('back_description', String(w.get('description_text_b') ?? ''));
  w.set('button_text', String(w.get('button_text') ?? ''));
  const link = url(w.raw('link'));
  w.set('link', link ?? { url: '', target: '', nofollow: false });
  w.set('link_click', w.get('link_click') === 'box' ? 'box' : 'button');
  for (const [key, def] of [['title_tag', 'h3'], ['description_tag', 'div']] as const) {
    const tag = w.raw(key);
    if (typeof tag === 'string' && tag !== '' && tag !== def) w.note(`Flip box ${key.replace('_', ' ')} "${tag}" is not carried over.`);
  }

  // Effect.
  const effect = String(w.get('flip_effect') || 'flip');
  const zEffect = effect === 'zoom-in' || effect === 'zoom-out' ? 'zoom' : ['flip', 'slide', 'push', 'zoom', 'fade'].includes(effect) ? effect : 'flip';
  if (effect === 'zoom-out') w.note('The "zoom out" flip effect is shown as Zadex\'s zoom.');
  w.set('effect', zEffect);
  const dir = String(w.get('flip_direction') || 'up');
  w.set('direction', DIRECTIONS.includes(dir) ? dir : 'up');
  const depth = bool(w.get('flip_3d'));
  w.set('depth', zEffect === 'flip' && depth);

  // Box (Elementor's stylesheet: no radius, 35px padding).
  w.slider('height', 'height');
  w.set('radius', desktopSlider(w, 'border_radius') ?? { size: 0, unit: 'px' });
  w.set('padding', { top: 35, right: 35, bottom: 35, left: 35, unit: 'px', linked: true });
  w.dimensions('padding_a', 'padding');
  w.map('alignment_a', 'text_align', only(textAlign(ctx), ['left', 'center', 'right']));
  w.map('vertical_position_a', 'v_align', VERTICAL);
  for (const [side, label] of [['padding', 'Padding'], ['alignment', 'Alignment'], ['vertical_position', 'Vertical position']] as const) {
    for (const [k] of deviceKeys(`${side}_b`)) {
      const a = w.raw(k.replace(/_b(?=$|_)/, '_a'));
      const b = w.raw(k);
      if (b !== undefined && JSON.stringify(a) !== JSON.stringify(b) && !(side === 'alignment' && a === undefined && b === 'center')) {
        w.note(`${label} of the back side differs from the front; Zadex uses one value for both sides (front kept).`);
      }
    }
  }
  w.boxShadow('shadow_a', 'box_shadow');
  if (bool(w.raw('shadow_b_box_shadow_type'))) {
    if (!bool(w.raw('shadow_a_box_shadow_type'))) w.boxShadow('shadow_b', 'box_shadow');
    else if (JSON.stringify(w.raw('shadow_a_box_shadow')) !== JSON.stringify(w.raw('shadow_b_box_shadow'))) w.note('The back side box shadow differs from the front; Zadex uses one shadow (front kept).');
  }
  w.consume('shadow_b_*');

  // Front / back backgrounds (Elementor's stylesheet colors when nothing is stored), overlays, borders.
  convertBackground(w, 'background_a', 'front_background', { allow: ['classic', 'gradient'] });
  convertBackground(w, 'background_b', 'back_background', { allow: ['classic', 'gradient'] });
  for (const k of Object.keys(w.settings)) if (/^(front|back)_background@/.test(k)) delete w.settings[k];
  for (const [dst, color] of [['front_background', '#1abc9c'], ['back_background', '#4054b2']] as const) {
    const bg = w.settings[dst] as Record<string, unknown> | undefined;
    if (!bg || typeof bg !== 'object') w.set(dst, { type: 'classic', color });
    else if (bg.type === 'classic' && (bg.color === undefined || bg.color === '')) w.set(dst, { ...bg, color });
  }
  w.color('background_overlay_a', 'front_overlay');
  w.color('background_overlay_b', 'back_overlay');
  for (const side of ['a', 'b'] as const) {
    const dst = side === 'a' ? 'front_border' : 'back_border';
    w.border(`border_${side}`, dst);
    for (const k of Object.keys(w.settings)) if (k.startsWith(`${dst}@`)) delete w.settings[k];
  }
  for (const side of ['a', 'b']) {
    if (typeof w.raw(`background_overlay_${side}_blend_mode`) === 'string' && w.raw(`background_overlay_${side}_blend_mode`) !== '') w.note('Overlay blend modes are not available on the Zadex flip box.');
    if (bool(w.raw(`background_overlay_${side}_filters_css_filter`))) w.note('Overlay CSS filters are not available on the Zadex flip box.');
  }
  w.consume('background_overlay_a_*', 'background_overlay_b_*');

  // Graphic.
  w.color('icon_primary_color', 'front_icon_color');
  w.slider('icon_size', 'front_icon_size');
  w.slider('image_width', 'front_image_width', undefined, '%');

  // Texts.
  w.color('title_color_a', 'front_title_color');
  w.typography('title_typography_a', 'front_title_typography');
  w.color('description_color_a', 'front_description_color');
  w.typography('description_typography_a', 'front_description_typography');
  w.color('title_color_b', 'back_title_color');
  w.typography('title_typography_b', 'back_title_typography');
  w.color('description_color_b', 'back_description_color');
  w.typography('description_typography_b', 'back_description_typography');

  // Button (Elementor: outlined white button, `button_size` sm).
  const size = String(w.get('button_size') || 'sm');
  const filled = buttonStyles(w, { color: 'button_color', bg: 'button_bg', border: 'button_border', typography: 'button_typography', padding: 'button_padding' });
  w.set('button_skin', filled ? 'filled' : 'outline');
  buttonPreset(w, size, { padding: 'button_padding', typography: 'button_typography', border: 'button_border' });
  if (slider(w.raw('icon_rotate'))?.size || slider(w.raw('icon_padding')) || dimensions(w.raw('icon_border_radius'))) w.note('Icon padding / rotation / radius are not available on the Zadex flip box.');
  w.consume('icon_rotate*', 'icon_padding*', 'icon_border_radius*');
  return w.finish();
});
