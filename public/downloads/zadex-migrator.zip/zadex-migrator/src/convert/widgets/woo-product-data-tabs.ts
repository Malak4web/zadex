import { registerWidget } from '../registry';
import type { ElementWriter } from '../context';
import { deviceKeys } from '../responsive';
import { slider } from '../values';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { borderColor, flatColor, isObj, looseBorder, noteIfSet } from './_woo-product';
import { typographyAlt } from './_marketing';

/**
 * Panel styles shared with `woocommerce-product-additional-information` (panel text color / typography).
 * Exported for that mapper.
 */
export function panelText(w: ElementWriter, colorKeys: string[], typoPrefixes: string[]): void {
  flatColor(w, colorKeys, 'panel_color');
  typographyAlt(w, typoPrefixes, 'panel_typography');
}

/**
 * Elementor Pro `woocommerce-product-data-tabs` -> Zadex `product-data-tabs` (WooCommerce's own tabs markup on
 * both sides). Verified against Elementor Pro 3.33.2:
 *  - tabs: `tab_text_color`, `tab_bg_color`, `tabs_border_color` (tabs + panel border), `active_tab_text_color`,
 *    `active_tab_bg_color` (active tab + panel background), `active_tabs_border_color` (active tab + panel border),
 *    `tab_typography_*`, `tab_border_radius` (slider, top corners only);
 *  - panel: `text_color`, `content_typography_*`, `heading_color` / `content_heading_typography_*` (panel h2),
 *    `panel_border_width` (dimensions), `panel_border_radius` (dimensions), `panel_box_shadow_*`. Pro has no panel
 *    background / padding of its own and no switches to hide built-in tabs (the Zadex switches stay on).
 */
registerWidget('woocommerce-product-data-tabs', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-data-tabs');
  if (off) return off;
  const w = ctx.writer(source, 'product-data-tabs');
  markPro(w);

  // Tabs
  flatColor(w, ['tab_text_color'], 'tab_color');
  flatColor(w, ['active_tab_text_color'], 'tab_active_color');
  flatColor(w, ['tab_bg_color'], 'tab_bg');
  flatColor(w, ['active_tab_bg_color'], 'tab_active_bg');
  typographyAlt(w, ['tab_typography'], 'tab_typography');
  borderColor(w, ['tabs_border_color'], 'tab_border');
  for (const [key, bp] of deviceKeys('tab_border_radius')) {
    const s = slider(w.raw(key));
    if (!s || typeof s.size !== 'number') continue;
    const cur = w.settings[bp ? `tab_border@${bp}` : 'tab_border'];
    const radius = { top: s.size, right: s.size, bottom: 0, left: 0, unit: s.unit, linked: false };
    w.set('tab_border', { ...(isObj(cur) ? cur : {}), radius }, { bp });
  }

  // Panel: Elementor's active tab background and the (active) tabs border color also style the panel.
  panelText(w, ['text_color'], ['content_typography']);
  const activeBg = w.settings.tab_active_bg;
  if (activeBg !== undefined) w.set('panel_bg', activeBg);
  looseBorder(w, { width: 'panel_border_width', radius: 'panel_border_radius' }, 'panel_border');
  const activeBorder = w.has('active_tabs_border_color') || Boolean(w.globalRef('active_tabs_border_color'));
  borderColor(w, [activeBorder ? 'active_tabs_border_color' : 'tabs_border_color'], 'panel_border');
  if (activeBorder) w.note('The active tab border color is not carried over (only the panel border uses it).');
  noteIfSet(w, ['heading_color', 'content_heading_typography_*'], 'The panel heading styles are not carried over.');
  noteIfSet(w, ['panel_box_shadow_*'], 'The panel box shadow is not carried over.');
  return w.finish();
});
