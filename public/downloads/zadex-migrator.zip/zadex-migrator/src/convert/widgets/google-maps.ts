import { registerWidget } from '../registry';
import { bool, num, slider } from '../values';
import { deviceKeys } from '../responsive';

type Obj = Record<string, unknown>;
const size = (v: unknown, d: number): number => {
  const n = typeof v === 'object' && v !== null ? num((v as Obj).size) : undefined;
  return typeof n === 'number' ? n : d;
};

/**
 * Elementor `google_maps` -> Zadex `google-maps`. Elementor's map is 300px high unless set (stylesheet default) and
 * the iframe takes the mouse wheel (no scroll protection in current Elementor). CSS filters only survive as the
 * Zadex grayscale preset; anything else is reported.
 */
registerWidget('google_maps', (el, ctx) => {
  const w = ctx.writer(el, 'google-maps');
  w.set('address', String(w.get('address') ?? ''));
  if (w.dynamicRef('address')) w.note('The address was bound to a dynamic tag; the static address was kept.');
  const zoom = slider(w.get('zoom'));
  w.set('zoom', typeof zoom?.size === 'number' ? Math.max(1, Math.min(20, Math.round(zoom.size))) : 10);

  for (const [key, bp] of deviceKeys('height')) {
    const v = slider(bp ? w.raw(key) : w.get(key));
    if (v) w.set('height', v, { bp });
    else if (!bp) w.set('height', { size: 300, unit: 'px' });
  }

  // Older Elementor versions had a "Prevent Scroll" switch; current versions let the map take the wheel.
  const prevent = w.raw('prevent_scroll');
  w.set('prevent_scroll', prevent === undefined ? false : bool(prevent));

  // CSS filters (normal + hover).
  w.consume('css_filters_*');
  if (bool(w.raw('css_filters_css_filter'))) {
    const brightness = size(w.get('css_filters_brightness'), 100);
    const contrast = size(w.get('css_filters_contrast'), 100);
    const saturate = size(w.get('css_filters_saturate'), 100);
    const blur = size(w.get('css_filters_blur'), 0);
    const hue = size(w.get('css_filters_hue'), 0);
    const plain = brightness === 100 && contrast === 100 && blur === 0 && hue === 0;
    if (saturate === 0) {
      w.set('filter', 'grayscale(1)');
      if (!plain) {
        w.note('The CSS filter was approximated with the Zadex grayscale preset.');
        w.status('partial');
      }
    } else if (!(plain && saturate === 100)) {
      w.note('Custom CSS filters are not available on the Zadex map (only presets); the filter was not carried over.');
      w.status('partial');
    }
  }
  if (bool(w.raw('css_filters_hover_css_filter'))) {
    w.note('Hover CSS filters are not available on the Zadex map.');
    w.status('partial');
  }
  return w.finish();
});
