import { registerWidget } from '../registry';
import { fallback } from '../fallback';
import type { ConvertContext } from '../context';
import { isBlank } from '../values';
import { PRO_NOTE, markPro } from './_pro';

/**
 * Elementor Pro `template` (`template_id` = an `elementor_library` post id). When `source.libraryTemplates` maps that
 * id to the Zadex post it was migrated to (a `zadex_library` item or a `zadex_template`), the widget becomes a Zadex
 * `template` widget (`template_id`, a string post id like the options of `Zadex\ProContent\TemplateEmbed`). Otherwise
 * the template does not exist in Zadex yet: Elementor's rendered HTML is kept when the server sent it (fallback),
 * else the element is skipped. Both cases name the template id so it can be re-inserted after migrating the template.
 * Key verified against Elementor Pro 3.33.2 (`template_id`, a query control).
 */

/** Zadex post id for an Elementor library template id, or undefined when it was not migrated yet. */
export function resolveLibraryTemplate(ctx: ConvertContext, templateId: unknown): string | undefined {
  if (isBlank(templateId)) return undefined;
  const hit = ctx.source.libraryTemplates?.[String(templateId)];
  if (hit === undefined || hit === null || hit === '') return undefined;
  const id = Number(hit);
  return Number.isInteger(id) && id > 0 ? String(id) : undefined;
}

registerWidget('template', (el, ctx) => {
  const target = resolveLibraryTemplate(ctx, el.settings?.template_id);
  if (target) {
    const w = ctx.writer(el, 'template');
    markPro(w);
    w.raw('template_id');
    w.set('template_id', target);
    return w.finish();
  }
  const id = Number(el.settings?.template_id) || 0;
  const out = fallback(el, ctx);
  const entry = ctx.report.entries.find((e) => e.source === el.id);
  if (entry) {
    entry.notes.push(PRO_NOTE);
    entry.notes.push(
      id
        ? `Elementor template #${id} is embedded here. Migrate that template to the Zadex library, then insert it with the Zadex "Template" widget.`
        : 'The Elementor template widget has no template selected.',
    );
    if (out.length === 0 && id) entry.notes.push('No rendered HTML was sent for the template, so nothing was kept in its place.');
  }
  return out;
});
