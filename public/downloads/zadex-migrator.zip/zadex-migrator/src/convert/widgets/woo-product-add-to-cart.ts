import { registerWidget } from '../registry';
import { deviceKeys } from '../responsive';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { borderColor, borderWithRadius, flatColor, looseBorder, noteIfSet } from './_woo-product';
import { dimensionsAlt, typographyAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-add-to-cart` -> Zadex `add-to-cart`.
 * Verified against Elementor Pro 3.33.2:
 *  - content: `show_quantity` (default yes), `layout` ('' inline default | stacked | auto), `alignment` (R, left /
 *    center / right / justify);
 *  - button: `button_typography_*`, `button_border_*` group + `button_border_radius`, `button_padding`,
 *    `button_text_color` / `button_bg_color` / `button_border_color` and `*_hover` variants, `button_transition`;
 *    "View cart" link `view_cart_color` / `view_cart_typography_*` / `view_cart_spacing`;
 *  - quantity: `spacing` (button gap), `quantity_typography_*`, `quantity_border_*` group + `quantity_border_radius`,
 *    `quantity_padding`, `quantity_text_color` / `quantity_bg_color` / `quantity_border_color` and `*_focus`
 *    variants, `quantity_transition` (no quantity width control);
 *  - variations: `variations_width`, `variations_spacing`, `variations_space_between`, label color
 *    `variations_label_color_focus` (Pro's id for the normal label color), `variations_label_typography_*`,
 *    `variations_select_color`, `variations_select_bg_color`, `variations_select_border_color`,
 *    `variations_select_border_radius` (slider), `variations_select_typography_*`.
 */
registerWidget('woocommerce-product-add-to-cart', (source, ctx) => {
  const off = wooGuard(source, ctx, 'add-to-cart');
  if (off) return off;
  const w = ctx.writer(source, 'add-to-cart');
  markPro(w);

  w.set('show_quantity', w.get('show_quantity') === 'yes');
  const layout = String(w.get('layout') ?? '');
  if (layout === 'stacked') w.set('layout', 'stacked');
  else {
    w.set('layout', 'inline');
    if (layout === 'auto') w.note('Layout "auto" became "inline".');
    else if (layout !== '') w.note(`Layout "${layout}" has no Zadex equivalent; "inline" is used.`);
  }

  // Alignment: Zadex has no alignment control; "justify" (full-width button) becomes a 100% minimum width.
  for (const [key, bp] of deviceKeys('alignment')) {
    const v = w.raw(key);
    if (v === 'justify') w.set('button_width', { size: 100, unit: '%' }, { bp });
    else if (typeof v === 'string' && v !== '') w.note(`Button alignment "${v}" is not carried over; align the widget with its container.`);
  }

  // Button
  typographyAlt(w, ['button_typography'], 'button_typography');
  flatColor(w, ['button_text_color'], 'button_color');
  flatColor(w, ['button_bg_color'], 'button_bg');
  flatColor(w, ['button_text_color_hover'], 'button_color', 'hover');
  flatColor(w, ['button_bg_color_hover'], 'button_bg', 'hover');
  borderWithRadius(w, 'button_border', 'button_border_radius', 'button_border');
  borderColor(w, ['button_border_color_hover'], 'button_border', 'hover');
  dimensionsAlt(w, ['button_padding'], 'button_padding');
  w.consume('button_transition');
  noteIfSet(w, ['view_cart_color', 'view_cart_spacing', 'view_cart_typography_*'], 'The "View cart" link styles are not carried over.');

  // Quantity
  typographyAlt(w, ['quantity_typography'], 'qty_typography');
  flatColor(w, ['quantity_text_color'], 'qty_color');
  flatColor(w, ['quantity_bg_color'], 'qty_bg');
  borderWithRadius(w, 'quantity_border', 'quantity_border_radius', 'qty_border');
  noteIfSet(w, ['quantity_text_color_focus', 'quantity_bg_color_focus', 'quantity_border_color_focus'], 'The quantity field focus styles are not carried over.');
  w.consume('quantity_transition');
  noteIfSet(w, ['quantity_padding'], 'The quantity field padding is not carried over.');
  noteIfSet(w, ['spacing'], 'The space between the quantity field and the button is not carried over.');

  // Variations
  typographyAlt(w, ['variations_label_typography'], 'var_label_typography');
  flatColor(w, ['variations_label_color_focus'], 'var_label_color');
  flatColor(w, ['variations_select_bg_color'], 'var_select_bg');
  looseBorder(w, { color: 'variations_select_border_color', radius: 'variations_select_border_radius' }, 'var_select_border');
  noteIfSet(w, ['variations_select_color', 'variations_select_typography_*'], 'The variation select text color / typography is not carried over.');
  noteIfSet(w, ['variations_width', 'variations_spacing', 'variations_space_between'], 'The variations table width / spacing is not carried over.');
  return w.finish();
});
