import { registerWidget } from '../registry';
import { flexAlign, textAlign } from '../align';
import { bool, isBlank, url } from '../values';
import { itemIdFor, only, repeaterItems, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { VERTICAL, buttonStyles, desktopSlider, field, mediaOf, posInt } from './_marketing';

type Obj = Record<string, unknown>;

/** Repeater field defaults of Elementor Pro 3.33 (`slides[]`), used for fields a stored row does not carry. */
const FIELD_DEFAULTS = {
  heading: 'Slide Heading',
  description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
  button_text: 'Click Here',
  background_color: '#bbbbbb',
  background_overlay_color: 'rgba(0,0,0,0.5)',
};
const HEADING_TAGS = ['h1', 'h2', 'h3', 'h4', 'div'];
const BUTTON_SIZES: Record<string, string> = { xs: 'sm', sm: 'sm', md: 'md', lg: 'lg', xl: 'lg' };

/**
 * Elementor Pro `slides` -> Zadex `slides`. Verified against Elementor Pro 3.33.2 (dev/reference/elementor-pro-controls.json):
 * repeater `slides` {heading, description, button_text, link, link_click slide|button, background_color (#bbbbbb),
 * background_image, background_size (cover), background_ken_burns, zoom_direction (in), background_overlay,
 * background_overlay_color, background_overlay_blend_mode, custom_style, horizontal_position, vertical_position,
 * text_align, content_color, repeater_text_shadow}; widget `slides_height` (400px), `slides_title_tag` /
 * `slides_description_tag` (div), `navigation` (both), `autoplay` / `pause_on_hover` / `pause_on_interaction` /
 * `infinite` (yes), `autoplay_speed` (5000), `transition` slide|fade, `transition_speed` (500), `content_animation`
 * (fadeInUp), style `content_max_width` (66%), `slides_padding`, `slides_horizontal_position`,
 * `slides_vertical_position`, `slides_text_align`, heading (primary typography) / description (secondary) / button
 * (accent; `button_background` group) styles, `arrows_*`, `dots_*`. Real defaults come from `w.get()`.
 */
registerWidget('slides', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    heading_typography_typography: 'globals/typography?id=primary',
    description_typography_typography: 'globals/typography?id=secondary',
    button_typography_typography: 'globals/typography?id=accent',
  });
  const w = ctx.writer(el, 'slides');
  markPro(w);
  const items = repeaterItems(w.get('slides'));
  if (!items.length) w.note('The slides widget has no slides.');
  const hAlign = only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']);
  const tAlign = only(textAlign(ctx), ['left', 'center', 'right']);
  const blend = new Set<string>();
  let textShadow = false;

  const slides = items.map((item, i) => {
    const out: Obj = {
      _id: itemIdFor(ctx, el, item, i),
      heading: field(item, 'heading', FIELD_DEFAULTS.heading),
      description: field(item, 'description', FIELD_DEFAULTS.description),
      button_text: field(item, 'button_text', FIELD_DEFAULTS.button_text),
      link: url(item.link) ?? { url: '', target: '', nofollow: false },
      link_click: item.link_click === 'button' ? 'button' : 'slide', // Elementor default: whole slide
    };
    // Background: color + optional image, centered like Elementor's `.swiper-slide-bg`.
    const bg: Obj = { type: 'classic' };
    const color = field(item, 'background_color', FIELD_DEFAULTS.background_color);
    if (color !== '') bg.color = color;
    const image = mediaOf(ctx, item.background_image);
    if (image) {
      bg.image = image;
      bg.position = 'center center';
      bg.size = field(item, 'background_size', 'cover') || 'cover';
    }
    out.background = bg;
    out.ken_burns = Boolean(image) && bool(item.background_ken_burns);
    out.ken_burns_direction = item.zoom_direction === 'out' ? 'out' : 'in';
    if (bool(item.background_overlay)) {
      out.overlay = field(item, 'background_overlay_color', FIELD_DEFAULTS.background_overlay_color) || FIELD_DEFAULTS.background_overlay_color;
      if (typeof item.background_overlay_blend_mode === 'string' && item.background_overlay_blend_mode !== '') blend.add(item.background_overlay_blend_mode);
    } else out.overlay = '';
    out.custom_style = bool(item.custom_style);
    if (out.custom_style) {
      // The per-slide positions have no default in Pro (empty = centered by the slide's flex box).
      out.h_position = hAlign[String(item.horizontal_position ?? '')] ?? 'center';
      out.v_position = VERTICAL[String(item.vertical_position ?? '')] ?? 'center';
      out.text_align = tAlign[String(item.text_align ?? '')] ?? 'center';
      if (typeof item.content_color === 'string' && item.content_color !== '') out.text_color = item.content_color;
      if (!isBlank(item.repeater_text_shadow_text_shadow_type)) textShadow = true;
    }
    return out;
  });
  w.set('slides', slides);
  for (const mode of blend) w.note(`Slide overlay blend mode "${mode}" is not available in Zadex.`);
  if (textShadow) w.note('Per-slide text shadows are not available in Zadex.');

  // Content.
  const tag = String(w.get('slides_title_tag') || 'div');
  w.set('heading_tag', HEADING_TAGS.includes(tag) ? tag : tag === 'h5' || tag === 'h6' ? 'h4' : 'div');
  if (!HEADING_TAGS.includes(tag)) w.note(`Slide heading tag "${tag}" is not available in Zadex.`);
  const descTag = w.raw('slides_description_tag');
  if (typeof descTag === 'string' && descTag !== '' && descTag !== 'div') w.note(`Slide description tag "${descTag}" is not carried over (Zadex uses a paragraph).`);

  // Height (Elementor default 400px).
  w.slider('slides_height', 'height');

  // Slider settings.
  const nav = String(w.get('navigation') ?? 'both');
  w.set('arrows', nav === 'both' || nav === 'arrows');
  w.set('dots', nav === 'both' || nav === 'dots');
  const autoplay = bool(w.get('autoplay'));
  w.set('autoplay', autoplay);
  if (autoplay) {
    w.set('autoplay_speed', posInt(w.get('autoplay_speed')) ?? 5000);
    w.set('pause_on_hover', bool(w.get('pause_on_hover')));
    if (w.raw('pause_on_interaction') === '') w.note('Zadex always pauses autoplay after an interaction.');
  } else w.consume('autoplay_speed', 'pause_on_hover', 'pause_on_interaction');
  // Elementor has no pause button; Zadex's would add a visible control.
  w.set('pause_button', false);
  w.set('loop', bool(w.get('infinite')));
  w.set('effect', w.get('transition') === 'fade' ? 'fade' : 'slide');
  w.set('speed', posInt(w.get('transition_speed')) ?? 500);
  const anim = w.get('content_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`The slide content animation "${anim}" is not available in Zadex (content appears without animation).`);
  w.consume('slides_name');

  // Slide layout (style tab).
  w.slider('content_max_width', 'content_width', undefined, '%');
  w.dimensions('slides_padding', 'padding');
  w.map('slides_horizontal_position', 'h_position', hAlign);
  w.map('slides_vertical_position', 'v_position', VERTICAL);
  w.map('slides_text_align', 'text_align', tAlign);
  if (bool(w.raw('text_shadow_text_shadow_type'))) w.note('The slide text shadow is not available in Zadex.');
  w.consume('text_shadow_text_shadow_type', 'text_shadow_text_shadow');

  // Heading / description.
  w.slider('heading_spacing', 'heading_spacing');
  w.color('heading_color', 'heading_color');
  w.typography('heading_typography', 'heading_typography');
  w.slider('description_spacing', 'description_spacing');
  w.color('description_color', 'description_color');
  w.typography('description_typography', 'description_typography');

  // Button (Elementor's slide button is outlined: transparent with a 2px border, unless a background is set).
  const size = String(w.get('button_size') || 'sm');
  w.set('button_size', BUTTON_SIZES[size] ?? 'sm');
  const filled = buttonStyles(w, { color: 'button_color', bg: 'button_bg', border: 'button_border', typography: 'button_typography', padding: 'button_padding' });
  w.set('button_skin', filled ? 'filled' : 'outline');

  // Navigation styles.
  const arrows = nav === 'both' || nav === 'arrows';
  const dots = nav === 'both' || nav === 'dots';
  if (w.get('arrows_position') === 'outside' && arrows) w.note('Arrows are placed inside the slides in Zadex.');
  w.slider('arrows_size', 'arrow_size');
  w.color('arrows_color', 'arrow_color');
  if (w.get('dots_position') === 'outside' && dots) w.note('Dots are placed inside the slides in Zadex.');
  const dotSize = desktopSlider(w, 'dots_size');
  if (dotSize) w.set('dot_size', dotSize);
  w.color('dots_color', 'dot_active_color');
  w.color('dots_color_inactive', 'dot_color');
  if (desktopSlider(w, 'dots_gap')) w.note('The dots spacing is not available on the Zadex slides.');
  return w.finish();
});
