import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { deviceKeys } from '../responsive';
import { slider, url } from '../values';
import { markPro, firstOf } from './_pro';
import { proNumber, proSwitch, proText, proVal } from './_pro-content';
import { only, unitless } from './_shared';

/** Elementor trigger -> Zadex trigger. `none` = Elementor plays the animation on page load. */
const TRIGGERS: Record<string, string> = {
  arriving_to_viewport: 'viewport',
  on_click: 'click',
  on_hover: 'hover',
  bind_to_scroll: 'scroll',
  none: 'autoplay',
};

/**
 * Elementor Pro `lottie` -> Zadex `lottie`. Keys verified against Elementor Pro 3.33.2 (defaults from
 * elementor-defaults.json): `source` media_file|external_url (media_file), `source_json` media, `source_external_url`
 * url, `link_to` none|custom, `custom_link`, `trigger` arriving_to_viewport|on_click|on_hover|bind_to_scroll|none
 * (arriving_to_viewport), `viewport` {sizes:{start:0,end:100}}, `effects_relative_to` viewport|page, `loop` (off),
 * `number_of_times`, `link_timeout`, `on_hover_out` default|reverse|pause, `hover_area`
 * animation|column|section|container, `reverse_animation`, `start_point` (0%) / `end_point` (100%), `play_speed`
 * ({size:1}), `renderer` svg|canvas, `lazyload`, `caption_source` none|title|caption|custom / `caption`; style `width`,
 * `space` (max width), `align` R (center), `opacity` / `opacity_hover`, `css_filters_*`, caption styles.
 */
registerWidget('lottie', (el, ctx) => {
  const w = ctx.writer(el, 'lottie');
  markPro(w);

  const source = proText(w, 'source', 'media_file');
  if (source === 'external_url') {
    const ext = url(w.raw('source_external_url'));
    w.set('source', 'url');
    w.set('json_url', ext?.url ?? '');
    if (!ext) w.note('The external Lottie URL is empty.');
  } else {
    const file = ctx.media(w.raw('source_json'));
    if (file) {
      w.set('source', 'file');
      w.set('file', { id: file.id, url: file.url, alt: file.alt });
    } else {
      // No file chosen: Elementor plays its bundled demo animation; Zadex shows its own demo for an empty URL.
      w.set('source', 'url');
      w.set('json_url', '');
      w.note('No Lottie file was chosen (Elementor showed its demo animation).');
    }
  }
  w.consume('source_json', 'source_external_url');

  if (proText(w, 'link_to', 'none') === 'custom') {
    const link = url(w.raw('custom_link'));
    if (link) w.set('link', link);
    if (w.has('link_timeout')) w.note('The link delay (play the animation before following the link) is not available in Zadex.');
  }
  w.consume('custom_link', 'link_timeout');

  const trigger = proText(w, 'trigger', 'arriving_to_viewport');
  w.set('trigger', TRIGGERS[trigger] ?? 'viewport');
  if (!TRIGGERS[trigger]) w.note(`Trigger "${trigger}" has no Zadex equivalent; "viewport" is used.`);
  const range = w.raw('viewport');
  const sizes = typeof range === 'object' && range !== null ? (range as { sizes?: { start?: unknown; end?: unknown } }).sizes : undefined;
  if (sizes && typeof sizes === 'object' && (Number(sizes.start ?? 0) > 0 || Number(sizes.end ?? 100) < 100)) {
    w.note('The viewport start / end range is not available in Zadex (the animation plays while visible).');
  }
  if (w.has('effects_relative_to') && w.raw('effects_relative_to') !== 'viewport') w.note('Scroll effects relative to the whole page are approximated (Zadex follows the viewport).');
  const hoverOut = w.raw('on_hover_out');
  if (typeof hoverOut === 'string' && hoverOut !== '' && hoverOut !== 'default') w.note(`The "${hoverOut}" behavior when the mouse leaves is not available in Zadex.`);
  const hoverArea = w.raw('hover_area');
  if (typeof hoverArea === 'string' && hoverArea !== '' && hoverArea !== 'animation') w.note(`Hovering the whole ${hoverArea} is not available in Zadex (the animation itself is the hover area).`);
  w.consume('viewport', 'effects_relative_to');

  const loop = proSwitch(w, 'loop', false);
  w.set('loop', loop);
  const times = proNumber(w.raw('number_of_times'));
  if (loop && times !== undefined && times > 0) w.set('loop_count', Math.round(times));
  const speed = proNumber(proVal(w, 'play_speed', { size: 1 }));
  if (speed !== undefined && speed > 0) w.set('speed', speed);
  w.set('reverse', proSwitch(w, 'reverse_animation', false));
  const start = proNumber(w.raw('start_point'));
  const end = proNumber(w.raw('end_point'));
  if ((start !== undefined && start > 0) || (end !== undefined && end < 100)) {
    w.note('The start / end points (percent of the animation) were not carried over: Zadex segments use frame numbers.');
    w.status('partial');
  }
  w.consume('renderer', 'lazyload');

  const caption = proText(w, 'caption_source', 'none');
  if (caption !== 'none' && caption !== '') {
    w.note('Lottie captions are not available in Zadex.');
    w.status('partial');
  }
  w.consume('caption', 'caption_*');

  w.slider('width', 'width');
  for (const [key, bp] of deviceKeys('space')) {
    if (w.raw(key) !== undefined && !w.settings[bp ? `width@${bp}` : 'width']) {
      const s = slider(w.raw(key));
      if (s) w.set('width', s, { bp });
    }
  }
  if (w.has('space')) w.note('The maximum width was used as the width.');
  w.map('align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  const opacity = unitless(w.raw('opacity'));
  if (opacity) w.set('opacity', opacity);
  const opacityHover = unitless(firstOf(w, 'opacity_hover'));
  if (opacityHover) w.set('opacity', opacityHover, { state: 'hover' });
  if (w.raw('css_filters_css_filter') === 'custom' || w.raw('css_filters_hover_css_filter') === 'custom') w.note('CSS filters are not available on the Zadex Lottie widget.');
  w.consume('css_filters_*', 'css_filters_hover_*', 'background_hover_transition');
  return w.finish();
});
