import { registerWidget } from '../registry';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement, Settings, ZElement } from '../types';
import { slider, url } from '../values';
import { markPro } from './_pro';
import { proText, proVal } from './_pro-content';
import { isObj, itemIdFor, repeaterItems } from './_shared';

type Obj = Record<string, unknown>;

/**
 * Elementor link-in-bio platforms (`Social_Network_Provider` constants) -> Zadex `social-icons` networks. Platforms
 * without a Zadex network (Telephone, Messenger, Waze, Apple Music, SoundCloud, SMS, Viber, Skype, File Download, vCard)
 * use the generic "website" icon with the platform name as label.
 */
const NETWORKS: Record<string, string> = {
  Facebook: 'facebook',
  'X (Twitter)': 'x-twitter',
  Instagram: 'instagram',
  LinkedIn: 'linkedin',
  Pinterest: 'pinterest',
  YouTube: 'youtube',
  TikTok: 'tiktok',
  WhatsApp: 'whatsapp',
  Spotify: 'spotify',
  Behance: 'behance',
  Dribbble: 'dribbble',
  Vimeo: 'vimeo',
  Email: 'email',
  Url: 'website',
};

const TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div', 'span'];
const ICON_SIZES: Record<string, number> = { small: 16, medium: 20, large: 26 };
const CORNERS: Record<string, number> = { sharp: 0, rounded: 12, round: 999 };

/**
 * Link built the way Elementor's link-in-bio renderer does (`get_formatted_link_based_on_type_for_cta` /
 * `get_formatted_link_for_icon`): mail / tel / Messenger / Waze / WhatsApp / file links, else the URL field.
 */
function platformLink(item: Obj, prefix: 'cta_link' | 'icon', platform: string, ctx: ConvertContext): string {
  const str = (k: string) => (typeof item[`${prefix}_${k}`] === 'string' ? String(item[`${prefix}_${k}`]).trim() : '');
  switch (platform) {
    case 'Email': {
      const mail = str('mail');
      if (!mail) return '';
      const subject = str('mail_subject');
      const body = str('mail_body');
      let link = `mailto:${mail}`;
      if (subject) link += `?subject=${encodeURIComponent(subject)}`;
      if (body) link += `${subject ? '&' : '?'}body=${encodeURIComponent(body)}`;
      return link;
    }
    case 'Telephone':
      return str('number') ? `tel:${str('number')}` : '';
    case 'SMS':
      return str('number') ? `sms:${str('number')}` : '';
    case 'WhatsApp':
      return str('number') ? `https://wa.me/${str('number')}` : '';
    case 'Messenger':
      return str('username') ? `https://m.me/${str('username')}` : '';
    case 'Waze':
      return url(item[`${prefix}_location`])?.url ?? '';
    case 'File Download':
    case 'Save contact (vCard)': {
      const file = item[`${prefix}_file`];
      return (isObj(file) && ctx.media(file)?.url) || '';
    }
    default:
      return url(item[`${prefix}_url`])?.url ?? '';
  }
}

const linkValue = (href: string) => ({ url: href, target: /^https?:/i.test(href) ? '_blank' : '', nofollow: false });

/** Moves the settings written under a temporary id (all breakpoints / states) into a child element's settings. */
function move(w: ElementWriter, tmp: string, target: Settings, dst: string): void {
  for (const key of Object.keys(w.settings)) {
    if (key !== tmp && !key.startsWith(`${tmp}@`) && !key.startsWith(`${tmp}::`)) continue;
    target[dst + key.slice(tmp.length)] = w.settings[key];
    delete w.settings[key];
  }
}

/** Real (non-placeholder) image of a media control. */
function realImage(ctx: ConvertContext, v: unknown) {
  if (!isObj(v) || (!Number(v.id) && typeof v.url === 'string' && /placeholder\.png$/.test(v.url))) return undefined;
  return ctx.media(v);
}

/**
 * Elementor link-in-bio widgets (Pro `link-in-bio-var-2` … `var-7`, free `link-in-bio`) -> a centered Zadex column
 * container holding the identity image (`image`), name / title / about (`heading`), description (`text`), the social
 * icons (`social-icons`) and the CTA links (`bio-links`). Keys verified against Elementor Pro 3.33.2: identity
 * `identity_image` (+ `identity_image_style` profile|cover, `identity_image_shape` circle|square, `identity_image_cover`
 * on var-2), `bio_heading` / `bio_heading_tag`, `bio_title` / `bio_title_tag`, `bio_about` / `bio_about_tag` (var-7),
 * `bio_description`; repeater `icon` {`icon_platform`, `icon_text` (var-7), `icon_url`, `icon_mail*`, `icon_number`,
 * `icon_location`, `icon_username`}; repeater `cta_link` {`cta_link_text`, `cta_link_type`, `cta_link_url`,
 * `cta_link_file`, `cta_link_mail*`, `cta_link_number`, `cta_link_location`, `cta_link_username`} (var-7: one CTA with
 * `cta_section_button_text` + top-level `cta_link_*`; var-6: `image_links` repeater); style `*_text_color`,
 * `*_typography`, `icons_color`, `icons_size` small|medium|large, `cta_links_type` button|link, `cta_links_text_color`,
 * `cta_links_background_color`, `cta_links_show_border` / `_border_width` / `_border_color`, `cta_links_corners`
 * round|rounded|sharp, `cta_links_padding`, `background_border_background_group_*` (container background),
 * `background_show_border`, `advanced_layout_*`.
 */
function linkInBio(el: ElElement, ctx: ConvertContext): ZElement {
  const w = ctx.writer(el, 'container');
  markPro(w);
  const type = el.widgetType ?? 'link-in-bio';
  const children: ZElement[] = [];
  const child = (suffix: string, zType: string, settings: Settings) => {
    const node: ZElement = { id: ctx.idFor(el.id, suffix), type: zType, settings, children: [] };
    children.push(node);
    return node;
  };

  w.set('direction', 'column');
  w.set('align', 'center');
  w.background('background_border_background_group', 'background');
  if (w.raw('background_border_background_overlay_group_background')) w.note('The link-in-bio background overlay is not carried over.');
  w.consume('background_border_background_overlay_group_*', 'background_overlay_opacity');
  if (w.raw('background_show_border') === 'yes') {
    const width = slider(w.get('background_border_width'));
    const color = proText(w, 'background_border_color', '#000000');
    const n = typeof width?.size === 'number' ? width.size : 1;
    w.set('border', { style: 'solid', width: { top: n, right: n, bottom: n, left: n, unit: 'px', linked: true }, color });
  }
  w.consume('background_show_border', 'background_border_width', 'background_border_color');
  const contentWidth = slider(w.raw('advanced_layout_content_width'));
  if (contentWidth) w.set('content_width', contentWidth);
  if (w.has('advanced_layout_width') || w.raw('advanced_layout_full_width_custom') === 'yes' || w.raw('advanced_layout_full_screen_height') === 'yes') {
    w.note('The link-in-bio layout width / full-screen height options are not carried over (use the container width settings).');
  }
  w.consume('advanced_layout_*');

  // Identity: cover image (var-2 `identity_image_cover`, or `identity_image_style: cover`) and profile image.
  const coverImg = realImage(ctx, w.raw('identity_image_cover'));
  if (coverImg) child('cov', 'image', { image: { id: coverImg.id, url: coverImg.url, alt: coverImg.alt }, size: 'full', width: { size: 100, unit: '%' }, lightbox: false });
  w.consume('identity_image_cover', 'identity_image_cover_position', 'identity_image_bottom_*', 'identity_section_style_cover_divider_*');
  const img = realImage(ctx, w.raw('identity_image'));
  if (img) {
    const cover = proText(w, 'identity_image_style', 'profile') === 'cover';
    const settings: Settings = { image: { id: img.id, url: img.url, alt: img.alt }, size: cover ? 'full' : 'medium', align: 'center', lightbox: false };
    const size = slider(w.raw(cover ? 'identity_image_height' : 'identity_image_size'));
    if (cover) settings.width = { size: 100, unit: '%' };
    else if (size) settings.width = { size: size.size, unit: 'px' };
    const border: Obj = {};
    if (!cover && proText(w, 'identity_image_shape', 'circle') === 'circle') {
      border.radius = { top: 50, right: 50, bottom: 50, left: 50, unit: '%', linked: true };
    }
    if (w.raw('identity_image_show_border') === 'yes') {
      const bw = slider(w.get('identity_image_border_width'));
      const n = typeof bw?.size === 'number' ? bw.size : 1;
      Object.assign(border, { style: 'solid', width: { top: n, right: n, bottom: n, left: n, unit: 'px', linked: true }, color: proText(w, 'identity_image_border_color', '#000000') });
    }
    if (Object.keys(border).length) settings.border = border;
    child('img', 'image', settings);
  }
  w.consume('identity_image', 'identity_image_position', 'identity_image_style', 'identity_image_shape', 'identity_image_size', 'identity_image_height', 'identity_image_show_border', 'identity_image_border_*');

  // Bio texts.
  const heading = (key: string, suffix: string, defTag: string) => {
    const text = proText(w, key).trim();
    w.consume(`${key}_tag`, `${key}_text_color`, `${key}_typography_*`);
    if (text === '') return;
    const tag = proText(w, `${key}_tag`, defTag);
    const settings: Settings = { text, tag: TAGS.includes(tag) ? tag : defTag, align: 'center' };
    w.color(`${key}_text_color`, `zxm_tmp_${suffix}_color`);
    move(w, `zxm_tmp_${suffix}_color`, settings, 'color');
    w.typography(`${key}_typography`, `zxm_tmp_${suffix}_typo`);
    move(w, `zxm_tmp_${suffix}_typo`, settings, 'typography');
    child(suffix, 'heading', settings);
  };
  heading('bio_heading', 'name', 'h2');
  heading('bio_title', 'ttl', 'h3');
  heading('bio_about', 'abt', 'h3');
  const description = proText(w, 'bio_description').trim();
  if (description !== '') {
    const settings: Settings = { content: `<p>${escapeHtml(description).replace(/\r?\n/g, '<br>')}</p>`, align: 'center' };
    w.color('bio_description_text_color', 'zxm_tmp_desc_color');
    move(w, 'zxm_tmp_desc_color', settings, 'color');
    w.typography('bio_description_typography', 'zxm_tmp_desc_typo');
    move(w, 'zxm_tmp_desc_typo', settings, 'typography');
    child('dsc', 'text', settings);
  }
  w.consume('bio_description_*');

  // Social icons.
  const generic: string[] = [];
  const icons = repeaterItems(proVal(w, 'icon', [])).map((item, i) => {
    const platform = String(item.icon_platform ?? 'Facebook');
    const network = NETWORKS[platform];
    if (!network) generic.push(platform);
    const label = typeof item.icon_text === 'string' && item.icon_text !== '' ? item.icon_text : platform;
    return { _id: itemIdFor(ctx, el, item, i), network: network ?? 'website', link: linkValue(platformLink(item, 'icon', platform, ctx)), label };
  });
  if (icons.length) {
    const settings: Settings = { items: icons, align: 'center', shape: 'circle' };
    const size = ICON_SIZES[proText(w, 'icons_size', 'small')];
    if (size) settings.size = { size, unit: 'px' };
    w.color('icons_color', 'zxm_tmp_icons_color');
    if (w.settings.zxm_tmp_icons_color !== undefined) settings.scheme = 'custom';
    move(w, 'zxm_tmp_icons_color', settings, 'icon_color');
    child('soc', 'social-icons', settings);
  }
  if (generic.length) w.note(`Contact platforms without a Zadex social network use the generic website icon: ${[...new Set(generic)].join(', ')}.`);
  if (w.has('icons_per_row') || w.has('icons_color_background') || w.raw('icons_border_show_border') === 'yes' || w.raw('icons_typography_typography') === 'custom') {
    w.note('Icon grid columns, icon background / border and icon label typography are not carried over.');
  }
  w.consume('icons_*');

  // CTA links (bio-links). var-7 has one CTA with top-level `cta_link_*` keys.
  let ctas = repeaterItems(proVal(w, 'cta_link', []));
  if (type === 'link-in-bio-var-7') {
    const single: Obj = { cta_link_text: proText(w, 'cta_section_button_text') };
    for (const k of ['type', 'file', 'url', 'mail', 'mail_subject', 'mail_body', 'number', 'location', 'username']) single[`cta_link_${k}`] = proVal(w, `cta_link_${k}`);
    ctas = single.cta_link_text ? [single] : [];
  }
  const links = ctas.map((item, i) => {
    const platform = String(item.cta_link_type ?? 'Url');
    return { _id: itemIdFor(ctx, el, item, i), label: typeof item.cta_link_text === 'string' ? item.cta_link_text : '', sub_label: '', link: linkValue(platformLink(item, 'cta_link', platform, ctx)), icon: { library: '', value: '' } };
  });
  // var-6: image links (images with links) -> bio-links items labelled with the image alt text.
  const imageLinks = type === 'link-in-bio-var-6' ? repeaterItems(proVal(w, 'image_links', [])) : [];
  if (imageLinks.length) {
    imageLinks.forEach((item, i) => {
      const media = realImage(ctx, item.image_links_image);
      const href = url(item.image_links_url)?.url ?? '';
      if (!media && !href) return;
      links.push({ _id: itemIdFor(ctx, el, item, i + 100), label: media?.alt || href || 'Link', sub_label: '', link: linkValue(href), icon: { library: '', value: '' } });
    });
    w.note('Image links are converted to text links (the images are not shown).');
    w.status('partial');
  }
  w.consume('image_links*');
  if (links.length) {
    const settings: Settings = { items: links, layout: 'list', content_align: 'center' };
    const isButton = proText(w, 'cta_links_type', 'button') === 'button';
    settings.button_style = isButton ? 'filled' : 'soft';
    w.color('cta_links_text_color', 'zxm_tmp_cta_color');
    move(w, 'zxm_tmp_cta_color', settings, 'text_color');
    w.color('cta_links_background_color', 'zxm_tmp_cta_bg');
    move(w, 'zxm_tmp_cta_bg', settings, 'bg_color');
    if (w.raw('cta_links_show_border') === 'yes') {
      const bw = slider(w.get('cta_links_border_width'));
      settings.border_width = { size: typeof bw?.size === 'number' ? bw.size : 1, unit: 'px' };
      settings.border_color = proText(w, 'cta_links_border_color', '#000000');
    }
    if (isButton) {
      const radius = CORNERS[proText(w, 'cta_links_corners', 'sharp')];
      if (radius !== undefined) settings.radius = { size: radius, unit: 'px' };
    }
    w.dimensions('cta_links_padding', 'zxm_tmp_cta_pad');
    move(w, 'zxm_tmp_cta_pad', settings, 'padding');
    w.typography('cta_links_typography', 'zxm_tmp_cta_typo');
    move(w, 'zxm_tmp_cta_typo', settings, 'label_typography');
    child('lnk', 'bio-links', settings);
  }
  if (w.has('cta_links_divider_color') || w.has('cta_links_divider_width')) w.note('The divider between links is not carried over.');
  w.consume('cta_link', 'cta_link_*', 'cta_links_*', 'cta_section_button_text');

  w.note('The link-in-bio widget was rebuilt from Zadex widgets (image, headings, text, social icons, bio links); its Elementor styling is approximated.');
  return w.finish(children);
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

for (const type of ['link-in-bio', 'link-in-bio-var-2', 'link-in-bio-var-3', 'link-in-bio-var-4', 'link-in-bio-var-5', 'link-in-bio-var-6', 'link-in-bio-var-7']) {
  registerWidget(type, linkInBio);
}
