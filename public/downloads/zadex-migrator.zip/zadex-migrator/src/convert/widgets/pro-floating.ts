import { registerWidget } from '../registry';
import { PRO_NOTE } from './_pro';

/**
 * Elementor floating elements (Pro 3.33.2 `contact-buttons-var-1|3…10`, `floating-bars-var-2|3`; free
 * `contact-buttons`, `floating-bars-var-1`). They are fixed-position site overlays (a chat / contact bubble, a top or
 * bottom announcement bar), normally saved as their own "Floating Elements" document. Zadex has no widget for them:
 * site-wide floating buttons (WhatsApp, call, email, link, scroll to top) live in Zadex > Site settings > Floating
 * buttons. The element is skipped (rendered HTML would lose its fixed positioning and scripts) and the report says
 * where to recreate it.
 */
const CONTACT = ['contact-buttons', 'contact-buttons-var-1', 'contact-buttons-var-3', 'contact-buttons-var-4', 'contact-buttons-var-5', 'contact-buttons-var-6', 'contact-buttons-var-7', 'contact-buttons-var-8', 'contact-buttons-var-9', 'contact-buttons-var-10'];
const BARS = ['floating-bars-var-1', 'floating-bars-var-2', 'floating-bars-var-3'];

for (const type of [...CONTACT, ...BARS]) {
  const bar = type.startsWith('floating-bars');
  registerWidget(type, (el, ctx) => {
    ctx.record({
      source: el.id,
      sourceType: type,
      status: 'skipped',
      target: [],
      dropped: [],
      notes: [
        PRO_NOTE,
        bar
          ? `Elementor floating bar "${type}" has no Zadex widget and was skipped. Recreate an announcement bar with a Zadex container (sticky / fixed position) or a popup; site-wide contact buttons are in Zadex > Site settings > Floating buttons.`
          : `Elementor floating contact buttons "${type}" have no Zadex widget and were skipped. Set them up once for the whole site in Zadex > Site settings > Floating buttons (WhatsApp, call, email, link, scroll to top).`,
      ],
    });
    return [];
  });
}
