import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { bool, slider, url } from '../values';
import { iconOf } from './_media-support';
import { itemIdFor, only, repeaterItems, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { buttonPreset, buttonStyles, desktopSlider, dimensionsAlt, field, logicalSide, typographyAlt } from './_marketing';

type Obj = Record<string, unknown>;

/** Elementor Pro `currency_symbol` options -> symbol (Pro's `get_currency_symbol()`). */
const SYMBOLS: Record<string, string> = {
  dollar: '$',
  euro: '€',
  baht: '฿',
  franc: '₣',
  guilder: 'ƒ',
  krona: 'kr',
  lira: '₤',
  peseta: '₧',
  peso: '₱',
  pound: '£',
  real: 'R$',
  ruble: '₽',
  rupee: '₨',
  indian_rupee: '₹',
  shekel: '₪',
  yen: '¥',
  won: '₩',
};
const TITLE_TAGS = ['h2', 'h3', 'h4', 'h5', 'h6', 'div'];

/** Pro's currency / fraction size is a percentage of the price size (`calc(N em / 100)`) -> Zadex em. */
function percentEm(v: unknown): { size: number; unit: string } | undefined {
  const s = slider(v);
  return s && typeof s.size === 'number' ? { size: s.size / 100, unit: 'em' } : undefined;
}

/**
 * Elementor Pro `price-table` -> Zadex `price-table`. Verified against Elementor Pro 3.33.2: `heading`, `sub_heading`,
 * `heading_tag` (h3), `currency_symbol` (dollar … custom, '' = none) + `currency_symbol_custom`, `price` (39.99),
 * `currency_format` ('' = '.', or ','), `sale`, `original_price` (59), `period` (Monthly), repeater `features_list`
 * {item_text, selected_item_icon (far fa-check-circle), item_icon_color}, `button_text`, `link` (#),
 * `footer_additional_info`, `show_ribbon` (yes), `ribbon_title` (Popular), `ribbon_horizontal_position`; styles:
 * header (`header_bg_color` secondary), heading (primary typography), sub heading (secondary), pricing
 * (`pricing_element_*`, price primary typography, `currency_size` / `fractional-part_size` in % of the price,
 * `currency_position` before), original price (secondary / primary), period (secondary / secondary, `period_position`
 * below), features (`features_list_color` / typography text, `list_divider` on, `divider_color` text), footer,
 * button (`button_size` md, accent background / typography, `button_border` group, `button_text_padding`, hover
 * `button_hover_color` / `button_background_hover_*`), additional info (text / text), ribbon (accent background,
 * white text, accent typography, `box_shadow`).
 */
registerWidget('price-table', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    header_bg_color: 'globals/colors?id=secondary',
    heading_typography_typography: 'globals/typography?id=primary',
    sub_heading_typography_typography: 'globals/typography?id=secondary',
    price_typography_typography: 'globals/typography?id=primary',
    original_price_color: 'globals/colors?id=secondary',
    original_price_typography_typography: 'globals/typography?id=primary',
    period_color: 'globals/colors?id=secondary',
    period_typography_typography: 'globals/typography?id=secondary',
    features_list_color: 'globals/colors?id=text',
    features_list_typography_typography: 'globals/typography?id=text',
    divider_color: 'globals/colors?id=text',
    button_typography_typography: 'globals/typography?id=accent',
    button_background_color: 'globals/colors?id=accent',
    additional_info_color: 'globals/colors?id=text',
    additional_info_typography_typography: 'globals/typography?id=text',
    ribbon_bg_color: 'globals/colors?id=accent',
    ribbon_typography_typography: 'globals/typography?id=accent',
  });
  const w = ctx.writer(el, 'price-table');
  markPro(w);

  // Header.
  w.set('title', String(w.get('heading') ?? ''));
  w.set('subtitle', String(w.get('sub_heading') ?? ''));
  const tag = String(w.get('heading_tag') || 'h3');
  const zTag = TITLE_TAGS.includes(tag) ? tag : tag === 'h1' ? 'h2' : 'div';
  if (zTag !== tag) w.note(`Title tag "${tag}" is not available in Zadex; "${zTag}" is used.`);
  w.set('title_tag', zTag);

  // Pricing.
  const symbol = String(w.get('currency_symbol') ?? '');
  w.set('currency', symbol === 'custom' ? String(w.get('currency_symbol_custom') ?? '') : SYMBOLS[symbol] ?? '');
  if (symbol !== 'custom') w.consume('currency_symbol_custom');
  w.set('currency_position', w.get('currency_position') === 'after' ? 'after' : 'before');
  const price = String(w.get('price') ?? '');
  w.set('price', price);
  // Pro splits the price at `currency_format` ('.' or ',') and raises the part after it; Zadex splits at the last
  // '.' or ',' followed by digits.
  const sep = w.get('currency_format') === ',' ? ',' : '.';
  const parts = price.split(sep);
  w.set('fraction', true);
  if (parts.length === 2 && !/^\d+$/.test(parts[1]!)) w.note(`The price fraction "${parts[1]}" may be split differently in Zadex.`);
  if (sep === '.' && /,\d+$/.test(price) && !price.includes('.')) w.note('Elementor shows this price without a raised fraction (decimal separator "."); Zadex raises the part after ",".');
  const sale = bool(w.get('sale'));
  w.set('sale', sale);
  if (sale) w.set('original_price', String(w.get('original_price') ?? ''));
  else w.consume('original_price');
  w.set('period', String(w.get('period') ?? ''));
  w.set('period_position', w.get('period_position') === 'beside' ? 'beside' : 'below');

  // Features.
  const items = repeaterItems(w.get('features_list'));
  let unsupportedIcon = false;
  w.set(
    'features',
    items.map((item, i) => {
      const out: Obj = { _id: itemIdFor(ctx, el, item, i), text: field(item, 'item_text', 'List Item') };
      const raw = item.selected_item_icon === undefined ? { value: 'far fa-check-circle', library: 'fa-regular' } : item.selected_item_icon;
      const ic = iconOf(ctx, raw);
      out.icon = ic ?? { library: '', value: '' };
      if (!ic && raw && typeof raw === 'object' && (raw as Obj).value) unsupportedIcon = true;
      if (typeof item.item_icon_color === 'string' && item.item_icon_color !== '') out.icon_color = item.item_icon_color;
      return out;
    }),
  );
  if (unsupportedIcon) w.note('Some feature icons are not available in Zadex; they were left empty.');

  // Button / footer.
  const buttonText = String(w.get('button_text') ?? '');
  w.set('button_text', buttonText);
  w.set('button_link', url(w.get('link')) ?? { url: '', target: '', nofollow: false });
  w.set('footer_text', String(w.get('footer_additional_info') ?? ''));

  // Ribbon (shown by default in Elementor; no stored position = right).
  const ribbon = bool(w.get('show_ribbon'));
  w.set('ribbon', ribbon);
  if (ribbon) {
    w.set('ribbon_title', String(w.get('ribbon_title') ?? ''));
    w.set('ribbon_position', logicalSide(ctx, w.get('ribbon_horizontal_position') || 'right', 'end'));
  } else w.consume('ribbon_title', 'ribbon_horizontal_position');
  w.set('featured', false);

  // Header styles.
  w.color('header_bg_color', 'header_bg');
  w.dimensions('header_padding', 'header_padding');
  w.color('heading_color', 'title_color');
  w.typography('heading_typography', 'title_typography');
  w.color('sub_heading_color', 'subtitle_color');
  w.typography('sub_heading_typography', 'subtitle_typography');
  // Pro's CSS (widget-price-table.css): heading / sub heading #fff on the header, price #555. The controls have no
  // default, so unset colors must be written or Zadex shows its theme colors (dark title on a dark header, V7).
  if (w.settings.title_color === undefined) w.set('title_color', '#ffffff');
  if (w.settings.subtitle_color === undefined) w.set('subtitle_color', '#ffffff');

  // Pricing styles.
  w.color('pricing_element_bg_color', 'pricing_bg');
  dimensionsAlt(w, ['pricing_element_padding'], 'pricing_padding');
  w.color('price_color', 'price_color');
  if (w.settings.price_color === undefined) w.set('price_color', '#555555');
  w.typography('price_typography', 'price_typography');
  const currencySize = percentEm(desktopSlider(w, 'currency_size'));
  if (currencySize) w.set('currency_size', currencySize);
  const fractionSize = percentEm(desktopSlider(w, 'fractional-part_size'));
  if (fractionSize) w.set('fraction_size', fractionSize);
  for (const [k, def] of [['currency_vertical_position', 'top'], ['fractional_part_vertical_position', 'top'], ['original_price_vertical_position', 'bottom']] as const) {
    const v = w.raw(k);
    if (typeof v === 'string' && v !== '' && v !== def) w.note(`${k} "${v}" is not available in Zadex.`);
  }
  w.color('original_price_color', 'original_color');
  typographyAlt(w, ['original_price_typography'], 'original_typography', false);
  w.color('period_color', 'period_color');
  typographyAlt(w, ['period_typography'], 'period_typography', false);

  // Features styles.
  dimensionsAlt(w, ['features_list_padding'], 'features_padding');
  w.color('features_list_color', 'features_color');
  w.typography('features_list_typography', 'features_typography');
  w.map('features_list_alignment', 'features_align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  const divider = bool(w.get('list_divider'));
  w.set('features_divider', divider);
  if (divider) {
    w.color('divider_color', 'features_divider_color');
    const style = w.get('divider_style');
    if (typeof style === 'string' && style !== 'solid') w.note(`Divider style "${style}" is shown solid in Zadex.`);
    if (w.has('divider_weight') || w.has('divider_width') || w.has('divider_gap')) w.note('The features divider weight / width / gap are not available in Zadex.');
  }
  w.consume('divider_color', 'divider_style', 'divider_weight*', 'divider_width*', 'divider_gap*');
  if (w.has('features_list_bg_color')) w.note('The features list background color is not available in Zadex.');
  if (w.has('footer_bg_color')) w.note('The footer background color is not available in Zadex.');
  w.consume('features_list_bg_color', 'footer_bg_color');

  // Button (Elementor's price table button is inline and centered, not full width).
  const size = String(w.get('button_size') || 'md');
  buttonStyles(w, { color: 'button_color', bg: 'button_bg', border: 'button_border', typography: 'button_typography', padding: 'button_padding', radius: 'button_radius', responsivePadding: false, responsiveTypography: false });
  buttonPreset(w, size, { padding: 'button_padding', typography: 'button_typography', radius: 'button_radius' });
  w.set('button_full', false);
  w.color('additional_info_color', 'footer_color');
  typographyAlt(w, ['additional_info_typography'], 'footer_typography', false);

  // Ribbon styles.
  w.color('ribbon_bg_color', 'ribbon_bg');
  w.color('ribbon_text_color', 'ribbon_color');
  typographyAlt(w, ['ribbon_typography'], 'ribbon_typography', false);
  if (desktopSlider(w, 'ribbon_distance')) w.note('The ribbon distance is not available in Zadex.');
  if (bool(w.raw('box_shadow_box_shadow_type'))) w.note('The ribbon box shadow is not carried over (the Zadex box shadow is on the whole table).');
  w.consume('box_shadow_box_shadow_type', 'box_shadow_box_shadow', 'box_shadow_box_shadow_position');
  return w.finish();
});
