import { registerWidget } from '../registry';

/** Elementor `menu-anchor` -> Zadex `menu-anchor` (`anchor` -> `anchor_id`; Zadex keeps `A-Za-z0-9_-`). */
registerWidget('menu-anchor', (el, ctx) => {
  const w = ctx.writer(el, 'menu-anchor');
  const anchor = String(w.get('anchor') ?? '').trim();
  const clean = anchor.replace(/\s+/g, '-').replace(/[^A-Za-z0-9_-]/g, '');
  w.set('anchor_id', clean);
  if (clean !== anchor) w.note(`The anchor "${anchor}" was changed to "${clean}" (Zadex anchors use letters, digits, "-" and "_"); update links that point to it.`);
  return w.finish();
});
