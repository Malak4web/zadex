import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { wooGuard } from './_woo';
import { flatColor, noteIfSet } from './_woo-product';
import { typographyAlt } from './_marketing';

/**
 * Elementor Pro `woocommerce-product-price` -> Zadex `product-price`.
 * Verified against Elementor Pro 3.33.2: `text_align` (R, left | center | right), `price_color` (global primary) on
 * `.price`, price typography group `typography_*` (global primary), `sale_price_color` / `sale_price_typography_*`
 * on `.price ins` (the discounted price), `price_block` (switcher: prices stacked), `sale_price_spacing` (R). Zadex
 * styles the whole price (incl. `ins`) and the regular crossed-out price (`del`) only, so the sale-price styles
 * cannot be applied to `ins` alone and are noted.
 */
registerWidget('woocommerce-product-price', (source, ctx) => {
  const off = wooGuard(source, ctx, 'product-price');
  if (off) return off;
  const el = withGlobalDefaults(source, ctx, {
    price_color: 'globals/colors?id=primary',
    typography_typography: 'globals/typography?id=primary',
  });
  const w = ctx.writer(el, 'product-price');
  markPro(w);
  w.map('text_align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  flatColor(w, ['price_color'], 'color');
  typographyAlt(w, ['typography'], 'typography');
  if (w.get('price_block') === 'yes') w.set('stacked', true);
  noteIfSet(w, ['sale_price_color', 'sale_price_typography_*'], 'The sale price styles (discounted price only) are not carried over; Zadex styles the whole price and the regular crossed-out price.');
  noteIfSet(w, ['sale_price_spacing'], 'The space between the regular and the sale price is not carried over.');
  return w.finish();
});
