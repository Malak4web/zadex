import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { proSwitch, proText, proVal } from './_pro-content';

/** Prism language ids (Elementor Pro) -> Zadex tokenizer languages; others are shown as plain text. */
const LANGUAGES: Record<string, string> = {
  markup: 'html',
  html: 'html',
  xml: 'html',
  svg: 'html',
  css: 'css',
  scss: 'css',
  sass: 'css',
  less: 'css',
  javascript: 'js',
  js: 'js',
  typescript: 'js',
  jsx: 'js',
  tsx: 'js',
  php: 'php',
  json: 'json',
  bash: 'bash',
  shell: 'bash',
  'shell-session': 'bash',
  python: 'python',
  text: 'text',
};
/** Exact matches (no approximation note). */
const EXACT = new Set(['markup', 'html', 'css', 'javascript', 'js', 'php', 'json', 'bash', 'python', 'text']);
/** Prism themes -> Zadex light / dark. */
const LIGHT_THEMES = new Set(['default', 'solarized', 'solarizedlight', 'coy']);

/**
 * Elementor Pro `code-highlight` -> Zadex `code-highlight`. Keys verified against Elementor Pro 3.33.2 (defaults from
 * elementor-defaults.json): `language` (select2, javascript; markup|html|css|sass|scss|less|javascript|typescript|
 * jsx|tsx|php|ruby|json|http|xml|svg|rust|csharp|dart|git|java|sql|go|kotlin|julia|python|swift|bash|scala|haskell|
 * perl|objectivec|visual-basic|r|c|cpp|aspnet), `code` ("console.log( 'Code is Poetry' );"), `line_numbers` (return
 * value 'line-numbers', on), `copy_to_clipboard` (return value 'copy-to-clipboard', on), `highlight_lines`,
 * `word_wrap` (off), `theme` default|dark|okaidia|solarizedlight|tomorrow|twilight (default), `height`, `font_size`.
 */
registerWidget('code-highlight', (el, ctx) => {
  const w = ctx.writer(el, 'code-highlight');
  markPro(w);

  const rawLang = proVal(w, 'language', 'javascript');
  const lang = String((Array.isArray(rawLang) ? rawLang[0] : rawLang) ?? 'javascript');
  w.set('language', LANGUAGES[lang] ?? 'text');
  if (!LANGUAGES[lang]) w.note(`Language "${lang}" is not highlighted by Zadex; the code is shown as plain text.`);
  else if (!EXACT.has(lang)) w.note(`Language "${lang}" is highlighted as "${LANGUAGES[lang]}" in Zadex.`);
  w.set('code', proText(w, 'code'));
  w.set('line_numbers', proSwitch(w, 'line_numbers', true));
  w.set('copy_button', proSwitch(w, 'copy_to_clipboard', true));
  w.set('highlight_lines', proText(w, 'highlight_lines').trim());
  w.set('word_wrap', proSwitch(w, 'word_wrap'));

  const theme = proText(w, 'theme', 'default');
  w.set('theme', LIGHT_THEMES.has(theme) ? 'light' : 'dark');
  if (!['default', 'dark'].includes(theme)) w.note(`Prism theme "${theme}" is approximated with the Zadex ${LIGHT_THEMES.has(theme) ? 'light' : 'dark'} theme.`);

  w.slider('height', 'max_height');
  w.slider('font_size', 'font_size');
  return w.finish();
});
