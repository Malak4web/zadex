import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import type { ConvertContext, ElementWriter } from '../context';
import { slider } from '../values';
import { describeIcon, isObj, only, toNumber, withGlobalDefaults } from './_shared';

function starAlign(w: ElementWriter, ctx: ConvertContext, src: string): void {
  w.map(src, 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  for (const k of [src, `${src}_tablet`, `${src}_mobile`]) {
    if (w.raw(k) === 'justify') w.note('"Justify" alignment (title and stars at both ends) is not available in Zadex.');
  }
}

/** Elementor `star-rating` -> Zadex `star-rating`. */
registerWidget('star-rating', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_color: 'globals/colors?id=text',
    title_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'star-rating');
  const scale = String(w.get('rating_scale') ?? '5') === '10' ? '10' : '5';
  w.set('scale', scale);
  const rating = toNumber(w.get('rating'));
  if (rating !== undefined) w.set('rating', Math.max(0, Math.min(Number(scale), rating)));
  const starStyle = w.get('star_style');
  if (starStyle === 'star_unicode') w.note('Unicode stars are shown as Zadex icon stars.');
  w.set('icon_style', w.get('unmarked_star_style') === 'outline' ? 'outline' : 'solid');
  w.set('title', String(w.get('title') ?? ''));
  starAlign(w, ctx, 'align');
  w.color('title_color', 'title_color');
  w.typography('title_typography', 'title_typography');
  w.slider('title_gap', 'title_gap');
  w.slider('icon_size', 'size');
  w.slider('icon_space', 'spacing');
  w.color('stars_color', 'color');
  w.color('stars_unmarked_color', 'unmarked_color');
  return w.finish();
});

/** Elementor `rating` (the newer rating widget) -> Zadex `star-rating`. */
registerWidget('rating', (el, ctx) => {
  const w = ctx.writer(el, 'star-rating');
  const scaleValue = slider(w.get('rating_scale'));
  const scaleNum = typeof scaleValue?.size === 'number' ? scaleValue.size : 5;
  const scale = scaleNum > 5 ? '10' : '5';
  w.set('scale', scale);
  if (scaleNum !== 5 && scaleNum !== 10) w.note(`A rating scale of ${scaleNum} is not available in Zadex (5 or 10); ${scale} is used.`);
  const raw = toNumber(w.get('rating_value'));
  const value = raw === undefined ? scaleNum : raw;
  const scaled = scaleNum === Number(scale) ? value : (value / scaleNum) * Number(scale);
  w.set('rating', Math.max(0, Math.min(Number(scale), Math.round(scaled * 100) / 100)));
  const ic = w.get('rating_icon');
  const name = describeIcon(ic);
  if (isObj(ic) && name !== '' && !/(^|\s|-)(eicon-star|fa-star)$/.test(name)) w.note(`The rating icon "${name}" is shown as a star.`);
  w.set('title', '');
  starAlign(w, ctx, 'icon_alignment');
  w.slider('icon_size', 'size');
  w.slider('icon_gap', 'spacing');
  w.color('icon_color', 'color');
  w.color('icon_unmarked_color', 'unmarked_color');
  return w.finish();
});
