import type { ElementWriter } from '../context';
import { parseDynamicTag, type ParsedTag } from '../dynamic';
import { isBlank } from '../values';

/**
 * Helpers shared by the Elementor Pro theme widget mappers (P5: theme-*, archive-posts, author-box, post-*,
 * sitemap, breadcrumbs). Verified against Elementor Pro 3.33.2: `elementor-defaults.json` holds Pro's real defaults,
 * so the mappers read with `w.get()`; `opt` / `optStr` / `optBool` remain for values without a Pro default.
 */

/** Stored value of a key, or the given Elementor Pro default when absent / empty. Marks the key as handled. */
export function opt(w: ElementWriter, key: string, def: unknown): unknown {
  const v = w.raw(key);
  return isBlank(v) ? def : v;
}

/** String form of `opt`. */
export function optStr(w: ElementWriter, key: string, def: string): string {
  const v = opt(w, key, def);
  return typeof v === 'string' || typeof v === 'number' ? String(v) : def;
}

/** Elementor switcher with a Pro default (`yes` / ''). */
export function optBool(w: ElementWriter, key: string, def: boolean): boolean {
  const v = w.raw(key);
  if (v === undefined || v === null) return def;
  return v === 'yes' || v === true;
}

/**
 * HTML tag limited to the Zadex control's options; anything else becomes `fallback[tag]` or the first option
 * (noted).
 */
export function pickTag(w: ElementWriter, tag: string, allowed: string[], fallback: Record<string, string> = {}): string {
  if (allowed.includes(tag)) return tag;
  const out = fallback[tag] ?? (allowed.includes('div') ? 'div' : allowed.includes('p') ? 'p' : allowed[0]);
  w.note(`HTML tag "${tag}" is not available on this Zadex widget; "${out}" is used.`);
  return out;
}

/** Parsed `__dynamic__[key]` tag of the element (undefined when the key is static). */
export function dynamicTag(w: ElementWriter, key: string): ParsedTag | undefined {
  return parseDynamicTag(w.dynamicRef(key));
}

/** True when the element stores no `__dynamic__` map at all (the widget's default dynamic bindings apply). */
export function noDynamicData(w: ElementWriter): boolean {
  const d = w.el.settings?.__dynamic__;
  return d === undefined || d === null || (typeof d === 'object' && !Array.isArray(d) && Object.keys(d).length === 0);
}

/**
 * Theme widgets whose content comes from a fixed dynamic tag (post title, site title, archive title …): the
 * Zadex widget always shows that content. A binding to one of `expected` tags (or no binding: Elementor Pro's
 * default) is carried over; a static text or another tag is noted (and the binding stays in the dropped list).
 */
export function fixedSource(w: ElementWriter, key: string, expected: string[], what: string): ParsedTag | undefined {
  w.raw(key); // the static text is a placeholder for the editor
  const tag = dynamicTag(w, key);
  if (tag && expected.includes(tag.name)) {
    w.consumeDynamic(key);
    return tag;
  }
  if (tag) w.note(`The content was bound to the "${tag.name}" tag; the Zadex widget always shows the ${what}.`);
  else if (!noDynamicData(w) && !isBlank(w.el.settings?.[key])) w.note(`A static text was set; the Zadex widget always shows the ${what}.`);
  return undefined;
}

/** Decodes the HTML entities Elementor Pro uses in default labels (`&laquo; Previous`, `Next &raquo;`). */
export function decodeEntities(s: string): string {
  return s
    .replace(/&laquo;/g, '«')
    .replace(/&raquo;/g, '»')
    .replace(/&larr;/g, '←')
    .replace(/&rarr;/g, '→')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
}
