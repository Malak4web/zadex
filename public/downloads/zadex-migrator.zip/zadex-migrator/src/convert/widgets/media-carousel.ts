import { registerWidget } from '../registry';
import { isBlank, slider, url } from '../values';
import { markPro } from './_pro';
import { isObj, itemIdFor, repeaterItems } from './_shared';
import { borderFrom, colorOf, desktopSlider, dimsFrom, getBool, getInt, getStr, responsiveGet, toInt } from './_pro-posts';

const SIZES: Record<string, string> = { thumbnail: 'thumbnail', medium: 'medium', medium_large: 'large', large: 'large', '1536x1536': 'full', '2048x2048': 'full', full: 'full', custom: 'large' };
/** Pro `thumbs_ratio` option values (`43`, `169`…) -> Zadex `thumbs_ratio`. */
const THUMB_RATIOS: Record<string, string> = { '11': '1/1', '43': '4/3', '169': '16/9', '219': '16/9' };

/**
 * Elementor Pro `media-carousel` -> Zadex `media-carousel`, verified against Pro 3.33.2: `skin` carousel |
 * slideshow | coverflow, `slides` repeater {`type` image | video, `image`, `image_link_to_type` '' | file | custom,
 * `image_link_to` (url), `video` (url)}, `effect` slide | fade | cube, `slides_per_view` R (no stored default: Pro's
 * script uses 3 / 2 / 1; fade / cube show one slide), `slides_to_scroll`, slideshow `slideshow_slides_per_view` R
 * (script default 5 / 4 / 3), `thumbs_ratio` (219), `centered_slides`, `slideshow_height`, `height` / `width`,
 * `show_arrows` (yes), `pagination` bullets (default) | fraction | progressbar | '', `speed` (500), `autoplay`
 * (yes), `autoplay_speed` (5000), `loop` (yes), `pause_on_hover` (yes), `overlay` '' | text | icon,
 * `image_size_size` (full), `image_fit` '' | contain | auto, `space_between` R (10px); style `slide_*`,
 * `arrows_size` (20px) / `arrows_color`, `pagination_*`, `play_icon_*`, `overlay_*`, `lightbox_*`.
 * The lightbox is per slide in Pro (file links and video slides open it); Zadex has one switch.
 */
registerWidget('media-carousel', (el, ctx) => {
  const w = ctx.writer(el, 'media-carousel');
  markPro(w);

  // Slides.
  const rawSlides = repeaterItems(w.raw('slides'));
  let fileLinks = 0;
  let unlinked = 0;
  let videos = 0;
  const slides = rawSlides.map((item, i) => {
    const type = item.type === 'video' ? 'video' : 'image';
    const image = ctx.media(item.image) ?? { id: 0, url: '', alt: '' };
    const videoUrl = url(item.video)?.url ?? '';
    const linkType = String(item.image_link_to_type ?? '');
    if (type === 'video') videos++;
    else if (linkType === 'file') fileLinks++;
    else if (linkType === '') unlinked++;
    const link = type === 'image' && linkType === 'custom' ? url(item.image_link_to) : undefined;
    return { _id: itemIdFor(ctx, el, item, i), type, image, video_url: type === 'video' ? videoUrl : '', link: link ?? { url: '', target: '', nofollow: false } };
  });
  w.set('slides', slides);
  if (!slides.length) w.note('The carousel has no slides.');
  if (rawSlides.some((s) => s.type === 'video' && isBlank(isObj(s.video) ? s.video.url : undefined))) w.note('A video slide has no video link.');
  const lightbox = fileLinks > 0 || videos > 0;
  w.set('lightbox', lightbox);
  if (lightbox && unlinked > 0) w.note('Zadex has one lightbox switch: image slides without a link open the lightbox too.');

  // Skin / effect.
  const skin = getStr(w, 'skin') || 'carousel';
  w.set('skin', ['carousel', 'slideshow', 'coverflow'].includes(skin) ? skin : 'carousel');
  const effect = skin === 'coverflow' ? 'slide' : getStr(w, 'effect') || 'slide';
  if (effect !== 'slide') {
    w.note(`The "${effect}" transition is not available in Zadex; slides slide.`);
    w.status('partial');
  }
  w.set('image_size', SIZES[getStr(w, 'image_size_size')] ?? 'large');
  w.consume('image_size_custom_dimension');
  const fit = getStr(w, 'image_fit');
  w.set('object_fit', fit === 'contain' ? 'contain' : 'cover');
  if (fit === 'auto') w.note('The "auto" image fit is not available in Zadex; images cover the slide.');
  if (skin !== 'slideshow' && (slider(w.raw('height')) || slider(w.raw('height_tablet')) || slider(w.raw('height_mobile')))) {
    w.note('Zadex sizes slides by aspect ratio, not by a fixed height; the default 3:2 ratio is used.');
  }
  if (skin === 'slideshow' && slider(w.raw('slideshow_height'))) w.note('Zadex sizes the slideshow by aspect ratio, not by a fixed height; the default 3:2 ratio is used.');
  if (slider(w.raw('width'))) w.note('A fixed slide width is not available in Zadex.');
  w.consume('height*', 'width*', 'slideshow_height*', 'lazyload', 'slides_name');

  // Slides per view (Pro script defaults made explicit), thumbnails for the slideshow skin.
  if (skin === 'slideshow') {
    responsiveGet(w, 'slideshow_slides_per_view', 'thumbs_per_view', [2, 12], { desktop: 5, tablet: 4, mobile: 3 });
    w.set('thumbs_ratio', THUMB_RATIOS[getStr(w, 'thumbs_ratio')] ?? '4/3');
    if (getBool(w, 'centered_slides')) w.note('Centered thumbnails are not available in Zadex.');
    w.consume('slides_per_view*', 'slides_to_scroll*');
  } else {
    w.consume('slideshow_slides_per_view*', 'thumbs_ratio', 'centered_slides');
    if (effect === 'slide') {
      responsiveGet(w, 'slides_per_view', 'slides_to_show', [1, 10], { desktop: 3, tablet: 2, mobile: 1 });
      const scroll = toInt(w.raw('slides_to_scroll'));
      if (scroll) w.set('slides_to_scroll', Math.min(10, scroll));
    } else w.set('slides_to_show', 1);
    w.consume('slides_per_view*', 'slides_to_scroll*');
  }
  const space = slider(w.get('space_between')) ?? { size: 10, unit: 'px' };
  w.set('gap', space);
  if (skin === 'slideshow') w.set('thumbs_gap', space);
  for (const k of ['space_between_tablet', 'space_between_mobile']) {
    const s = slider(w.raw(k));
    if (s && (s.size !== space.size || s.unit !== space.unit)) w.note('Per-device slide gaps are not supported by the Zadex media carousel; the desktop gap is used.');
  }
  w.consume('space_between*');

  // Navigation / playback.
  w.set('arrows', getBool(w, 'show_arrows'));
  const pagination = skin === 'slideshow' ? '' : getStr(w, 'pagination');
  w.set('dots', pagination !== '');
  if (pagination === 'fraction' || pagination === 'progressbar') w.note(`The "${pagination}" pagination is shown as dots in Zadex.`);
  w.set('speed', Math.min(5000, getInt(w, 'speed') ?? 500));
  const autoplay = getBool(w, 'autoplay');
  w.set('autoplay', autoplay);
  if (autoplay) {
    w.set('autoplay_speed', Math.min(30000, Math.max(500, getInt(w, 'autoplay_speed') ?? 5000)));
    w.set('pause_on_hover', getBool(w, 'pause_on_hover'));
  } else w.consume('autoplay_speed', 'pause_on_hover');
  w.consume('pause_on_interaction');
  w.set('loop', getBool(w, 'loop'));

  // Overlay (text / icon content has no Zadex equivalent; its background color is kept).
  const overlay = skin === 'slideshow' ? '' : getStr(w, 'overlay');
  if (overlay !== '') {
    w.note(`The "${overlay}" hover overlay content is not available in Zadex; only its color is kept.`);
    const c = colorOf(w, 'overlay_background_color');
    if (c) w.set('overlay', c);
  }
  w.consume('overlay', 'overlay_*', 'caption', 'caption_typography_*', 'icon', 'icon_size');

  // Slide style.
  const bg = colorOf(w, 'slide_background_color');
  if (bg) w.set('slide_bg', bg);
  const border = borderFrom(w.raw('slide_border_size'), colorOf(w, 'slide_border_color'));
  if (border) w.set('slide_border', border);
  dimsFrom(w, 'slide_border_radius', 'slide_radius');
  if (!isBlank(w.raw('slide_padding'))) w.note('Slide padding is not available in Zadex.');

  // Arrows / dots / play icon.
  const arrowSize = slider(w.get('arrows_size'));
  if (arrowSize) w.set('arrow_size', arrowSize);
  w.color('arrows_color', 'arrow_color');
  if (pagination !== '') {
    desktopSlider(w, 'pagination_size', 'dot_size');
    w.color('pagination_color', 'dot_active_color');
    w.color('pagination_color_inactive', 'dot_color');
    desktopSlider(w, 'pagination_gap', 'dots_spacing');
    if (getStr(w, 'pagination_position') === 'inside') w.note('Dots inside the slides are not available in Zadex; they sit below.');
  }
  w.consume('pagination_*');
  w.color('play_icon_color', 'play_color');
  desktopSlider(w, 'play_icon_size', 'play_size');
  if (['lightbox_color', 'lightbox_ui_color', 'lightbox_ui_hover_color', 'lightbox_video_width'].some((k) => !isBlank(w.raw(k)) && !(isObj(w.raw(k)) && isBlank((w.raw(k) as Record<string, unknown>).size)))) {
    w.note('Lightbox colors and video width are not available in Zadex.');
  }
  w.consume('lightbox_*');
  return w.finish();
});
