import { registerWidget } from '../registry';
import { bool, slider, url } from '../values';
import { typographyWithDefaults, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';
import { dimensionsAlt, posInt, sidesOf } from './_marketing';
import { deviceKeys } from '../responsive';

const UNITS = ['days', 'hours', 'minutes', 'seconds'] as const;
const LABELS: Record<(typeof UNITS)[number], string> = { days: 'Days', hours: 'Hours', minutes: 'Minutes', seconds: 'Seconds' };
const ACTIONS = ['hide', 'message', 'redirect'];

/** Elementor `Y-m-d H:i` (site timezone) -> Zadex `datetime-local` value `YYYY-MM-DDTHH:MM` (also site timezone). */
export function dueDate(v: unknown): string | undefined {
  if (typeof v !== 'string') return undefined;
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/.exec(v.trim());
  if (!m) return undefined;
  const p = (s: string | undefined) => String(s ?? '0').padStart(2, '0');
  return `${m[1]}-${p(m[2])}-${p(m[3])}T${p(m[4])}:${p(m[5])}`;
}

/**
 * Elementor Pro `countdown` -> Zadex `countdown`. Verified against Elementor Pro 3.33.2: `countdown_type`
 * due_date|evergreen, `due_date` ('Y-m-d H:i' in the site timezone, Pro builds a `DateTime` with `wp_timezone()`;
 * its default is one month after each page load), `evergreen_counter_hours` (47) / `_minutes` (59), `show_days|hours|
 * minutes|seconds` / `show_labels` (yes), `custom_labels` + `label_*`, `expire_actions` (select2: redirect|hide|
 * message), `message_after_expire`, `expire_redirect_url`; style `label_display` block|inline, `container_width`
 * (block, 100%), `boxes_alignment` (inline), `box_spacing` (10px), `box_padding`, `box_background_color` (primary),
 * `box_border` group, `box_border_radius`, `box_shadow` group, `digits_color` / `digits_typography` (text),
 * `label_color` / `label_typography` (secondary), message `align`, `text_color` / `typography` (text),
 * `message_padding`. Elementor's stylesheet (white 69px digits, 19px labels, 20px vertical box padding) is written
 * where nothing is stored.
 */
registerWidget('countdown', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    box_background_color: 'globals/colors?id=primary',
    digits_typography_typography: 'globals/typography?id=text',
    label_typography_typography: 'globals/typography?id=secondary',
    text_color: 'globals/colors?id=text',
    typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'countdown');
  markPro(w);
  const evergreen = w.get('countdown_type') === 'evergreen';
  w.set('countdown_type', evergreen ? 'evergreen' : 'due_date');
  if (evergreen) {
    w.set('evergreen_hours', posInt(w.get('evergreen_counter_hours')) ?? 0);
    w.set('evergreen_minutes', posInt(w.get('evergreen_counter_minutes')) ?? 0);
    w.set('evergreen_reset', 0);
    w.consume('due_date');
  } else {
    const due = dueDate(w.raw('due_date'));
    if (due) w.set('due_date', due);
    else w.note('The countdown due date was not stored (Elementor Pro then counts down to one month after each page load); set it in Zadex.');
    w.consume('evergreen_counter_hours', 'evergreen_counter_minutes');
  }

  // Units and labels.
  const labels = bool(w.get('show_labels'));
  const custom = labels && bool(w.get('custom_labels'));
  for (const unit of UNITS) {
    const shown = bool(w.get(`show_${unit}`));
    w.set(`show_${unit}`, shown);
    w.set(`label_${unit}`, custom ? String(w.get(`label_${unit}`) ?? LABELS[unit]) : LABELS[unit]);
    if (!custom) w.consume(`label_${unit}`);
  }
  if (!labels) w.consume('custom_labels');
  w.set('show_labels', labels);
  const inline = w.get('label_display') === 'inline';
  w.set('layout', inline ? 'inline' : 'block');
  w.set('separator', false);

  // Expire actions.
  const raw = w.raw('expire_actions');
  const list = (Array.isArray(raw) ? raw : typeof raw === 'string' && raw !== '' ? [raw] : []).map(String);
  const actions = list.filter((a) => ACTIONS.includes(a));
  for (const a of list) if (!ACTIONS.includes(a)) w.note(`Expire action "${a}" is not available in Zadex.`);
  w.set('expire_actions', actions);
  if (actions.includes('message')) w.set('expire_message', String(w.get('message_after_expire') ?? ''));
  else w.consume('message_after_expire');
  const redirect = url(w.raw('expire_redirect_url'));
  if (actions.includes('redirect')) w.set('expire_redirect', redirect ?? { url: '', target: '', nofollow: false });

  // Boxes. Block labels: the boxes share the width evenly (`container_width` 100%); inline labels: inline boxes
  // aligned by `boxes_alignment` (centered). Spacing 10px.
  w.set('stretch', !inline);
  if (inline) {
    const a = w.get('boxes_alignment');
    w.set('align', a === 'start' ? 'flex-start' : a === 'end' ? 'flex-end' : 'center');
    w.consume('container_width*');
  } else {
    w.consume('boxes_alignment');
    for (const [k] of deviceKeys('container_width')) {
      const s = slider(w.raw(k), '%');
      if (s && !(s.unit === '%' && Number(s.size) === 100)) w.note(`The countdown width (${k}) is not carried over; set the Zadex element width instead.`);
    }
  }
  w.slider('box_spacing', 'gap');
  w.color('box_background_color', 'box_bg');
  w.border('box_border', 'box_border');
  for (const k of Object.keys(w.settings)) if (k.startsWith('box_border@')) delete w.settings[k];
  const radius = sidesOf(w.raw('box_border_radius'));
  if (radius) w.set('box_radius', radius);
  dimensionsAlt(w, ['box_padding'], 'box_padding');
  // Elementor stylesheet: 20px vertical padding (inline labels: 5px sides too), 69px digits, 19px labels.
  if (w.settings.box_padding === undefined) w.set('box_padding', { top: 20, right: inline ? 5 : 0, bottom: 20, left: inline ? 5 : 0, unit: 'px', linked: false });
  w.boxShadow('box_shadow', 'box_shadow');

  // Digits / labels: Elementor prints white text on the (primary) box background.
  const hasBg = typeof w.settings.box_bg === 'string' && w.settings.box_bg !== '';
  w.color('digits_color', 'digits_color');
  typographyWithDefaults(w, 'digits_typography', 'digits_typography', { size: { size: 69, unit: 'px' }, lineHeight: { size: 1, unit: 'custom' } });
  w.color('label_color', 'labels_color');
  typographyWithDefaults(w, 'label_typography', 'labels_typography', { size: { size: 19, unit: 'px' }, lineHeight: { size: 1, unit: 'custom' } });
  if (hasBg && w.settings.digits_color === undefined) w.set('digits_color', '#ffffff');
  if (hasBg && w.settings.labels_color === undefined) w.set('labels_color', '#ffffff');

  // Expire message.
  w.color('text_color', 'message_color');
  w.typography('typography', 'message_typography');
  const msgAlign = w.raw('align');
  if (typeof msgAlign === 'string' && msgAlign !== '' && msgAlign !== 'center') w.note(`Expire message alignment "${msgAlign}" is not available in Zadex (centered).`);
  for (const k of ['digits_text_shadow_text_shadow_type', 'label_text_shadow_text_shadow_type', 'message_text_shadow_text_shadow_type', 'text_stroke_text_stroke_type']) {
    if (bool(w.raw(k))) w.note('Text shadows / strokes of the countdown are not available in Zadex.');
    w.consume(k.replace(/_type$/, ''), k.replace(/_text_stroke_type$/, '_stroke_color'));
  }
  return w.finish();
});
