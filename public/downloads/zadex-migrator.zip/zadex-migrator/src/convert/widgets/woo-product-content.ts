import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { fallback } from '../fallback';
import { desktopOnly, only, withGlobalDefaults } from './_shared';
import { markPro } from './_pro';

/**
 * Elementor Pro `woocommerce-product-content` -> Zadex `post-content` (the product description = the post content).
 * Verified against Elementor Pro 3.33.2: it extends `theme-post-content`, so same keys: `align` (R, left | center |
 * right | justify), `text_color` (global text), `typography_*` (global text). `post-content` is not a WooCommerce widget in Zadex (always available), so
 * no WooCommerce guard; the plain fallback runs only if the target has no `post-content` at all.
 */
registerWidget('woocommerce-product-content', (source, ctx) => {
  if (!ctx.hasWidget('post-content')) return fallback(source, ctx);
  const el = withGlobalDefaults(source, ctx, {
    text_color: 'globals/colors?id=text',
    typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'post-content');
  markPro(w);
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right', 'justify']));
  w.color('text_color', 'color');
  desktopOnly(w, 'color');
  w.typography('typography', 'typography');
  return w.finish();
});
