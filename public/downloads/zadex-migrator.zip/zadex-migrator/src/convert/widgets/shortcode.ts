import { registerWidget } from '../registry';

/** Elementor `shortcode` -> Zadex `shortcode` (rendered by WordPress on the server, same as Elementor). */
registerWidget('shortcode', (el, ctx) => {
  const w = ctx.writer(el, 'shortcode');
  w.set('shortcode', String(w.get('shortcode') ?? ''));
  return w.finish();
});
