import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { flexAlign } from '../align';
import { desktopOnly, only, withGlobalDefaults } from './_shared';

/**
 * Elementor Pro `breadcrumbs` -> Zadex `breadcrumbs`. The Pro widget prints Yoast SEO's breadcrumbs (`yoast_breadcrumb`)
 * and only has `html_tag` ('' = p, p, div, nav, span), `align` R (left / center / right), `typography` (global
 * secondary), `text_color`, `link_color`, `link_hover_color` (verified against Pro 3.33.2 source; the widget is only
 * registered while Yoast SEO is active, so it is not in the control dump). Zadex `source: auto`
 * uses Yoast / Rank Math on the live site when present, else its own trail; home label / separator then come from
 * Yoast's settings as before.
 */
registerWidget('breadcrumbs', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, { typography_typography: 'globals/typography?id=secondary' });
  const w = ctx.writer(el, 'breadcrumbs');
  markPro(w);
  w.set('source', 'auto');
  w.note('Breadcrumbs: Yoast / Rank Math breadcrumbs are used when the plugin is active, otherwise Zadex builds its own trail.');
  const tag = w.raw('html_tag');
  if (typeof tag === 'string' && tag !== '' && tag !== 'p') w.note(`HTML tag "${tag}" is not carried over (Zadex prints a nav element).`);
  w.map('align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  w.typography('typography', 'typography');
  w.color('text_color', 'color');
  desktopOnly(w, 'color');
  w.color('link_color', 'link_color');
  desktopOnly(w, 'link_color');
  w.color('link_hover_color', 'link_color_hover');
  desktopOnly(w, 'link_color_hover');
  return w.finish();
});
