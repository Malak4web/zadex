import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement } from '../types';
import { colorRef } from '../globals';
import { bool, dimensions, isBlank, num } from '../values';
import { iconValue, itemIdFor, repeaterItems, withGlobalDefaults } from './_shared';
import { firstOf, markPro } from './_pro';
import { mapPopupId } from '../popup-links';
import { BUTTON_PRESETS, FIELD_PRESETS, isObj, mergeDefaults, noteDeviceValues, pbool, pget, pstr, pxDims } from './_pro-site';

/**
 * Elementor Pro `form` -> Zadex `form`.
 *
 * Key names, option values, repeater shapes and defaults verified against Elementor Pro 3.33.2
 * (dev/reference/elementor-pro-controls.json and modules/forms in the Pro source). `w.get()` returns Pro's real
 * defaults, except the email controls whose defaults are computed from the site at render time (admin email, site
 * name, domain): those are read raw and replaced by Zadex placeholders (`[site:name]`) or Zadex's own fallbacks.
 */

type Obj = Record<string, unknown>;

const SAME_TYPES = new Set(['text', 'email', 'textarea', 'tel', 'number', 'date', 'time', 'select', 'radio', 'checkbox', 'acceptance', 'upload', 'password', 'hidden', 'html', 'step']);

/** Elementor column widths (%; '' = Default, full width) -> closest Zadex width option. */
const WIDTHS: Record<string, string> = { '100': '100', '80': '100', '75': '100', '70': '50', '66': '50', '60': '50', '50': '50', '40': '33', '33': '33', '30': '33', '25': '25', '20': '25' };

/** Elementor `submit_actions` ids -> Zadex `actions` checklist values. */
const ACTIONS: Record<string, string> = {
  email: 'email',
  email2: 'email_2',
  redirect: 'redirect',
  popup: 'popup',
  webhook: 'webhook',
  mailchimp: 'mailchimp',
  activecampaign: 'activecampaign',
  getresponse: 'getresponse',
  convertkit: 'convertkit',
  mailerlite: 'mailerlite',
  drip: 'drip',
  discord: 'discord',
  slack: 'slack',
  'save-to-database': 'collect',
};

/** Elementor message controls -> Zadex message ids + Pro 3.33.2 default texts (used while `custom_messages` is off). */
const MESSAGES: Record<string, [string, string]> = {
  success_message: ['success_message', 'Your submission was successful.'],
  error_message: ['error_message', 'Your submission failed because of an error.'],
  required_field_message: ['required_message', 'This field is required.'],
  invalid_message: ['invalid_message', 'Your submission failed because the form is invalid.'],
};

/**
 * Elementor `label|value` option lines -> Zadex `value|label` lines (lines without a pipe stay as they are). Pro
 * renders `list( $label, $value ) = explode( '|', $option )` (classes/form-base.php), so the label comes first.
 */
export function convertOptions(raw: unknown): string {
  return String(raw ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line !== '')
    .map((line) => {
      if (!line.includes('|')) return line;
      // Like PHP's list() over explode(): parts after the second are ignored.
      const [first, second] = line.split('|');
      const label = (first ?? '').trim();
      const value = (second ?? '').trim();
      return value === '' || value === label ? label : `${value}|${label}`;
    })
    .join('\n');
}

/** Zadex field id rules (`includes/Forms/Fields.php`): lower-case `[a-z0-9_-]`, max 40 chars. */
export function fieldId(raw: unknown): string {
  return String(raw ?? '').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 40);
}

/**
 * Elementor shortcodes in action texts -> Zadex placeholders: `[field id="x"]` -> `[field:x]`, `[all-fields]` kept.
 * Elementor's `[all-fields]` / `[field]` are the only form shortcodes; others (dynamic tags) are left as typed.
 */
export function convertShortcodes(text: unknown): string {
  return String(text ?? '')
    .replace(/\[field\s+id=(?:"|'|&quot;)?([^"'\]\s&]+)(?:"|'|&quot;)?\s*\]/gi, (_m, id: string) => `[field:${fieldId(id)}]`)
    .replace(/\[all-fields(?:\s[^\]]*)?\]/gi, '[all-fields]');
}

interface FieldsResult {
  fields: Obj[];
  recaptcha?: 'v2' | 'v3';
  honeypot: boolean;
  stepNext?: string;
  stepPrev?: string;
  hasSteps: boolean;
}

function convertFields(w: ElementWriter, ctx: ConvertContext, el: ElElement): FieldsResult {
  // Absent = Pro's default fields (name, email (required), message).
  const items = repeaterItems(w.get('form_fields'));
  const res: FieldsResult = { fields: [], honeypot: false, hasSteps: false };
  const notes = new Set<string>();
  items.forEach((item, i) => {
    const elType = String(item.field_type ?? 'text');
    if (elType === 'recaptcha' || elType === 'recaptcha_v3') {
      res.recaptcha = elType === 'recaptcha' ? 'v2' : 'v3';
      notes.add('The reCAPTCHA field became the form\'s reCAPTCHA setting; set the keys in Zadex > Settings.');
      return;
    }
    if (elType === 'honeypot') {
      res.honeypot = true;
      return;
    }
    let type = elType;
    if (elType === 'url') {
      type = 'text';
      notes.add('URL fields became text fields (Zadex has no URL field type).');
    } else if (!SAME_TYPES.has(elType)) {
      type = 'text';
      notes.add(`Field type "${elType}" is not available in Zadex; a text field is used.`);
    }
    const f: Obj = { _id: itemIdFor(ctx, el, item, i), type };
    const label = item.field_label;
    if (typeof label === 'string') f.label = label;
    const customId = fieldId(item.custom_id) || fieldId(item._id);
    if (customId) f.custom_id = customId;

    if (type === 'step') {
      res.hasSteps = true;
      // Per-step button labels (`next_button` / `previous_button` on step items, default: the form's labels).
      if (!res.stepNext && typeof item.next_button === 'string' && item.next_button) res.stepNext = item.next_button;
      if (!res.stepPrev && typeof item.previous_button === 'string' && item.previous_button) res.stepPrev = item.previous_button;
      if (!isBlank(item.selected_icon)) notes.add('Step icons are not available in Zadex.');
      res.fields.push(f);
      return;
    }

    if (typeof item.placeholder === 'string' && item.placeholder !== '') f.placeholder = item.placeholder;
    if (type !== 'html' && type !== 'hidden') f.required = bool(item.required);
    if (type !== 'hidden') {
      const width = String(item.width ?? '100') || '100';
      f.width = WIDTHS[width] ?? '100';
      if (!WIDTHS[width] || WIDTHS[width] !== width) notes.add('Field widths are approximated to the Zadex options (100, 50, 33, 25%).');
      for (const k of ['width_tablet', 'width_mobile']) {
        if (!isBlank(item[k]) && !(k === 'width_mobile' && String(item[k]) === '100')) notes.add('Per-device field widths are not supported (Zadex fields are full width on mobile).');
      }
    }
    if (['select', 'radio', 'checkbox'].includes(type)) f.options = convertOptions(item.field_options);
    if (type === 'select' && bool(item.allow_multiple)) notes.add('Multiple-choice select fields are single choice in Zadex (use a checkbox field instead).');
    if (!isBlank(item.inline_list)) notes.add('Inline radio / checkbox lists are stacked in Zadex.');
    const def = item.field_value;
    if (!isBlank(def) && !['html', 'step', 'upload', 'acceptance', 'password'].includes(type)) f.default = String(def);
    if (type === 'textarea') {
      const rows = num(item.rows);
      f.rows = typeof rows === 'number' && rows > 0 ? Math.min(30, Math.round(rows)) : 4;
    }
    if (type === 'number') {
      if (!isBlank(item.field_min)) f.min = String(item.field_min);
      if (!isBlank(item.field_max)) f.max = String(item.field_max);
    }
    if (type === 'date') {
      if (!isBlank(item.min_date)) f.min = String(item.min_date);
      if (!isBlank(item.max_date)) f.max = String(item.max_date);
    }
    if (type === 'upload') {
      const size = num(item.file_sizes);
      if (typeof size === 'number' && size > 0) f.max_size = Math.min(100, Math.max(1, size));
      if (!isBlank(item.file_types)) {
        f.accept = String(item.file_types)
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean)
          .map((t) => (t.startsWith('.') ? t : `.${t}`))
          .join(',');
      }
      f.multiple = bool(item.allow_multiple_upload);
      if (!isBlank(item.max_files)) notes.add('The maximum number of uploaded files is not limited in Zadex.');
    }
    if (type === 'html') f.html = typeof item.field_html === 'string' ? item.field_html : '';
    if (type === 'acceptance') {
      f.acceptance_text = typeof item.acceptance_text === 'string' ? item.acceptance_text : '';
      if (bool(item.checked_by_default)) notes.add('Acceptance fields checked by default start unchecked in Zadex.');
    }
    if (!isBlank(item.css_classes)) notes.add('Per-field CSS classes are not carried over.');
    if (!isBlank(item.select_size)) notes.add('The visible size of select lists is not carried over.');
    if (!isBlank(item.use_native_date) || !isBlank(item.use_native_time)) notes.add('Zadex always uses the browser\'s native date / time pickers.');
    res.fields.push(f);
  });
  for (const n of notes) w.note(n);
  return res;
}

/** `<x>_fields_map` repeater ({remote_id, local_id}) -> Zadex email / name / last name field ids + custom fields. */
function fieldsMap(w: ElementWriter, ctx: ConvertContext, el: ElElement, id: string): void {
  const mapKey = `${id}_fields_map`;
  const items = repeaterItems(w.raw(mapKey));
  const extra: Obj[] = [];
  items.forEach((item, i) => {
    const remote = String(item.remote_id ?? '').trim();
    const local = fieldId(item.local_id);
    if (!remote || !local) return;
    const r = remote.toLowerCase();
    if (r === 'email' || r === 'email_address') w.set(`${id}_email_field`, local);
    else if (['fname', 'first_name', 'firstname', 'name'].includes(r)) w.set(`${id}_name_field`, local);
    else if (['lname', 'last_name', 'lastname'].includes(r)) w.set(`${id}_last_name_field`, local);
    else extra.push({ _id: ctx.itemId(item._id ?? `${el.id}${id.slice(0, 3)}${i}`), key: remote, value: `[field:${local}]` });
  });
  if (extra.length) w.set(`${id}_fields`, extra);
}

function tagsValue(v: unknown): string | undefined {
  if (Array.isArray(v)) return v.map(String).filter(Boolean).join(', ') || undefined;
  if (typeof v === 'string' && v.trim() !== '') return convertShortcodes(v.trim());
  return undefined;
}

/** API credentials stored on the Elementor widget are never copied into page data (Zadex keeps them in settings). */
function credentials(w: ElementWriter, label: string, sourceKey: string, ...secretKeys: string[]): void {
  const source = w.raw(sourceKey);
  const secrets = secretKeys.some((k) => w.has(k));
  for (const k of secretKeys) w.raw(k);
  if (source === 'custom' || secrets) w.note(`${label}: the API key set on the Elementor widget is not copied; set it in Zadex > Settings > Integrations.`);
  else w.note(`${label}: set the API credentials in Zadex > Settings > Integrations.`);
}

function emailAction(w: ElementWriter, suffix: '' | '_2'): void {
  const z = suffix ? 'email_2_' : 'email_';
  // Elementor keys: `email_to`, `email_subject` … and for the second email the same names with a `_2` suffix.
  const k = (base: string) => `${base}${suffix}`;
  // `email_to`, `email_subject`, `email_from(_name)` defaults are site-dependent (admin email, site name, domain) and
  // read raw: absent -> Zadex placeholders / fallbacks.
  const to = w.raw(k('email_to'));
  if (!isBlank(to)) w.set(`${z}to`, convertShortcodes(to));
  else if (suffix) {
    w.set(`${z}to`, '');
    w.note('The second email went to the site admin email (Elementor default); set its recipient in the Zadex form.');
  }
  const subject = w.raw(k('email_subject'));
  w.set(`${z}subject`, convertShortcodes(isBlank(subject) ? 'New message from "[site:name]"' : subject));
  w.set(`${z}message`, convertShortcodes(pget(w, k('email_content'), '[all-fields]')));
  const fromName = w.raw(k('email_from_name'));
  w.set(`${z}from_name`, isBlank(fromName) ? '[site:name]' : convertShortcodes(fromName));
  const from = w.raw(k('email_from'));
  if (!isBlank(from)) w.set(`${z}from`, convertShortcodes(from));
  // Reply-To is a field id (select of the form's fields; the second email's text control defaults to the admin email).
  const reply = w.raw(k('email_reply_to'));
  if (!isBlank(reply)) {
    const s = String(reply);
    const m = s.match(/\[field\s+id=["']?([^"'\]\s]+)/i);
    w.set(`${z}reply_to`, m ? fieldId(m[1]) : s.includes('@') ? s : fieldId(s));
    if (s.includes('@')) w.note('Reply-To was an email address; Zadex expects a field ID there.');
  }
  const cc = w.raw(k('email_to_cc'));
  if (!isBlank(cc)) w.set(`${z}cc`, convertShortcodes(cc));
  const bcc = w.raw(k('email_to_bcc'));
  if (!isBlank(bcc)) w.set(`${z}bcc`, convertShortcodes(bcc));
  const type = pstr(w, k('email_content_type'), 'html');
  w.set(`${z}format`, type === 'plain' ? 'plain' : 'html');
  // Pro default: date, time, page URL, user agent, IP and credit lines on the first email; none on the second.
  const meta = w.get(k('form_metadata'));
  if (Array.isArray(meta) && meta.length) w.note('Form metadata lines (date, page URL, user agent …) are not appended to Zadex emails.');
}

function convertActions(w: ElementWriter, ctx: ConvertContext, el: ElElement): string[] {
  // Pro default: Email + Collect Submissions (`save-to-database`). Other ids (`mailpoet`, `mailpoet3`, `cf7db`,
  // `activity-log`, add-on actions) have no Zadex equivalent and are noted.
  const stored = w.get('submit_actions');
  const list = Array.isArray(stored) ? stored.map(String) : [];
  const popupAction = pstr(w, 'popup_action', '');
  if (list.includes('popup') && popupAction !== 'open' && popupAction !== 'close') {
    list.splice(list.indexOf('popup'), 1);
    w.note('The form popup action had no action chosen ("Choose"), so it did nothing in Elementor and was not carried over.');
  }
  if (list.includes('save-to-database')) w.consume('submissions_metadata');
  const out: string[] = [];
  for (const a of list) {
    const z = ACTIONS[a];
    if (z) {
      if (!out.includes(z)) out.push(z);
    } else w.note(`After-submit action "${a}" has no Zadex equivalent and was not carried over.`);
  }
  // Zadex runs `collect` first.
  out.sort((a, b) => (a === 'collect' ? -1 : b === 'collect' ? 1 : 0));
  w.set('actions', out);

  if (out.includes('email')) emailAction(w, '');
  else w.consume('email_to', 'email_subject', 'email_content', 'email_from', 'email_from_name', 'email_reply_to', 'email_to_cc', 'email_to_bcc', 'email_content_type', 'form_metadata');
  if (out.includes('email_2')) emailAction(w, '_2');
  else w.consume('email_to_2', 'email_subject_2', 'email_content_2', 'email_from_2', 'email_from_name_2', 'email_reply_to_2', 'email_to_cc_2', 'email_to_bcc_2', 'email_content_type_2', 'form_metadata_2');

  if (out.includes('redirect')) {
    w.set('redirect_url', convertShortcodes(pget(w, 'redirect_to', '')));
    w.set('redirect_delay', 0);
    if (w.dynamicRef('redirect_to')) {
      w.consumeDynamic('redirect_to');
      w.note('The redirect URL was a dynamic tag; set the URL in the Zadex form.');
    }
  } else w.consume('redirect_to');

  if (out.includes('popup')) {
    const action = popupAction;
    w.set('popup_action', action === 'close' ? 'close' : 'open');
    // Elementor popup id -> Zadex popup template id through `source.popupTemplates` (src/convert/popup-links.ts).
    // Assumption: Elementor's "close" closes the popup holding the form when no popup is chosen, so a form inside a
    // converted popup closes that popup (its own id, when the server already put it in the map).
    const elId = w.raw('popup_action_popup_id');
    const map = ctx.source.popupTemplates;
    const zid = mapPopupId(elId, map) ?? (action === 'close' && isBlank(elId) && ctx.source.templateType === 'popup' ? mapPopupId(ctx.source.postId, map) : undefined);
    if (zid) {
      w.set('popup_id', zid);
      w.note(`The form popup action now ${action === 'close' ? 'closes' : 'opens'} the Zadex popup #${zid}.`);
    } else {
      w.note(
        isBlank(elId)
          ? 'The form popup action has no popup Zadex can use: choose the Zadex popup in the form\'s Popup action.'
          : `The form popup action pointed at Elementor popup #${String(elId)}, which has not been migrated to Zadex yet: migrate it and convert this page again, or choose the Zadex popup in the form.`,
      );
    }
    if (pbool(w, 'popup_action_do_not_show_again')) {
      w.note('"Do not show again" of the form popup action became no setting: turn on "Never show again after a form is sent" in the Zadex popup.');
    }
  } else w.consume('popup_action', 'popup_action_popup_id', 'popup_action_do_not_show_again');

  if (out.includes('webhook')) {
    w.set('webhook_url', String(pget(w, 'webhooks', '')));
    // Elementor posts the fields form-encoded (labels as keys); the closest Zadex format is "form".
    w.set('webhook_format', 'form');
    const advanced = pbool(w, 'webhooks_advanced_data');
    w.set('webhook_meta', advanced);
    w.note('Webhook payload keys differ from Elementor\'s (Zadex sends fields[<id>]); check the receiving Zap / scenario.');
  } else w.consume('webhooks', 'webhooks_advanced_data');

  const integration = (id: string, label: string, listKeys: string[], extra: () => void, creds: [string, ...string[]]): void => {
    const keys = [...listKeys, `${id}_fields_map`, `${id}_tags`];
    if (!out.includes(id)) {
      w.consume(...keys, ...creds);
      return;
    }
    const list = firstOf(w, ...listKeys);
    if (!isBlank(list)) w.set(`${id}_list`, String(list));
    fieldsMap(w, ctx, el, id);
    extra();
    credentials(w, label, ...creds);
  };
  integration('mailchimp', 'Mailchimp', ['mailchimp_list'], () => {
    const tags = tagsValue(w.raw('mailchimp_tags'));
    if (tags) w.set('mailchimp_tags', tags);
    w.set('mailchimp_double_optin', pbool(w, 'mailchimp_double_opt_in'));
    if (w.has('mailchimp_groups')) {
      w.raw('mailchimp_groups');
      w.note('Mailchimp groups (interests) are not supported by the Zadex action.');
    }
  }, ['mailchimp_api_key_source', 'mailchimp_api_key']);
  integration('activecampaign', 'ActiveCampaign', ['activecampaign_list'], () => {
    const tags = tagsValue(w.raw('activecampaign_tags'));
    if (tags) w.set('activecampaign_tags', tags);
  }, ['activecampaign_api_credentials_source', 'activecampaign_api_key', 'activecampaign_api_url']);
  integration('getresponse', 'GetResponse', ['getresponse_list'], () => {
    if (w.has('getresponse_dayofcycle')) {
      w.raw('getresponse_dayofcycle');
      w.note('The GetResponse autoresponder day is not supported by the Zadex action.');
    }
  }, ['getresponse_api_key_source', 'getresponse_custom_api_key']);
  // ConvertKit stores its form in `convertkit_form`, tags as a select2 array of tag ids.
  integration('convertkit', 'ConvertKit', ['convertkit_form'], () => {
    const tags = tagsValue(w.raw('convertkit_tags'));
    if (tags) w.set('convertkit_tags', tags);
  }, ['convertkit_api_key_source', 'convertkit_custom_api_key']);
  // MailerLite stores its group in `mailerlite_group`; the re-subscribe switch is the shared `allow_resubscribe`.
  integration('mailerlite', 'MailerLite', ['mailerlite_group'], () => {
    if (w.has('allow_resubscribe')) w.note('MailerLite re-subscribe is not an option of the Zadex action.');
    w.raw('allow_resubscribe');
  }, ['mailerlite_api_key_source', 'mailerlite_custom_api_key']);
  if (!out.includes('mailerlite')) w.consume('allow_resubscribe');
  if (out.includes('drip')) {
    fieldsMap(w, ctx, el, 'drip');
    // Drip's tags control is the unprefixed `tags` (comma separated, shortcodes allowed).
    const tags = tagsValue(w.raw('tags'));
    if (tags) w.set('drip_tags', tags);
    if (w.has('drip_account')) {
      w.raw('drip_account');
      w.note('Drip: the account ID is set in Zadex > Settings > Integrations.');
    }
    if (bool(w.raw('drip_custom_fields'))) w.note('Drip: "send all fields as custom fields" is not supported; map them in the Drip action.');
    credentials(w, 'Drip', 'drip_api_token_source', 'drip_custom_api_token');
  } else w.consume('drip_fields_map', 'tags', 'drip_account', 'drip_custom_fields', 'drip_api_token_source', 'drip_custom_api_token');

  if (out.includes('slack')) {
    w.set('slack_webhook_url', String(pget(w, 'slack_webhook', '')));
    const parts = [w.raw('slack_pretext'), w.raw('slack_title'), w.raw('slack_text')].filter((p) => !isBlank(p)).map((p) => convertShortcodes(p));
    if (parts.length) w.set('slack_message', parts.join('\n'));
    w.set('slack_blocks', pbool(w, 'slack_add_fields'));
    const user = w.raw('slack_username');
    if (!isBlank(user)) w.set('slack_username', String(user));
    const icon = w.raw('slack_icon_url');
    if (!isBlank(icon)) w.set('slack_icon', String(icon));
    for (const k of ['slack_channel', 'slack_add_ts', 'slack_webhook_color']) {
      if (w.has(k)) w.note(`Slack: "${k}" is not supported by the Zadex action.`);
      w.raw(k);
    }
  } else w.consume('slack_*');

  if (out.includes('discord')) {
    w.set('discord_webhook_url', String(pget(w, 'discord_webhook', '')));
    const title = w.raw('discord_title');
    const content = w.raw('discord_content');
    const parts = [isBlank(title) ? '' : `**${convertShortcodes(title)}**`, isBlank(content) ? '' : convertShortcodes(content)].filter(Boolean);
    if (parts.length) w.set('discord_message', parts.join('\n'));
    w.set('discord_embed', pbool(w, 'discord_form_data'));
    w.color('discord_webhook_color', 'discord_embed_color');
    const user = w.raw('discord_username');
    if (!isBlank(user)) w.set('discord_username', String(user));
    const avatar = w.raw('discord_avatar_url');
    if (!isBlank(avatar)) w.set('discord_avatar_url', String(avatar));
    if (w.has('discord_ts')) w.note('Discord: the timestamp option is not needed (Zadex always adds one to embeds).');
    w.raw('discord_ts');
  } else w.consume('discord_*');
  return out;
}

function convertMessages(w: ElementWriter): void {
  const custom = pbool(w, 'custom_messages');
  // The required-field message only replaces the browser's own message with "Custom" form validation.
  const customValidation = w.raw('form_validation') === 'custom';
  for (const [src, [dst, def]] of Object.entries(MESSAGES)) {
    const v = w.raw(src);
    const usable = custom && (src !== 'required_field_message' || customValidation);
    w.set(dst, usable && typeof v === 'string' && v !== '' ? v : def);
  }
  if (custom && w.has('server_message')) w.note('The server error message is shown as the general error message in Zadex.');
  w.raw('server_message');
}

function convertSteps(w: ElementWriter, fields: FieldsResult): void {
  w.set('next_text', fields.stepNext ?? pstr(w, 'step_next_label', 'Next'));
  w.set('prev_text', fields.stepPrev ?? pstr(w, 'step_previous_label', 'Previous'));
  const type = pstr(w, 'step_type', 'number_text');
  w.raw('step_icon_shape');
  if (!fields.hasSteps) return;
  w.set('show_progress', type === 'progress_bar');
  w.set('show_step_titles', ['text', 'number_text', 'icon_text'].includes(type));
  if (['number', 'icon', 'number_text', 'icon_text'].includes(type)) w.note(`Step indicator "${type}" is shown as step titles in Zadex (no numbers / icons).`);
  // Step styles: progress bar (height default 20px) or indicator colors, shared `steps_typography`.
  if (type === 'progress_bar') {
    w.color('step_progress_bar_color', 'progress_color');
    w.color('step_progress_bar_background_color', 'progress_bg');
    w.slider('step_progress_bar_height', 'progress_height');
  } else {
    w.color('step_inactive_primary_color', 'step_title_color');
    w.color('step_active_primary_color', 'step_title_active');
  }
  w.typography('steps_typography', 'step_typography');
}

function convertStyles(w: ElementWriter, ctx: ConvertContext): void {
  // Layout gaps (Pro defaults 10px via `w.get`; Zadex 16px).
  w.slider('column_gap', 'column_gap');
  w.slider('row_gap', 'row_gap');

  // Labels.
  w.color('label_color', 'label_color');
  w.typography('label_typography', 'label_typography');
  w.color('mark_required_color', 'required_color');
  const spacing = w.get('label_spacing');
  w.set('label_spacing', isObj(spacing) && !isBlank(spacing.size) ? { size: Number(spacing.size) || 0, unit: 'px' } : { size: 0, unit: 'px' });
  noteDeviceValues(w, 'label_spacing', 'Label spacing');

  // Fields: size preset (Elementor core `.elementor-field-textual.elementor-size-*`) + colors + border.
  const size = pstr(w, 'input_size', 'sm');
  const [fs, py, px, radius] = FIELD_PRESETS[size] ?? FIELD_PRESETS.sm!;
  w.color('field_text_color', 'field_color');
  w.typography('field_typography', 'field_typography');
  mergeDefaults(w, 'field_typography', { size: { size: fs, unit: 'px' } });
  // Pro default #ffffff.
  w.color('field_background_color', 'field_bg');
  const width = dimensions(w.raw('field_border_width'));
  const rad = dimensions(w.raw('field_border_radius'));
  const borderRef = w.globalRef('field_border_color');
  const rawBorder = w.raw('field_border_color');
  const borderColor = borderRef?.kind === 'colors' ? colorRef(ctx, borderRef.id) : typeof rawBorder === 'string' && rawBorder !== '' ? rawBorder : undefined;
  w.set('field_border', { style: 'solid', width: width ?? pxDims(1, 1), color: borderColor ?? '#69727d', radius: rad ?? pxDims(radius, radius) });
  noteDeviceValues(w, 'field_border_width', 'Field border width');
  noteDeviceValues(w, 'field_border_radius', 'Field border radius');
  w.set('field_padding', pxDims(py, px));

  // Submit button.
  const bsize = pstr(w, 'button_size', 'sm');
  const [bfs, bpy, bpx, bradius] = BUTTON_PRESETS[bsize] ?? BUTTON_PRESETS.sm!;
  w.typography('button_typography', 'button_typography');
  mergeDefaults(w, 'button_typography', { size: { size: bfs, unit: 'px' }, lineHeight: { size: 1, unit: 'custom' } });
  w.color('button_text_color', 'button_color');
  w.color('button_background_color', 'button_bg');
  w.color('button_hover_color', 'button_color', 'hover');
  w.color('button_background_hover_color', 'button_bg', 'hover');
  w.border('button_border', 'button_border', 'button_border_radius');
  mergeDefaults(w, 'button_border', { radius: pxDims(bradius, bradius) });
  for (const k of Object.keys(w.settings)) if (k.startsWith('button_border@')) {
    delete w.settings[k];
    w.note('Button border: per-device values are not supported by this Zadex control; the desktop value is used.');
  }
  const pad = dimensions(w.raw('button_text_padding'));
  w.set('button_padding', pad ?? pxDims(bpy, bpx));
  noteDeviceValues(w, 'button_text_padding', 'Button padding');
  if (w.has('button_hover_border_color')) w.note('The button hover border color is not supported by the Zadex form.');
  w.raw('button_hover_border_color');
  const anim = w.raw('button_hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Button hover animation "${anim}" is not available in Zadex.`);
  // Previous (step) button: normal colors (text default #ffffff); Zadex has no hover state for it.
  w.color('previous_button_text_color', 'prev_color');
  w.color('previous_button_background_color', 'prev_bg');
  for (const k of ['previous_button_text_color_hover', 'previous_button_background_color_hover', 'previous_button_border_color', 'previous_button_border_color_hover']) {
    const v = w.raw(k);
    if (!isBlank(v) && !(k === 'previous_button_text_color_hover' && String(v).toLowerCase() === '#ffffff')) {
      w.note('The previous-step button hover / border colors are not supported by the Zadex form.');
    }
  }

  // Messages.
  w.color('success_message_color', 'success_color');
  w.color('error_message_color', 'error_color');
  if (!w.settings.error_color) w.color('inline_message_color', 'error_color');
  else w.raw('inline_message_color');
  w.typography('message_typography', 'message_typography');
}

/** Elementor Pro `form` -> Zadex `form`. */
registerWidget('form', (source, ctx) => {
  // Pro's global defaults (form.php `global` args).
  const el = withGlobalDefaults(source, ctx, {
    label_color: 'globals/colors?id=text',
    label_typography_typography: 'globals/typography?id=text',
    field_text_color: 'globals/colors?id=text',
    field_typography_typography: 'globals/typography?id=text',
    button_background_color: 'globals/colors?id=accent',
    button_typography_typography: 'globals/typography?id=accent',
    previous_button_background_color: 'globals/colors?id=accent',
    message_typography_typography: 'globals/typography?id=text',
    steps_typography_typography: 'globals/typography?id=accent',
    step_inactive_primary_color: 'globals/colors?id=text',
    step_active_primary_color: 'globals/colors?id=accent',
    step_progress_bar_color: 'globals/colors?id=accent',
    step_progress_bar_background_color: 'globals/colors?id=text',
  });
  const w = ctx.writer(el, 'form');
  markPro(w);

  w.set('form_name', pstr(w, 'form_name', 'New Form'));
  const fields = convertFields(w, ctx, source);
  w.set('fields', fields.fields);
  if (fields.fields.length === 0) w.note('The form has no fields.');
  w.set('show_labels', pbool(w, 'show_labels'));
  w.set('mark_required', pbool(w, 'mark_required'));
  // Hidden control in Pro 3.33.2 (default "above"); older forms may still store "inline".
  w.set('label_position', w.raw('label_position') === 'inline' ? 'inline' : 'top');
  w.set('honeypot', fields.honeypot);
  if (fields.recaptcha) w.set('recaptcha', fields.recaptcha);

  // Buttons.
  w.set('button_text', pstr(w, 'button_text', 'Send'));
  const ic = iconValue(w, 'selected_button_icon', true);
  if (ic) {
    w.set('button_icon', ic);
    // `row` (icon first, default) / `row-reverse`; forms saved before Pro 3.x stored `left` / `right`.
    const align = w.raw('button_icon_align');
    if (align === 'right' || align === 'row-reverse') w.note('The submit icon is placed before the text in Zadex.');
    const indent = w.raw('button_icon_indent');
    if (isObj(indent) && !isBlank(indent.size)) w.note('The submit icon spacing is not carried over.');
  }
  // `button_icon`: pre-Font Awesome 5 key, migrated to `selected_button_icon` by Elementor.
  w.consume('button_icon_align', 'button_icon_indent', 'button_icon');
  const bwidth = String(pget(w, 'button_width', '100'));
  noteDeviceValues(w, 'button_width', 'Button width');
  const balign = String(pget(w, 'button_align', 'stretch'));
  const table = flexAlign(ctx);
  if (balign === 'stretch' || balign === 'justify') w.set('button_full', true);
  else {
    w.set('button_full', false);
    const a = table[balign];
    if (a && a !== 'stretch') w.set('button_align', a);
  }
  for (const bp of ['tablet', 'mobile', 'tablet_extra', 'mobile_extra', 'laptop', 'widescreen'] as const) {
    const v = w.raw(`button_align_${bp}`);
    if (isBlank(v)) continue;
    const a = table[String(v)];
    const zbp = bp === 'tablet_extra' ? 'tablet_large' : bp === 'mobile_extra' ? 'mobile_large' : bp;
    if (a && a !== 'stretch') w.set('button_align', a, { bp: zbp });
    else w.note('Per-device "stretch" button alignment is not supported by Zadex.');
  }
  if (bwidth !== '100' && (balign === 'stretch' || balign === 'justify')) w.note(`The submit button column width (${bwidth}%) is not carried over; it spans the full form width.`);
  else if (bwidth !== '100') w.note(`The submit button column width (${bwidth}%) is not carried over.`);
  if (w.has('button_css_id')) w.note('The submit button CSS ID is not carried over.');
  w.raw('button_css_id');

  convertSteps(w, fields);
  convertActions(w, ctx, source);
  convertMessages(w);

  const formId = w.raw('form_id');
  if (!isBlank(formId)) w.note('The form ID attribute is not carried over (add it as the CSS ID in the Advanced tab if needed).');

  convertStyles(w, ctx);
  return w.finish();
});
