import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { toInt } from './_pro-posts';
import { wooFallback, wooGuard } from './_woo';
import { WOO_PROBE } from './_woo-shop';

/**
 * Elementor Pro `wc-elements` (WooCommerce pages as shortcodes) -> Zadex `shortcode` with the same WooCommerce
 * shortcode, so the output is WooCommerce's own. Verified against Elementor Pro 3.33.2: `element` '' |
 * woocommerce_cart | product_page (+ `product_id`) | woocommerce_checkout | woocommerce_order_tracking |
 * woocommerce_my_account (the short names cart / checkout / order_tracking / my_account are accepted too).
 * Unknown / empty elements fall back like an inactive WooCommerce (rendered HTML or skipped).
 */
const SHORTCODES: Record<string, string> = {
  woocommerce_cart: '[woocommerce_cart]',
  cart: '[woocommerce_cart]',
  woocommerce_checkout: '[woocommerce_checkout]',
  checkout: '[woocommerce_checkout]',
  woocommerce_order_tracking: '[woocommerce_order_tracking]',
  order_tracking: '[woocommerce_order_tracking]',
  woocommerce_my_account: '[woocommerce_my_account]',
  my_account: '[woocommerce_my_account]',
};

registerWidget('wc-elements', (source, ctx) => {
  const off = wooGuard(source, ctx, ['shortcode', WOO_PROBE]);
  if (off) return off;
  const element = String(source.settings?.element ?? '');
  const productId = toInt(source.settings?.product_id);
  let shortcode = SHORTCODES[element];
  if (element === 'product_page' && productId) shortcode = `[product_page id="${productId}"]`;
  if (!shortcode) {
    const why = element === 'product_page' ? 'No product was chosen for the WooCommerce product page element' : `WooCommerce element "${element || '(none)'}" is not known`;
    return wooFallback(source, ctx, why);
  }
  const w = ctx.writer(source, 'shortcode');
  markPro(w);
  w.raw('element');
  w.raw('product_id');
  w.set('shortcode', shortcode);
  w.note(`Converted to the WooCommerce shortcode ${shortcode}.`);
  return w.finish();
});

/**
 * Elementor Pro `wc-single-elements` (deprecated, hidden from the panel: one WooCommerce single-product template
 * function of the current product). Verified against Elementor Pro 3.33.2: one control `element` with the function
 * names below. Each maps to the matching Zadex product widget with its defaults; Sharing (a theme / plugin hook) and
 * the standalone sale flash have no Zadex widget and fall back (rendered HTML or skipped).
 */
const SINGLE: Record<string, { type: string; settings?: Record<string, unknown>; note?: string }> = {
  woocommerce_output_product_data_tabs: { type: 'product-data-tabs', settings: { description: false }, note: 'Elementor removes the Description tab here; Zadex shows the other tabs.' },
  woocommerce_template_single_title: { type: 'product-title' },
  woocommerce_template_single_rating: { type: 'product-rating' },
  woocommerce_template_single_price: { type: 'product-price' },
  woocommerce_template_single_excerpt: { type: 'product-short-description' },
  woocommerce_template_single_meta: { type: 'product-meta' },
  woocommerce_product_additional_information_tab: { type: 'product-data-tabs', settings: { description: false, additional: true, reviews: false }, note: 'Shown as product data tabs with only the "Additional information" tab (its tab title is visible).' },
  woocommerce_upsell_display: { type: 'product-upsells' },
  wc_get_stock_html: { type: 'product-stock' },
};

registerWidget('wc-single-elements', (source, ctx) => {
  const element = String(source.settings?.element ?? '');
  const target = SINGLE[element];
  if (!target) {
    const why = element === '' ? 'No WooCommerce element was chosen' : `WooCommerce element "${element}" has no Zadex widget`;
    if (!ctx.hasWidget(WOO_PROBE)) return wooFallback(source, ctx);
    return wooFallback(source, ctx, why);
  }
  const off = wooGuard(source, ctx, target.type);
  if (off) return off;
  const w = ctx.writer(source, target.type);
  markPro(w);
  w.raw('element');
  for (const [k, v] of Object.entries(target.settings ?? {})) w.set(k, v);
  w.note(`WooCommerce element "${element}" (current product) became the Zadex ${target.type} widget with its default styles.`);
  if (target.note) w.note(target.note);
  return w.finish();
});
