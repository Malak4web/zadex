import type { ConvertContext, ElementWriter } from '../context';
import { bool, isBlank, num, slider } from '../values';
import { iconValue } from './_shared';
import { buttonBackground } from './button';

/**
 * Helpers for the Elementor Pro content widgets (table-of-contents, share-buttons, blockquote, facebook-*, template,
 * global, lottie, code-highlight, hotspot, paypal-button, stripe-button, progress-tracker, off-canvas,
 * link-in-bio-var-*, contact-buttons-var-*, floating-bars-var-*).
 *
 * Verified against Elementor Pro 3.33.2 (`dev/reference/elementor-pro-controls.json`):
 * `src/convert/data/elementor-defaults.json` holds Pro's real defaults, so the helpers read the stored value through
 * `w.get()` (Pro's default when the key is absent). `def` is only used for keys Pro gives no (or an empty) default.
 */

/** Stored value, else Elementor Pro's default, else `def`. Marks the key as handled. */
export function proVal<T>(w: ElementWriter, key: string, def?: T): unknown {
  const v = w.get(key);
  return v === undefined || v === null ? def : v;
}

/** Stored text, else Pro's default, else `def`. */
export function proText(w: ElementWriter, key: string, def = ''): string {
  const v = proVal(w, key, def);
  return typeof v === 'string' || typeof v === 'number' ? String(v) : def;
}

/** Elementor switcher (`'yes'` / `''` / `'no'`, or a custom return value such as `'line-numbers'`), else Pro's default. */
export function proSwitch(w: ElementWriter, key: string, def = false): boolean {
  const v = w.get(key);
  return v === undefined || v === null ? def : bool(v);
}

/** Number from a number control or a slider's size, else undefined. */
export function proNumber(v: unknown): number | undefined {
  const s = typeof v === 'object' && v !== null ? slider(v)?.size : num(v);
  return typeof s === 'number' ? s : undefined;
}

/**
 * Physical Elementor alignment (`left|center|right|justify`, newer `start|end`) -> logical Zadex alignment
 * (`start|center|end|stretch`). Physical left is the start on LTR sites and the end on RTL sites.
 */
export function logicalAlign(ctx: ConvertContext, withStretch = true): Record<string, string> {
  const rtl = Boolean(ctx.source.rtl);
  const out: Record<string, string> = {
    left: rtl ? 'end' : 'start',
    right: rtl ? 'start' : 'end',
    center: 'center',
    start: 'start',
    end: 'end',
  };
  if (withStretch) {
    out.justify = 'stretch';
    out.stretch = 'stretch';
  }
  return out;
}

/** Elementor button size presets -> Zadex presets (same table as the basic button mapper). */
const BUTTON_SIZES: Record<string, string> = { xs: 'sm', sm: 'md', md: 'lg', lg: 'xl', xl: 'xl' };

/**
 * The Elementor button controls the Pro payment widgets inherit (Pro 3.33.2 `Payment_Button`: `text` "Buy Now",
 * `selected_icon` (PayPal `fab fa-paypal`, Stripe `fab fa-stripe-s`), `icon_align` row|row-reverse, `icon_indent`,
 * `button_css_id`, `align` R + `content_align`, typography, text shadow, `button_text_color` (#FFF), background group
 * `background` (PayPal #032E82, Stripe #635bff), hover colors, border, `text_padding`, shadows, `hover_animation`) ->
 * the Zadex payment button controls (`paypal-button`, `stripe-button`). Pro removes Elementor's `size` and
 * `button_type` controls; a stored `size` (older data) is still honoured.
 */
export function paymentButton(w: ElementWriter, ctx: ConvertContext): void {
  w.set('text', proText(w, 'text', 'Buy Now'));
  if (w.dynamicRef('text')) w.note('The button text was bound to a dynamic tag; the static text was kept.');
  const size = w.raw('size');
  w.set('size', (typeof size === 'string' && BUTTON_SIZES[size]) || 'md');

  // Pro's default icon comes from elementor-defaults.json (PayPal / Stripe brand icon).
  const ic = iconValue(w, 'selected_icon');
  w.set('icon', ic ?? { library: '', value: '' });
  const iconAlign = w.raw('icon_align');
  if (ic && (iconAlign === 'right' || iconAlign === 'row-reverse')) w.note('The icon after the text is not available on the Zadex payment button (it is shown before).');
  w.consumeResponsive('icon_indent');

  w.map('align', 'align', logicalAlign(ctx));
  const contentAlign = w.raw('content_align');
  if (typeof contentAlign === 'string' && contentAlign !== '' && contentAlign !== 'center') w.note('The content alignment inside a full-width button is not carried over (centered).');
  w.consumeResponsive('content_align');
  const cssId = w.raw('button_css_id');
  if (typeof cssId === 'string' && cssId !== '') w.note('The button CSS id is not carried over (use the element CSS id).');

  w.typography('typography', 'typography');
  if (bool(w.raw('text_shadow_text_shadow_type'))) w.note('The button text shadow is not available on the Zadex payment button.');
  w.consume('text_shadow_*');
  w.color('button_text_color', 'color');
  w.color('hover_color', 'color', 'hover');
  buttonBackground(w, 'background');
  buttonBackground(w, 'button_background_hover', 'hover');
  w.border('border', 'border', 'border_radius');
  w.color('button_hover_border_color', 'border', 'hover');
  const hoverBorder = w.settings['border::hover'];
  if (typeof hoverBorder === 'string') w.set('border', { color: hoverBorder }, { state: 'hover' });
  // The Zadex border control is not responsive on the payment buttons: keep the desktop value.
  for (const key of Object.keys(w.settings)) {
    if (key.startsWith('border@') || (key.startsWith('border::') && key.includes('@'))) {
      delete w.settings[key];
      w.note('border: per-device values are not supported by this Zadex control; the desktop value is used.');
    }
  }
  w.dimensions('text_padding', 'padding');
  w.boxShadow('button_box_shadow', 'box_shadow');
  w.boxShadow('button_hover_box_shadow', 'box_shadow', 'hover');
  w.consume('button_hover_transition_duration');
  const anim = w.raw('hover_animation');
  if (typeof anim === 'string' && anim !== '') w.note(`Hover animation "${anim}" is not available on the Zadex payment button.`);
  w.consume('button_type');

  // Error message styles (Pro prints its messages under the button; the Zadex payment buttons style their own).
  if (w.has('message_color_global') || w.has('message_color_payment') || w.raw('message_typography_typography') === 'custom') {
    w.note('The error message colors / typography are not carried over.');
  }
  w.consume('message_*');
}

/** Elementor Facebook `url_type` (`current_page` | `custom`) + `url` -> Zadex `url_source` + `target_url`. */
export function facebookTarget(w: ElementWriter): void {
  const type = proText(w, 'url_type', 'current_page');
  const href = proText(w, 'url', '').trim();
  if (type === 'custom' && href !== '') {
    w.set('url_source', 'custom');
    w.set('target_url', href);
  } else {
    w.set('url_source', 'current');
    if (type === 'custom') w.note('The custom Facebook URL was empty; the current page URL is used.');
  }
  const format = w.raw('url_format');
  if (format === 'pretty') w.note('The "pretty permalink" URL format is not needed in Zadex (the permalink is used).');
}

/** Removes `<p>` wrappers from WYSIWYG HTML for a Zadex textarea (inline tags are kept). */
export function wysiwygToTextarea(html: unknown): string {
  if (typeof html !== 'string' || isBlank(html)) return '';
  return html
    .replace(/<\/p>\s*<p[^>]*>/gi, '\n')
    .replace(/<\/?p[^>]*>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .trim();
}

/** First key holding a value or a global (to feed responsive / global-aware helpers); the others count as handled. */
export function firstKey(w: ElementWriter, keys: string[]): string {
  const hit = keys.find((k) => w.has(k) || w.globalRef(k));
  for (const k of keys) if (k !== hit) w.consume(k);
  return hit ?? keys[0]!;
}
