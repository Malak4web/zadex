import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { desktopOnly, only, toNumber, withGlobalDefaults } from './_shared';
import { fixedSource } from './_theme';

/**
 * Elementor Pro `theme-post-excerpt` -> Zadex `post-excerpt`. Verified against Pro 3.33.2
 * (`modules/theme-builder/widgets/post-excerpt.php`): `excerpt` (text with the `post-excerpt` tag as dynamic
 * default; tag settings `max_length` (empty = WordPress' 55 words) and `apply_to_post_content`), `align` R
 * (left | center | right | justify), `typography` (global text), `text_shadow`, `paragraph_spacing` R,
 * `title_color` ("Text Color", global text), `link_color`, `link_hover_color` (+ transition). The widget has no
 * length control of its own.
 */
registerWidget('theme-post-excerpt', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_color: 'globals/colors?id=text',
    typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'post-excerpt');
  markPro(w);
  const tag = fixedSource(w, 'excerpt', ['post-excerpt'], 'post excerpt');
  const length = toNumber(tag?.settings.max_length);
  w.set('length', length !== undefined && length >= 0 ? length : 55);
  if (tag?.settings.apply_to_post_content === 'yes') w.note('"Apply to post content" is not carried over (Zadex excerpts the post content when there is no excerpt).');
  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right', 'justify']));
  w.color('title_color', 'color');
  desktopOnly(w, 'color');
  w.typography('typography', 'typography');
  if (w.raw('text_shadow_text_shadow_type') === 'yes') w.note('The text shadow is not available on the Zadex post excerpt.');
  w.consume('text_shadow_*');
  if (w.has('paragraph_spacing')) w.note('Paragraph spacing is not available on the Zadex post excerpt.');
  w.consumeResponsive('paragraph_spacing');
  if (w.has('link_color') || w.has('link_hover_color')) w.note('Link colors inside the excerpt are not available on the Zadex post excerpt.');
  w.consume('link_color', 'link_hover_color', 'link_hover_color_transition_duration');
  return w.finish();
});
