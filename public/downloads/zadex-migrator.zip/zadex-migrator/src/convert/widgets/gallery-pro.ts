import { registerWidget } from '../registry';
import { textAlign } from '../align';
import { bool, isBlank, slider, url } from '../values';
import { markPro } from './_pro';
import { galleryImages } from './_media-support';
import { itemIdFor, repeaterItems, withGlobalDefaults } from './_shared';
import {
  borderFrom,
  colorOf,
  desktopSlider,
  flexOf,
  getBool,
  getStr,
  imageSizeName,
  responsiveGet,
  responsiveSliderGet,
  sliderOrDims,
} from './_pro-posts';

const SIZES = ['thumbnail', 'medium', 'medium_large', 'large', 'full'];
const TRANSPARENT = 'rgba(0,0,0,0)';

/** Pro `aspect_ratio` options -> Zadex `ratio` (portrait 9:16 and 21:9 approximated). */
const RATIOS: Record<string, string> = { '1:1': '1 / 1', '3:2': '3 / 2', '4:3': '4 / 3', '16:9': '16 / 9', '9:16': '3 / 4', '21:9': '16 / 9' };

/** Pro `image_hover_animation` -> Zadex `hover_animation` (the "move contained" pans have no equivalent). */
const HOVER: Record<string, string> = { '': 'none', grow: 'zoom-in', 'shrink-contained': 'zoom-out' };

/**
 * Elementor Pro `gallery` -> Zadex `gallery-pro`, verified against Pro 3.33.2: `gallery_type` single | multiple,
 * `gallery` / `galleries` repeater {`gallery_title` (New Gallery), `multiple_gallery`}, `order_by` '' | random,
 * `lazyload` (yes), `gallery_layout` grid | justified | masonry, `columns` R (4 / 2 / 1), `ideal_row_height` R
 * (200 / 150px), `gap` R (10px), `link_to` file (default) | custom | '', `url`, `open_lightbox` default | yes | no,
 * `aspect_ratio` (3:2), `thumbnail_image_size` (medium), `show_all_galleries` (yes) + label (All), `pointer`
 * (underline), `overlay_background` (yes) with the background groups `overlay_background_*` (always shown) and
 * `overlay_background_hover_*` (hover, default rgba(0,0,0,0.5)), `overlay_title` / `overlay_description`,
 * `image_hover_animation`, `content_hover_animation` (fade-in), style `image_border_width` / `_color` / `_radius`
 * (sliders, + hover), `content_alignment` (center), `content_vertical_position`, `content_padding` (20px),
 * `title_color` / `title_typography_*` (kit primary), filter bar `align_filter_bar_items`,
 * `galleries_title_color_normal` / `_hover` / `_active`, `galleries_titles_typography_*`,
 * `galleries_titles_space_between`, `galleries_titles_gap`.
 */
registerWidget('gallery', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    title_typography_typography: 'globals/typography?id=primary',
    galleries_title_color_normal: 'globals/colors?id=primary',
    galleries_titles_typography_typography: 'globals/typography?id=primary',
    galleries_title_color_hover: 'globals/colors?id=secondary',
    galleries_title_color_active: 'globals/colors?id=secondary',
  });
  const w = ctx.writer(el, 'gallery-pro');
  markPro(w);
  const rtl = Boolean(ctx.source.rtl);

  // Galleries.
  const multiple = getStr(w, 'gallery_type') === 'multiple';
  const galleries: Array<{ _id: string; title: string; images: ReturnType<typeof galleryImages>; links: string }> = [];
  if (multiple) {
    repeaterItems(w.raw('galleries')).forEach((item, i) => {
      const title = typeof item.gallery_title === 'string' ? item.gallery_title : 'New Gallery';
      galleries.push({ _id: itemIdFor(ctx, el, item, i), title, images: galleryImages(ctx, item.multiple_gallery), links: '' });
    });
    w.consume('gallery');
  } else {
    galleries.push({ _id: ctx.itemId(`${el.id}g`), title: 'Gallery', images: galleryImages(ctx, w.raw('gallery')), links: '' });
    w.consume('galleries');
  }
  const count = galleries.reduce((n, g) => n + g.images.length, 0);
  if (!count) w.note('The gallery has no images.');

  // Links (one custom URL for every image; Zadex takes one per line).
  const linkTo = getStr(w, 'link_to');
  const custom = url(w.raw('url'));
  if (linkTo === 'custom' && custom) {
    w.set('link', 'custom');
    for (const g of galleries) g.links = g.images.map(() => custom.url).join('\n');
    w.set('link_new_tab', custom.target === '_blank');
  } else {
    w.set('link', linkTo === 'file' ? 'file' : 'none');
    if (linkTo === 'custom') w.note('The custom link of the gallery is empty; images are not linked.');
  }
  if (linkTo === 'file' && getStr(w, 'open_lightbox') === 'no') w.note('Zadex opens file links of the gallery in its lightbox.');
  w.set('galleries', galleries);
  if (getStr(w, 'order_by') === 'random') {
    w.note('Random image order is not available in Zadex; images keep their saved order.');
    w.status('partial');
  }
  w.set('lazy', getBool(w, 'lazyload'));

  // Layout.
  const layout = getStr(w, 'gallery_layout') || 'grid';
  w.set('layout', ['grid', 'justified', 'masonry'].includes(layout) ? layout : 'grid');
  if (layout !== 'justified') responsiveGet(w, 'columns', 'columns', [1, 12]);
  else w.consume('columns*');
  responsiveSliderGet(w, 'gap', 'gap');
  if (layout === 'justified') responsiveSliderGet(w, 'ideal_row_height', 'row_height');
  else w.consume('ideal_row_height*');
  if (layout === 'grid') {
    const ar = getStr(w, 'aspect_ratio') || '3:2';
    w.set('ratio', RATIOS[ar] ?? '3 / 2');
    if (ar === '9:16' || ar === '21:9') w.note(`Aspect ratio ${ar} is not available in Zadex; the closest ratio is used.`);
  } else w.consume('aspect_ratio');
  w.set('image_size', imageSizeName(w, getStr(w, 'thumbnail_image_size') || 'medium', SIZES, 'medium'));
  w.consume('thumbnail_image_custom_dimension');

  // Overlay: Zadex shows one overlay color on hover (Pro's hover background, default rgba(0,0,0,0.5)).
  const overlay = getBool(w, 'overlay_background');
  w.set('overlay', overlay);
  if (overlay) {
    const hoverType = getStr(w, 'overlay_background_hover_background');
    const hoverColor = colorOf(w, 'overlay_background_hover_color');
    if (hoverColor) w.set('overlay_bg', hoverColor);
    if (hoverType && hoverType !== 'classic') w.note(`The ${hoverType} hover overlay is not available in Zadex; only its first color is kept.`);
    if (getStr(w, 'overlay_background_background') !== '' || !isBlank(w.raw('overlay_background_color'))) {
      w.note('An always-visible overlay color is not available in Zadex; only the hover overlay is kept.');
    }
    if (!isBlank(w.raw('image_blend_mode'))) w.note('The overlay blend mode is not available in Zadex.');
    if (!isBlank(w.raw('background_overlay_hover_animation'))) w.note('Overlay animations are not available in Zadex; the overlay fades in.');
  }
  w.consume('overlay_background_*', 'image_blend_mode', 'background_overlay_hover_animation', 'background_overlay_animation_duration');

  // Captions.
  const title = getStr(w, 'overlay_title');
  const caption = title === 'description' ? 'caption' : ['title', 'caption', 'alt'].includes(title) ? title : 'none';
  if (title === 'description') w.note('Zadex shows the attachment caption instead of the description.');
  w.set('caption', caption);
  if (caption !== 'none') w.set('caption_position', 'hover');
  if (!isBlank(w.raw('overlay_description'))) {
    w.note('A second overlay text (description) is not available in Zadex.');
    w.status('partial');
  }
  w.consume('description_color', 'description_typography_*');
  const hover = getStr(w, 'image_hover_animation');
  w.set('hover_animation', HOVER[hover] ?? 'none');
  if (!(hover in HOVER)) w.note(`Image hover animation "${hover}" is not available in Zadex.`);
  w.consume('image_animation_duration');
  const contentAnim = getStr(w, 'content_hover_animation');
  if (caption !== 'none' && contentAnim !== 'fade-in' && contentAnim !== '') w.note(`Overlay text animation "${contentAnim}" is not available in Zadex; the text fades in.`);
  w.consume('content_animation_duration', 'content_sequenced_animation');

  // Filter bar (multiple galleries).
  w.set('show_filter', multiple);
  if (multiple) {
    const showAll = getBool(w, 'show_all_galleries');
    w.set('show_all', showAll);
    if (showAll) w.set('all_text', getStr(w, 'show_all_galleries_label'));
    else w.consume('show_all_galleries_label');
    const align = flexOf(w.raw('align_filter_bar_items'), rtl);
    if (align) w.set('filter_align', align);
    w.typography('galleries_titles_typography', 'filter_typography');
    w.color('galleries_title_color_normal', 'filter_color');
    const colorHover = colorOf(w, 'galleries_title_color_hover');
    if (colorHover) w.set('filter_color', colorHover, { state: 'hover' });
    w.color('galleries_title_color_active', 'filter_active_color');
    w.set('filter_bg', TRANSPARENT);
    w.set('filter_active_bg', TRANSPARENT);
    w.set('filter_border', { style: 'none' });
    desktopSlider(w, 'galleries_titles_space_between', 'filter_gap');
    desktopSlider(w, 'galleries_titles_gap', 'filter_spacing');
    const pointer = getStr(w, 'pointer');
    if (pointer !== '' && pointer !== 'none') w.note(`The "${pointer}" pointer of the filter bar is not available in Zadex.`);
  }
  w.consume('show_all_galleries*', 'pointer', 'pointer_width', 'animation_line', 'animation_framed', 'animation_background', 'animation_text', 'galleries_*', 'align_filter_bar_items');

  // Image style (Pro: slider width + color, solid).
  const border = borderFrom(w.raw('image_border_width'), colorOf(w, 'image_border_color'));
  if (border) w.set('image_border', border);
  const borderHover = colorOf(w, 'image_border_color_hover');
  if (border && borderHover) w.set('image_border', { ...border, color: borderHover }, { state: 'hover' });
  const radius = sliderOrDims(w.raw('image_border_radius'));
  if (radius) w.set('image_radius', radius);
  if (slider(w.raw('image_border_radius_hover'))) w.note('A different border radius on hover is not available in Zadex.');
  if (bool(w.raw('image_css_filters_css_filter')) || bool(w.raw('image_css_filters_hover_css_filter'))) w.note('CSS filters on the gallery images are not available in Zadex.');
  w.consume('image_css_filters_*');

  // Caption style (Pro "Content" section). Pro text sits on the overlay without a box of its own.
  if (caption !== 'none') {
    const a = getStr(w, 'content_alignment');
    const v = textAlign(ctx)[a];
    if (v && v !== 'justify') w.set('caption_align', v);
    w.color('title_color', 'caption_color');
    w.typography('title_typography', 'caption_typography');
    w.set('caption_bg', TRANSPARENT);
    const pad = slider(w.get('content_padding'));
    if (pad) {
      const n = Number(pad.size);
      w.set('caption_padding', { top: n, right: n, bottom: n, left: n, unit: pad.unit, linked: true });
    }
    if (getStr(w, 'content_vertical_position') !== 'bottom') w.note('Zadex shows the overlay text at the bottom of the image (Elementor: vertically centered unless set to bottom).');
  }
  w.consume('content_alignment', 'content_padding', 'content_vertical_position', 'title_color', 'title_typography_*', 'title_spacing');
  return w.finish();
});
