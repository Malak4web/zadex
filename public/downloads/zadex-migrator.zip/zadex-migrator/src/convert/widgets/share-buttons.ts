import { registerWidget } from '../registry';
import { flexAlign } from '../align';
import { deviceKeys } from '../responsive';
import { slider, url } from '../values';
import { markPro } from './_pro';
import { proText, proVal } from './_pro-content';
import { desktopOnly, itemIdFor, only, repeaterItems } from './_shared';

/**
 * Elementor share network -> Zadex network. Pro 3.33.2 offers facebook, twitter, x-twitter, linkedin, pinterest,
 * reddit, vk, odnoklassniki, tumblr, digg, skype, stumbleupon, mix, telegram, pocket, xing, whatsapp, email, print,
 * threads; the ones missing here have no Zadex button.
 */
const NETWORKS: Record<string, string> = {
  facebook: 'facebook',
  twitter: 'x',
  'x-twitter': 'x',
  linkedin: 'linkedin',
  whatsapp: 'whatsapp',
  telegram: 'telegram',
  pinterest: 'pinterest',
  reddit: 'reddit',
  email: 'email',
  print: 'print',
};

/**
 * Elementor skins -> Zadex skins (closest look): flat / gradient = filled (solid), framed = brand-colored border and
 * text (outline), boxed = border + filled icon box (framed), minimal = filled icon box without a frame (framed, or
 * solid for icon-only buttons).
 */
const SKINS: Record<string, string> = { flat: 'solid', gradient: 'solid', framed: 'outline', boxed: 'framed', minimal: 'framed' };
const VIEWS: Record<string, string> = { 'icon-text': 'both', icon: 'icon', text: 'text' };

/**
 * Elementor Pro `share-buttons` -> Zadex `share-buttons`. Keys verified against Elementor Pro 3.33.2 (defaults from
 * elementor-defaults.json): `share_buttons` repeater {`button`, `text`} (facebook, twitter, linkedin), `view`
 * icon-text|icon|text (icon-text), `show_label` (yes, icon-text view), `skin` gradient|minimal|framed|boxed|flat
 * (gradient), `shape` square|rounded|circle (square), `columns` 0…6 R ('0' = auto), `alignment`
 * left|center|right|justify R (auto columns only), `share_url_type` current_page|custom + `share_url` (url),
 * `column_gap` (10px) / `row_gap` (10px), `button_size` (factor: font-size = size x 10px), `icon_size` (em),
 * `button_height` (em), `border_size` (2px, framed / boxed), `color_source` official|custom + `primary_color` /
 * `secondary_color` (+ `_hover`), `typography`, `text_padding` (text view).
 */
registerWidget('share-buttons', (el, ctx) => {
  const w = ctx.writer(el, 'share-buttons');
  markPro(w);

  const raw = proVal(w, 'share_buttons', []);
  const unsupported: string[] = [];
  const items: Array<Record<string, unknown>> = [];
  repeaterItems(raw).forEach((item, i) => {
    const button = String(item.button ?? 'facebook');
    const network = NETWORKS[button];
    if (!network) {
      unsupported.push(button);
      return;
    }
    items.push({ _id: itemIdFor(ctx, el, item, i), network, label: typeof item.text === 'string' ? item.text : '' });
  });
  w.set('networks', items);
  if (unsupported.length) {
    w.note(`Share networks without a Zadex button were left out: ${unsupported.join(', ')}.`);
    w.status('partial');
  }

  const view = proText(w, 'view', 'icon-text');
  w.set('view', VIEWS[view] ?? 'both');
  if (view === 'icon-text' && proText(w, 'show_label', 'yes') === '') w.set('view', 'icon');
  else w.consume('show_label');
  const skin = proText(w, 'skin', 'gradient');
  const zskin = skin === 'minimal' && view === 'icon' ? 'solid' : (SKINS[skin] ?? 'solid');
  w.set('skin', zskin);
  if (skin === 'gradient' || skin === 'minimal') w.note(`Skin "${skin}" is approximated with the Zadex "${zskin}" skin.`);
  const shape = proText(w, 'shape', 'square');
  w.set('shape', ['square', 'rounded', 'circle'].includes(shape) ? shape : 'square');

  for (const [key, bp] of deviceKeys('columns')) {
    const v = bp ? w.raw(key) : w.get(key);
    if (v === undefined || v === null || v === '') continue;
    const n = String(v);
    w.set('columns', n === '0' ? 'auto' : ['1', '2', '3', '4', '5', '6'].includes(n) ? n : 'auto', { bp });
  }
  const align = { ...only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']), justify: 'space-between' };
  w.map('alignment', 'align', align);
  if (w.raw('alignment') === 'justify') w.note('Justified buttons are approximated with "space between" (buttons keep their width).');

  const urlType = proText(w, 'share_url_type', 'current_page');
  const custom = url(w.raw('share_url'));
  if (urlType === 'custom' && custom) {
    w.set('share_url', 'custom');
    w.set('custom_url', custom.url);
  } else {
    w.set('share_url', 'current');
    if (urlType === 'custom') w.note('The custom share URL was empty; the current page URL is shared.');
  }

  // Colors.
  const source = proText(w, 'color_source', 'official');
  if (source === 'custom') {
    w.color('primary_color', 'primary_color');
    w.color('secondary_color', 'secondary_color');
    w.color('primary_color_hover', 'primary_color_hover');
    w.color('secondary_color_hover', 'secondary_color_hover');
  } else w.consume('primary_color', 'secondary_color', 'primary_color_hover', 'secondary_color_hover');

  // Sizes. Pro: `.elementor-share-btn { font-size: calc(SIZE * 10) }` (range 0.5…2, so 1 = 10px).
  for (const [key, bp] of deviceKeys('button_size')) {
    const s = slider(w.raw(key));
    if (!s || typeof s.size !== 'number') continue;
    w.set('size', { size: Math.round(s.size * 10 * 100) / 100, unit: 'px' }, { bp });
  }
  for (const [key, bp] of deviceKeys('icon_size')) {
    const s = slider(w.raw(key), 'em');
    if (s) w.set('icon_size', { size: s.size, unit: s.unit === 'px' ? 'px' : 'em' }, { bp });
  }
  w.slider('column_gap', 'gap');
  const row = slider(w.get('row_gap'));
  const col = slider(w.get('column_gap'));
  if (row && row.size !== (col?.size ?? 10)) w.note('A separate row gap is not available in Zadex (the column gap is used for both).');
  w.consumeResponsive('row_gap');
  if (w.has('button_height')) w.note('A fixed button height is not available in Zadex.');
  const border = slider(w.raw('border_size'));
  if (border && border.size !== 2 && (skin === 'framed' || skin === 'boxed')) w.note('The frame border width is not available in Zadex.');
  w.consumeResponsive('button_height');
  w.consumeResponsive('border_size');
  w.typography('typography', 'typography');
  desktopOnly(w, 'typography');
  if (view === 'text' && w.has('text_padding')) w.note('The text padding is not available on the Zadex share buttons.');
  w.consumeResponsive('text_padding');
  return w.finish();
});
