import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { flexAlign } from '../align';
import { icon, isBlank, slider, url } from '../values';
import { describeIcon, desktopOnly, isObj, itemIdFor, only, repeaterItems, single, withGlobalDefaults } from './_shared';

/**
 * Elementor Pro `post-info` -> Zadex `post-info`. Verified against Pro 3.33.2 (defaults via `w.get`): repeater `icon_list`
 * {`type` author / date / time / comments / terms / custom, `date_format` default / 0..3 / custom
 * (+ `custom_date_format`), `time_format` default / 0..2 / custom (+ `custom_time_format`), `taxonomy`,
 * `text_prefix`, `show_avatar`, `comments_custom_strings` …, `link` (yes), `custom_text`, `custom_url`, `show_icon`
 * default / custom / none, `selected_icon`}; `view` inline (default) / traditional; icon-list styles
 * (`space_between`, `icon_align`, `divider`, `icon_color`, `icon_size`, `text_indent`, `text_color`,
 * `icon_typography`). `taxonomy` is a select2 list (Pro prints the terms of each); Pro's default list is author,
 * date, time, comments.
 */

const DATE_FORMATS: Record<string, string> = { '0': 'F j, Y', '1': 'Y-m-d', '2': 'm/d/Y', '3': 'd/m/Y' };
const TIME_FORMATS: Record<string, string> = { '0': 'g:i a', '1': 'g:i A', '2': 'H:i' };
/** Elementor Pro's default icon per item type. */
const DEFAULT_ICONS: Record<string, { library: string; value: string }> = {
  author: { library: 'fa-regular', value: 'fa-user-circle' },
  date: { library: 'fa-solid', value: 'fa-calendar' },
  time: { library: 'fa-regular', value: 'fa-clock' },
  comments: { library: 'fa-regular', value: 'fa-comment-dots' },
  terms: { library: 'fa-solid', value: 'fa-tags' },
  custom: { library: 'fa-solid', value: 'fa-info-circle' },
};
const TYPES = ['author', 'date', 'time', 'comments', 'terms', 'custom'];

registerWidget('post-info', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, {
    icon_color: 'globals/colors?id=primary',
    text_color: 'globals/colors?id=secondary',
    icon_typography_typography: 'globals/typography?id=text',
  });
  const w = ctx.writer(el, 'post-info');
  markPro(w);

  // Pro's default list: author, date, time, comments.
  const list = repeaterItems(w.get('icon_list'));
  const notes = new Set<string>();
  const items = list.map((item, i) => {
    const type = TYPES.includes(String(item.type ?? 'date')) ? String(item.type ?? 'date') : 'date';
    const out: Record<string, unknown> = { _id: itemIdFor(ctx, el, item, i), type };
    if (type === 'date') {
      const f = String(item.date_format ?? 'default');
      out.format = f === 'custom' ? String(item.custom_date_format ?? '') : DATE_FORMATS[f] ?? '';
    } else if (type === 'time') {
      const f = String(item.time_format ?? 'default');
      out.format = f === 'custom' ? String(item.custom_time_format ?? '') : TIME_FORMATS[f] ?? '';
    } else if (type === 'terms') {
      const tax = (Array.isArray(item.taxonomy) ? item.taxonomy : typeof item.taxonomy === 'string' && item.taxonomy !== '' ? [item.taxonomy] : []).map(String).filter(Boolean);
      out.taxonomy = tax[0] ?? 'category';
      if (tax.length > 1) notes.add(`Post info terms of several taxonomies (${tax.join(', ')}) became the terms of ${tax[0]} only.`);
    }
    else if (type === 'custom') {
      out.text = String(item.custom_text ?? '');
      if (url(item.custom_url)) notes.add('Custom item URLs are not available; custom items are plain text.');
    }
    if (!isBlank(item.text_prefix)) out.before = String(item.text_prefix);
    out.link = item.link === undefined ? true : item.link === 'yes' || item.link === true;
    const show = String(item.show_icon ?? 'default');
    if (show === 'none') out.icon = { library: '', value: '' };
    else if (show === 'custom' && isObj(item.selected_icon)) {
      const ic = icon(item.selected_icon, item.selected_icon.library === 'svg' ? ctx.svg(item.selected_icon.value) : undefined);
      if (!ic) notes.add(`Icon "${describeIcon(item.selected_icon)}" is not available in Zadex.`);
      out.icon = ic ?? DEFAULT_ICONS[type];
    } else out.icon = DEFAULT_ICONS[type];
    if (type === 'author' && (item.show_avatar === 'yes')) notes.add('The author avatar in post info is not available.');
    if (type === 'comments' && item.comments_custom_strings === 'yes') notes.add('Custom comment count texts are not available.');
    if (isObj(item.__dynamic__)) notes.add('Dynamic tags inside post info items were not carried over.');
    return out;
  });
  for (const n of notes) w.note(n);
  w.set('items', items);

  const view = String(w.get('view') ?? 'inline');
  w.set('layout', view === 'traditional' ? 'list' : 'inline');
  // Elementor's divider (a line between items) -> a text separator.
  if (w.get('divider') === 'yes') {
    if (view !== 'traditional') w.set('separator', '|');
    w.note('The divider line between items became a "|" separator.');
  }
  w.consume('divider_*');
  w.slider('space_between', 'gap');
  w.map('icon_align', 'align', only(flexAlign(ctx), ['flex-start', 'center', 'flex-end']));
  w.color('icon_color', 'icon_color');
  desktopOnly(w, 'icon_color');
  single(w, 'icon_size', 'icon_size', (v) => slider(v));
  if (w.has('text_indent')) w.note('The icon / text spacing is not available on the Zadex post info.');
  w.consumeResponsive('text_indent');
  w.typography('icon_typography', 'typography');
  w.color('text_color', 'color');
  desktopOnly(w, 'color');
  // Elementor's text color also colors the links.
  if (w.settings.color !== undefined) w.set('link_color', w.settings.color);
  w.color('text_color_hover', 'link_color_hover');
  desktopOnly(w, 'link_color_hover');
  w.consume('icon_color_hover', 'text_color_hover_transition', 'icon_color_hover_transition');
  return w.finish();
});
