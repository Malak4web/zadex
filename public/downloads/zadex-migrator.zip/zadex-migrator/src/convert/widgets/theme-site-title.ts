import { registerWidget } from '../registry';
import { markPro } from './_pro';
import { textAlign } from '../align';
import { url } from '../values';
import { HEADING_GLOBAL_DEFAULTS, headingStyle } from './heading';
import { desktopOnly, only, withGlobalDefaults } from './_shared';
import { dynamicTag, fixedSource, noDynamicData, pickTag } from './_theme';

/**
 * Elementor Pro `theme-site-title` -> Zadex `site-title`. Extends the Heading widget (verified against Pro 3.33.2):
 * `title` with the `site-title` tag as dynamic default, `link` with the `site-url` tag as dynamic default,
 * `header_size` (Pro default h2, via `w.get`), heading styles.
 */
registerWidget('theme-site-title', (source, ctx) => {
  const el = withGlobalDefaults(source, ctx, HEADING_GLOBAL_DEFAULTS);
  const w = ctx.writer(el, 'site-title');
  markPro(w);
  fixedSource(w, 'title', ['site-title'], 'site title');
  w.set('tag', pickTag(w, String(w.get('header_size') ?? 'h2'), ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div', 'span']));

  // Link: Pro binds it to the site URL by default. No `__dynamic__` map at all = the untouched default.
  const linkTag = dynamicTag(w, 'link');
  const link = url(w.raw('link'));
  if (linkTag?.name === 'site-url') {
    w.set('link_home', true);
    w.consumeDynamic('link');
  } else if (linkTag || link) {
    w.set('link_home', true);
    w.note('The site title linked to a custom URL; the Zadex site title links to the home page.');
  } else w.set('link_home', noDynamicData(w));

  w.map('align', 'align', only(textAlign(ctx), ['left', 'center', 'right']));
  headingStyle(w, { color: 'color', hover: { id: 'color', state: 'hover' }, typography: 'typography' });
  desktopOnly(w, 'color');
  return w.finish();
});
