import { registerWidget } from '../registry';
import type { ElementWriter } from '../context';
import { textAlign } from '../align';
import { bool, dimensions, isBlank, slider } from '../values';
import { markPro } from './_pro';
import { withGlobalDefaults } from './_shared';
import {
  borderFrom,
  colorOf,
  desktopSlider,
  postsCssDefaults,
  dimsFrom,
  getBool,
  getInt,
  getStr,
  imageSizeName,
  list,
  mapNothingFound,
  mapPagination,
  mapQuery,
  ratioOption,
  responsiveGet,
  responsiveSlider,
  responsiveSliderGet,
  titleTag,
} from './_pro-posts';

const SKINS = ['classic', 'cards', 'full_content'];
const RATIOS = ['16 / 9', '4 / 3', '3 / 2', '1 / 1', '3 / 4'];
const SIZES = ['thumbnail', 'medium', 'medium_large', 'large', 'full'];
const TITLE_TAGS = ['h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div'];
const META = ['author', 'date', 'comments', 'modified'];

/** Pro's kit global defaults of a posts skin (`global.default` of the controls in Pro 3.33.2). */
export function postsGlobalDefaults(skin: string): Record<string, string> {
  const p = `${skin}_`;
  const out: Record<string, string> = {
    [`${p}title_color`]: 'globals/colors?id=secondary',
    [`${p}title_typography_typography`]: 'globals/typography?id=primary',
    [`${p}meta_typography_typography`]: 'globals/typography?id=secondary',
    [`${p}excerpt_typography_typography`]: 'globals/typography?id=text',
    [`${p}read_more_color`]: 'globals/colors?id=accent',
    [`${p}read_more_typography_typography`]: 'globals/typography?id=accent',
  };
  if (skin === 'cards') {
    out.cards_badge_bg_color = 'globals/colors?id=accent';
    out.cards_badge_typography_typography = 'globals/typography?id=accent';
  }
  return out;
}

/** Kit global defaults of the pagination / load more button (posts and loop grid, Pro 3.33.2). */
export const PAGINATION_GLOBALS: Record<string, string> = {
  pagination_typography_typography: 'globals/typography?id=secondary',
  typography_typography: 'globals/typography?id=accent',
  background_color: 'globals/colors?id=accent',
};

/**
 * Elementor Pro `posts` -> Zadex `posts`, verified against Pro 3.33.2: `_skin` classic (default) | cards |
 * full_content, every skin control prefixed with the skin id (`classic_columns`, `cards_meta_data` …), query group
 * `posts_*`. Pro defaults come from `w.get()`; kit global defaults (title secondary color, accent read more …) are
 * applied like Elementor does.
 */
registerWidget('posts', (source, ctx) => {
  const rawSkin = String(source.settings?._skin ?? 'classic') || 'classic';
  const skin = SKINS.includes(rawSkin) ? rawSkin : 'classic';
  const el = withGlobalDefaults(source, ctx, { ...postsGlobalDefaults(skin), ...PAGINATION_GLOBALS });
  const w = ctx.writer(el, 'posts');
  markPro(w);
  w.consume('_skin');
  if (skin !== rawSkin) {
    w.note(`Skin "${rawSkin}" is not available in Zadex; the classic skin is used.`);
    w.status('partial');
  }
  w.set('skin', skin);
  // Controls of the skins that are not active are ignored by Elementor too.
  for (const s of SKINS) if (s !== skin) w.consume(`${s}_*`);
  const perPage = postsSkin(w, skin);
  if (skin !== 'full_content') postsCssDefaults(w, skin);
  mapQuery(w, 'posts_', perPage);
  mapPagination(w, Boolean(ctx.source.rtl));
  loadMoreButtonDefaults(w);
  mapNothingFound(w);
  return w.finish();
});

/**
 * Elementor's button look for the load more button (`.elementor-button`: white text, 12px 24px padding, 3px radius;
 * the accent background comes from the kit global default) where the page did not style it.
 */
export function loadMoreButtonDefaults(w: ElementWriter): void {
  if (w.settings.pagination !== 'load_more') return;
  if (w.settings.pagination_color === undefined) w.set('pagination_color', '#ffffff');
  if (w.settings.pagination_padding === undefined) w.set('pagination_padding', { top: 12, right: 24, bottom: 12, left: 24, unit: 'px', linked: false });
  if (w.settings.pagination_border === undefined) w.set('pagination_border', { style: 'none', radius: { top: 3, right: 3, bottom: 3, left: 3, unit: 'px', linked: true } });
}

/**
 * Skin controls (`<skin>_*`) of a Pro posts widget -> Zadex posts layout, parts and styles (Pro 3.33.2 keys).
 * Returns the posts per page (`<skin>_posts_per_page`, default 6).
 */
export function postsSkin(w: ElementWriter, skin: string): number {
  const p = `${skin}_`;
  const full = skin === 'full_content';

  // Layout. The full content skin is a single column list (no columns / column gap / masonry controls).
  if (full) w.set('columns', 1);
  else responsiveGet(w, `${p}columns`, 'columns', [1, 12]);
  const perPage = getInt(w, `${p}posts_per_page`) ?? 6;
  if (!full) responsiveSliderGet(w, `${p}column_gap`, 'column_gap');
  responsiveSliderGet(w, `${p}row_gap`, 'row_gap');

  // Image: classic top | left | right | none, cards top | none, full content a switcher (off by default).
  const thumb = full ? (getBool(w, `${p}thumbnail`) ? 'top' : 'none') : getStr(w, `${p}thumbnail`) || 'top';
  const showImage = thumb !== 'none';
  const masonry = !full && thumb === 'top' && getBool(w, `${p}masonry`);
  w.set('masonry', masonry);
  w.set('show_image', showImage);
  if (showImage) {
    if (skin === 'classic' && (thumb === 'left' || thumb === 'right' || thumb === 'top')) {
      w.set('image_position', thumb);
      if (thumb !== 'top') responsiveSlider(w, `${p}image_width`, 'image_width');
      else w.consume(`${p}image_width*`);
    } else w.consume(`${p}image_width*`);
    w.set('image_size', imageSizeName(w, getStr(w, `${p}thumbnail_size_size`) || 'medium', SIZES, 'medium'));
    w.consume(`${p}thumbnail_size_custom_dimension`);
    if (masonry) {
      // Masonry keeps the natural image height in Elementor.
      w.set('image_ratio', 'auto');
      w.consume(`${p}item_ratio*`);
    } else {
      const ratio = ratioOption(w, w.get(`${p}item_ratio`), RATIOS, 'Image ratio');
      if (ratio) w.set('image_ratio', ratio);
      w.consume(`${p}item_ratio_*`);
    }
  } else w.consume(`${p}thumbnail_size_*`, `${p}item_ratio*`, `${p}image_width*`);

  // Content parts.
  const showTitle = getBool(w, `${p}show_title`);
  w.set('show_title', showTitle);
  if (showTitle) w.set('title_tag', titleTag(w, getStr(w, `${p}title_tag`) || 'h3', TITLE_TAGS));
  else w.consume(`${p}title_tag`);
  const meta = list(w.get(`${p}meta_data`));
  if (meta.includes('time')) w.note('The post time is not available as a separate meta item in Zadex.');
  w.set('meta', meta.filter((m) => META.includes(m)));
  w.set('meta_separator', getStr(w, `${p}meta_separator`));
  if (!full) {
    const showExcerpt = getBool(w, `${p}show_excerpt`);
    w.set('show_excerpt', showExcerpt);
    if (showExcerpt) w.set('excerpt_length', getInt(w, `${p}excerpt_length`) ?? 25);
    else w.consume(`${p}excerpt_length`);
    if (showExcerpt && getBool(w, `${p}apply_to_custom_excerpt`)) {
      w.note('Trimming hand-written excerpts to the excerpt length is not available in Zadex.');
    }
    const showMore = getBool(w, `${p}show_read_more`);
    w.set('show_read_more', showMore);
    if (showMore) w.set('read_more_text', getStr(w, `${p}read_more_text`));
    else w.consume(`${p}read_more_text`);
  }
  w.consume(`${p}apply_to_custom_excerpt`, `${p}read_more_alignment`);
  if (getBool(w, `${p}open_new_tab`)) w.note('Opening posts in a new tab is not available in Zadex.');
  if (skin === 'cards') {
    const badge = getBool(w, `${p}show_badge`);
    w.set('show_badge', badge);
    if (badge) {
      w.set('badge_taxonomy', list(w.get(`${p}badge_taxonomy`))[0] ?? 'category');
      if (showImage && getStr(w, `${p}badge_position`) === 'right') w.note('The card badge sits in the start corner of the image in Zadex (Elementor: right).');
    } else w.consume(`${p}badge_taxonomy`, `${p}badge_position`);
    w.set('show_avatar', showImage && getBool(w, `${p}show_avatar`));
    if (slider(w.raw(`${p}avatar_size`))) w.note('The avatar size is not available in Zadex.');
    if (slider(w.raw(`${p}badge_size`))) w.note('The badge size is not available in Zadex; set the badge typography instead.');
    w.consume(`${p}badge_margin`);
  }

  // Card box (classic / full content `box_*`, cards `card_*`).
  const align = w.raw(`${p}alignment`);
  if (!isBlank(align)) {
    const v = textAlign(w.ctx)[String(align)];
    if (v && v !== 'justify') w.set('card_align', v);
  }
  if (skin === 'cards') cardsBox(w, p);
  else {
    const bg = colorOf(w, `${p}box_bg_color`);
    if (bg) w.set('card_bg', bg);
    const bgHover = colorOf(w, `${p}box_bg_color_hover`);
    if (bgHover) w.set('card_bg', bgHover, { state: 'hover' });
    const border = borderFrom(w.raw(`${p}box_border_width`), colorOf(w, `${p}box_border_color`));
    if (border) w.set('card_border', border);
    const bColorHover = colorOf(w, `${p}box_border_color_hover`);
    if (border && bColorHover) w.set('card_border', { ...border, color: bColorHover }, { state: 'hover' });
    dimsFrom(w, `${p}box_border_radius`, 'card_radius');
    w.boxShadow(`${p}box_shadow`, 'card_shadow');
    w.boxShadow(`${p}box_shadow_hover`, 'card_shadow', 'hover');
    dimsFrom(w, `${p}content_padding`, 'card_padding', true);
    if (dimensions(w.raw(`${p}box_padding`))) w.note('The box padding (around image and text) is not available in Zadex; the content padding is used.');
    w.consume(`${p}box_padding*`);
  }

  // Image style.
  const radius = dimensions(w.raw(`${p}img_border_radius`));
  if (radius) w.set('image_radius', radius);
  w.consume(`${p}img_border_radius_*`);
  if (showImage) responsiveSliderGet(w, `${p}image_spacing`, 'image_spacing');
  else w.consume(`${p}image_spacing*`);
  w.set('image_hover', 'none');
  if (skin === 'cards' && showImage && getStr(w, `${p}hover_effect`) === 'gradient') {
    w.note('The dark gradient over card images is not available in Zadex.');
  }
  if (bool(w.raw(`${p}thumbnail_filters_css_filter`)) || bool(w.raw(`${p}thumbnail_hover_filters_css_filter`))) {
    w.note('CSS filters on the post images are not available in Zadex.');
  }
  w.consume(`${p}hover_effect`, `${p}thumbnail_filters_*`, `${p}thumbnail_hover_filters_*`);

  // Text styles.
  w.color(`${p}title_color`, 'title_color');
  w.typography(`${p}title_typography`, 'title_typography');
  desktopSlider(w, `${p}title_spacing`, 'title_spacing');
  w.color(`${p}meta_color`, 'meta_color');
  w.color(`${p}meta_separator_color`, 'meta_sep_color');
  w.typography(`${p}meta_typography`, 'meta_typography');
  desktopSlider(w, `${p}meta_spacing`, 'meta_spacing');
  w.color(`${p}excerpt_color`, 'excerpt_color');
  w.typography(`${p}excerpt_typography`, 'excerpt_typography');
  desktopSlider(w, `${p}excerpt_spacing`, 'excerpt_spacing');
  w.color(`${p}read_more_color`, 'more_color');
  w.typography(`${p}read_more_typography`, 'more_typography');
  if (slider(w.raw(`${p}read_more_spacing`))) w.note('The space below the read more link is not available in Zadex.');
  if (skin === 'cards') {
    w.color(`${p}badge_bg_color`, 'badge_bg');
    w.color(`${p}badge_color`, 'badge_color');
    dimsFrom(w, `${p}badge_radius`, 'badge_radius');
    w.typography(`${p}badge_typography`, 'badge_typography');
    w.color(`${p}meta_border_color`, 'footer_border_color');
  }
  return perPage;
}

/**
 * Cards skin box. Pro's look (white card, no border, 3px radius, text padded 0 30px under a 20px gap, shadow
 * `0 0 10px rgba(0,0,0,.15)` growing to 30px on hover while `cards_box_shadow_box_shadow_type` is on, the default)
 * is written explicitly because the Zadex cards skin differs (1px border, 10px radius, no shadow).
 */
function cardsBox(w: ElementWriter, p: string): void {
  w.set('card_bg', colorOf(w, `${p}card_bg_color`) ?? '#ffffff');
  const width = slider(w.raw(`${p}card_border_width`));
  const color = colorOf(w, `${p}card_border_color`);
  if (width && Number(width.size) > 0) w.set('card_border', borderFrom(width, color ?? '#69727d'));
  else w.set('card_border', { style: 'none' });
  const r = slider(w.raw(`${p}card_border_radius`));
  const rs = r ? Number(r.size) : 3;
  w.set('card_radius', { top: rs, right: rs, bottom: rs, left: rs, unit: r?.unit ?? 'px', linked: true });
  const h = slider(w.raw(`${p}card_padding`));
  const v = slider(w.raw(`${p}card_vertical_padding`));
  const hs = h ? Number(h.size) : 30;
  const vs = v ? Number(v.size) : 20;
  w.set('card_padding', { top: vs, right: hs, bottom: vs, left: hs, unit: h?.unit ?? v?.unit ?? 'px', linked: false });
  w.consume(`${p}card_padding_*`, `${p}card_vertical_padding_*`);
  if (getBool(w, `${p}box_shadow_box_shadow_type`)) {
    w.set('card_shadow', { x: 0, y: 0, blur: 10, spread: 0, color: 'rgba(0,0,0,0.15)', inset: false });
    w.set('card_shadow', { x: 0, y: 0, blur: 30, spread: 0, color: 'rgba(0,0,0,0.15)', inset: false }, { state: 'hover' });
  }
}
