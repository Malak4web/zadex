import { registerWidget } from '../registry';
import { slider } from '../values';
import { markPro, firstOf } from './_pro';
import { logicalAlign, proSwitch, proText } from './_pro-content';
import { desktopOnly } from './_shared';

const SKINS = ['border', 'quotation', 'boxed', 'clean'];

/**
 * Elementor Pro `blockquote` -> Zadex `blockquote`. Keys verified against Elementor Pro 3.33.2 (defaults from
 * elementor-defaults.json): content `blockquote_skin` border|quotation|boxed|clean (border), `alignment`
 * left|center|right R, `blockquote_content`, `author_name` (John Doe), `tweet_button` (yes), `tweet_button_view`
 * icon-text|icon|text, `tweet_button_skin` classic|bubble|link, `tweet_button_label` (Tweet), `user_name` (via),
 * `url_type` current_page|none|custom + `url`; style `content_text_color`, `content_typography`, `content_gap`,
 * `author_text_color`, `author_typography`, `author_gap`, tweet button `button_size`, `button_border_radius`,
 * `button_background_color` / `button_text_color` (+ `_hover`), `button_typography`; border skin `border_color`,
 * `border_width`, `border_gap`, `border_vertical_padding` (+ `_hover`); boxed / quotation / clean skins
 * `box_padding`, `box_background_color`, `box_border_*`, `box_border_radius`, `box_box_shadow_*` (+ hover);
 * quotation `quote_text_color`, `quote_size`, `quote_gap`.
 */
registerWidget('blockquote', (el, ctx) => {
  const w = ctx.writer(el, 'blockquote');
  markPro(w);

  w.set('quote', proText(w, 'blockquote_content'));
  w.set('author', proText(w, 'author_name'));
  w.set('author_title', '');
  w.set('cite_url', '');
  const skin = proText(w, 'blockquote_skin', 'border');
  w.set('skin', SKINS.includes(skin) ? skin : 'border');
  w.map('alignment', 'align', logicalAlign(ctx, false));

  const tweet = proSwitch(w, 'tweet_button', true);
  w.set('tweet_button', tweet);
  if (tweet) {
    w.set('tweet_label', proText(w, 'tweet_button_label', 'Tweet'));
    w.set('via', proText(w, 'user_name').replace(/^@/, ''));
    const view = proText(w, 'tweet_button_view', 'icon-text');
    if (view !== 'icon-text') w.note(`Tweet button view "${view}" is not available in Zadex (icon and label are shown).`);
    const skin2 = proText(w, 'tweet_button_skin', 'classic');
    if (skin2 !== 'classic') w.note(`Tweet button skin "${skin2}" is not carried over.`);
    const urlType = proText(w, 'url_type', 'current_page');
    if (urlType === 'custom') w.note('The custom tweet URL is not available in Zadex; the current page URL is shared.');
    if (urlType === 'none') w.note('Tweeting without a URL is not available in Zadex; the current page URL is shared.');
  }
  w.consume('tweet_button_label', 'user_name', 'tweet_button_view', 'tweet_button_skin', 'url_type', 'url');

  // Content and author.
  w.color('content_text_color', 'quote_color');
  w.typography('content_typography', 'quote_typography');
  const gap = slider(w.raw('content_gap'));
  if (gap) w.set('gap', gap);
  w.consumeResponsive('content_gap');
  w.color('author_text_color', 'author_color');
  w.typography('author_typography', 'author_typography');
  if (w.has('author_gap')) w.note('The gap between the author and the tweet button is not available in Zadex.');
  w.consumeResponsive('author_gap');

  // Skin accents.
  if (skin === 'border') {
    w.color('border_color', 'accent_color');
    const width = slider(w.raw('border_width'));
    if (width) w.set('border_width', { size: width.size, unit: 'px' });
  } else if (skin === 'quotation') {
    w.color('quote_text_color', 'accent_color');
  }
  if (skin !== 'border') w.color('box_background_color', 'box_bg');
  if (firstOf(w, 'border_color_hover', 'border_width_hover', 'border_gap', 'border_gap_hover', 'border_vertical_padding', 'quote_size', 'quote_gap', 'box_border_radius', 'box_padding', 'box_background_color_hover', 'box_border_border', 'box_border_hover_border')) {
    w.note('Some skin details (hover border, spacing, quote size, box border / radius / padding) are not available in Zadex.');
  }
  if (w.raw('box_box_shadow_box_shadow_type') === 'yes' || w.raw('box_box_shadow_hover_box_shadow_type') === 'yes') w.note('The box shadow is not available on the Zadex blockquote.');
  w.consume('border_color', 'border_width*', 'border_color_hover', 'border_gap*', 'border_vertical_padding*', 'border_transition_duration', 'quote_text_color', 'quote_size*', 'quote_gap*', 'box_*');

  // Tweet button (Pro always applies these colors; there is no "official colors" switch).
  w.color('button_background_color', 'button_bg');
  w.color('button_text_color', 'button_color');
  w.color('button_background_color_hover', 'button_bg_hover');
  w.color('button_text_color_hover', 'button_color_hover');
  w.typography('button_typography', 'button_typography');
  desktopOnly(w, 'button_typography');
  const r = slider(w.raw('button_border_radius'));
  if (r) w.set('button_radius', { size: r.size, unit: 'px' });
  if (w.has('button_size')) w.note('The tweet button size is not available in Zadex (use its typography).');
  w.consume('button_size', 'button_border_radius*', 'button_transition_duration');
  return w.finish();
});
