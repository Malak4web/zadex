import type { ConvertContext } from './context';
import type { Settings, SourceDocument } from './types';
import { bool, isBlank } from './values';
import { splitDeviceKey } from './responsive';

/** Elementor page templates -> Zadex page templates. */
const TEMPLATES: Record<string, string> = {
  elementor_canvas: 'zadex-canvas.php',
  elementor_header_footer: 'zadex-full-width.php',
  'elementor_theme': '',
  default: '',
  '': '',
};

/** Page settings that describe the post itself (saved to the post by Elementor) or are handled elsewhere. */
const IGNORED = new Set(['template', 'hide_title', 'post_title', 'post_status', 'post_excerpt', 'post_featured_image', 'menu_order', 'scroll_snap']);

/**
 * Page-level settings (`_elementor_page_settings` + `_wp_page_template`) -> Zadex page settings
 * (`src/editor/core/pageControls.ts` in the Zadex repo: `page_template`, `hide_title`, `scroll_snap*`,
 * `scroll_smooth`). Zadex page settings have no style controls, so the Elementor body style (background, padding)
 * and custom CSS are reported in the document notes; every other stored key is listed there too.
 */
export function convertPageSettings(source: SourceDocument, ctx: ConvertContext): { pageSettings: Settings; template: string } {
  const settings: Settings = {};
  const page = source.pageSettings ?? {};
  const fromPage = typeof page.template === 'string' ? page.template : '';
  const tpl = source.template && source.template !== 'default' ? source.template : fromPage || source.template || '';
  let template = '';
  if (Object.prototype.hasOwnProperty.call(TEMPLATES, tpl)) template = TEMPLATES[tpl];
  else ctx.note(`Page template "${tpl}" is kept as the theme default.`);
  if (template) settings.page_template = template;
  if (bool(page.hide_title)) settings.hide_title = true;
  if (bool(page.scroll_snap)) settings.scroll_snap = true;

  const background: string[] = [];
  const padding: string[] = [];
  const other: string[] = [];
  let customCss = false;
  for (const [key, value] of Object.entries(page)) {
    if (IGNORED.has(key) || isBlank(value)) continue;
    const { base } = splitDeviceKey(key);
    if (key.startsWith('background_')) background.push(key);
    else if (base === 'padding') padding.push(key);
    else if (key === 'custom_css') customCss = typeof value === 'string' && value.trim() !== '';
    else other.push(key);
  }
  if (background.length && hasBackground(page)) {
    ctx.note('The page background (Elementor page settings > Style) is not supported by Zadex page settings; add it to the theme or to a full-width container.');
  }
  if (padding.length) ctx.note('The page padding (Elementor page settings > Style) is not supported by Zadex page settings; it was not carried over.');
  if (customCss) ctx.note('Custom CSS is not supported by Zadex (WordPress.org rule); the page custom CSS was not carried over.');
  if (other.length) ctx.note(`Page settings not carried over: ${other.sort().join(', ')}.`);
  return { pageSettings: settings, template };
}

/** True when the Elementor background group actually paints something (a type is chosen). */
function hasBackground(page: Record<string, unknown>): boolean {
  return ['background_background', 'background_background_tablet', 'background_background_mobile'].some((k) => typeof page[k] === 'string' && page[k] !== '');
}
