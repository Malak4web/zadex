import type { ConvertContext } from './context';

/** Elementor's built-in global ids keep their name in Zadex (Zadex ships the same four colors / fonts). */
const SYSTEM_IDS = new Set(['primary', 'secondary', 'text', 'accent']);

/**
 * Zadex global id for an Elementor global (color or typography) id. System ids are kept; custom ids (random
 * 7-char hex) become `el<id>` so they are letter-first and cannot clash with ids the user created in Zadex.
 * The kit importer (kit.ts) and the element converter both use this, so references line up.
 */
export function zadexGlobalId(elementorId: string): string {
  if (SYSTEM_IDS.has(elementorId)) return elementorId;
  return 'el' + elementorId.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Value to write for a `globals/colors?id=<id>` reference: the Zadex variable when that global exists (or will
 * exist after the kit import), else the literal kit color, else undefined.
 */
export function colorRef(ctx: ConvertContext, elementorId: string): string | undefined {
  const id = zadexGlobalId(elementorId);
  const exists = (ctx.env.global?.colors ?? []).some((c) => c.id === id);
  if (exists) return `var(--zx-color-${id})`;
  return ctx.kitColor(elementorId);
}

/** Family to write for a `globals/typography?id=<id>` reference: the Zadex font variable when it exists. */
export function fontRef(ctx: ConvertContext, elementorId: string): string | undefined {
  const id = zadexGlobalId(elementorId);
  const exists = (ctx.env.global?.fonts ?? []).some((f) => f.id === id);
  if (exists) return `var(--zx-font-${id})`;
  const preset = ctx.typographyPreset(elementorId);
  const family = preset?.typography_font_family;
  return typeof family === 'string' && family !== '' ? family : undefined;
}

/**
 * Typography group keys (`<prefix>_typography`) whose global reference was injected by `withGlobalDefaults` (the
 * widget's kit default), per settings object. Elementor prints that default as a widget-type rule
 * (`.elementor-widget-heading .elementor-heading-title{font-family:var(--e-global-typography-primary-font-family)}`)
 * underneath the element's own rule, so the element's own fields (custom family, size…) win field by field.
 */
export const defaultTypography = new WeakMap<object, Set<string>>();
