import type { ElementState, ElementWriter } from './context';
import type { BreakpointKey } from './types';
import { DEVICE_SUFFIXES } from './responsive';
import { bool, isBlank, num, slider } from './values';
import { colorRef } from './globals';

/**
 * Elementor background group (`<prefix>_background`, `<prefix>_color`, `<prefix>_image` …) -> Zadex background value
 * (`dev/reference/zadex-shapes.md`). Works for every prefix Elementor uses: `background`, `background_hover`,
 * `background_overlay`, `background_overlay_hover` (sections / columns / containers) and `_background`,
 * `_background_hover` (widget Advanced tab).
 *
 * Responsive fields (image, position, size, repeat, gradient stops / angle …) produce one full background object per
 * breakpoint that has its own values: Zadex's CSS handler only emits `background-position` & co next to an image, so
 * every breakpoint object carries the cascaded desktop values too.
 */

export type BackgroundType = 'classic' | 'gradient' | 'video' | 'slideshow';

export interface BackgroundOptions {
  state?: ElementState;
  /** Background types the target control supports (Zadex: video / slideshow only on containers). */
  allow?: BackgroundType[];
}

export interface ZBackground {
  type: BackgroundType;
  color?: string;
  image?: ReturnType<ElementWriter['ctx']['media']>;
  position?: string;
  size?: string;
  repeat?: string;
  attachment?: string;
  gradient?: { type: 'linear' | 'radial'; angle: number; stops: Array<{ color: string; position: number }> };
  video?: { url: string; poster?: ReturnType<ElementWriter['ctx']['media']>; loop?: boolean; playOnMobile?: boolean };
  slideshow?: { images: NonNullable<ReturnType<ElementWriter['ctx']['media']>>[]; duration?: number; transition?: string; kenBurns?: boolean };
}

/** Every field of Elementor's background group (Group_Control_Background), without the prefix. */
const FIELDS = [
  'background',
  'color',
  'color_stop',
  'color_b',
  'color_b_stop',
  'gradient_type',
  'gradient_angle',
  'gradient_position',
  'image',
  'position',
  'xpos',
  'ypos',
  'attachment',
  'repeat',
  'size',
  'bg_width',
  'video_link',
  'video_start',
  'video_end',
  'play_once',
  'play_on_mobile',
  'privacy_mode',
  'video_fallback',
  'slideshow_gallery',
  'slideshow_loop',
  'slideshow_slide_duration',
  'slideshow_slide_transition',
  'slideshow_transition_duration',
  'slideshow_background_size',
  'slideshow_background_position',
  'slideshow_lazyload',
  'slideshow_ken_burns',
  'slideshow_ken_burns_zoom_direction',
  'transition',
];

/** Fields Elementor lets the user set per device. */
const RESPONSIVE = ['image', 'position', 'xpos', 'ypos', 'repeat', 'size', 'bg_width', 'color_stop', 'color_b_stop', 'gradient_angle', 'gradient_position'];

/** Parent breakpoint in the desktop-first cascade (widescreen inherits desktop). */
const PARENT: Partial<Record<BreakpointKey, BreakpointKey | undefined>> = {
  widescreen: undefined,
  laptop: undefined,
  tablet_large: 'laptop',
  tablet: 'tablet_large',
  mobile_large: 'tablet',
  mobile: 'mobile_large',
};

/** Marks every key of the group (all fields, all devices) as handled. */
export function consumeBackground(w: ElementWriter, prefix: string): void {
  for (const f of FIELDS) for (const { suffix } of DEVICE_SUFFIXES) w.consume(`${prefix}_${f}${suffix}`);
}

/** True when the element stores a background type for this group (cheap check, nothing is consumed). */
export function hasBackground(w: ElementWriter, prefix: string): boolean {
  return w.has(`${prefix}_background`);
}

/**
 * Converts one background group and writes it to `dst` (`w.set(dst, value, {bp, state})`). Returns the desktop value
 * (undefined when nothing visible was written). Unsupported details are noted on the writer.
 */
export function convertBackground(w: ElementWriter, prefix: string, dst: string, opts: BackgroundOptions = {}): ZBackground | undefined {
  consumeBackground(w, prefix);
  const type = w.raw(`${prefix}_background`);
  if (typeof type !== 'string' || type === '') return undefined;
  const allow = opts.allow ?? ['classic', 'gradient', 'video', 'slideshow'];
  if (!allow.includes(type as BackgroundType)) {
    w.note(`Background type "${type}" (${prefix}) is not supported by the Zadex element; it was not carried over.`);
    w.status('partial');
    return undefined;
  }
  const state = opts.state;

  // Desktop values (with Elementor defaults) + per-device overrides of the responsive fields.
  const base: Record<string, unknown> = {};
  for (const f of FIELDS) base[f] = w.get(`${prefix}_${f}`);
  const own: Partial<Record<BreakpointKey, Record<string, unknown>>> = {};
  for (const { suffix, bp } of DEVICE_SUFFIXES) {
    if (!bp) continue;
    const o: Record<string, unknown> = {};
    for (const f of RESPONSIVE) {
      const v = w.raw(`${prefix}_${f}${suffix}`);
      if (!isBlank(v) && !(f === 'image' && !hasUrl(v))) o[f] = v;
    }
    if (Object.keys(o).length) own[bp] = o;
  }

  const build = (fields: Record<string, unknown>, noteIssues: boolean): ZBackground | undefined => {
    if (type === 'classic') return classic(w, prefix, fields);
    if (type === 'gradient') return gradient(w, prefix, fields, noteIssues);
    if (type === 'video') return video(w, prefix, fields);
    return slideshow(w, prefix, fields);
  };

  const desktop = build(base, true);
  if (desktop) w.set(dst, desktop, { state });
  if (type === 'classic' || type === 'gradient') {
    const effective: Partial<Record<BreakpointKey, Record<string, unknown>>> = {};
    for (const { bp } of DEVICE_SUFFIXES) {
      if (!bp) continue;
      const parent = PARENT[bp];
      const inherited = parent ? effective[parent] ?? base : base;
      effective[bp] = own[bp] ? { ...inherited, ...own[bp] } : inherited;
      if (!own[bp]) continue;
      const value = build(effective[bp]!, false);
      if (value) w.set(dst, value, { bp, state });
    }
  }
  return desktop;
}

/**
 * Elementor background overlay (`<prefix>` = `background_overlay` / `background_overlay_hover`) -> Zadex `overlay` +
 * `overlay_opacity` (Elementor's overlay opacity default 0.5 applies whenever an overlay is set).
 */
export function convertOverlay(w: ElementWriter, prefix: string, dst = 'overlay', opacityDst = 'overlay_opacity', state?: ElementState): ZBackground | undefined {
  w.consume(`${prefix}_opacity`, `${prefix}_transition`);
  const value = convertBackground(w, prefix, dst, { state, allow: ['classic', 'gradient'] });
  if (!value) return undefined;
  const op = slider(w.get(`${prefix}_opacity`));
  if (op && typeof op.size === 'number') w.set(opacityDst, { size: op.size, unit: 'custom' }, { state });
  return value;
}

/* ---- helpers ---- */

function hasUrl(v: unknown): boolean {
  return typeof v === 'object' && v !== null && typeof (v as Record<string, unknown>).url === 'string' && (v as Record<string, unknown>).url !== '';
}

function colorOf(w: ElementWriter, key: string): string | undefined {
  const ref = w.globalRef(key);
  if (ref && ref.kind === 'colors') {
    const value = colorRef(w.ctx, ref.id);
    if (!value) w.note(`Global color "${ref.id}" was not found.`);
    return value;
  }
  const v = w.get(key);
  return typeof v === 'string' && v !== '' ? v : undefined;
}

function sliderCss(v: unknown, defUnit = 'px'): string | undefined {
  const s = slider(v, defUnit);
  if (!s) return undefined;
  return s.unit === 'custom' ? String(s.size) : `${s.size}${s.unit}`;
}

function classic(w: ElementWriter, prefix: string, f: Record<string, unknown>): ZBackground | undefined {
  const out: ZBackground = { type: 'classic' };
  const color = colorOf(w, `${prefix}_color`);
  if (color) out.color = color;
  const image = w.ctx.media(f.image);
  if (image) {
    out.image = image;
    const pos = f.position;
    if (pos === 'initial') {
      const x = sliderCss(f.xpos) ?? '0px';
      const y = sliderCss(f.ypos) ?? '0px';
      out.position = `${x} ${y}`;
    } else if (typeof pos === 'string' && pos !== '') out.position = pos;
    const size = f.size;
    if (size === 'initial') out.size = `${sliderCss(f.bg_width, '%') ?? '100%'} auto`;
    else if (typeof size === 'string' && size !== '') out.size = size;
    if (typeof f.repeat === 'string' && f.repeat !== '') out.repeat = f.repeat;
    if (typeof f.attachment === 'string' && f.attachment !== '') out.attachment = f.attachment;
  }
  return out.color || out.image ? out : undefined;
}

function stopPosition(w: ElementWriter, v: unknown, fallback: number, note: boolean): number {
  const s = slider(v, '%');
  if (!s || typeof s.size !== 'number') return fallback;
  if (s.unit !== '%' && note) w.note(`Gradient stop in "${s.unit}" was converted as a percentage.`);
  return s.size;
}

function gradient(w: ElementWriter, prefix: string, f: Record<string, unknown>, note: boolean): ZBackground | undefined {
  const a = colorOf(w, `${prefix}_color`);
  const b = colorOf(w, `${prefix}_color_b`);
  if (!a || !b) {
    if (note) w.note('A gradient background without its first color renders nothing in Elementor; it was skipped.');
    return undefined;
  }
  const kind = f.gradient_type === 'radial' ? 'radial' : 'linear';
  const angleSlider = slider(f.gradient_angle, 'deg');
  let angle = angleSlider && typeof angleSlider.size === 'number' ? angleSlider.size : 180;
  if (angleSlider && angleSlider.unit !== 'deg' && typeof angleSlider.size === 'number') {
    const factor: Record<string, number> = { grad: 0.9, rad: 180 / Math.PI, turn: 360 };
    angle = Math.round(angleSlider.size * (factor[angleSlider.unit] ?? 1) * 100) / 100;
  }
  if (note && kind === 'radial' && typeof f.gradient_position === 'string' && f.gradient_position !== 'center center') {
    w.note(`Radial gradient position "${f.gradient_position}" is not supported by Zadex (centered circle used).`);
  }
  return {
    type: 'gradient',
    gradient: {
      type: kind,
      angle,
      stops: [
        { color: a, position: stopPosition(w, f.color_stop, 0, note) },
        { color: b, position: stopPosition(w, f.color_b_stop, 100, note) },
      ],
    },
  };
}

const YOUTUBE = /(?:youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|v\/)|youtu\.be\/)[A-Za-z0-9_-]{11}/;

function video(w: ElementWriter, prefix: string, f: Record<string, unknown>): ZBackground | undefined {
  const link = typeof f.video_link === 'string' ? f.video_link.trim() : '';
  const poster = w.ctx.media(f.video_fallback);
  const color = colorOf(w, `${prefix}_color`);
  if (!link || /vimeo\.com/i.test(link)) {
    if (link) w.note('Vimeo background videos are not supported by Zadex; the fallback image was used instead.');
    w.status('partial');
    if (!poster && !color) return undefined;
    const out: ZBackground = { type: 'classic' };
    if (color) out.color = color;
    if (poster) Object.assign(out, { image: poster, position: 'center center', size: 'cover' });
    return out;
  }
  if (!YOUTUBE.test(link) && !/\.(mp4|webm|ogg|ogv|mov)(\?|#|$)/i.test(link)) w.note('The background video URL is neither YouTube nor a video file; Zadex plays it as a video file.');
  const out: ZBackground = { type: 'video', video: { url: link, loop: !bool(f.play_once), playOnMobile: bool(f.play_on_mobile) } };
  if (poster) out.video!.poster = poster;
  if (color) out.color = color;
  if (!isBlank(f.video_start) || !isBlank(f.video_end)) w.note('Background video start / end times are not supported by Zadex.');
  if (bool(f.privacy_mode)) w.note('Zadex always uses youtube-nocookie.com for background videos (privacy mode).');
  return out;
}

function slideshow(w: ElementWriter, prefix: string, f: Record<string, unknown>): ZBackground | undefined {
  const images = (Array.isArray(f.slideshow_gallery) ? f.slideshow_gallery : []).map((m) => w.ctx.media(m)).filter((m): m is NonNullable<typeof m> => Boolean(m));
  if (!images.length) return undefined;
  const duration = num(f.slideshow_slide_duration);
  const transition = String(f.slideshow_slide_transition ?? 'fade');
  const out: ZBackground = {
    type: 'slideshow',
    slideshow: { images, duration: typeof duration === 'number' ? duration : 5000, transition: transition === 'fade' ? 'fade' : 'slide', kenBurns: bool(f.slideshow_ken_burns) },
  };
  const color = colorOf(w, `${prefix}_color`);
  if (color) out.color = color;
  if (transition !== 'fade' && transition !== 'slide_left') w.note(`Slideshow transition "${transition}" became Zadex's horizontal slide.`);
  if (f.slideshow_loop === '' || f.slideshow_loop === 'no') w.note('Zadex background slideshows always loop.');
  const td = num(f.slideshow_transition_duration);
  if (typeof td === 'number' && td !== 500) w.note('The slideshow transition duration is fixed in Zadex.');
  if (!isBlank(f.slideshow_background_size) && f.slideshow_background_size !== 'cover') w.note('Slideshow image size is always "cover" in Zadex.');
  if (!isBlank(f.slideshow_background_position) && f.slideshow_background_position !== 'center center') w.note('Slideshow image position is always centered in Zadex.');
  if (bool(f.slideshow_ken_burns) && f.slideshow_ken_burns_zoom_direction === 'out') w.note('Ken Burns "zoom out" is not supported by Zadex (zoom in used).');
  return out;
}
