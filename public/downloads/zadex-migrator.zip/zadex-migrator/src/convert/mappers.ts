/**
 * Imports every mapper module so they register themselves. One line per file; keep it sorted by area.
 * Agents: add your line in your own block (additive edits only).
 */

// Layout
import './layout/section';
import './layout/column';
import './layout/container';

// Basic widgets
import './widgets/heading';
import './widgets/alert';
import './widgets/button';
import './widgets/counter';
import './widgets/divider';
import './widgets/html';
import './widgets/icon';
import './widgets/icon-box';
import './widgets/icon-list';
import './widgets/image';
import './widgets/image-box';
import './widgets/menu-anchor';
import './widgets/progress';
import './widgets/read-more';
import './widgets/shortcode';
import './widgets/social-icons';
import './widgets/spacer';
import './widgets/star-rating'; // also registers `rating`
import './widgets/testimonial';
import './widgets/text-editor';
import './widgets/text-path';

// Media / interactive widgets
import './widgets/accordion';
import './widgets/audio';
import './widgets/google-maps';
import './widgets/image-carousel';
import './widgets/image-gallery';
import './widgets/nested-accordion';
import './widgets/nested-tabs';
import './widgets/sidebar';
import './widgets/tabs';
import './widgets/toggle';
import './widgets/video';
import './widgets/wp-widgets'; // wp-widget-search, wp-widget-nav_menu only

// v4 atomic elements
import './atomic/layout'; // e-flexbox, e-div-block, e-grid
import './atomic/heading';
import './atomic/paragraph';
import './atomic/button';
import './atomic/image';
import './atomic/svg';
import './atomic/divider';
import './atomic/video'; // e-youtube, e-self-hosted-video
import './atomic/google-maps';

// Elementor Pro: posts and media (P2)
import './widgets/posts';
import './widgets/portfolio';
import './widgets/gallery-pro'; // Pro `gallery`
import './widgets/media-carousel';
import './widgets/video-playlist';
import './widgets/loop'; // loop-grid, loop-carousel
import './widgets/taxonomy-filter'; // Pro loop filter -> loop-filter
import './widgets/nested-carousel'; // -> grid of the slide containers

// Elementor Pro: content (P4)
import './widgets/table-of-contents';
import './widgets/share-buttons';
import './widgets/blockquote';
import './widgets/facebook'; // facebook-button, facebook-comments, facebook-embed, facebook-page
import './widgets/template';
import './widgets/lottie';
import './widgets/code-highlight';
import './widgets/hotspot';
import './widgets/paypal-button';
import './widgets/stripe-button';
import './widgets/progress-tracker'; // -> reading-progress
import './widgets/off-canvas';
import './widgets/global'; // Pro global widget instance
import './widgets/link-in-bio'; // link-in-bio-var-2 … var-7 -> container + bio-links
import './widgets/pro-floating'; // contact-buttons-var-*, floating-bars-var-* (skipped, site floating buttons)

// Elementor Pro: marketing (P3)
import './widgets/slides';
import './widgets/animated-headline';
import './widgets/flip-box';
import './widgets/call-to-action';
import './widgets/price-list';
import './widgets/price-table';
import './widgets/testimonial-carousel';
import './widgets/reviews';
import './widgets/countdown';

// Elementor Pro: forms and site (P1)
import './widgets/form';
import './widgets/login';
import './widgets/search'; // search-form, search
import './widgets/nav-menu';
import './widgets/mega-menu';

// Elementor Pro: theme widgets (P5)
import './widgets/theme-site-logo';
import './widgets/theme-site-title';
import './widgets/theme-post-title'; // theme-post-title, theme-page-title
import './widgets/theme-post-excerpt';
import './widgets/theme-post-content';
import './widgets/theme-post-featured-image';
import './widgets/theme-archive-title';
import './widgets/archive-posts';
import './widgets/author-box';
import './widgets/post-comments'; // -> comments
import './widgets/post-navigation';
import './widgets/post-info';
import './widgets/sitemap';
import './widgets/breadcrumbs';

// Elementor Pro: WooCommerce product page (W1)
import './widgets/woo-product-title';
import './widgets/woo-product-images';
import './widgets/woo-product-price';
import './widgets/woo-product-add-to-cart';
import './widgets/woo-product-rating';
import './widgets/woo-product-stock';
import './widgets/woo-product-meta';
import './widgets/woo-product-short-description';
import './widgets/woo-product-data-tabs';
import './widgets/woo-product-additional-information'; // -> product-data-tabs (single tab)
import './widgets/woo-product-related';
import './widgets/woo-product-upsell';
import './widgets/woo-product-content'; // -> post-content

// Elementor Pro: WooCommerce shop and site (W2)
import './widgets/woo-products'; // woocommerce-products, wc-archive-products, woocommerce-archive-products, wc-products
import './widgets/woo-product-categories'; // wc-categories, woocommerce-product-categories
import './widgets/woo-add-to-cart-button'; // wc-add-to-cart -> button (chosen product) or add-to-cart
import './widgets/woo-menu-cart';
import './widgets/woo-cart';
import './widgets/woo-checkout'; // woocommerce-checkout-page
import './widgets/woo-my-account';
import './widgets/woo-purchase-summary';
import './widgets/woo-breadcrumb'; // -> breadcrumbs
import './widgets/woo-notices'; // -> shortcode [shop_messages]
import './widgets/woo-elements'; // wc-elements -> WooCommerce shortcodes; wc-single-elements -> product widgets
import './widgets/woo-archive-description'; // -> text + archive-description tag
