import type { ConvertContext } from './context';

/**
 * Text alignment table for Elementor `choose` controls. Elementor 3.x stored `left|center|right|justify`; newer
 * versions store logical `start|end`. Zadex text alignments are physical, so `start`/`end` depend on the site's
 * direction.
 */
export function textAlign(ctx: ConvertContext): Record<string, string> {
  const rtl = Boolean(ctx.source.rtl);
  return {
    left: 'left',
    center: 'center',
    right: 'right',
    justify: 'justify',
    start: rtl ? 'right' : 'left',
    end: rtl ? 'left' : 'right',
  };
}

/** Same values as flex alignment (`flex-start|center|flex-end|stretch`), for widgets whose Zadex control is flex-based. */
export function flexAlign(ctx: ConvertContext): Record<string, string> {
  const rtl = Boolean(ctx.source.rtl);
  return {
    left: rtl ? 'flex-end' : 'flex-start',
    center: 'center',
    right: rtl ? 'flex-start' : 'flex-end',
    start: 'flex-start',
    end: 'flex-end',
    justify: 'stretch',
    stretch: 'stretch',
  };
}
