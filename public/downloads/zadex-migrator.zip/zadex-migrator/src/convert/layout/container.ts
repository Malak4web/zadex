import { registerElement } from '../registry';
import type { ConvertContext, ElementWriter } from '../context';
import type { ElElement, Settings, ZElement } from '../types';
import { num, slider, type Slider } from '../values';
import {
  cascade,
  contentWidthCascade,
  decoration,
  finishChain,
  hasAny,
  htmlTag,
  isDefaultGap,
  kitPadding,
  kitWidgetGap,
  paddingCascade,
  put,
  putCascade,
  strictDims,
  strictGap,
  uniform,
  ZERO,
  type Cascade,
  type Gap,
} from './shared';

/**
 * Elementor flexbox container (and nested containers) -> Zadex container; grid container (`container_type: grid`)
 * -> Zadex `grid` widget.
 *
 * Elementor defaults reproduced explicitly: padding 10px (kit `container_padding`), gap 20px (kit
 * `space_between_widgets`; Zadex's `var(--zx-gap, 20px)` fallback already matches), boxed content width 1140px
 * (kit `container_width`), `flex-wrap: wrap` on mobile for row containers, grid columns 1 on mobile.
 *
 * Boxed: Elementor paints `.e-con` full width and centres `.e-con-inner` (max-width W) inside its side padding.
 * Without visible decoration the Zadex container is boxed with `content_width` = W + side padding (same content box);
 * with background / overlay / border / shadow / shape dividers it becomes outer full (decoration, padding, min
 * height) + inner boxed (`i` suffix, flex settings).
 */

const DIRECTION = { row: 'row', column: 'column', 'row-reverse': 'row-reverse', 'column-reverse': 'column-reverse' };
const JUSTIFY = { 'flex-start': 'flex-start', center: 'center', 'flex-end': 'flex-end', 'space-between': 'space-between', 'space-around': 'space-around', 'space-evenly': 'space-evenly' };
const ALIGN = { 'flex-start': 'flex-start', center: 'center', 'flex-end': 'flex-end', stretch: 'stretch' };
const GRID_ALIGN = { start: 'start', center: 'center', end: 'end', stretch: 'stretch' };
const GRID_TAGS = new Set(['div', 'section', 'article', 'aside']);

registerElement('container', (el, ctx) => convertContainer(el, ctx));

export function convertContainer(el: ElElement, ctx: ConvertContext): ZElement {
  const s = el.settings ?? {};
  const isGrid = (s.container_type ?? 'flex') === 'grid';
  const boxed = (s.content_width ?? 'boxed') !== 'full';
  // Zadex `grid` has no overlay / media background / shape dividers / link / width preset: wrap it in a container.
  const needsWrapper =
    isGrid &&
    (boxed ||
      ['background_overlay_background', 'background_overlay_hover_background', 'shape_divider_top', 'shape_divider_bottom'].some((k) => typeof s[k] === 'string' && s[k] !== '') ||
      s.background_background === 'video' ||
      s.background_background === 'slideshow' ||
      (typeof s.html_tag === 'string' && s.html_tag !== '' && !GRID_TAGS.has(s.html_tag)) ||
      (typeof s.overflow === 'string' && s.overflow !== ''));
  const gridOnly = isGrid && !needsWrapper;
  const w = ctx.writer(el, gridOnly ? 'grid' : 'container');
  // Read above from the raw settings (they decide the structure): never "dropped".
  w.consume('content_width');
  w.consume('container_type');

  // Tag / link (`html_tag: a` turns the container into a link; Zadex renders <a> when `link` is set).
  w.consume('link');
  const tag = htmlTag(w);
  if (tag === 'a') {
    if (gridOnly) w.note('A grid container used as a link cannot be a Zadex grid link.');
    else w.url('link', 'link');
  }

  // Overflow (not on the Zadex grid; a grid with overflow is wrapped above).
  const overflow = w.raw('overflow');
  if (overflow === 'hidden' || overflow === 'auto') w.set('_overflow', overflow);

  const visible = decoration(w, {
    allow: gridOnly ? ['classic', 'gradient'] : ['classic', 'gradient', 'video', 'slideshow'],
    overlay: !gridOnly,
    shapes: !gridOnly,
  });

  // Spacing.
  const padding = paddingCascade(w, 'padding', kitPadding(ctx));
  w.consumeResponsive('margin');
  putCascade(w.settings, '_margin', cascade((suffix) => strictDims(w.raw('margin' + suffix))));
  w.slider('min_height', 'min_height');

  // Layout settings go to a holder: the element itself, the inner boxed container or the grid.
  const holder: Settings = {};
  if (isGrid) {
    consumeFlex(w);
    gridSettings(w, holder, ctx);
  } else {
    consumeGrid(w);
    flexSettings(w, holder, ctx);
  }

  // Width.
  w.consumeResponsive('width');
  w.consumeResponsive('boxed_width');
  const children = ctx.convert(el.elements);
  if (!isGrid) rowWidgetWidths(holder, children);
  if (!boxed) {
    w.set('width_preset', 'full');
    w.responsive('width', '_width', (v) => slider(v, '%'));
  }
  const ownWidth: Cascade<Slider> = boxed ? cascade((suffix) => slider(w.raw('boxed_width' + suffix))) : {};

  if (gridOnly) {
    delete w.settings.width_preset;
    putCascade(w.settings, '_padding', padding);
    Object.assign(w.settings, holder);
    return w.finish(children);
  }

  const chain: ZElement[] = [];
  const split = boxed && visible;
  if (!split) {
    if (boxed) {
      w.set('width_preset', 'boxed');
      putCascade(w.settings, 'content_width', contentWidthCascade(ctx, ownWidth, padding));
    }
    putCascade(w.settings, '_padding', padding);
    if (!isGrid) Object.assign(w.settings, holder);
  } else {
    w.set('width_preset', 'full');
    putCascade(w.settings, '_padding', padding);
    const inner: Settings = { width_preset: 'boxed', _padding: { ...ZERO } };
    putCascade(inner, 'content_width', contentWidthCascade(ctx, ownWidth, uniform(ZERO)));
    if (!isGrid) Object.assign(inner, holder);
    if (hasAny(w.settings, 'min_height')) inner._flex_grow = 1;
    chain.push({ id: ctx.idFor(el.id, 'i'), type: 'container', settings: inner, children: [] });
  }
  if (isGrid) {
    const grid: Settings = { _padding: { ...ZERO } };
    Object.assign(grid, holder);
    if (hasAny(w.settings, 'min_height') && !split) grid._flex_grow = 1;
    chain.push({ id: ctx.idFor(el.id, 'g'), type: 'grid', settings: grid, children: [] });
  }
  return chain.length ? finishChain(w, chain, children) : w.finish(children);
}

/* ---- flex ---- */

function flexSettings(w: ElementWriter, holder: Settings, ctx: ConvertContext): void {
  const tmp = w.settings;
  const before = new Set(Object.keys(tmp));
  w.map('flex_direction', 'direction', DIRECTION);
  w.map('flex_justify_content', 'justify', JUSTIFY);
  w.map('flex_align_items', 'align', ALIGN);
  w.map('flex_wrap', 'wrap', { nowrap: 'nowrap', wrap: 'wrap' });
  for (const key of Object.keys(tmp)) {
    if (!before.has(key)) {
      holder[key] = tmp[key];
      delete tmp[key];
    }
  }
  // Gap: own `flex_gap[_device]` (both sides required, like Elementor), else the kit gap when it is not 20px.
  w.consumeResponsive('flex_gap');
  const own = cascade<Gap>((suffix) => strictGap(w.raw('flex_gap' + suffix)));
  const kit = kitWidgetGap(ctx);
  putCascade(holder, 'gap', own.desktop || isDefaultGap(kit) ? own : { ...uniform(kit), ...Object.fromEntries(Object.entries(own).filter(([, v]) => v !== undefined)) });
  // Elementor sets `--flex-wrap: wrap` on every flex container on mobile unless the element sets its own wrap.
  const rowish = Object.entries(holder).some(([k, v]) => k.startsWith('direction') && typeof v === 'string' && v.startsWith('row'));
  if (rowish && !w.has('flex_wrap') && !w.has('flex_wrap_mobile')) put(holder, 'wrap', 'wrap', 'mobile');
  if (w.has('flex_align_content')) w.consumeResponsive('flex_align_content');
  if (w.el.settings?.flex_align_content) w.note('"Align content" (wrapped rows) is not supported by the Zadex container.');
}

const LAYOUT_TYPES = new Set(['container', 'grid']);
// Elementor keeps these widgets 100% wide in rows too (`.e-con .elementor-widget-video{width:100%}`, swiper widgets).
const FULL_IN_ROWS = new Set(['video', 'google-maps', 'image-carousel', 'testimonial-carousel', 'media-carousel']);
// Widgets without intrinsic width (flip box faces are absolutely positioned, slides / review carousels are sliders):
// in a Zadex row their wrapper is `flex: 0 1 auto` with no width, so they collapse to 0 px, while Elementor's flex
// items share the row. They get `_width: 100%` in rows (the row shrinks them equally, like Elementor) (V7).
const NO_INTRINSIC_WIDTH = new Set(['flip-box', 'slides', 'reviews', 'loop-carousel']);

/**
 * Elementor sizes widgets in a row container by their content (`--container-widget-width: initial`) and 100% wide in
 * a column one; several Zadex widgets (image, icon box…) are always `width: 100%`. Widgets without their own width
 * get `_width: auto` on the breakpoints where the container is a row (and 100% again where it turns into a column).
 */
function rowWidgetWidths(holder: Settings, children: ZElement[]): void {
  const dir = cascade<string>((_suffix, bp) => {
    const v = holder[bp ? `direction@${bp}` : 'direction'];
    return typeof v === 'string' ? v : undefined;
  });
  const isRow = (v: string | undefined) => typeof v === 'string' && v.startsWith('row');
  if (!Object.values(dir).some(isRow)) return;
  const widths = cascade<Slider>((_suffix, bp) => {
    const key = bp === undefined ? 'desktop' : bp;
    return isRow(dir[key]) ? { size: 'auto', unit: 'custom' } : { size: 100, unit: '%' };
  });
  const full = cascade<Slider>(() => ({ size: 100, unit: '%' }));
  for (const child of children) {
    if (LAYOUT_TYPES.has(child.type) || FULL_IN_ROWS.has(child.type) || hasAny(child.settings, '_width')) continue;
    putCascade(child.settings, '_width', NO_INTRINSIC_WIDTH.has(child.type) ? full : widths);
  }
}

function consumeFlex(w: ElementWriter): void {
  for (const k of ['flex_direction', 'flex_justify_content', 'flex_align_items', 'flex_gap', 'flex_wrap', 'flex_align_content']) w.consumeResponsive(k);
}

/* ---- grid ---- */

function gridSettings(w: ElementWriter, holder: Settings, ctx: ConvertContext): void {
  for (const k of ['grid_columns_grid', 'grid_rows_grid', 'grid_gaps', 'grid_auto_flow', 'grid_justify_items', 'grid_align_items', 'grid_justify_content', 'grid_align_content']) w.consumeResponsive(k);
  // Columns: `repeat(N, 1fr)` (unit fr) or a raw template (unit custom); Elementor's mobile default is 1 column.
  for (const [suffix, bp] of [['', undefined], ['_widescreen', 'widescreen'], ['_laptop', 'laptop'], ['_tablet_extra', 'tablet_large'], ['_tablet', 'tablet'], ['_mobile_extra', 'mobile_large'], ['_mobile', 'mobile']] as const) {
    const cols = slider(bp ? w.raw('grid_columns_grid' + suffix) : w.get('grid_columns_grid'), 'fr');
    if (cols) {
      if (cols.unit === 'custom') put(holder, 'custom_columns', String(cols.size), bp);
      else if (typeof num(cols.size) === 'number') put(holder, 'columns', num(cols.size), bp);
    } else if (bp === 'mobile') put(holder, 'columns', 1, 'mobile');
    const rows = slider(w.raw('grid_rows_grid' + suffix), 'fr');
    if (rows) {
      if (rows.unit === 'custom') w.note('Custom grid row templates are not supported by the Zadex grid.');
      else if (typeof num(rows.size) === 'number') put(holder, 'rows', num(rows.size), bp);
    }
  }
  if (holder.custom_columns !== undefined && holder['columns@mobile'] === 1 && !w.has('grid_columns_grid_mobile')) put(holder, 'custom_columns', '1fr', 'mobile');
  if (holder.rows !== undefined) w.note('Grid rows are sized by their content in Zadex (Elementor stretches them to equal heights).');
  const own = cascade<Gap>((suffix) => strictGap(w.raw('grid_gaps' + suffix)));
  const kit = kitWidgetGap(ctx);
  putCascade(holder, 'gap', own.desktop || isDefaultGap(kit) ? own : { ...uniform(kit), ...Object.fromEntries(Object.entries(own).filter(([, v]) => v !== undefined)) });
  const flow = w.get('grid_auto_flow');
  if (flow === 'column') holder.auto_flow = 'column';
  const tmp = w.settings;
  const before = new Set(Object.keys(tmp));
  w.map('grid_justify_items', 'justify_items', GRID_ALIGN);
  w.map('grid_align_items', 'align_items', GRID_ALIGN);
  for (const key of Object.keys(tmp)) {
    if (!before.has(key)) {
      holder[key] = tmp[key];
      delete tmp[key];
    }
  }
  if (w.el.settings?.grid_justify_content || w.el.settings?.grid_align_content) w.note('Grid "justify content" / "align content" are not supported by the Zadex grid.');
}

function consumeGrid(w: ElementWriter): void {
  for (const k of ['grid_columns_grid', 'grid_rows_grid', 'grid_gaps', 'grid_auto_flow', 'grid_justify_items', 'grid_align_items', 'grid_justify_content', 'grid_align_content']) w.consumeResponsive(k);
}
