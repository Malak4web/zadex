import { makeKey } from '@zadex/editor/core/settings';
import type { ConvertContext, ElementWriter } from '../context';
import type { BreakpointKey, Settings, ZElement } from '../types';
import { bool, num, slider, type Slider } from '../values';
import { convertBackground, convertOverlay, type BackgroundType } from '../background';

/**
 * Helpers shared by the layout mappers (section / column / container): breakpoint cascade, Elementor's strict
 * dimension semantics, kit layout defaults, boxed width maths, decoration (background, overlay, border, shadow,
 * shape dividers) and the outer-full + inner-boxed split.
 */

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/* ---- breakpoint cascade (desktop-first) ---- */

export type BpKey = BreakpointKey | 'desktop';

export const BPS: Array<{ suffix: string; bp: BreakpointKey | undefined; key: BpKey; parent?: BpKey }> = [
  { suffix: '', bp: undefined, key: 'desktop' },
  { suffix: '_widescreen', bp: 'widescreen', key: 'widescreen', parent: 'desktop' },
  { suffix: '_laptop', bp: 'laptop', key: 'laptop', parent: 'desktop' },
  { suffix: '_tablet_extra', bp: 'tablet_large', key: 'tablet_large', parent: 'laptop' },
  { suffix: '_tablet', bp: 'tablet', key: 'tablet', parent: 'tablet_large' },
  { suffix: '_mobile_extra', bp: 'mobile_large', key: 'mobile_large', parent: 'tablet' },
  { suffix: '_mobile', bp: 'mobile', key: 'mobile', parent: 'mobile_large' },
];

export type Cascade<T> = Partial<Record<BpKey, T>>;

/** Effective value per breakpoint: own value, else the parent breakpoint's effective value. */
export function cascade<T>(own: (suffix: string, bp: BreakpointKey | undefined) => T | undefined): Cascade<T> {
  const out: Cascade<T> = {};
  for (const b of BPS) {
    const v = own(b.suffix, b.bp);
    out[b.key] = v !== undefined ? v : b.parent ? out[b.parent] : undefined;
  }
  return out;
}

/** Combines two cascades per breakpoint (`a` wins, `b` is the fallback). */
export function orElse<T>(a: Cascade<T>, b: Cascade<T>): Cascade<T> {
  const out: Cascade<T> = {};
  for (const { key } of BPS) out[key] = a[key] !== undefined ? a[key] : b[key];
  return out;
}

export function mapCascade<T, U>(c: Cascade<T>, fn: (v: T | undefined, key: BpKey) => U | undefined): Cascade<U> {
  const out: Cascade<U> = {};
  for (const { key } of BPS) out[key] = fn(c[key], key);
  return out;
}

/** Writes the desktop value and every device value that differs from what the device would inherit. */
export function putCascade(settings: Settings, id: string, c: Cascade<unknown>): void {
  for (const b of BPS) {
    const v = c[b.key];
    if (v === undefined) continue;
    if (b.parent && JSON.stringify(v) === JSON.stringify(c[b.parent])) continue;
    settings[makeKey(id, { bp: b.bp })] = v;
  }
}

export function put(settings: Settings, id: string, value: unknown, bp?: BreakpointKey): void {
  if (value !== undefined) settings[makeKey(id, { bp })] = value;
}

/* ---- Elementor value semantics ---- */

export interface Dims {
  top: number | string;
  right: number | string;
  bottom: number | string;
  left: number | string;
  unit: string;
  linked: boolean;
}

export const ZERO: Dims = { top: 0, right: 0, bottom: 0, left: 0, unit: 'px', linked: true };

/**
 * Elementor dimensions as Elementor renders them: its CSS generator skips the whole rule when any placeholder of
 * the selector is empty, so a value with an empty side is ignored (undefined), like on the Elementor page.
 */
export function strictDims(v: unknown): Dims | undefined {
  if (!isObj(v)) return undefined;
  const sides = (['top', 'right', 'bottom', 'left'] as const).map((s) => num(v[s]));
  if (sides.some((s) => s === undefined)) return undefined;
  const [top, right, bottom, left] = sides as Array<number | string>;
  return { top, right, bottom, left, unit: typeof v.unit === 'string' && v.unit !== '' ? v.unit : 'px', linked: v.isLinked === true || v.isLinked === 'true' };
}

export interface Gap {
  row: number | string;
  column: number | string;
  unit: string;
  linked: boolean;
}

/** Elementor `gaps` control `{row, column, isLinked, unit}` -> Zadex gap (both sides required, like Elementor). */
export function strictGap(v: unknown): Gap | undefined {
  if (!isObj(v)) return undefined;
  const row = num(v.row);
  const column = num(v.column);
  if (row === undefined || column === undefined) return undefined;
  return { row, column, unit: typeof v.unit === 'string' && v.unit !== '' ? v.unit : 'px', linked: row === column };
}

export function isZeroDims(d: Dims | undefined): boolean {
  return !d || [d.top, d.right, d.bottom, d.left].every((s) => Number(s) === 0);
}

/** One side as CSS (`10px`, `2em`, raw value for the custom unit). */
export function sideCss(v: number | string, unit: string): string {
  if (unit === 'custom') return String(v);
  return Number(v) === 0 ? '0px' : `${v}${unit}`;
}

/* ---- kit layout defaults (Site Settings > Layout); the Zadex globals import (M5) mirrors them ---- */

/** Kit `container_width` (desktop) or Elementor's 1140px. */
export function kitContentWidth(ctx: ConvertContext): Slider {
  const s = slider(ctx.source.kit?.container_width);
  return s ?? { size: 1140, unit: 'px' };
}

/** Kit `container_padding[_device]` or Elementor's 10px on every side. */
export function kitPadding(ctx: ConvertContext): Cascade<Dims> {
  const kit = ctx.source.kit ?? {};
  const c = cascade((suffix) => strictDims(kit[`container_padding${suffix}`]));
  if (c.desktop) return c;
  const def: Dims = { top: 10, right: 10, bottom: 10, left: 10, unit: 'px', linked: true };
  return orElse(c, { desktop: def, widescreen: def, laptop: def, tablet_large: def, tablet: def, mobile_large: def, mobile: def });
}

/** Kit `space_between_widgets` (gaps in Elementor 3.16+, slider / number before) or 20px. */
export function kitWidgetGap(ctx: ConvertContext): Gap {
  const v = ctx.source.kit?.space_between_widgets;
  const g = strictGap(v);
  if (g) return g;
  const s = slider(v);
  if (s && typeof s.size === 'number') return { row: s.size, column: s.size, unit: s.unit, linked: true };
  return { row: 20, column: 20, unit: 'px', linked: true };
}

/** True when the kit gap equals Zadex's built-in container gap fallback (`var(--zx-gap, 20px)`). */
export function isDefaultGap(g: Gap): boolean {
  return g.unit === 'px' && Number(g.row) === 20 && Number(g.column) === 20;
}

/* ---- boxed width ---- */

/**
 * Zadex `content_width` (a max-width on the element itself, border-box) that gives the same content box as Elementor's
 * boxed layout, where the padding sits outside the `max-width: W` inner box: W + left + right padding.
 * `own` is the element's own boxed width (undefined = kit width through `var(--zx-content-width, <kit>)`).
 * Returns undefined when Zadex's default (`var(--zx-content-width, 1140px)`) already matches.
 */
export function contentWidth(ctx: ConvertContext, own: Slider | undefined, pad: Dims | undefined): Slider | undefined {
  const kit = kitContentWidth(ctx);
  const kitCss = kit.unit === 'custom' ? String(kit.size) : `${kit.size}${kit.unit}`;
  const varCss = `var(--zx-content-width, ${kitCss})`;
  const wCss = own ? (own.unit === 'custom' ? String(own.size) : `${own.size}${own.unit}`) : varCss;
  if (isZeroDims(pad)) {
    if (own) return own;
    return kitCss === '1140px' ? undefined : { size: varCss, unit: 'custom' };
  }
  const p = pad!;
  if (own && own.unit === 'px' && typeof own.size === 'number' && p.unit === 'px' && typeof p.left === 'number' && typeof p.right === 'number') {
    return { size: own.size + p.left + p.right, unit: 'px' };
  }
  return { size: `calc(${wCss} + ${sideCss(p.left, p.unit)} + ${sideCss(p.right, p.unit)})`, unit: 'custom' };
}

/** `content_width` per breakpoint; once any breakpoint needs a value, the others get the explicit default. */
export function contentWidthCascade(ctx: ConvertContext, own: Cascade<Slider>, pad: Cascade<Dims>): Cascade<Slider> {
  const c = mapCascade(own, (w, key) => contentWidth(ctx, w, pad[key]));
  const any = BPS.some(({ key }) => c[key] !== undefined);
  if (!any) return {};
  return mapCascade(c, (v) => v ?? { size: 'var(--zx-content-width, 1140px)', unit: 'custom' });
}

/* ---- decoration ---- */

export interface DecorationOptions {
  allow: BackgroundType[];
  overlay: boolean;
  shapes: boolean;
  /** Classic columns only draw border / shadow on a populated column (`.elementor-element-populated`). */
  border?: boolean;
}

/**
 * Background (+hover), overlay (+hover), border (+hover, radius), box shadow (+hover) and shape dividers.
 * Returns true when something visible was written (used to decide the boxed split).
 */
export function decoration(w: ElementWriter, opts: DecorationOptions): boolean {
  convertBackground(w, 'background', 'background', { allow: opts.allow });
  convertBackground(w, 'background_hover', 'background', { state: 'hover', allow: ['classic', 'gradient'] });
  w.consume('background_hover_transition', 'border_hover_transition');
  if (opts.overlay) {
    convertOverlay(w, 'background_overlay');
    convertOverlay(w, 'background_overlay_hover', 'overlay', 'overlay_opacity', 'hover');
  }
  if (opts.border !== false) {
    w.border('border', 'border', 'border_radius');
    w.border('border_hover', 'border', 'border_radius_hover', 'hover');
    w.boxShadow('box_shadow', 'box_shadow');
    w.boxShadow('box_shadow_hover', 'box_shadow', 'hover');
  } else {
    for (const k of ['border_border', 'border_color', 'border_hover_border', 'border_hover_color', 'box_shadow_box_shadow_type', 'box_shadow_box_shadow_position', 'box_shadow_hover_box_shadow_type', 'box_shadow_hover_box_shadow_position']) w.consume(k);
    for (const k of ['border_width', 'border_radius', 'border_hover_width', 'border_radius_hover', 'box_shadow_box_shadow', 'box_shadow_hover_box_shadow']) w.consumeResponsive(k);
  }
  if (opts.shapes) shapes(w);
  return Object.keys(w.settings).some((key) => {
    const base = key.replace(/(::[a-z_]+)?(@[a-z_]+)?$/, '');
    if (base === 'background' || base === 'overlay' || base === 'box_shadow' || base === 'shape_top' || base === 'shape_bottom') return true;
    if (base === 'border') {
      const b = w.settings[key] as Obj;
      return typeof b.style === 'string' && b.style !== 'none';
    }
    return false;
  });
}

/** Elementor shape -> [Zadex shape, exact match]. */
const SHAPES: Record<string, [string, boolean]> = {
  mountains: ['mountains', true],
  clouds: ['clouds', true],
  zigzag: ['zigzag', true],
  pyramids: ['pyramids', true],
  triangle: ['triangle', true],
  'triangle-asymmetrical': ['triangle-asymmetric', true],
  tilt: ['tilt', true],
  curve: ['curve', true],
  'curve-asymmetrical': ['curve-asymmetric', true],
  waves: ['waves', true],
  book: ['book', true],
  split: ['split', true],
  arrow: ['arrow', true],
  'opacity-tilt': ['tilt', false],
  'opacity-fan': ['triangle', false],
  'wave-brush': ['waves-2', false],
  'waves-pattern': ['waves-2', false],
  drops: ['clouds', false],
};

/** Height / width ratio of Elementor's shape SVGs (rendered with `height: auto`). Zadex's SVGs are all 1000 x 100. */
const SHAPE_RATIO: Record<string, number> = { arrow: 10 / 700, split: 20 / 1000, zigzag: 5.8 / 1800, clouds: 27.8 / 283.5, drops: 27.8 / 283.5, 'opacity-fan': 19.6 / 283.5, 'opacity-tilt': 131.1 / 2600, 'wave-brush': 27.8 / 283.5, 'waves-pattern': 3.7 / 1047.1 };

function shapes(w: ElementWriter): void {
  for (const pos of ['top', 'bottom'] as const) {
    const key = `shape_divider_${pos}`;
    w.consume(`${key}_*`);
    const name = w.raw(key);
    if (typeof name !== 'string' || name === '') continue;
    const hit = SHAPES[name];
    if (!hit) {
      w.note(`Shape divider "${name}" has no Zadex equivalent.`);
      w.status('partial');
      continue;
    }
    const dst = `shape_${pos}`;
    w.set(dst, hit[0]);
    if (!hit[1]) {
      w.note(`Shape divider "${name}" was approximated with Zadex's "${hit[0]}".`);
      w.status('partial');
    }
    w.color(`${key}_color`, `${dst}_color`);
    w.slider(`${key}_width`, `${dst}_width`, undefined, '%');
    w.slider(`${key}_height`, `${dst}_height`);
    if (w.settings[`${dst}_height`] === undefined) {
      // Elementor leaves the SVG height to its aspect ratio; Zadex's shapes are 1000 x 100 (10% of the width).
      const ratio = SHAPE_RATIO[name] ?? 0.1;
      w.set(`${dst}_height`, Math.abs(ratio - 0.1) < 0.001 ? { size: 'auto', unit: 'custom' } : { size: Math.round(ratio * 10000) / 100, unit: 'vw' });
    }
    if (bool(w.raw(`${key}_flip`))) w.set(`${dst}_flip`, true);
    if (bool(w.raw(`${key}_negative`))) w.set(`${dst}_invert`, true);
    if (bool(w.raw(`${key}_above_content`))) w.set(`${dst}_front`, true);
  }
}

/* ---- tags, margins, padding ---- */

/** `html_tag` -> Zadex `tag` when the target control lists it. */
export function htmlTag(w: ElementWriter, key = 'html_tag'): string | undefined {
  const tag = w.raw(key);
  if (typeof tag !== 'string' || tag === '') return undefined;
  const control = w.ctx.manifests[w.type]?.controls.find((c) => c.id === 'tag');
  const options = Array.isArray(control?.options) ? control.options : [];
  const ok = options.some((o) => (typeof o === 'string' ? o : o.value) === tag);
  if (ok) w.set('tag', tag);
  else if (tag !== 'a') w.note(`HTML tag "${tag}" is not available on the Zadex ${w.type}; "div" was used.`);
  return tag;
}

/** Element padding per breakpoint: the element's own `padding[_device]` (strict) or a fallback cascade. */
export function paddingCascade(w: ElementWriter, key: string, fallback: Cascade<Dims>): Cascade<Dims> {
  w.consumeResponsive(key);
  return orElse(cascade((suffix) => strictDims(w.raw(key + suffix))), fallback);
}

/** Uniform cascade (same value at every breakpoint). */
export function uniform<T>(v: T): Cascade<T> {
  const out: Cascade<T> = {};
  for (const { key } of BPS) out[key] = v;
  return out;
}

/** Moves every key whose base id is listed (`id`, `id::hover`, `id@tablet` …) from one settings object to another. */
export function moveKeys(from: Settings, to: Settings, bases: string[]): void {
  for (const key of Object.keys(from)) {
    const base = key.replace(/(::[a-z_]+)?(@[a-z_]+)?$/, '');
    if (bases.includes(base)) {
      to[key] = from[key];
      delete from[key];
    }
  }
}

export function hasAny(settings: Settings, base: string): boolean {
  return Object.keys(settings).some((k) => k === base || k.startsWith(base + '@') || k.startsWith(base + '::'));
}

/**
 * Finishes an element whose content sits in extra Zadex wrappers (boxed split, grid holder). `chain` lists the
 * inner elements from outside in (their `children` are filled here); only the outer writer runs the shared
 * Advanced-tab conversion and gets a report entry (listing every produced id).
 */
export function finishChain(w: ElementWriter, chain: ZElement[], children: ZElement[]): ZElement {
  for (let i = 0; i < chain.length; i++) chain[i].children = i === chain.length - 1 ? children : [chain[i + 1]];
  const outer = w.finish(chain.length ? [chain[0]] : children);
  const entry = w.ctx.report.entries.find((e) => e.source === w.el.id && e.target[0] === w.id);
  if (entry) entry.target.push(...chain.map((c) => c.id));
  return outer;
}

