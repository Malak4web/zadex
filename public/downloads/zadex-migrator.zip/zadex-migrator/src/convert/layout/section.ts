import { registerElement } from '../registry';
import type { Settings, ZElement } from '../types';
import { slider, type Slider } from '../values';
import { convertColumn } from './column';
import { cascade, contentWidthCascade, decoration, finishChain, htmlTag, orElse, paddingCascade, put, putCascade, uniform, ZERO, type Cascade, type Dims } from './shared';

/**
 * Classic Elementor section (and inner section, `isInner`) -> Zadex container holding a row of column containers,
 * the same shape Zadex's own structure presets build (`direction: row`, `align: stretch`, `wrap: nowrap`,
 * `direction@mobile: column`).
 *
 * Elementor draws a boxed section full width (background, border, padding) and centres `.elementor-container`
 * (max-width = `content_width` or the kit container width) inside it. Zadex `width_preset: boxed` limits the element
 * itself, so:
 *  - nothing visible on the section: one boxed container whose `content_width` is W + the section's side padding;
 *  - visible background / overlay / border / shadow / shape divider: an outer full-width container (decoration,
 *    padding, margin) + an inner boxed container (id suffix `i`) holding the columns.
 * Columns sit edge to edge (row gap 0) and pad themselves with the section's column gap.
 */

const GAP_PADDING: Record<string, number> = { no: 0, narrow: 5, default: 10, extended: 15, wide: 20, wider: 30 };
const COLUMN_POSITION: Record<string, string> = { stretch: 'stretch', top: 'flex-start', middle: 'center', bottom: 'flex-end' };

registerElement('section', (el, ctx) => {
  const w = ctx.writer(el, 'container');
  const inner = Boolean(el.isInner);
  const boxed = w.get('layout') !== 'full_width';
  w.consume('structure', 'layout');
  if (w.raw('stretch_section') === 'section-stretched') {
    w.note('"Stretch section" relies on Elementor JavaScript; use a Zadex full-width page template to span the viewport.');
  }

  htmlTag(w);
  if (w.raw('overflow') === 'hidden') w.set('_overflow', 'hidden');
  const visible = decoration(w, { allow: ['classic', 'gradient', 'video', 'slideshow'], overlay: true, shapes: true });

  // Margin: Elementor sections only apply top / bottom (`margin-top`, `margin-bottom`); the sides stay auto.
  w.consumeResponsive('margin');
  for (const { suffix, bp } of BPS_LIST) {
    const m = w.raw('margin' + suffix) as Record<string, unknown> | undefined;
    if (!m || m.top === undefined || m.top === '' || m.bottom === undefined || m.bottom === '') continue;
    put(w.settings, '_margin', { top: Number(m.top) || m.top, right: '', bottom: Number(m.bottom) || m.bottom, left: '', unit: typeof m.unit === 'string' && m.unit ? m.unit : 'px', linked: false }, bp);
  }
  const padding = paddingCascade(w, 'padding', uniform(ZERO));

  // Height and column vertical position.
  for (const k of ['height', 'height_inner', 'column_position']) w.consume(k);
  for (const k of ['custom_height', 'custom_height_inner']) w.consumeResponsive(k);
  const heightKey = inner ? 'height_inner' : 'height';
  const height = String(w.get(heightKey) ?? 'default');
  const row: Settings = {};
  let fullHeight = false;
  if (height === 'full') {
    fullHeight = true;
  } else if (height === 'min-height') {
    const key = inner ? 'custom_height_inner' : 'custom_height';
    putCascade(row, 'min_height', cascade((suffix, bp) => slider(bp ? w.raw(key + suffix) : w.get(key))));
  }
  put(row, 'direction', 'row');
  put(row, 'align', height !== 'default' ? COLUMN_POSITION[String(w.get('column_position'))] ?? 'center' : 'stretch');
  put(row, 'wrap', 'nowrap');
  put(row, 'gap', { row: 0, column: 0, unit: 'px', linked: true });

  // Responsive stacking: Elementor wraps at <= 1024px and gives columns 100% on mobile unless they set widths.
  const columns = (el.elements ?? []).filter((c) => c.elType === 'column');
  const hasWidth = (suffix: string) => columns.some((c) => c.settings?.[`_inline_size${suffix}`] !== undefined && c.settings[`_inline_size${suffix}`] !== null && c.settings[`_inline_size${suffix}`] !== '');
  w.consume('reverse_order_tablet', 'reverse_order_mobile');
  const reverseTablet = w.raw('reverse_order_tablet') === 'reverse-tablet';
  const reverseMobile = w.raw('reverse_order_mobile') === 'reverse-mobile';
  if (reverseTablet) put(row, 'direction', 'row-reverse', 'tablet');
  if (hasWidth('_tablet')) put(row, 'wrap', 'wrap', 'tablet');
  if (hasWidth('_mobile')) {
    put(row, 'direction', reverseMobile ? 'row-reverse' : 'row', 'mobile');
    put(row, 'wrap', 'wrap', 'mobile');
  } else {
    put(row, 'direction', reverseMobile ? 'column-reverse' : 'column', 'mobile');
  }

  // Column gap -> column padding.
  w.consume('gap');
  w.consumeResponsive('gap_columns_custom');
  const gap = String(w.get('gap') ?? 'default');
  let gapPadding: Cascade<Dims>;
  if (gap === 'custom') {
    const custom = cascade((suffix) => {
      const s = slider(w.raw('gap_columns_custom' + suffix));
      return s ? ({ top: s.size, right: s.size, bottom: s.size, left: s.size, unit: s.unit, linked: true } as Dims) : undefined;
    });
    gapPadding = orElse(custom, uniform({ top: 10, right: 10, bottom: 10, left: 10, unit: 'px', linked: true }));
  } else {
    const n = GAP_PADDING[gap] ?? 10;
    gapPadding = uniform({ top: n, right: n, bottom: n, left: n, unit: 'px', linked: true });
  }
  w.consume('content_position');
  const contentPosition = w.raw('content_position');

  const children: ZElement[] = [];
  for (const child of el.elements ?? []) {
    if (child.elType === 'column') {
      children.push(convertColumn(child, ctx, { padding: gapPadding, contentPosition: typeof contentPosition === 'string' && contentPosition ? contentPosition : undefined, siblings: columns.length }));
    } else children.push(...ctx.convert([child]));
  }

  // Width: full / boxed (single) / boxed with visible decoration (outer full + inner boxed).
  w.consumeResponsive('content_width');
  const ownWidth: Cascade<Slider> = boxed ? cascade((suffix) => slider(w.raw('content_width' + suffix))) : {};
  if (!boxed || !visible) {
    w.set('width_preset', boxed ? 'boxed' : 'full');
    putCascade(w.settings, '_padding', padding);
    Object.assign(w.settings, row);
    if (boxed) putCascade(w.settings, 'content_width', contentWidthCascade(ctx, ownWidth, padding));
    if (fullHeight) w.set('min_height', { size: 100, unit: 'vh' });
    return w.finish(children);
  }
  w.set('width_preset', 'full');
  putCascade(w.settings, '_padding', padding);
  const innerSettings: Settings = { width_preset: 'boxed', _padding: { ...ZERO } };
  Object.assign(innerSettings, row);
  putCascade(innerSettings, 'content_width', contentWidthCascade(ctx, ownWidth, uniform(ZERO)));
  if (fullHeight) {
    w.set('min_height', { size: 100, unit: 'vh' });
    innerSettings._flex_grow = 1;
  }
  const innerEl: ZElement = { id: ctx.idFor(el.id, 'i'), type: 'container', settings: innerSettings, children: [] };
  return finishChain(w, [innerEl], children);
});

const BPS_LIST = [
  { suffix: '', bp: undefined },
  { suffix: '_widescreen', bp: 'widescreen' as const },
  { suffix: '_laptop', bp: 'laptop' as const },
  { suffix: '_tablet_extra', bp: 'tablet_large' as const },
  { suffix: '_tablet', bp: 'tablet' as const },
  { suffix: '_mobile_extra', bp: 'mobile_large' as const },
  { suffix: '_mobile', bp: 'mobile' as const },
];

