import { registerElement } from '../registry';
import type { ConvertContext } from '../context';
import type { ElElement, ZElement } from '../types';
import { num } from '../values';
import { BPS, cascade, decoration, htmlTag, isDefaultGap, kitWidgetGap, mapCascade, orElse, putCascade, sideCss, strictDims, uniform, ZERO, type Cascade, type Dims } from './shared';

/**
 * Classic Elementor column -> Zadex container (direction column), like Zadex's own section presets
 * (`_width` in %, `_width@mobile: 100%`).
 *  - width: `_inline_size` (custom drag width) or the `_column_size` class width; `_inline_size_tablet` /
 *    `_inline_size_mobile` override per device (Elementor stacks columns at 100% on mobile).
 *  - padding: the section's column gap (default 10px) unless the column sets its own padding; empty columns get none
 *    (Elementor pads `.elementor-element-populated` only).
 *  - spacing between widgets: Elementor's `margin-block-end` on widgets (kit `space_between_widgets`, column
 *    `space_between_widgets`) becomes the column `gap`; inner sections carry no such margin in Elementor, so the gap
 *    after an inner section is cancelled with a negative bottom margin.
 */

/** Elementor `_column_size` classes (`.elementor-col-33 { width: 33.333% }`). */
const COL_SIZES: Record<number, number> = { 10: 10, 11: 11.111, 12: 12.5, 14: 14.285, 16: 16.666, 20: 20, 25: 25, 30: 30, 33: 33.333, 40: 40, 50: 50, 60: 60, 66: 66.666, 70: 70, 75: 75, 80: 80, 83: 83.333, 90: 90, 100: 100 };

const JUSTIFY: Record<string, string> = {
  top: 'flex-start',
  middle: 'center',
  center: 'center',
  bottom: 'flex-end',
  'space-between': 'space-between',
  'space-around': 'space-around',
  'space-evenly': 'space-evenly',
};

export interface ColumnInherit {
  /** Padding from the parent section's column gap, per breakpoint. */
  padding: Cascade<Dims>;
  /** Section `content_position` (vertical alignment of every column's widgets). */
  contentPosition?: string;
  /** Number of columns in the section (fallback width when `_column_size` is missing). */
  siblings: number;
}

export function convertColumn(el: ElElement, ctx: ConvertContext, inherit: ColumnInherit): ZElement {
  const w = ctx.writer(el, 'container');
  const populated = (el.elements ?? []).length > 0;
  w.set('direction', 'column');

  // Width (+ horizontal margins, which Elementor puts inside the column on `.elementor-element-populated`).
  w.consume('_column_size', '_inline_size', '_inline_size_tablet', '_inline_size_mobile');
  const size = num(w.raw('_column_size'));
  const inline = num(w.raw('_inline_size'));
  const base = typeof inline === 'number' ? inline : typeof size === 'number' ? COL_SIZES[size] ?? size : Math.round((100 / Math.max(1, inherit.siblings)) * 1000) / 1000;
  const tablet = num(w.raw('_inline_size_tablet'));
  const mobile = num(w.raw('_inline_size_mobile'));
  const widths = cascade<number>((_suffix, bp) => {
    if (!bp) return base;
    if (bp === 'tablet' && typeof tablet === 'number') return tablet;
    if (bp === 'mobile') return typeof mobile === 'number' ? mobile : 100;
    return undefined;
  });
  w.consumeResponsive('margin');
  const margins = populated ? cascade((suffix) => strictDims(w.raw('margin' + suffix))) : {};
  const widthValues = mapCascade(widths, (pct, key) => {
    if (pct === undefined) return undefined;
    const m = margins[key];
    const size = Math.round(pct * 1000) / 1000;
    if (!m || (Number(m.left) === 0 && Number(m.right) === 0)) return { size, unit: '%' };
    return { size: `calc(${size}% - ${sideCss(m.left, m.unit)} - ${sideCss(m.right, m.unit)})`, unit: 'custom' };
  });
  putCascade(w.settings, '_width', widthValues);
  putCascade(w.settings, '_margin', margins);

  // Padding: own padding (strict, per device) over the section gap; nothing on empty columns.
  w.consumeResponsive('padding');
  const ownPadding = cascade((suffix) => strictDims(w.raw('padding' + suffix)));
  putCascade(w.settings, '_padding', populated ? orElse(ownPadding, inherit.padding) : uniform(ZERO));

  // Space between widgets.
  w.consumeResponsive('space_between_widgets');
  const kitGap = kitWidgetGap(ctx);
  const spacing = cascade((suffix) => {
    const n = num(w.raw('space_between_widgets' + suffix));
    return typeof n === 'number' ? n : undefined;
  });
  let rowGap = Number(kitGap.row) || 0;
  if (spacing.desktop !== undefined || BPS.some(({ key }) => spacing[key] !== undefined)) {
    const gaps = mapCascade(spacing, (n) => (n === undefined ? undefined : { row: n, column: n, unit: 'px', linked: true }));
    putCascade(w.settings, 'gap', gaps.desktop ? gaps : orElse(gaps, uniform({ row: kitGap.row, column: kitGap.column, unit: kitGap.unit, linked: true })));
    if (spacing.desktop !== undefined) rowGap = spacing.desktop;
  } else if (!isDefaultGap(kitGap)) {
    w.set('gap', { row: kitGap.row, column: kitGap.row, unit: kitGap.unit, linked: true });
  }

  // Vertical position of the widgets.
  if (w.has('content_position')) w.map('content_position', 'justify', JUSTIFY);
  else {
    w.consumeResponsive('content_position');
    const inherited = inherit.contentPosition ? JUSTIFY[inherit.contentPosition] : undefined;
    if (inherited) w.set('justify', inherited);
  }
  if (w.has('align')) w.note('Column horizontal alignment only affected widgets with a custom width in Elementor; it was not carried over.');

  htmlTag(w);
  decoration(w, { allow: ['classic', 'gradient', 'slideshow'], overlay: true, shapes: false, border: populated });

  // Children; cancel the gap after inner sections (Elementor's widget spacing is a margin on widgets only).
  const children: ZElement[] = [];
  const kids = el.elements ?? [];
  kids.forEach((child, i) => {
    const out = ctx.convert([child]);
    if (child.elType === 'section' && i < kids.length - 1 && out[0] && kitGap.unit === 'px') cancelGapAfter(out[0], rowGap);
    children.push(...out);
  });
  return w.finish(children);
}

function cancelGapAfter(z: ZElement, gap: number): void {
  if (!gap) return;
  const m = z.settings._margin as Partial<Dims> | undefined;
  if (m && m.unit && m.unit !== 'px') return;
  const bottom = Number(m?.bottom ?? 0) || 0;
  z.settings._margin = { top: m?.top ?? '', right: m?.right ?? '', bottom: bottom - gap, left: m?.left ?? '', unit: 'px', linked: false };
}

/** A column outside a section (should not happen in valid data): default column gap padding. */
registerElement('column', (el, ctx) => convertColumn(el, ctx, { padding: uniform({ top: 10, right: 10, bottom: 10, left: 10, unit: 'px', linked: true }), siblings: 1 }));
