import type { Breakpoint, BreakpointKey, ControlDef, GlobalSettings, Settings, WidgetManifest, ZDocument, ZElement } from '@zadex/editor/core/types';

export type { Breakpoint, BreakpointKey, ControlDef, GlobalSettings, Settings, WidgetManifest, ZDocument, ZElement };
import type { ConditionRule, ThemeTemplateSettings, ThemeTemplateType } from '@zadex/editor/core/themeTemplate';

/** Raw Elementor settings object (`_elementor_data` element settings, `_elementor_page_settings`, kit settings). */
export type ElSettings = Record<string, unknown>;

/** One node of `_elementor_data` (classic section/column/container/widget or a v4 atomic element). */
export interface ElElement {
  id: string;
  elType: string;
  widgetType?: string;
  isInner?: boolean;
  settings: ElSettings;
  elements: ElElement[];
  /** v4 atomic elements: local style definitions referenced by `classes` props. */
  styles?: Record<string, unknown>;
  [key: string]: unknown;
}

/** Attachment details the server sends along with the source (alt text, sizes, inline SVG markup). */
export interface MediaInfo {
  id: number;
  url: string;
  alt?: string;
  width?: number;
  height?: number;
  sizes?: Record<string, { url: string; width: number; height: number }>;
  /** Sanitized inline SVG markup for SVG attachments (icons uploaded to Elementor's "svg" library). */
  svg?: string;
}

/** Everything the converter needs about one Elementor document, as returned by GET /zadex-migrator/v1/source/{id}. */
export interface SourceDocument {
  postId: number;
  title: string;
  postType: string;
  elements: ElElement[];
  pageSettings: ElSettings;
  /** `_wp_page_template` (e.g. `elementor_canvas`, `elementor_header_footer`, `default`). */
  template: string;
  elementorVersion?: string;
  /** Site language direction: Elementor's logical `start`/`end` alignments become `right`/`left` on RTL sites. */
  rtl?: boolean;
  /** Active kit settings (global colors, typography, layout, breakpoints). */
  kit?: ElSettings;
  /** Attachment id -> details, for every media id referenced by the tree. */
  media?: Record<string, MediaInfo>;
  /** Elementor-rendered HTML per element id, for widgets Zadex has no equivalent for (only when Elementor is active). */
  rendered?: Record<string, string>;
  /**
   * v4 global classes referenced by atomic elements' `classes` prop: class id (`g-…`) -> `{id, label, type,
   * variants}` (Elementor `Global_Classes_Repository::make()->get_by_ids()`). Inlined into each element.
   */
  globalClasses?: Record<string, unknown>;
  /** v4 global variables (kit meta `_elementor_global_variables`, whole record or its `data` map): id -> `{type, label, value}`. */
  globalVariables?: Record<string, unknown>;
  /**
   * Elementor Pro loop item template id -> Zadex loop-item template id (`zadex_template` post), for templates that
   * were already converted. Loop grid / carousel widgets whose template is not listed fall back to Zadex `posts`.
   */
  loopTemplates?: Record<string, number | string>;
  /** WordPress navigation menus, slug -> term id (Elementor Pro's nav-menu stores the slug, Zadex the id). */
  menus?: Record<string, number>;
  /** `elementor_library` posts: `_elementor_template_type` (header, footer, single-post, archive, loop-item, section …). */
  templateType?: string;
  /** `elementor_library` posts: raw `_elementor_conditions` strings (`include/singular/post`, `exclude/archive/category/5` …). */
  conditions?: unknown;
  /**
   * Elementor library template id -> Zadex `zadex_library` or `zadex_template` post id, for templates that were
   * already converted (the Elementor Pro `template` widget becomes a Zadex `template` widget pointing at it).
   */
  libraryTemplates?: Record<string, number | string>;
  /**
   * Elementor Pro global widgets used by the tree: global widget template id (`templateID` of a `global` element) ->
   * the template's widget element (first element of its `_elementor_data`). The `global` mapper converts it in place.
   */
  globalWidgets?: Record<string, ElElement>;
  /**
   * Elementor popup id -> Zadex popup template id (`zadex_template` of type popup), for popups already converted:
   * popup action links and form popup actions are rewritten through it (src/convert/popup-links.ts).
   */
  popupTemplates?: Record<string, number | string>;
  /** Popups: decoded `_elementor_popup_display_settings` (`{triggers: {…}, timing: {…}}`), see src/convert/popup.ts. */
  popupSettings?: unknown;
}

/** Zadex display rule of a theme template (`Zadex\Theme\Conditions`). */
export type ZadexConditionRule = ConditionRule;

/** Where an `elementor_library` document goes in Zadex (`docs/ARCHITECTURE.md` "Theme Builder and saved templates"). */
export type TemplateTarget =
  | { kind: 'theme'; type: ThemeTemplateType; rules: ConditionRule[]; settings: Required<Pick<ThemeTemplateSettings, 'sticky' | 'transparent' | 'layout'>> }
  | { kind: 'library'; type: 'page' | 'section' };

/** Zadex side the converter targets, read from GET /zadex/v1/widgets and GET /zadex/v1/global. */
export interface ZadexEnv {
  manifests: WidgetManifest[];
  commonControls: ControlDef[];
  /** Current Zadex global settings (to know which global color / font ids exist). */
  global?: GlobalSettings;
}

export type ElementStatus = 'converted' | 'partial' | 'fallback' | 'skipped';

export interface ReportEntry {
  /** Elementor element id. */
  source: string;
  /** `widgetType` for widgets, else `elType`. */
  sourceType: string;
  status: ElementStatus;
  /** Zadex element id(s) produced (first = the main one). */
  target: string[];
  targetType?: string;
  /** Elementor setting keys that were set but could not be carried over. */
  dropped: string[];
  /** Human-readable notes (English, translated at display time). */
  notes: string[];
}

export interface Report {
  entries: ReportEntry[];
  /** Document-level notes (page settings, template, globals). */
  notes: string[];
}

export interface ConvertResult {
  document: ZDocument;
  pageSettings: Settings;
  /** Zadex page template: '' | 'zadex-canvas.php' | 'zadex-full-width.php'. */
  template: string;
  report: Report;
  summary: ReportSummary;
  /** Set for `elementor_library` sources whose template type Zadex supports (theme template or library item). */
  target?: TemplateTarget;
}

export interface ReportSummary {
  elements: number;
  converted: number;
  partial: number;
  fallback: number;
  skipped: number;
  /** 0..100: converted = 1, partial = 0.75, fallback = 0.25, skipped = 0. */
  score: number;
}
