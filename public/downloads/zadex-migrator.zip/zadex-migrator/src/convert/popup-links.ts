import type { ReportEntry, SourceDocument, ZElement } from './types';
import { parseDynamicTag } from './dynamic';

/**
 * Elementor Pro popup references -> Zadex popup actions (docs/ARCHITECTURE.md "Popups (converter)").
 *
 * Verified against Elementor 3.33 / Elementor Pro 3.33.2 (`Frontend::create_action_hash()`, `modules/popup/tag.php`):
 *  - `create_action_hash($action, $settings)` = `'#' . rawurlencode('elementor-action:action=<action>&settings=' .
 *    base64_encode(wp_json_encode($settings)))`, i.e. `#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3D…`
 *    (base64 `=` / `+` / `/` encoded too). Open links carry `{"id":"<popup id>","toggle":false|true}` (toggle is
 *    `popup:open` + `toggle: true`), close links `{"do_not_show_again":"yes"|""}`. The editor JS builds the same
 *    string unencoded (`#elementor-action:action=…&settings=<btoa>`); HTML content may escape `&` as `&amp;`. All
 *    variants are decoded; `popup:toggle` is accepted too.
 *  - The `popup` dynamic tag (url category) has controls `action` open | close | toggle (default open), `popup`
 *    (post id, open / toggle) and `do_not_show_again` (switcher, close); its rendered value is the action link.
 *  - Elementor popup ids are post ids; `source.popupTemplates` maps them (as strings) to Zadex popup template ids.
 * Other Elementor actions (`lightbox`, …) are left untouched.
 */

export type PopupMap = Record<string, number | string> | undefined;

/** What the link helpers need: the id map, directly or through the source document / convert context. */
export type PopupLinkContext = { popupTemplates?: PopupMap } | { source: Pick<SourceDocument, 'popupTemplates'> };

export interface PopupLinkResult {
  url: string;
  note?: string;
  /** True when the link pointed at an Elementor popup that has no Zadex counterpart (it became `#`). */
  unmapped?: boolean;
}

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Matches one Elementor action link inside any string (plain, URL-encoded incl. `%23` for `#`, or double-encoded). */
const ACTION_RE = /(?:#|%23|%2523)elementor-action(?::|%3A|%253A)[^"'\s<>]*/gi;

/** Kept for existing imports: the link format is verified against Pro 3.33.2, so there is nothing to add. */
export const LINK_VERIFY = '';

function mapOf(ctx: PopupLinkContext | undefined): PopupMap {
  if (!ctx) return undefined;
  return 'source' in ctx ? ctx.source?.popupTemplates : ctx.popupTemplates;
}

/** Elementor popup id -> Zadex popup template id (string), or undefined when it is not in the map. */
export function mapPopupId(id: unknown, map: PopupMap): string | undefined {
  if (!map || id === undefined || id === null || id === '') return undefined;
  const key = typeof id === 'number' ? String(id) : typeof id === 'string' ? id.trim() : '';
  if (key === '' || !Object.prototype.hasOwnProperty.call(map, key)) return undefined;
  const target = map[key];
  const n = typeof target === 'number' ? target : typeof target === 'string' && /^\d+$/.test(target.trim()) ? Number(target) : NaN;
  return Number.isInteger(n) && n > 0 ? String(n) : undefined;
}

function safeDecode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

function base64Json(raw: string): Record<string, unknown> {
  let text = raw.trim();
  if (text === '') return {};
  // Plain JSON (hand-written links) first.
  if (text.startsWith('{')) {
    try {
      const v = JSON.parse(text);
      return isObj(v) ? v : {};
    } catch {
      return {};
    }
  }
  text = text.replace(/-/g, '+').replace(/_/g, '/').replace(/\s/g, '');
  while (text.length % 4) text += '=';
  try {
    const decoded = globalThis.atob(text);
    const v = JSON.parse(decoded);
    return isObj(v) ? v : {};
  } catch {
    return {};
  }
}

interface ParsedAction {
  action: string;
  settings: Record<string, unknown>;
}

/** `#elementor-action:action=popup:open&settings=…` (any encoding) -> {action, settings}. */
export function parseActionLink(link: string): ParsedAction | undefined {
  let s = link.replace(/&amp;/gi, '&').replace(/&#0?38;/g, '&');
  // Up to two rounds of URL-decoding (rendered HTML encodes the whole fragment; some builders encode it twice).
  for (let i = 0; i < 2 && /%(3A|3D|26|25|23)/i.test(s); i++) s = safeDecode(s);
  const at = s.toLowerCase().indexOf('#elementor-action:');
  if (at === -1) return undefined;
  const params: Record<string, string> = {};
  for (const part of s.slice(at + '#elementor-action:'.length).split('&')) {
    const eq = part.indexOf('=');
    if (eq <= 0) continue;
    params[part.slice(0, eq).trim().toLowerCase()] = part.slice(eq + 1);
  }
  const action = (params.action ?? '').trim().toLowerCase();
  if (action === '') return undefined;
  return { action, settings: base64Json(safeDecode(params.settings ?? '')) };
}

const yes = (v: unknown): boolean => v === true || v === 'yes' || v === 'true' || v === 1 || v === '1';

/** Builds the Zadex action for a decoded Elementor popup action. Undefined when it is not a popup action. */
function zadexAction(kind: string, id: unknown, doNotShowAgain: unknown, map: PopupMap): PopupLinkResult | undefined {
  if (kind !== 'open' && kind !== 'toggle' && kind !== 'close') return undefined;
  const idText = id === undefined || id === null ? '' : String(id).trim();
  const zid = mapPopupId(idText, map);
  if (kind === 'close') {
    const extra = yes(doNotShowAgain)
      ? ' Its "do not show again" option has no Zadex link equivalent: use the cooldown / "never show again" rules of the Zadex popup.'
      : '';
    return { url: zid ? `#zx-popup:close:${zid}` : '#zx-popup:close', note: `An Elementor popup close link became a Zadex popup close link.${extra}` };
  }
  if (!zid) {
    return {
      url: '#',
      unmapped: true,
      note: idText
        ? `A link to Elementor popup #${idText} became "#": that popup has not been migrated to Zadex yet. Migrate it, then convert this document again.`
        : 'An Elementor popup link without a popup became "#".',
    };
  }
  return { url: `#zx-popup:${kind}:${zid}`, note: `A link to Elementor popup #${idText} now ${kind === 'toggle' ? 'toggles' : 'opens'} the Zadex popup #${zid}.` };
}

function fromParsed(p: ParsedAction, map: PopupMap): PopupLinkResult | undefined {
  if (!p.action.startsWith('popup:')) return undefined;
  let kind = p.action.slice('popup:'.length);
  if (kind === 'open' && yes(p.settings.toggle)) kind = 'toggle';
  return zadexAction(kind, p.settings.id ?? p.settings.popup, p.settings.do_not_show_again, map);
}

/**
 * Rewrites the Elementor popup action link(s) in a url value. Strings without one come back unchanged (no note).
 * The Zadex runtime reads `#zx-popup:…` anywhere in an href, so a prefix (`https://site/page/`) is kept.
 */
export function rewritePopupLink(url: string, ctx?: PopupLinkContext): PopupLinkResult {
  const out = rewritePopupLinksInText(url, ctx);
  return { url: out.text, ...(out.notes.length ? { note: out.notes.join(' ') } : {}), ...(out.unmapped ? { unmapped: true } : {}) };
}

/** Rewrites every Elementor popup action link inside text / HTML (hrefs, pasted URLs). */
export function rewritePopupLinksInText(text: string, ctx?: PopupLinkContext): { text: string; notes: string[]; unmapped: boolean; changed: boolean } {
  const notes: string[] = [];
  let unmapped = false;
  let changed = false;
  if (typeof text !== 'string' || !/(#|%23)elementor-action/i.test(text)) return { text, notes, unmapped, changed };
  const map = mapOf(ctx);
  const result = text.replace(ACTION_RE, (match) => {
    const parsed = parseActionLink(match);
    const r = parsed ? fromParsed(parsed, map) : undefined;
    if (!r) return match;
    changed = true;
    if (r.unmapped) unmapped = true;
    if (r.note && !notes.includes(r.note)) notes.push(r.note);
    return r.url;
  });
  return { text: result, notes, unmapped, changed };
}

/**
 * Elementor Pro `popup` dynamic tag on a url control -> Zadex popup link. Undefined when the shortcode is not a
 * popup tag.
 */
export function popupTagLink(shortcode: unknown, ctx?: PopupLinkContext): PopupLinkResult | undefined {
  const tag = parseDynamicTag(shortcode);
  if (!tag || tag.name !== 'popup') return undefined;
  const s = tag.settings;
  const kind = typeof s.action === 'string' && s.action !== '' ? s.action.toLowerCase() : 'open';
  return zadexAction(kind, s.popup ?? s.id, s.do_not_show_again, mapOf(ctx)) ?? { url: '#', unmapped: true, note: `Elementor popup action "${kind}" has no Zadex equivalent; the link became "#".` };
}

type Json = unknown;

/** Walks a settings value and rewrites popup links in every string. */
function walk(value: Json, ctx: PopupLinkContext, acc: { notes: string[]; unmapped: boolean }): { value: Json; changed: boolean } {
  if (typeof value === 'string') {
    const r = rewritePopupLinksInText(value, ctx);
    if (!r.changed) return { value, changed: false };
    for (const n of r.notes) if (!acc.notes.includes(n)) acc.notes.push(n);
    if (r.unmapped) acc.unmapped = true;
    return { value: r.text, changed: true };
  }
  if (Array.isArray(value)) {
    let changed = false;
    const out = value.map((v) => {
      const r = walk(v, ctx, acc);
      if (r.changed) changed = true;
      return r.value;
    });
    return changed ? { value: out, changed } : { value, changed: false };
  }
  if (isObj(value)) {
    let changed = false;
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      const r = walk(v, ctx, acc);
      if (r.changed) changed = true;
      out[k] = r.value;
    }
    return changed ? { value: out, changed } : { value, changed: false };
  }
  return { value, changed: false };
}

/**
 * Post-processing pass over a finished Zadex document: every string setting holding an Elementor popup action
 * link (url objects of any widget, text-editor / html content, repeater items) is rewritten. Notes go to the
 * report entry that produced the element (else to `docNote`); an unmapped link turns a "converted" entry into
 * "partial".
 */
export function rewriteDocumentPopupLinks(elements: ZElement[], ctx: PopupLinkContext, entries: ReportEntry[], docNote: (text: string) => void): void {
  if (!/(#|%23)elementor-action/i.test(JSON.stringify(elements))) return;
  const visit = (list: ZElement[]): void => {
    for (const el of list) {
      const acc = { notes: [] as string[], unmapped: false };
      const r = walk(el.settings, ctx, acc);
      if (r.changed) {
        el.settings = r.value as ZElement['settings'];
        const entry = entries.find((e) => e.target.includes(el.id));
        if (entry) {
          for (const n of acc.notes) if (!entry.notes.includes(n)) entry.notes.push(n);
          if (acc.unmapped && entry.status === 'converted') entry.status = 'partial';
        } else acc.notes.forEach(docNote);
      }
      if (Array.isArray(el.children) && el.children.length) visit(el.children);
    }
  };
  visit(elements);
}
