import { makeKey } from '@zadex/editor/core/settings';
import type { BreakpointKey, ElSettings, GlobalSettings, Settings } from './types';
import { DEVICE_SUFFIXES, VIEWPORT_KEYS, deviceKeys } from './responsive';
import { bool, dimensions, isBlank, num, parseGlobalRef, slider, type Slider } from './values';
import { zadexGlobalId } from './globals';

/**
 * Elementor kit (site settings) -> Zadex global settings + breakpoints.
 *
 * - Global colors / typography (system + custom) become Zadex global colors / fonts with the ids `zadexGlobalId()`
 *   gives, so element references (`colorRef` / `fontRef`) resolve to `var(--zx-color-<id>)` / `var(--zx-font-<id>)`.
 *   They are MERGED into the current Zadex globals (same id replaced, others kept).
 * - Layout: `container_width` -> `layout.contentWidth`, `space_between_widgets` -> `layout.gap`,
 *   `container_padding` (only when set) -> `layout.containerPadding`, lightbox colors/options -> `layout.lightbox`.
 * - Breakpoints: `viewport_*` + `active_breakpoints` -> Zadex breakpoint config (same widths and semantics).
 * - Theme style (body, links, headings, buttons, form fields, images) -> `themeStyle` (Zadex theme style controls,
 *   `src/editor/core/themeStyleControls.ts`), merged over the current values.
 * Whatever has no Zadex equivalent is listed in `report.notes` / `report.dropped`.
 */

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

export type BreakpointConfig = Record<BreakpointKey, { value: number; enabled: boolean }>;
export type CurrentBreakpoints = Partial<Record<BreakpointKey, { value?: number; enabled?: boolean }>>;

export interface KitReport {
  notes: string[];
  /** Global colors imported. */
  colors: number;
  /** Global fonts imported. */
  fonts: number;
  /** Kit setting keys holding a value that could not be carried over. */
  dropped: string[];
}

export interface KitResult {
  global: GlobalSettings;
  breakpoints: BreakpointConfig;
  report: KitReport;
}

/** Elementor's kit control defaults that matter when the kit does not store a value (Elementor 4.4 kit controls). */
export const KIT_DEFAULTS: ElSettings = {
  system_colors: [
    { _id: 'primary', title: 'Primary', color: '#6EC1E4' },
    { _id: 'secondary', title: 'Secondary', color: '#54595F' },
    { _id: 'text', title: 'Text', color: '#7A7A7A' },
    { _id: 'accent', title: 'Accent', color: '#61CE70' },
  ],
  system_typography: [
    { _id: 'primary', title: 'Primary', typography_typography: 'custom', typography_font_family: 'Roboto', typography_font_weight: '600' },
    { _id: 'secondary', title: 'Secondary', typography_typography: 'custom', typography_font_family: 'Roboto Slab', typography_font_weight: '400' },
    { _id: 'text', title: 'Text', typography_typography: 'custom', typography_font_family: 'Roboto', typography_font_weight: '400' },
    { _id: 'accent', title: 'Accent', typography_typography: 'custom', typography_font_family: 'Roboto', typography_font_weight: '500' },
  ],
  container_width: { unit: 'px', size: 1140, sizes: [] },
  space_between_widgets: { column: '20', row: '20', isLinked: true, unit: 'px' },
  active_breakpoints: ['viewport_mobile', 'viewport_tablet'],
  lightbox_enable_counter: 'yes',
  lightbox_enable_zoom: 'yes',
  lightbox_title_src: 'title',
  lightbox_description_src: 'description',
};

/** Elementor default viewport widths (identical to Zadex's default breakpoint values). */
const VIEWPORT_DEFAULTS: Record<string, number> = {
  mobile: 767,
  mobile_large: 880,
  tablet: 1024,
  tablet_large: 1200,
  laptop: 1366,
  widescreen: 2400,
};

/** Kit keys that are not design settings (or are handled by other parts of the migrator). Never reported. */
const IGNORED = new Set([
  'template',
  'post_title',
  'post_status',
  'site_name',
  'site_description',
  'site_logo',
  'site_favicon',
  'default_generic_fonts',
  'page_title_selector',
  'default_page_template',
  'stretched_section_container',
  'colors_enable_styleguide_preview',
  'typography_enable_styleguide_preview',
  'global_image_lightbox',
  'viewport_md',
  'viewport_lg',
  '__globals__',
  '__dynamic__',
]);

/** Elementor defaults with no Zadex counterpart: not reported when the kit just holds the default. */
const UNSUPPORTED_DEFAULTS: Record<string, unknown> = {
  lightbox_enable_fullscreen: 'yes',
  lightbox_enable_share: 'yes',
  body_overscroll_behavior: '',
};

/** Families every browser has (no download needed). */
const WEB_SAFE = new Set(['arial', 'helvetica', 'georgia', 'times new roman', 'times', 'verdana', 'tahoma', 'trebuchet ms', 'courier new', 'courier', 'system-ui', 'sans-serif', 'serif', 'monospace', 'inherit']);

const TYPO_PARTS = ['font_family', 'font_size', 'font_weight', 'text_transform', 'font_style', 'text_decoration', 'line_height', 'letter_spacing', 'word_spacing'];

export function convertKit(kit: ElSettings, current: GlobalSettings, currentBreakpoints?: CurrentBreakpoints): KitResult {
  return new KitConverter(kit ?? {}, current, currentBreakpoints).run();
}

class KitConverter {
  private consumed = new Set<string>();
  private consumedPrefixes: string[] = [];
  private notes: string[] = [];
  private theme: Settings = {};
  private colors: GlobalSettings['colors'] = [];
  private fonts: GlobalSettings['fonts'] = [];

  constructor(
    private readonly kit: ElSettings,
    private readonly current: GlobalSettings,
    private readonly currentBreakpoints?: CurrentBreakpoints,
  ) {}

  run(): KitResult {
    const colorsIn = this.globalColors();
    const fontsIn = this.globalFonts();
    this.colors = mergeById(this.current.colors ?? [], colorsIn);
    this.fonts = mergeById(this.current.fonts ?? [], fontsIn);
    const layout = this.layout();
    const breakpoints = this.breakpoints();
    this.themeStyle();
    if (Object.keys(this.theme).length) this.note('Theme style (body, headings, links, buttons, form fields, images) applies to Zadex pages.');

    const global: GlobalSettings = {
      ...this.current,
      colors: this.colors,
      fonts: this.fonts,
      spacing: this.current.spacing ?? [],
      classes: this.current.classes ?? [],
      themeStyle: { ...asObject(this.current.themeStyle), ...this.theme },
      layout,
    };
    const dropped = this.dropped();
    if (dropped.length) this.note(`Kit settings not carried over: ${dropped.join(', ')}.`);
    return { global, breakpoints, report: { notes: this.notes, colors: colorsIn.length, fonts: fontsIn.length, dropped } };
  }

  /* ---- reading ---- */

  private get(key: string): unknown {
    this.consumed.add(key);
    if (Object.prototype.hasOwnProperty.call(this.kit, key) && !isBlank(this.kit[key])) return this.kit[key];
    return KIT_DEFAULTS[key] ?? this.kit[key];
  }

  private raw(key: string): unknown {
    this.consumed.add(key);
    return this.kit[key];
  }

  private stored(key: string): boolean {
    return Object.prototype.hasOwnProperty.call(this.kit, key);
  }

  private consumePrefix(prefix: string): void {
    this.consumedPrefixes.push(prefix);
  }

  private globalRef(key: string): { kind: string; id: string } | undefined {
    const g = this.kit.__globals__;
    return isObj(g) ? parseGlobalRef(g[key]) : undefined;
  }

  private note(text: string): void {
    if (!this.notes.includes(text)) this.notes.push(text);
  }

  private set(id: string, value: unknown, bp?: BreakpointKey): void {
    if (value === undefined) return;
    this.theme[makeKey(id, { bp })] = value;
  }

  /* ---- globals ---- */

  private presets(key: 'system_colors' | 'custom_colors' | 'system_typography' | 'custom_typography'): Obj[] {
    const list = this.get(key);
    return Array.isArray(list) ? list.filter(isObj) : [];
  }

  private globalColors(): GlobalSettings['colors'] {
    const out: GlobalSettings['colors'] = [];
    for (const item of [...this.presets('system_colors'), ...this.presets('custom_colors')]) {
      const id = typeof item._id === 'string' ? item._id : '';
      const color = typeof item.color === 'string' ? item.color.trim() : '';
      if (!id) continue;
      if (!color) {
        this.note(`Global color "${titleOf(item, id)}" has no value and was skipped.`);
        continue;
      }
      upsert(out, { id: zadexGlobalId(id), label: titleOf(item, id), value: color });
    }
    return out;
  }

  private globalFonts(): GlobalSettings['fonts'] {
    const out: GlobalSettings['fonts'] = [];
    const bare: string[] = [];
    // Elementor prints every kit font with the kit's generic fallback (`default_generic_fonts`, default Sans-serif):
    // `font-family: "Roboto", Sans-serif`. Zadex keeps a family stack as is, so the fallback is carried over and a
    // font that is not installed falls back to the same generic family instead of the browser's serif (V7).
    const genericRaw = this.get('default_generic_fonts');
    const generic = typeof genericRaw === 'string' ? genericRaw.replace(/[^A-Za-z0-9 _-]/g, '').trim() : 'Sans-serif';
    let sized = false;
    for (const item of [...this.presets('system_typography'), ...this.presets('custom_typography')]) {
      const id = typeof item._id === 'string' ? item._id : '';
      if (!id) continue;
      const family = typeof item.typography_font_family === 'string' ? item.typography_font_family.trim() : '';
      const weight = item.typography_font_weight;
      for (const [k, v] of Object.entries(item)) {
        if (!k.startsWith('typography_') || k === 'typography_typography' || k === 'typography_font_family') continue;
        if (k === 'typography_font_weight') continue;
        if (meaningful(v)) sized = true;
      }
      if (!family) {
        this.note(`Global typography "${titleOf(item, id)}" has no font family; elements using it keep their sizes and weights but no Zadex global font is created.`);
        continue;
      }
      bare.push(family);
      const stacked = family.includes(',') || !generic ? family : `${/\s/.test(family) && !/^["']/.test(family) ? `"${family}"` : family}, ${generic}`;
      const value: { family: string; weight?: string } = { family: stacked };
      if (!isBlank(weight)) value.weight = String(weight);
      upsert(out, { id: zadexGlobalId(id), label: titleOf(item, id), value });
    }
    if (sized) {
      this.note('Zadex global fonts hold the family and weight only: sizes, line heights and spacing of Elementor global typography are written on every element that uses them.');
    }
    // Elementor loads Google Fonts itself; Zadex never loads remote fonts, so these fall back to the theme font.
    const remote = [...new Set(bare)].filter((f) => !WEB_SAFE.has(f.toLowerCase()));
    if (remote.length) {
      this.note(`Elementor loads these fonts from Google Fonts: ${remote.join(', ')}. Zadex does not load remote fonts: add them in Zadex → Custom Fonts (or through your theme), otherwise the theme font is shown.`);
    }
    return out;
  }

  /** Value for a `globals/colors?id=` reference: Zadex variable when the color exists, else the kit literal. */
  private colorRef(elementorId: string): string | undefined {
    const id = zadexGlobalId(elementorId);
    if (this.colors.some((c) => c.id === id)) return `var(--zx-color-${id})`;
    for (const item of [...this.presets('system_colors'), ...this.presets('custom_colors')]) {
      if (item._id === elementorId && typeof item.color === 'string' && item.color) return item.color;
    }
    return undefined;
  }

  private typographyPreset(elementorId: string): Obj | undefined {
    return [...this.presets('system_typography'), ...this.presets('custom_typography')].find((t) => t._id === elementorId);
  }

  /* ---- layout ---- */

  private layout(): GlobalSettings['layout'] {
    const layout: GlobalSettings['layout'] = { ...asObject(this.current.layout) };

    const width = slider(this.get('container_width'));
    if (width) layout.contentWidth = width;
    this.noteDevices('container_width', 'Content width');

    const padding = dimensions(this.raw('container_padding'));
    if (padding) layout.containerPadding = padding;
    this.noteDevices('container_padding', 'Container padding');

    const gap = this.gap();
    if (gap) layout.gap = gap;
    this.noteDevices('space_between_widgets', 'Widgets space');
    this.noteDevices('widgets_space', 'Widgets space');

    const lightbox = this.lightbox();
    if (lightbox) layout.lightbox = { ...(isObj(layout.lightbox) ? layout.lightbox : {}), ...lightbox };
    return layout;
  }

  /** `space_between_widgets` (gaps `{row, column, unit}` since Elementor 3.x, slider before) or legacy `widgets_space`. */
  private gap(): Slider | undefined {
    const legacy = this.raw('widgets_space');
    const v = this.stored('space_between_widgets') || isBlank(legacy) ? this.get('space_between_widgets') : legacy;
    if (isObj(v) && ('row' in v || 'column' in v)) {
      const unit = typeof v.unit === 'string' && v.unit ? v.unit : 'px';
      const row = num(v.row);
      const column = num(v.column);
      const size = row ?? column;
      if (size === undefined) return undefined;
      if (row !== undefined && column !== undefined && row !== column) {
        this.note(`Widgets space: Zadex uses one gap for rows and columns; the row value (${row}${unit}) was kept, the column value (${column}${unit}) was not.`);
      }
      return { size, unit };
    }
    return slider(v);
  }

  private lightbox(): Obj | undefined {
    const keys = ['lightbox_color', 'lightbox_ui_color', 'lightbox_enable_counter', 'lightbox_enable_zoom', 'lightbox_title_src', 'lightbox_description_src'];
    const touched = keys.some((k) => this.stored(k));
    const out: Obj = {};
    const bg = this.raw('lightbox_color');
    const ui = this.raw('lightbox_ui_color');
    const counter = this.get('lightbox_enable_counter');
    const zoom = this.get('lightbox_enable_zoom');
    const title = this.get('lightbox_title_src');
    const desc = this.get('lightbox_description_src');
    if (!touched) return undefined;
    if (typeof bg === 'string' && bg) out.bg = bg;
    if (typeof ui === 'string' && ui) out.color = ui;
    out.counter = bool(counter);
    out.zoom = bool(zoom);
    out.captions = !(isBlank(title) && isBlank(desc));
    return out;
  }

  private noteDevices(base: string, label: string): void {
    for (const [key, bp] of deviceKeys(base)) {
      if (!bp) continue;
      this.consumed.add(key);
      if (meaningful(this.kit[key])) this.note(`${label} per device (${bp}) has no Zadex equivalent: the desktop value applies to every device.`);
    }
  }

  /* ---- breakpoints ---- */

  private breakpoints(): BreakpointConfig {
    const activeRaw = this.get('active_breakpoints');
    const active = new Set(Array.isArray(activeRaw) ? activeRaw.map(String) : []);
    const md = num(this.raw('viewport_md'));
    const lg = num(this.raw('viewport_lg'));
    const out = { desktop: { value: 0, enabled: true } } as BreakpointConfig;
    for (const [vk, bp] of Object.entries(VIEWPORT_KEYS)) {
      let value = num(this.raw(vk));
      // Elementor < 3.2 stored the first pixel of the next device (`viewport_md` = mobile max + 1).
      if (value === undefined && bp === 'mobile' && typeof md === 'number') value = md - 1;
      if (value === undefined && bp === 'tablet' && typeof lg === 'number') value = lg - 1;
      const v = typeof value === 'number' ? Math.round(Math.max(200, Math.min(6000, value))) : VIEWPORT_DEFAULTS[bp];
      out[bp] = { value: v, enabled: active.has(vk) };
      const cur = this.currentBreakpoints?.[bp];
      if (cur && cur.enabled && typeof cur.value === 'number' && (cur.value !== v || !active.has(vk))) {
        this.note(`Breakpoint ${bp}: ${cur.value}px (on) becomes ${v}px (${active.has(vk) ? 'on' : 'off'}) to match Elementor.`);
      }
    }
    return out;
  }

  /* ---- theme style ---- */

  private themeStyle(): void {
    // Body
    this.color('body_color', 'body_color');
    this.typography('body_typography', 'body_typography');
    this.background('body_background', 'body_background');
    this.responsive('paragraph_spacing', 'p_margin', (v) => {
      const s = slider(v);
      return s ? { top: '', right: '', bottom: s.size, left: '', unit: s.unit, linked: false } : undefined;
    });

    // Headings
    for (const tag of ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']) {
      this.color(`${tag}_color`, `${tag}_color`);
      this.typography(`${tag}_typography`, `${tag}_typography`);
    }

    // Links
    this.color('link_normal_color', 'link_color');
    this.color('link_hover_color', 'link_color_hover');
    this.decoration('link_normal_typography', 'link_decoration');
    this.decoration('link_hover_typography', 'link_decoration_hover');

    // Buttons
    this.typography('button_typography', 'button_typography');
    this.color('button_text_color', 'button_color');
    this.color('button_hover_text_color', 'button_color_hover');
    this.background('button_background', 'button_background', true);
    this.background('button_hover_background', 'button_background_hover', true);
    this.responsive('button_padding', 'button_padding', (v) => dimensions(v));
    this.border('button_border', 'button_border');
    this.color('button_hover_border_color', 'button_border_color_hover');

    // Form fields
    this.color('form_field_text_color', 'field_color');
    this.color('form_field_background_color', 'field_background');
    this.border('form_field_border', 'field_border');
    this.responsive('form_field_padding', 'field_padding', (v) => dimensions(v));
    this.color('form_field_focus_border_color', 'field_border_color_focus');
    this.color('form_field_focus_background_color', 'field_background_focus');

    // Images
    this.responsive('image_border_radius', 'image_radius', (v) => dimensions(v));
    this.opacity('image_opacity', 'image_opacity');
    this.opacity('image_hover_opacity', 'image_opacity_hover');
    const transition = slider(this.raw('image_hover_transition'));
    if (transition) this.set('image_transition', { size: transition.size, unit: 'custom' });
  }

  /** Copies every device variant of `src` (`src`, `src_tablet`, …) to `dst`, `dst@tablet`, … */
  private responsive(src: string, dst: string, convert: (v: unknown) => unknown): void {
    for (const [key, bp] of deviceKeys(src)) {
      const v = this.raw(key);
      if (!meaningful(v)) continue;
      this.set(dst, convert(v), bp);
    }
  }

  private color(src: string, dst: string): void {
    for (const [key, bp] of deviceKeys(src)) {
      const ref = this.globalRef(key);
      if (ref && ref.kind === 'colors') {
        this.consumed.add(`__globals__.${key}`);
        this.consumed.add(key);
        const value = this.colorRef(ref.id);
        if (value) this.set(dst, value, bp);
        else this.note(`Global color "${ref.id}" used by ${key} was not found.`);
        continue;
      }
      const v = this.raw(key);
      if (typeof v === 'string' && v.trim() !== '') this.set(dst, v.trim(), bp);
    }
  }

  /** Elementor typography group (`<prefix>_typography: custom` + `<prefix>_font_*`) or a global typography reference. */
  private typography(prefix: string, dst: string): void {
    this.consumePrefix(`${prefix}_`);
    const ref = this.globalRef(`${prefix}_typography`);
    let src: ElSettings = this.kit;
    let p = prefix;
    let family: string | undefined;
    if (ref && ref.kind === 'typography') {
      this.consumed.add(`__globals__.${prefix}_typography`);
      const preset = this.typographyPreset(ref.id);
      if (!preset) {
        this.note(`Global typography "${ref.id}" used by ${prefix} was not found.`);
        return;
      }
      src = { ...preset };
      for (const [k, v] of Object.entries(this.kit)) {
        if (k.startsWith(`${prefix}_`) && k !== `${prefix}_typography` && meaningful(v)) src[`typography_${k.slice(prefix.length + 1)}`] = v;
      }
      p = 'typography';
      const id = zadexGlobalId(ref.id);
      if (this.fonts.some((f) => f.id === id)) family = `var(--zx-font-${id})`;
    } else if (this.kit[`${prefix}_typography`] !== 'custom') {
      return;
    }
    for (const { suffix, bp } of DEVICE_SUFFIXES) {
      const t: Obj = {};
      const s = (name: string): unknown => src[`${p}_${name}${suffix}`];
      if (!bp) {
        const fam = family ?? (typeof s('font_family') === 'string' && s('font_family') !== '' ? s('font_family') : undefined);
        if (fam) t.family = fam;
      }
      const size = slider(s('font_size'));
      if (size) t.size = size;
      const weight = s('font_weight');
      if (!isBlank(weight)) t.weight = String(weight);
      for (const [from, to] of [['text_transform', 'transform'], ['font_style', 'style'], ['text_decoration', 'decoration']] as const) {
        const v = s(from);
        if (!isBlank(v)) t[to] = String(v);
      }
      const lh = slider(s('line_height'), 'custom');
      if (lh) t.lineHeight = lh.unit === 'em' && typeof lh.size === 'number' ? { size: lh.size, unit: 'custom' } : lh;
      const ls = slider(s('letter_spacing'));
      if (ls) t.letterSpacing = ls;
      const ws = slider(s('word_spacing'));
      if (ws) t.wordSpacing = ws;
      if (Object.keys(t).length) this.set(dst, t, bp);
    }
  }

  /** Only the text decoration of a link typography group fits Zadex (`link_decoration` select: none|underline). */
  private decoration(prefix: string, dst: string): void {
    if (this.kit[`${prefix}_typography`] !== 'custom') return;
    const key = `${prefix}_text_decoration`;
    const v = this.raw(key);
    if (v === 'none' || v === 'underline') this.set(dst, v);
    const rest = TYPO_PARTS.filter((part) => part !== 'text_decoration').some((part) => deviceKeys(`${prefix}_${part}`).some(([k]) => meaningful(this.kit[k])));
    this.consumed.add(`${prefix}_typography`);
    if (rest) {
      this.consumePrefix(`${prefix}_`);
      this.note(`Link typography (${prefix.replace('_typography', '')}) other than the text decoration has no Zadex theme style equivalent.`);
    }
  }

  /** Elementor background group; `colorOnly` targets a Zadex color control (buttons). */
  private background(prefix: string, dst: string, colorOnly = false): void {
    this.consumePrefix(`${prefix}_`);
    const type = this.kit[`${prefix}_background`];
    const colorKey = `${prefix}_color`;
    const ref = this.globalRef(colorKey);
    if (ref) this.consumed.add(`__globals__.${colorKey}`);
    const color = ref?.kind === 'colors' ? this.colorRef(ref.id) : typeof this.kit[colorKey] === 'string' && this.kit[colorKey] !== '' ? (this.kit[colorKey] as string) : undefined;
    if (type === 'gradient') {
      const stops = [
        { color: color ?? '', position: positionOf(this.kit[`${prefix}_color_stop`], 0) },
        { color: this.gradientColorB(prefix), position: positionOf(this.kit[`${prefix}_color_b_stop`], 100) },
      ];
      if (colorOnly) {
        if (color) this.set(dst, color);
        this.note(`Gradient background (${prefix}) has no Zadex theme style equivalent: the first color was kept.`);
        return;
      }
      const angle = slider(this.kit[`${prefix}_gradient_angle`]);
      const gtype = this.kit[`${prefix}_gradient_type`] === 'radial' ? 'radial' : 'linear';
      if (gtype === 'radial' && !isBlank(this.kit[`${prefix}_gradient_position`]) && this.kit[`${prefix}_gradient_position`] !== 'center center') {
        this.note(`Radial gradient position (${prefix}) is not supported: the gradient is centred.`);
      }
      this.set(dst, { type: 'gradient', gradient: { type: gtype, angle: typeof angle?.size === 'number' ? angle.size : 180, stops } });
      return;
    }
    if (type === 'video' || type === 'slideshow') {
      this.note(`${type === 'video' ? 'Video' : 'Slideshow'} background (${prefix}) has no Zadex theme style equivalent.`);
      if (color && colorOnly) this.set(dst, color);
      return;
    }
    if (colorOnly) {
      if (color) this.set(dst, color);
      const image = this.kit[`${prefix}_image`];
      if (isObj(image) && typeof image.url === 'string' && image.url) this.note(`Background image (${prefix}) has no Zadex theme style equivalent.`);
      return;
    }
    const bg: Obj = { type: 'classic' };
    if (color) bg.color = color;
    const image = this.kit[`${prefix}_image`];
    if (isObj(image) && typeof image.url === 'string' && image.url) {
      bg.image = { id: Number(image.id) || 0, url: image.url, alt: '' };
      for (const [from, to] of [['position', 'position'], ['size', 'size'], ['repeat', 'repeat'], ['attachment', 'attachment']] as const) {
        const v = this.kit[`${prefix}_${from}`];
        if (typeof v === 'string' && v !== '' && v !== 'initial' && v !== 'default') bg[to] = v;
        else if (v === 'initial') this.note(`Custom background ${from} (${prefix}) is not supported.`);
      }
    }
    if (bg.color || bg.image) this.set(dst, bg);
  }

  private gradientColorB(prefix: string): string {
    const key = `${prefix}_color_b`;
    const ref = this.globalRef(key);
    if (ref?.kind === 'colors') {
      this.consumed.add(`__globals__.${key}`);
      return this.colorRef(ref.id) ?? '';
    }
    const v = this.kit[key];
    return typeof v === 'string' && v ? v : '#f2295b';
  }

  /** Elementor border group: `<p>_border` (style), `<p>_width`, `<p>_color`, `<p>_radius`. */
  private border(p: string, dst: string): void {
    const style = this.raw(`${p}_border`);
    const colorKey = `${p}_color`;
    const ref = this.globalRef(colorKey);
    let color: unknown = this.raw(colorKey);
    if (ref?.kind === 'colors') {
      this.consumed.add(`__globals__.${colorKey}`);
      color = this.colorRef(ref.id);
    }
    const hasStyle = typeof style === 'string' && style !== '' && style !== 'none';
    for (const { suffix, bp } of DEVICE_SUFFIXES) {
      const b: Obj = {};
      if (!bp && hasStyle) b.style = style;
      if (!bp && style === 'none') b.style = 'none';
      const width = dimensions(this.raw(`${p}_width${suffix}`));
      if (width && hasStyle) b.width = width;
      if (!bp && hasStyle && typeof color === 'string' && color !== '') b.color = color;
      const radius = dimensions(this.raw(`${p}_radius${suffix}`));
      if (radius) b.radius = radius;
      if (Object.keys(b).length) this.set(dst, b, bp);
    }
  }

  private opacity(src: string, dst: string): void {
    const s = slider(this.raw(src));
    if (s && typeof s.size === 'number') this.set(dst, { size: s.size, unit: 'custom' });
  }

  /* ---- report ---- */

  private dropped(): string[] {
    const out: string[] = [];
    for (const [key, value] of Object.entries(this.kit)) {
      if (IGNORED.has(key) || this.consumed.has(key)) continue;
      if (this.consumedPrefixes.some((p) => key.startsWith(p))) continue;
      if (!meaningful(value)) continue;
      if (!this.gateOpen(key)) continue;
      if (key in UNSUPPORTED_DEFAULTS && UNSUPPORTED_DEFAULTS[key] === value) continue;
      out.push(key);
    }
    const globals = this.kit.__globals__;
    if (isObj(globals)) {
      for (const [key, ref] of Object.entries(globals)) {
        if (!isBlank(ref) && !this.consumed.has(`__globals__.${key}`)) out.push(`__globals__.${key}`);
      }
    }
    return out;
  }

  /** Sub-keys of popover groups (shadows, css filters, typography) only count when the group is switched on. */
  private gateOpen(key: string): boolean {
    const shadow = key.match(/^(.+)_(box_shadow|text_shadow)(_position)?$/);
    if (shadow && !key.endsWith('_type')) return meaningful(this.kit[`${shadow[1]}_${shadow[2]}_type`]);
    const filters = key.indexOf('_css_filters_');
    if (filters > 0 && !key.endsWith('_css_filter')) return meaningful(this.kit[`${key.slice(0, filters)}_css_filters_css_filter`]);
    const typo = key.indexOf('_typography_');
    if (typo > 0 && !key.endsWith('_typography_typography')) return meaningful(this.kit[`${key.slice(0, typo)}_typography_typography`]);
    return true;
  }
}

/** True for values that hold something: not blank, not an empty slider / dimensions / media, not a blank select. */
function meaningful(v: unknown): boolean {
  if (isBlank(v)) return false;
  if (typeof v === 'string') return v.trim() !== '';
  if (isObj(v)) {
    if ('size' in v && 'unit' in v) return !isBlank(v.size);
    if ('top' in v || 'bottom' in v) return ['top', 'right', 'bottom', 'left'].some((s) => !isBlank(v[s]));
    if ('url' in v && 'id' in v) return !isBlank(v.url);
  }
  return true;
}

function positionOf(v: unknown, fallback: number): number {
  const s = slider(v, '%');
  return s && typeof s.size === 'number' ? s.size : fallback;
}

function titleOf(item: Obj, id: string): string {
  return typeof item.title === 'string' && item.title.trim() !== '' ? item.title.trim() : id;
}

function upsert<T extends { id: string }>(list: T[], item: T): void {
  const i = list.findIndex((x) => x.id === item.id);
  if (i >= 0) list[i] = item;
  else list.push(item);
}

/** Current items with the same id replaced in place, new ones appended. */
function mergeById<T extends { id: string }>(current: T[], incoming: T[]): T[] {
  const out = Array.isArray(current) ? current.map((x) => ({ ...x })) : [];
  for (const item of incoming) upsert(out, item);
  return out;
}

/** PHP encodes an empty object as `[]`. */
function asObject(v: unknown): Obj {
  return isObj(v) ? v : {};
}

