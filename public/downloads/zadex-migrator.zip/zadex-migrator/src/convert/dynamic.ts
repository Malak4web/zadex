/**
 * Elementor dynamic tags -> Zadex dynamic values.
 *
 * Elementor stores a dynamic binding in `settings.__dynamic__[<control>]` as a shortcode:
 *   [elementor-tag id="5b2c0a1" name="post-title" settings="%7B%22before%22%3A%22Hi%20%22%7D"]
 * where `settings` is the URL-encoded JSON of the tag's settings (PHP `urlencode(wp_json_encode())` turns spaces
 * into `+`; the editor uses `encodeURIComponent`). Text tags keep `before` / `after` / `fallback` in the same
 * settings ("Advanced" section of the tag); image tags keep `fallback` as a media object `{id, url}`.
 *
 * Zadex stores `{"__dynamic": {tag, settings, before, after, fallback}}` (`../plugin zadex/src/editor/core/dynamic.ts`,
 * tag names / settings from `includes/Dynamic/Tags/*.php`). Elementor Pro tag names, settings keys, options and
 * defaults are verified against Elementor Pro 3.33.2 (`modules/dynamic-tags/{tags,acf/tags,pods/tags,toolset/tags}`).
 * The editor stores only changed tag settings, so Pro's defaults are applied here (e.g. `post-terms` taxonomy
 * `post_tag`, `comments-number` texts "No Responses" / "One Response" / "{number} Responses"). Unknown names and
 * Pro tags without a Zadex equivalent (`archive-url`, `archive-meta`, `author-meta`, `comments-url`,
 * `contact-url`, `internal-url`, `lightbox`, `reload-page`, `shortcode`, `post-gallery`, `acf-gallery`, …)
 * return undefined so callers keep the static value and note it.
 *
 * Pure, never throws.
 */

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Category of the Zadex control receiving the value (Zadex `DYNAMIC_CONTROL_CATEGORIES`). */
export type DynamicCategory = 'text' | 'url' | 'image';

export interface ZDynamicData {
  tag: string;
  settings: Obj;
  before: string;
  after: string;
  fallback: string;
}

export interface ZDynamicValue {
  __dynamic: ZDynamicData;
}

export interface ParsedTag {
  id: string;
  name: string;
  settings: Obj;
}

/** Parses one `[elementor-tag …]` shortcode. Undefined when the string is not a tag shortcode. */
export function parseDynamicTag(shortcode: unknown): ParsedTag | undefined {
  if (typeof shortcode !== 'string') return undefined;
  const m = shortcode.match(/\[elementor-tag\s+([^\]]*)\]/);
  if (!m) return undefined;
  const attrs: Record<string, string> = {};
  for (const a of m[1].matchAll(/([a-z_-]+)="([^"]*)"/gi)) attrs[a[1].toLowerCase()] = a[2];
  if (!attrs.name) return undefined;
  return { id: attrs.id ?? '', name: attrs.name, settings: decodeSettings(attrs.settings) };
}

function decodeSettings(raw: string | undefined): Obj {
  if (!raw) return {};
  let text = raw;
  try {
    text = decodeURIComponent(raw.replace(/\+/g, ' '));
  } catch {
    // Malformed escape sequence: try the raw string as JSON.
  }
  try {
    const v = JSON.parse(text);
    return isObj(v) ? v : {};
  } catch {
    return {};
  }
}

interface Mapped {
  tag: string;
  settings?: Obj;
  note?: string;
}

const str = (v: unknown): string => (typeof v === 'string' || typeof v === 'number' ? String(v) : '');
const yes = (v: unknown): boolean => v === 'yes' || v === true;

/** Elementor date presets (`post-date` `format`, `current-date-time` `date_format`) -> PHP date format ('' = site setting). */
function dateFormat(format: unknown, custom: unknown): string {
  const f = str(format);
  if (f === '' || f === 'default') return '';
  if (f === 'custom') return str(custom);
  if (f === 'human') return '';
  return f; // 'F j, Y', 'Y-m-d', 'm/d/Y', 'd/m/Y' are stored as the PHP format itself.
}

/** Last `:`-separated segment: ACF keys are `field_abc123:field_name`, Pods / Toolset `group:field`. */
function fieldName(key: unknown): string {
  const k = str(key).trim();
  const parts = k.split(':').filter(Boolean);
  return parts.length ? parts[parts.length - 1] : '';
}

function pluginField(tag: 'acf' | 'pods' | 'toolset', label: string, s: Obj): Mapped | undefined {
  const key = fieldName(s.key);
  if (!key) return undefined;
  return { tag, settings: { key }, note: `The ${label} field "${key}" only resolves while ${label} is active.` };
}

interface Rule {
  cats: DynamicCategory[];
  map: (s: Obj, cat: DynamicCategory) => Mapped | undefined;
}

const ALL: DynamicCategory[] = ['text', 'url', 'image'];

const RULES: Record<string, Rule> = {
  'post-title': { cats: ['text'], map: () => ({ tag: 'post-title' }) },
  'page-title': {
    cats: ['text'],
    map: (s) => ({
      tag: 'post-title',
      note: yes(s.include_context) || yes(s.show_home_title) ? 'Page title tag: the archive context / home title options are not carried over (the post title is used).' : undefined,
    }),
  },
  'post-excerpt': {
    cats: ['text'],
    map: (s) => {
      const n = Number(s.max_length);
      return { tag: 'post-excerpt', settings: str(s.max_length) !== '' && Number.isFinite(n) ? { length: n } : {} };
    },
  },
  'post-date': {
    cats: ['text'],
    map: (s) => ({
      tag: 'post-date',
      settings: { type: /modified/.test(str(s.type)) ? 'modified' : 'published', format: dateFormat(s.format, s.custom_format) },
      note: s.format === 'human' ? 'Post date "human" format (time ago) is not available; the site date format is used.' : undefined,
    }),
  },
  'post-time': {
    cats: ['text'],
    map: (s) => {
      // Pro keys: `type` post_date_gmt | post_modified_gmt, `format` default | g:i a | g:i A | H:i | custom (+ custom_format).
      const f = str(s.format);
      const site = f === '' || f === 'default';
      // Zadex post-date has no time mode: an explicit PHP time format gives the same output.
      const format = f === 'custom' ? str(s.custom_format) : site ? 'g:i a' : f;
      return {
        tag: 'post-date',
        settings: { type: /modified/.test(str(s.type)) ? 'modified' : 'published', format },
        note: site ? 'Post time: the site\'s default time format was replaced by "g:i a".' : undefined,
      };
    },
  },
  'post-url': { cats: ['url', 'text'], map: () => ({ tag: 'post-url' }) },
  'post-id': { cats: ['text'], map: () => ({ tag: 'post-id' }) },
  'post-terms': {
    cats: ['text'],
    map: (s) => ({
      tag: 'post-terms',
      settings: { taxonomy: str(s.taxonomy) || 'post_tag', separator: s.separator === undefined ? ', ' : str(s.separator), link: s.link === undefined ? true : yes(s.link) },
    }),
  },
  'comments-number': {
    cats: ['text'],
    // Pro prints `format_no_comments` / `format_one_comments` / `format_many_comments` (defaults "No Responses",
    // "One Response", "{number} Responses"), optionally linked (`link_to` comments_link). Zadex prints the number.
    map: (s) => {
      const many = s.format_many_comments === undefined ? '{number} Responses' : str(s.format_many_comments);
      const plain = many.trim() === '{number}' && str(s.format_no_comments).trim() === '0' && str(s.format_one_comments).trim() === '1';
      const notes = [];
      if (!plain) notes.push('The comment count texts ("No Responses", "One Response", "{number} Responses" or custom ones) are not carried over: Zadex prints the number only.');
      if (s.link_to === 'comments_link') notes.push('The link to the comments was not carried over.');
      return { tag: 'comments-number', note: notes.length ? notes.join(' ') : undefined };
    },
  },
  'featured-image-data': {
    cats: ['url', 'text'],
    // Pro `attachment_data`: title (default) | alt | caption | src (file URL) | href (attachment page). Zadex: file URL.
    map: (s) => (s.attachment_data === 'src' ? { tag: 'featured-image-url', settings: { size: 'full' } } : undefined),
  },
  'post-featured-image': {
    cats: ['image', 'url', 'text'],
    map: (_s, cat) => (cat === 'image' ? { tag: 'featured-image' } : { tag: 'featured-image-url', settings: { size: 'full' } }),
  },
  'post-custom-field': {
    cats: ALL,
    map: (s) => {
      const key = str(s.key).trim() || str(s.custom_key).trim();
      if (!key) return undefined;
      return { tag: 'custom-field', settings: { key }, note: key.startsWith('_') ? `Custom field "${key}" is protected meta; Zadex never prints it.` : undefined };
    },
  },
  'site-title': { cats: ['text'], map: () => ({ tag: 'site-title' }) },
  'site-tagline': { cats: ['text'], map: () => ({ tag: 'site-tagline' }) },
  'site-url': { cats: ['url', 'text'], map: () => ({ tag: 'site-url' }) },
  'site-logo': { cats: ['image', 'url'], map: () => ({ tag: 'site-logo' }) },
  'archive-title': {
    cats: ['text'],
    map: (s) => ({
      tag: 'archive-title',
      note: s.include_context !== undefined && !yes(s.include_context) ? undefined : 'Archive title tag: the "Category:" / "Tag:" context prefix option is not carried over.',
    }),
  },
  'archive-description': { cats: ['text'], map: () => ({ tag: 'archive-description' }) },
  'author-name': { cats: ['text'], map: () => ({ tag: 'post-author', settings: { field: 'name' } }) },
  'author-info': {
    cats: ['text'],
    // Elementor `key`: description (bio) | email | url (website). Zadex post-author only has the bio.
    map: (s) => (str(s.key) === '' || s.key === 'description' ? { tag: 'post-author', settings: { field: 'bio' } } : undefined),
  },
  'author-url': {
    cats: ['url', 'text'],
    // Elementor `url`: archive (posts page) | website. Zadex post-author `url` is the archive URL.
    map: (s) => (s.url === 'website' ? undefined : { tag: 'post-author', settings: { field: 'url' } }),
  },
  'author-profile-picture': { cats: ['image'], map: () => ({ tag: 'post-author', settings: { field: 'avatar' } }) },
  'user-info': {
    cats: ['text'],
    map: (s) => {
      const table: Record<string, string> = {
        '': 'display_name',
        display_name: 'display_name',
        id: 'ID',
        login: 'user_login',
        email: 'user_email',
        first_name: 'first_name',
        last_name: 'last_name',
        nickname: 'nickname',
        description: 'description',
      };
      const field = table[str(s.type)];
      return field ? { tag: 'user-info', settings: { field } } : undefined;
    },
  },
  'user-profile-picture': { cats: ['image'], map: () => ({ tag: 'user-info', settings: { field: 'avatar' } }) },
  'current-date-time': {
    cats: ['text'],
    map: (s) => {
      // Elementor: date_format default | '' (none) | preset | custom (+ custom_format); time_format default | '' | preset.
      const df = str(s.date_format ?? 'default');
      const tf = str(s.time_format ?? 'default');
      if (df === 'custom') return { tag: 'current-date', settings: { format: str(s.custom_format) } };
      if ((df === 'default' || df === '') && tf === '') return { tag: 'current-date', settings: { format: '' } };
      const d = df === 'default' ? 'F j, Y' : df;
      const t = tf === 'default' ? 'g:i a' : tf;
      const format = [d, t].filter(Boolean).join(' ');
      const note = df === 'default' || tf === 'default' ? 'Current date: the site\'s default date / time format was replaced by "F j, Y" / "g:i a".' : undefined;
      return { tag: 'current-date', settings: { format }, note };
    },
  },
  // Pro's tag name is `request-arg` (class Request_Parameter); `request-parameter` is accepted too.
  'request-arg': {
    cats: ['text'],
    map: (s) => {
      const key = str(s.param_name).trim();
      if (!key) return undefined;
      const type = str(s.request_type) || 'get';
      return { tag: 'url-param', settings: { key }, note: type !== 'get' ? `Request parameter of type "${type}" became a URL (GET) parameter.` : undefined };
    },
  },
};

RULES['request-parameter'] = RULES['request-arg'];

for (const name of ['acf', 'acf-text', 'acf-url', 'acf-image', 'acf-number', 'acf-color', 'acf-file']) {
  RULES[name] = { cats: name === 'acf-image' ? ['image'] : name === 'acf-url' || name === 'acf-file' ? ['url', 'text'] : ALL, map: (s) => pluginField('acf', 'ACF', s) };
}
for (const name of ['pods', 'pods-text', 'pods-url', 'Pods-url', 'pods-image', 'pods-numeric', 'pods-date']) {
  RULES[name] = { cats: name === 'pods-image' ? ['image'] : ALL, map: (s) => pluginField('pods', 'Pods', s) };
}
for (const name of ['toolset', 'toolset-text', 'toolset-url', 'toolset-image', 'toolset-date']) {
  RULES[name] = { cats: name === 'toolset-image' ? ['image'] : ALL, map: (s) => pluginField('toolset', 'Toolset', s) };
}

/** Elementor tag names this module converts (for docs / the report). */
export const SUPPORTED_DYNAMIC_TAGS = Object.keys(RULES).sort();

/**
 * Zadex dynamic value for an Elementor `__dynamic__` shortcode, for a control of the given category (`text` by
 * default; `image` for media controls, `url` for links). Undefined when the tag is unknown, unsupported for that
 * category or missing a required setting: the caller then keeps the static value and notes it.
 */
export function dynamicValue(shortcode: unknown, category: DynamicCategory = 'text'): { value: ZDynamicValue; note?: string } | undefined {
  const parsed = parseDynamicTag(shortcode);
  if (!parsed) return undefined;
  const rule = RULES[parsed.name];
  if (!rule || !rule.cats.includes(category)) return undefined;
  const s = parsed.settings;
  let mapped: Mapped | undefined;
  try {
    mapped = rule.map(s, category);
  } catch {
    mapped = undefined;
  }
  if (!mapped) return undefined;
  // Image tags keep the fallback as a media object; Zadex uses a fallback string as the image URL.
  const fallback = isObj(s.fallback) ? str(s.fallback.url) : str(s.fallback);
  const value: ZDynamicValue = {
    __dynamic: {
      tag: mapped.tag,
      settings: mapped.settings ?? {},
      before: category === 'image' ? '' : str(s.before),
      after: category === 'image' ? '' : str(s.after),
      fallback,
    },
  };
  return mapped.note ? { value, note: mapped.note } : { value };
}
