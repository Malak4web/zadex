import { makeKey } from '@zadex/editor/core/settings';
import type { BreakpointKey, ElElement, ElSettings, ElementStatus, MediaInfo, Report, ReportEntry, Settings, SourceDocument, WidgetManifest, ZElement, ZadexEnv } from './types';
import { DEVICE_SUFFIXES, deviceKeys } from './responsive';
import { bool, dimensions, isBlank, parseGlobalRef, shadow, slider, url, type Dimensions } from './values';
import elementorDefaults from './data/elementor-defaults.json';
import { colorRef, defaultTypography, fontRef } from './globals';
import { convertBackground, type BackgroundType, type ZBackground } from './background';
import { popupTagLink, rewritePopupLink } from './popup-links';
import { KIT_DEFAULTS } from './kit';

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);

export type ElementState = 'hover' | 'focus' | 'active';
export interface WriteOptions {
  bp?: BreakpointKey;
  state?: ElementState;
}

/** A mapper turns one Elementor element into zero or more Zadex elements. */
export type Mapper = (el: ElElement, ctx: ConvertContext) => ZElement | ZElement[] | null;

/** Keys never reported as "dropped" (editor bookkeeping, handled elsewhere, or meaningless outside Elementor). */
const IGNORED_KEYS = new Set([
  '_title',
  '__globals__',
  '__dynamic__',
  '_element_cache',
  'handle_slideshow_asset_loading',
  'flex__is_row',
  'flex__is_column',
  'grid__is_row',
  'grid__is_column',
  'grid_outline',
  'presetTitle',
  'presetIcon',
  '_inline_size_tablet',
  'screen_sm',
  'screen_sm_width',
]);

const DEFAULTS = elementorDefaults as Record<string, Record<string, unknown>>;

/**
 * Collects the Zadex settings for one element while tracking which Elementor keys were read, so everything the
 * mapper did not carry over is listed in the report automatically.
 */
export class ElementWriter {
  readonly settings: Settings = {};
  private consumed = new Set<string>();
  private consumedPrefixes: string[] = [];
  private notes: string[] = [];
  private forcedStatus: ElementStatus | null = null;
  readonly id: string;

  constructor(
    readonly el: ElElement,
    readonly ctx: ConvertContext,
    readonly type: string,
    /** Elementor default-table key: widgetType for widgets, elType otherwise. */
    readonly sourceType: string = el.widgetType ?? el.elType,
    id?: string,
  ) {
    this.id = id ?? ctx.idFor(el.id);
  }

  /* ---- reading Elementor values ---- */

  private get src(): ElSettings {
    return this.el.settings ?? {};
  }

  /** True when the element stores a non-empty value for the key. */
  has(key: string): boolean {
    return !isBlank(this.src[key]);
  }

  /** Stored value, or Elementor's default for that control when the key is absent. Marks the key as handled. */
  get(key: string): unknown {
    this.consumed.add(key);
    if (Object.prototype.hasOwnProperty.call(this.src, key)) return this.src[key];
    return DEFAULTS[this.sourceType]?.[key];
  }

  /** Stored value only (no Elementor default). Marks the key as handled. */
  raw(key: string): unknown {
    this.consumed.add(key);
    return this.src[key];
  }

  /** Marks keys (or every key starting with `prefix*`) as handled without reading them. */
  consume(...keys: string[]): void {
    for (const k of keys) {
      if (k.endsWith('*')) this.consumedPrefixes.push(k.slice(0, -1));
      else this.consumed.add(k);
    }
  }

  /** Marks a responsive key and all its device variants as handled. */
  consumeResponsive(base: string): void {
    for (const [k] of deviceKeys(base)) this.consumed.add(k);
  }

  /** `__globals__[key]` reference, e.g. `{kind: 'colors', id: 'primary'}`. */
  globalRef(key: string): { kind: string; id: string } | undefined {
    const globals = this.src.__globals__;
    return isObj(globals) ? parseGlobalRef(globals[key]) : undefined;
  }

  /** Raw `__dynamic__` shortcode for a key, if the value is bound to a dynamic tag. */
  dynamicRef(key: string): string | undefined {
    const dyn = this.src.__dynamic__;
    return isObj(dyn) && typeof dyn[key] === 'string' ? (dyn[key] as string) : undefined;
  }

  /* ---- writing Zadex values ---- */

  set(id: string, value: unknown, opts: WriteOptions = {}): void {
    if (value === undefined) return;
    this.settings[makeKey(id, opts)] = value;
  }

  /**
   * Copies a responsive Elementor control to a Zadex control: `src`, `src_tablet`, `src_mobile`… -> `dst`,
   * `dst@tablet`, `dst@mobile`… The desktop value falls back to Elementor's default; device values never do.
   */
  responsive(src: string, dst: string, convert: (v: unknown) => unknown = (v) => v, state?: ElementState): void {
    for (const [key, bp] of deviceKeys(src)) {
      const v = bp ? this.raw(key) : this.get(key);
      if (isBlank(v)) continue;
      this.set(dst, convert(v), { bp, state });
    }
  }

  /** Responsive select/choose with a value table (`{left: 'flex-start'}`); unknown values are skipped and noted. */
  map(src: string, dst: string, table: Record<string, unknown>, state?: ElementState): void {
    this.responsive(
      src,
      dst,
      (v) => {
        const key = String(v);
        if (Object.prototype.hasOwnProperty.call(table, key)) return table[key];
        this.note(`Value "${key}" of ${src} has no Zadex equivalent.`);
        return undefined;
      },
      state,
    );
  }

  slider(src: string, dst: string, state?: ElementState, defaultUnit = 'px'): void {
    this.responsive(src, dst, (v) => slider(v, defaultUnit), state);
  }

  dimensions(src: string, dst: string, state?: ElementState): void {
    this.responsive(src, dst, (v) => dimensions(v), state);
  }

  url(src: string, dst: string): void {
    const value = url(this.get(src));
    // Elementor Pro popup actions (dynamic `popup` tag or `#elementor-action:…` link) -> Zadex popup links.
    const popup = popupTagLink(this.dynamicRef(src), this.ctx) ?? (value ? rewritePopupLink(value.url, this.ctx) : undefined);
    if (popup && (popup.note || popup.unmapped)) {
      if (this.dynamicRef(src)) this.consumeDynamic(src);
      if (popup.note) this.note(popup.note);
      if (popup.unmapped && !this.forcedStatus) this.forcedStatus = 'partial';
      this.set(dst, { ...(value ?? { target: '', nofollow: false }), url: popup.url });
      return;
    }
    this.set(dst, value);
  }

  /** A color, honouring `__globals__` references (global colors become `var(--zx-color-<id>)`). Responsive. */
  color(src: string, dst: string, state?: ElementState): void {
    for (const [key, bp] of deviceKeys(src)) {
      const ref = this.globalRef(key);
      if (ref && ref.kind === 'colors') {
        this.consumed.add(key);
        const value = colorRef(this.ctx, ref.id);
        if (value) this.set(dst, value, { bp, state });
        else this.note(`Global color "${ref.id}" was not found.`);
        continue;
      }
      const v = bp ? this.raw(key) : this.get(key);
      if (typeof v === 'string' && v !== '') this.set(dst, v, { bp, state });
    }
  }

  /**
   * Elementor typography group (`<prefix>_typography: 'custom'`, `<prefix>_font_family`, `<prefix>_font_size[_device]`…)
   * -> Zadex typography object per breakpoint. A `__globals__` typography reference is expanded from the kit, with the
   * family pointing at the matching Zadex global font when it exists.
   */
  typography(prefix: string, dst: string): void {
    this.consume(`${prefix}_*`);
    const ref = this.globalRef(`${prefix}_typography`);
    let src: ElSettings = this.src;
    let family: string | undefined;
    if (ref && ref.kind === 'typography') {
      const preset = this.ctx.typographyPreset(ref.id);
      if (!preset) {
        this.note(`Global typography "${ref.id}" was not found.`);
        return;
      }
      // Kit default of the widget (not chosen by the user): the element's own custom fields win field by field.
      const asDefault = defaultTypography.get(this.src)?.has(`${prefix}_typography`) === true;
      const custom = this.src[`${prefix}_typography`] === 'custom';
      const own = asDefault && !custom ? {} : pickPrefixed(this.src, prefix, 'typography');
      src = { ...preset, ...own };
      const ownFamily = own.typography_font_family;
      family = asDefault && typeof ownFamily === 'string' && ownFamily !== '' ? ownFamily : fontRef(this.ctx, ref.id);
      prefix = 'typography';
    } else if (this.src[`${prefix}_typography`] !== 'custom') {
      return;
    }
    for (const { suffix, bp } of DEVICE_SUFFIXES) {
      const t: Obj = {};
      const s = (name: string): unknown => src[`${prefix}_${name}${suffix}`];
      if (!bp) {
        const fam = family ?? (typeof src[`${prefix}_font_family`] === 'string' ? src[`${prefix}_font_family`] : undefined);
        if (fam) t.family = fam;
      }
      const size = slider(s('font_size'));
      if (size) t.size = size;
      const weight = s('font_weight');
      if (!isBlank(weight)) t.weight = String(weight);
      for (const [from, to] of [['text_transform', 'transform'], ['font_style', 'style'], ['text_decoration', 'decoration']] as const) {
        const v = s(from);
        if (!isBlank(v)) t[to] = String(v);
      }
      const lh = slider(s('line_height'), 'custom');
      if (lh) t.lineHeight = lh.unit === 'em' && typeof lh.size === 'number' ? { size: lh.size, unit: 'custom' } : lh;
      const ls = slider(s('letter_spacing'));
      if (ls) t.letterSpacing = ls;
      const ws = slider(s('word_spacing'));
      if (ws) t.wordSpacing = ws;
      if (Object.keys(t).length) this.set(dst, t, { bp });
    }
  }

  /** Elementor border group (`<prefix>_border`, `_width`, `_color`, optional radius key) -> Zadex border. */
  border(prefix: string, dst: string, radiusKey?: string, state?: ElementState): void {
    this.consume(`${prefix}_border`, `${prefix}_color`);
    this.consumeResponsive(`${prefix}_width`);
    const style = this.raw(`${prefix}_border`);
    for (const { suffix, bp } of DEVICE_SUFFIXES) {
      const b: Obj = {};
      if (!bp && typeof style === 'string' && style !== '' && style !== 'none') b.style = style;
      if (!bp && style === 'none') b.style = 'none';
      const width = dimensions(this.raw(`${prefix}_width${suffix}`));
      if (width && style && style !== 'none') b.width = width;
      if (!bp) {
        const ref = this.globalRef(`${prefix}_color`);
        const color = ref?.kind === 'colors' ? colorRef(this.ctx, ref.id) : this.raw(`${prefix}_color`);
        if (typeof color === 'string' && color !== '' && style && style !== 'none') b.color = color;
      }
      if (radiusKey) {
        const radius = dimensions(this.raw(`${radiusKey}${suffix}`));
        if (radius) b.radius = radius;
      }
      if (Object.keys(b).length) this.set(dst, b, { bp, state });
    }
    if (radiusKey) this.consumeResponsive(radiusKey);
  }

  /** Elementor box-shadow group (`<prefix>_box_shadow_type: 'yes'`, `<prefix>_box_shadow`, `<prefix>_box_shadow_position`). */
  boxShadow(prefix: string, dst: string, state?: ElementState): void {
    this.consume(`${prefix}_box_shadow_type`, `${prefix}_box_shadow_position`);
    this.consumeResponsive(`${prefix}_box_shadow`);
    if (!bool(this.raw(`${prefix}_box_shadow_type`))) return;
    const inset = this.raw(`${prefix}_box_shadow_position`) === 'inset';
    this.set(dst, shadow(this.raw(`${prefix}_box_shadow`), inset), { state });
  }

  /** Elementor text-shadow group (`<prefix>_text_shadow_type`, `<prefix>_text_shadow`). */
  textShadow(prefix: string, dst: string, state?: ElementState): void {
    this.consume(`${prefix}_text_shadow_type`);
    this.consumeResponsive(`${prefix}_text_shadow`);
    if (!bool(this.raw(`${prefix}_text_shadow_type`))) return;
    this.set(dst, shadow(this.raw(`${prefix}_text_shadow`)), { state });
  }

  /** Elementor background group (`<prefix>_background`, `_color`, `_image` …) -> Zadex background (background.ts). */
  background(prefix: string, dst: string, state?: ElementState, allow?: BackgroundType[]): ZBackground | undefined {
    return convertBackground(this, prefix, dst, { state, allow });
  }

  /** Dimension sides as a plain Zadex dimensions value (helper for mappers composing their own objects). */
  dims(key: string): Dimensions | undefined {
    return dimensions(this.raw(key));
  }

  /* ---- report ---- */

  note(text: string): void {
    if (!this.notes.includes(text)) this.notes.push(text);
  }

  /** Forces the element's report status (e.g. 'partial' when a feature is approximated). */
  status(status: ElementStatus): void {
    this.forcedStatus = status;
  }

  /** Elementor keys that hold a value but were never read by the mapper. */
  dropped(): string[] {
    const out: string[] = [];
    for (const [key, value] of Object.entries(this.src)) {
      if (IGNORED_KEYS.has(key) || this.consumed.has(key)) continue;
      if (this.consumedPrefixes.some((p) => key.startsWith(p))) continue;
      if (isBlank(value)) continue;
      if (isDefault(this.sourceType, key, value)) continue;
      out.push(key);
    }
    const dyn = this.src.__dynamic__;
    if (isObj(dyn)) for (const key of Object.keys(dyn)) if (!this.consumed.has(`__dynamic__.${key}`)) out.push(`__dynamic__.${key}`);
    return out;
  }

  /** Marks a dynamic binding as carried over (so it is not reported as dropped). */
  consumeDynamic(key: string): void {
    this.consumed.add(`__dynamic__.${key}`);
  }

  /**
   * Builds the Zadex element, runs the shared "Advanced tab" conversion (common.ts) and records the report entry.
   * `children` are already converted Zadex elements.
   */
  finish(children: ZElement[] = [], extra: Partial<ZElement> = {}): ZElement {
    this.ctx.applyCommon(this);
    const element: ZElement = { id: this.id, type: this.type, settings: this.settings, children, ...extra };
    const dropped = this.dropped();
    const status: ElementStatus = this.forcedStatus ?? (dropped.length ? 'partial' : 'converted');
    this.ctx.record({
      source: this.el.id,
      sourceType: this.el.widgetType ?? this.el.elType,
      status,
      target: [this.id],
      targetType: this.type,
      dropped,
      notes: this.notes,
    });
    return element;
  }
}

function pickPrefixed(src: ElSettings, from: string, to: string): ElSettings {
  const out: ElSettings = {};
  for (const [k, v] of Object.entries(src)) {
    if (k.startsWith(`${from}_`) && k !== `${from}_typography`) out[`${to}_${k.slice(from.length + 1)}`] = v;
  }
  return out;
}

function isDefault(type: string, key: string, value: unknown): boolean {
  const d = DEFAULTS[type]?.[key];
  return d !== undefined && JSON.stringify(d) === JSON.stringify(value);
}

/**
 * Shared state for one conversion: Zadex manifests, ids, media details, global lookups and the report.
 * Mappers receive it and call `ctx.convert(children)` for nested elements.
 */
export class ConvertContext {
  readonly report: Report = { entries: [], notes: [] };
  readonly manifests: Record<string, WidgetManifest> = {};
  private usedIds = new Set<string>();
  /** Hook set by common.ts: converts the Elementor "Advanced" tab into Zadex common controls. */
  commonHandler: (w: ElementWriter) => void = () => {};

  constructor(
    readonly source: SourceDocument,
    readonly env: ZadexEnv,
    private readonly dispatch: (el: ElElement, ctx: ConvertContext) => ZElement[],
  ) {
    for (const m of env.manifests) this.manifests[m.type] = m;
  }

  /** Converts a list of Elementor elements (recursion entry point for container mappers). */
  convert(elements: ElElement[] | undefined): ZElement[] {
    const out: ZElement[] = [];
    for (const el of elements ?? []) out.push(...this.dispatch(el, this));
    return out;
  }

  writer(el: ElElement, zadexType: string, opts: { sourceType?: string; id?: string } = {}): ElementWriter {
    return new ElementWriter(el, this, zadexType, opts.sourceType, opts.id);
  }

  hasWidget(type: string): boolean {
    return Boolean(this.manifests[type]);
  }

  /**
   * Stable Zadex id for an Elementor id: `e` + the Elementor id (Elementor ids are 7 hex chars that may start
   * with a digit; Zadex ids must be letter-first, /^[a-z][a-z0-9]{2,15}$/). Extra wrappers pass a suffix.
   */
  idFor(elementorId: string, suffix = ''): string {
    const clean = (elementorId || 'x').toLowerCase().replace(/[^a-z0-9]/g, '');
    let base = ('e' + clean + suffix).slice(0, 16);
    if (base.length < 3) base = base.padEnd(3, '0');
    let id = base;
    let n = 1;
    while (this.usedIds.has(id)) id = (base.slice(0, 14) + (n++).toString(36)).slice(0, 16);
    this.usedIds.add(id);
    return id;
  }

  /** Repeater item id from an Elementor `_id` (same rules as idFor, prefix `r`). */
  itemId(elementorItemId: unknown): string {
    const clean = String(elementorItemId ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
    return ('r' + (clean || Math.random().toString(36).slice(2, 9))).slice(0, 16).padEnd(8, '0');
  }

  /** Elementor media `{id, url}` -> Zadex MediaValue, enriched with alt / sizes from the source attachment map. */
  media(v: unknown): { id: number; url: string; alt: string; width?: number; height?: number; sizes?: MediaInfo['sizes'] } | undefined {
    if (!isObj(v)) return undefined;
    const id = Number(v.id) || 0;
    const info = id ? this.source.media?.[String(id)] : undefined;
    const href = (typeof v.url === 'string' && v.url) || info?.url || '';
    if (!href) return undefined;
    const out: { id: number; url: string; alt: string; width?: number; height?: number; sizes?: MediaInfo['sizes'] } = {
      id,
      url: href,
      alt: (typeof v.alt === 'string' && v.alt) || info?.alt || '',
    };
    if (info?.width) out.width = info.width;
    if (info?.height) out.height = info.height;
    if (info?.sizes) out.sizes = info.sizes;
    return out;
  }

  /** Inline SVG markup of an attachment (for Elementor "Upload SVG" icons). */
  svg(v: unknown): string | undefined {
    const id = isObj(v) ? Number(v.id) : 0;
    return id ? this.source.media?.[String(id)]?.svg : undefined;
  }

  /** Kit typography preset (system or custom) by Elementor id, as flat `typography_*` settings. */
  typographyPreset(id: string): ElSettings | undefined {
    const kit = this.source.kit ?? {};
    // An active kit that never stored its system fonts (fresh install, kit with the site name only; the server sends
    // `kit: {}`) renders with Elementor's defaults, like the kit importer uses (V7: every widget lost its Roboto
    // default on the clean install). No `kit` at all = no active kit: no presets.
    const system = Array.isArray(kit.system_typography) ? kit.system_typography : this.source.kit ? KIT_DEFAULTS.system_typography : undefined;
    for (const list of [system, kit.custom_typography]) {
      if (!Array.isArray(list)) continue;
      const hit = list.find((t) => isObj(t) && t._id === id);
      if (hit) return hit as ElSettings;
    }
    return undefined;
  }

  /** Kit color (system or custom) by Elementor id. */
  kitColor(id: string): string | undefined {
    const kit = this.source.kit ?? {};
    const system = Array.isArray(kit.system_colors) ? kit.system_colors : this.source.kit ? KIT_DEFAULTS.system_colors : undefined;
    for (const list of [system, kit.custom_colors]) {
      if (!Array.isArray(list)) continue;
      const hit = list.find((c) => isObj(c) && c._id === id) as Obj | undefined;
      if (hit && typeof hit.color === 'string') return hit.color;
    }
    return undefined;
  }

  applyCommon(w: ElementWriter): void {
    this.commonHandler(w);
  }

  record(entry: ReportEntry): void {
    this.report.entries.push(entry);
  }

  note(text: string): void {
    if (!this.report.notes.includes(text)) this.report.notes.push(text);
  }
}
