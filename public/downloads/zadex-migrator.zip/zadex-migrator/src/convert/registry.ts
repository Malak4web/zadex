import type { Mapper } from './context';

/**
 * Mapper registry. Keys:
 *  - `widget:<widgetType>` for classic widgets (e.g. `widget:heading`),
 *  - `el:<elType>` for layout / atomic elements (e.g. `el:section`, `el:column`, `el:container`, `el:e-flexbox`).
 * Each mapper lives in its own file under src/convert/widgets/ or src/convert/layout/ and registers itself;
 * src/convert/mappers.ts imports them all.
 */
const mappers = new Map<string, Mapper>();

export function registerWidget(widgetType: string, mapper: Mapper): void {
  mappers.set(`widget:${widgetType}`, mapper);
}

export function registerElement(elType: string, mapper: Mapper): void {
  mappers.set(`el:${elType}`, mapper);
}

export function getMapper(key: string): Mapper | undefined {
  return mappers.get(key);
}

/** Registered widget types (for the "supported widgets" list in the admin UI and the readme). */
export function supportedWidgets(): string[] {
  return [...mappers.keys()].filter((k) => k.startsWith('widget:')).map((k) => k.slice(7)).sort();
}
