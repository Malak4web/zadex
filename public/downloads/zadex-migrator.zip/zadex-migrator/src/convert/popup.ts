import type { ConvertContext } from './context';
import type { ElSettings, Settings, SourceDocument } from './types';
import { bool, dimensions, isBlank, parseGlobalRef, slider } from './values';
import { splitDeviceKey } from './responsive';
import { colorRef } from './globals';
import { PRO_NOTE } from './widgets/_pro';
import elementorDefaults from './data/elementor-defaults.json';

/**
 * Elementor Pro popup settings -> Zadex popup page settings `popup_*` (docs/ARCHITECTURE.md "Popups (converter)";
 * Zadex controls: `../plugin zadex/src/editor/core/popupControls.ts`, sanitized by `includes/Popups/Settings.php`).
 *
 * Verified against Elementor Pro 3.33.2 (`modules/popup/document.php`, `display-settings/{triggers,timing}.php`, the
 * popup frontend handlers, and the real control dump `dev/reference/elementor-pro-controls.json` `popup.*`). Defaults
 * are Pro's real ones from `elementor-defaults.json` (`popup:document`, `popup:triggers`, `popup:timing`). Never
 * throws: anything that cannot be carried over is named in a note.
 *
 * Layout (`_elementor_page_settings`):
 *  - `width` slider px | em | rem | vw (default 640px), `height_type` auto | fit_to_screen | custom, `height` slider
 *    px | em | rem | vh (custom only, default 380px), `content_position` top | center | bottom (content inside the
 *    box, only when the height is not auto), `horizontal_position` left | center | right and `vertical_position`
 *    top | center | bottom (choose controls, default center; physical sides).
 *  - `overlay` switcher (default yes), overlay background group `overlay_background_*` (default classic,
 *    rgba(0,0,0,.8)), `close_button` switcher (default yes), `close_button_position` '' (inside) | outside,
 *    `close_button_color`, `entrance_animation` / `exit_animation` (animate.css names, responsive), and
 *    `entrance_animation_duration` (a slider whose unit is stored as "px" but means seconds, default 1.2).
 *  - Style: background group `background_*` (no default type: the popup CSS paints white), `border_radius` /
 *    `padding` dimensions (default empty = 0, Zadex defaults are 8 / 24 so 0 is written explicitly), border group,
 *    box shadow group (on by default: 2px 8px 23px 3px rgba(0,0,0,.2), close to the Zadex popup shadow).
 *  - Advanced: `close_button_delay`, `close_automatically` (seconds), `prevent_close_on_background_click`,
 *    `prevent_close_on_esc_key`, `prevent_scroll` (default off; Zadex defaults on), `avoid_multiple_popups`,
 *    `open_selector`, `a11y_navigation` (default yes), `margin`, `classes`.
 * Display settings: post meta `_elementor_popup_display_settings` = `{triggers: {…}, timing: {…}}` (each group's
 * control ids are prefixed with the group name, e.g. `page_load_delay`), sent decoded as `source.popupSettings`; a
 * JSON string or one flat object is accepted too. See `convertTriggers()` and `convertTiming()`.
 */

type Obj = Record<string, unknown>;
type Note = (text: string) => void;

const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);
const str = (v: unknown): string => (typeof v === 'string' ? v.trim() : typeof v === 'number' ? String(v) : '');
/** Finite number or the fallback (Elementor stores numbers as strings too). */
function numberOr(v: unknown, fallback: number): number {
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;
  return Number.isFinite(n) ? n : fallback;
}
const clamp = (n: number, min: number, max: number): number => Math.min(max, Math.max(min, n));

/** Elementor Pro's real popup defaults (`elementor-defaults.json`). */
const PRO_DEFAULTS = elementorDefaults as Record<string, Record<string, unknown>>;
const DOC_DEFAULTS: Obj = PRO_DEFAULTS['popup:document'] ?? {};
const TRIGGER_DEFAULTS: Obj = PRO_DEFAULTS['popup:triggers'] ?? {};
const TIMING_DEFAULTS: Obj = PRO_DEFAULTS['popup:timing'] ?? {};
const EL_DEFAULT_WIDTH = slider(DOC_DEFAULTS.width) ?? { size: 640, unit: 'px' };
const EL_DEFAULT_HEIGHT = slider(DOC_DEFAULTS.height) ?? { size: 380, unit: 'px' };
const EL_DEFAULT_OVERLAY = str(DOC_DEFAULTS.overlay_background_color) || 'rgba(0,0,0,.8)';
const EL_DEFAULT_DURATION_S = numberOr(slider(DOC_DEFAULTS.entrance_animation_duration)?.size, 1.2);
/** Pro's default popup box shadow (`box_shadow_box_shadow_type` defaults to yes). */
const EL_DEFAULT_SHADOW = JSON.stringify(DOC_DEFAULTS.box_shadow_box_shadow ?? null);

/** Elementor em / rem lengths -> px (16px root); other units unchanged. */
function emToPx(s: { size: number | string; unit: string }): { size: number | string; unit: string } {
  return s.unit === 'em' || s.unit === 'rem' ? { size: Math.round(numberOr(s.size, 0) * 16), unit: 'px' } : s;
}

/** Same rule as Zadex `Popups\Settings::color()`. */
const COLOR = /^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla)\([0-9.,%\s/+-]+\)|var\(--[a-z0-9_-]+\)|transparent|currentColor|[a-z]+)$/i;

/** Page-settings keys handled elsewhere, editor-only or meaningless for a popup (never reported). */
const IGNORED = new Set([
  'template',
  'hide_title',
  'post_title',
  'post_status',
  'post_excerpt',
  'post_featured_image',
  'menu_order',
  'a11y_navigation',
  '__globals__',
  '__dynamic__',
  'scroll_snap',
  'preview_type',
  'preview_id',
  'preview_search_term',
  'assets_loading_hidden_control',
]);

/**
 * Elementor animate.css names -> Zadex popup animations. Exact: fadeIn, zoomIn, slideIn*. The rest are the closest
 * Zadex motion (noted). `Left` / `Right` are physical in Elementor; Zadex `slide_start` / `slide_end` are logical, so
 * they flip on RTL sites.
 */
function animation(name: string, rtl: boolean): { value: string; exact: boolean } | undefined {
  if (name === '' || name === 'none') return { value: 'none', exact: true };
  const left = rtl ? 'slide_end' : 'slide_start';
  const right = rtl ? 'slide_start' : 'slide_end';
  const exact: Record<string, string> = { fadeIn: 'fade', zoomIn: 'zoom', slideInUp: 'slide_up', slideInDown: 'slide_down', slideInLeft: left, slideInRight: right };
  if (exact[name]) return { value: exact[name], exact: true };
  // Directional entrances: "…InUp" moves up (comes from below) like Zadex slide_up.
  if (/InUp$/.test(name)) return { value: 'slide_up', exact: false };
  if (/InDown$/.test(name)) return { value: 'slide_down', exact: false };
  if (/InLeft$/.test(name)) return { value: left, exact: false };
  if (/InRight$/.test(name)) return { value: right, exact: false };
  if (/^(zoom|bounce|rubberBand|pulse|jello|tada)/i.test(name)) return { value: 'zoom', exact: false };
  if (/In/.test(name) || /^(fade|flash|rotate|roll|lightSpeed|flip|swing|wobble|headShake|shake)/i.test(name)) return { value: 'fade', exact: false };
  return undefined;
}

/** Reads the Elementor display settings in whatever shape the server sent them. */
function displaySettings(raw: unknown): { triggers: Obj; timing: Obj } {
  let v = raw;
  if (typeof v === 'string') {
    try {
      v = JSON.parse(v);
    } catch {
      v = {};
    }
  }
  if (!isObj(v)) return { triggers: {}, timing: {} };
  if (isObj(v.triggers) || isObj(v.timing)) return { triggers: isObj(v.triggers) ? v.triggers : {}, timing: isObj(v.timing) ? v.timing : {} };
  // A flat object holds both groups (the prefixed control ids do not collide).
  return { triggers: v, timing: v };
}

/**
 * Converts the popup layout (`source.pageSettings`) and display settings (`source.popupSettings`) into Zadex
 * `popup_*` page settings. `ctx` (optional) resolves global colors.
 */
export function convertPopupSettings(source: SourceDocument, note: Note, ctx?: ConvertContext): Settings {
  const out: Settings = {};
  const page: ElSettings = isObj(source.pageSettings) ? source.pageSettings : {};
  const used = new Set<string>();
  const get = (key: string): unknown => {
    used.add(key);
    return page[key];
  };
  /** Stored value, else Pro's real default. */
  const pget = (key: string): unknown => {
    const v = get(key);
    return v === undefined || v === null ? DOC_DEFAULTS[key] : v;
  };
  const color = (key: string): string | undefined => {
    const globals = page.__globals__;
    const ref = isObj(globals) ? parseGlobalRef(globals[key]) : undefined;
    if (ref && ref.kind === 'colors') {
      used.add(key);
      const value = ctx ? colorRef(ctx, ref.id) : undefined;
      if (!value) note(`Global color "${ref.id}" of ${key} was not found.`);
      return value && COLOR.test(value) ? value : undefined;
    }
    const v = str(get(key));
    if (v === '') return undefined;
    if (!COLOR.test(v)) {
      note(`Color "${v}" of ${key} is not a color Zadex popups accept.`);
      return undefined;
    }
    return v;
  };
  const rtl = source.rtl === true;

  note(PRO_NOTE.replace('widget', 'popup'));

  /* ---- layout ---- */
  const width = emToPx(slider(get('width')) ?? EL_DEFAULT_WIDTH);
  const heightType = str(pget('height_type')) || 'auto';
  const customHeightRaw = heightType === 'custom' ? (slider(get('height')) ?? EL_DEFAULT_HEIGHT) : undefined;
  const customHeight = customHeightRaw ? emToPx(customHeightRaw) : undefined;
  if (heightType !== 'custom') used.add('height');
  if ((slider(page.width)?.unit ?? '').endsWith('em') || (customHeightRaw?.unit ?? '').endsWith('em')) note('Popup sizes in em / rem became px (1em = 16px).');
  const horizontal = str(pget('horizontal_position')) || 'center';
  const vRaw = str(pget('vertical_position')) || 'center';
  const vertical = ['top', 'center', 'bottom'].includes(vRaw) ? vRaw : 'center';
  if (!['top', 'center', 'bottom'].includes(vRaw)) note(`Popup vertical position "${vRaw}" has no Zadex equivalent; the popup is centered.`);
  const wSize = numberOr(width.size, NaN);
  const fullWidth = (width.unit === 'vw' || width.unit === '%') && wSize >= 100;
  const fullHeight = heightType === 'fit_to_screen' || (customHeight !== undefined && customHeight.unit === 'vh' && numberOr(customHeight.size, 0) >= 100);

  let layout: 'center' | 'slide_in' | 'fullscreen' | 'top_bar' | 'bottom_bar' = 'center';
  if (fullWidth && fullHeight) layout = 'fullscreen';
  else if (fullWidth && vertical === 'top') layout = 'top_bar';
  else if (fullWidth && vertical === 'bottom') layout = 'bottom_bar';
  else if (fullHeight && (horizontal === 'left' || horizontal === 'right')) layout = 'slide_in';
  out.popup_layout = layout;

  const lengthOk = (s: { size: number | string; unit: string }, units: string[]): boolean => Number.isFinite(numberOr(s.size, NaN)) && numberOr(s.size, -1) >= 0 && units.includes(s.unit);
  if (layout === 'center') {
    out.popup_position = vertical;
    if (horizontal !== 'center') note(`Zadex centered popups are always horizontally centered; the Elementor horizontal position "${horizontal}" was not kept (use a slide-in layout for side panels).`);
  }
  if (layout === 'slide_in') {
    // Zadex sides are logical (start = left on LTR sites).
    out.popup_side = horizontal === 'left' ? (rtl ? 'end' : 'start') : rtl ? 'start' : 'end';
    if (vertical !== 'center') note(`Zadex slide-in panels are full height; the vertical position "${vertical}" was not kept.`);
  }
  if (layout === 'center' || layout === 'slide_in') {
    if (lengthOk(width, ['px', '%', 'vw'])) out.popup_width = { size: numberOr(width.size, 0), unit: width.unit };
    else note(`Popup width ${str(width.size)}${width.unit} has no Zadex equivalent (px, % or vw); the Zadex default width is used.`);
  }
  if (layout === 'center' || layout === 'top_bar' || layout === 'bottom_bar') {
    const h = heightType === 'fit_to_screen' ? { size: 100, unit: 'vh' } : customHeight;
    if (h) {
      if (lengthOk(h, ['px', 'vh'])) out.popup_height = { size: numberOr(h.size, 0), unit: h.unit };
      else note(`Popup height ${str(h.size)}${h.unit} has no Zadex equivalent (px or vh); the popup fits its content.`);
    }
  }
  // Pro default `top`; the control only applies when the height is not auto.
  const contentPosition = str(pget('content_position'));
  if (contentPosition && contentPosition !== 'top' && heightType !== 'auto') {
    note(`The content position "${contentPosition}" inside the popup was not carried over: align the content with the popup's root container in Zadex.`);
  }

  /* ---- style ---- */
  const bgType = str(get('background_background'));
  const bgColor = color('background_color');
  // Elementor paints the background color only for a chosen type (classic; gradient uses it as the first stop).
  if (bgColor && (bgType === 'classic' || bgType === 'gradient')) out.popup_background = bgColor;
  const bgImage = page.background_image;
  const hasImage = bgType === 'classic' && isObj(bgImage) && str(bgImage.url) !== '';
  if (bgType === 'gradient' || bgType === 'video' || bgType === 'slideshow' || hasImage) {
    note(`Zadex popups only have a background color: the Elementor ${hasImage ? 'background image' : `${bgType} background`} was not carried over${bgColor && out.popup_background ? ' (its color was kept)' : ''}.`);
  }
  // The rest of the background group (position, size, gradient stops …) goes with the type.
  for (const k of Object.keys(page)) if (k.startsWith('background_')) used.add(k);
  out.popup_radius = side('border_radius', 'corner radius', 0, page, used, note);
  out.popup_padding = side('padding', 'padding', 0, page, used, note);
  if (!isBlank(page.border_border) && page.border_border !== 'none') note('The popup border was not carried over: Zadex popups have no border setting.');
  // Pro's popup has a box shadow by default (`fields_options.box_shadow_type.default = yes` in document.php; the
  // popover toggle default is missing from elementor-defaults.json), like the Zadex popup.
  const shadowRaw = get('box_shadow_box_shadow_type');
  const shadowOn = shadowRaw === undefined || shadowRaw === null ? true : bool(shadowRaw);
  if (!shadowOn) note('The Elementor popup had its box shadow turned off; Zadex popups always use their own shadow.');
  else if (page.box_shadow_box_shadow !== undefined && JSON.stringify(page.box_shadow_box_shadow) !== EL_DEFAULT_SHADOW) note('The custom popup box shadow was not carried over: Zadex popups use their own shadow.');
  for (const k of Object.keys(page)) if (k.startsWith('border_') || k.startsWith('box_shadow_')) used.add(k);

  /* ---- overlay ---- */
  const overlay = bool(pget('overlay'));
  out.popup_overlay = overlay;
  if (overlay) {
    const type = str(pget('overlay_background_background'));
    const c = color('overlay_background_color');
    // Pro's default overlay is a classic rgba(0,0,0,.8) background; a cleared type paints no overlay color.
    out.popup_overlay_color = type === '' ? 'transparent' : (c ?? EL_DEFAULT_OVERLAY);
    const image = page.overlay_background_image;
    if (type === 'gradient' || (type === 'classic' && isObj(image) && str(image.url) !== '')) note('Zadex popup overlays only have a color: the Elementor overlay gradient / image was not carried over.');
    out.popup_overlay_close = !bool(get('prevent_close_on_background_click'));
  } else {
    used.add('prevent_close_on_background_click');
  }
  for (const k of Object.keys(page)) if (k.startsWith('overlay_background_')) used.add(k);

  /* ---- close button ---- */
  const close = bool(pget('close_button'));
  out.popup_close = close;
  if (close) {
    out.popup_close_position = str(get('close_button_position')) === 'outside' ? 'outside' : 'inside';
    const c = color('close_button_color');
    if (c) out.popup_close_color = c;
    const delay = get('close_button_delay');
    if (!isBlank(delay)) out.popup_close_delay = clamp(numberOr(delay, 0), 0, 600);
  } else {
    for (const k of Object.keys(page)) if (k.startsWith('close_button_')) used.add(k);
    used.add('icon_size');
  }
  if (bool(get('prevent_close_on_esc_key'))) note('"Prevent closing on ESC key" has no Zadex equivalent: Escape always closes Zadex popups (accessibility).');

  /* ---- animation and behaviour ---- */
  for (const [key, dst] of [['entrance_animation', 'popup_anim_in'], ['exit_animation', 'popup_anim_out']] as const) {
    const name = str(get(key));
    const a = animation(name, rtl);
    if (!a) {
      out[dst] = 'fade';
      note(`Popup animation "${name}" has no Zadex equivalent; Fade is used.`);
    } else {
      out[dst] = a.value;
      if (!a.exact) note(`Popup animation "${name}" was approximated by the Zadex "${a.value}" animation.`);
    }
  }
  const animated = out.popup_anim_in !== 'none' || out.popup_anim_out !== 'none';
  // Stored as a slider whose unit is "px" although the value is in seconds.
  const d = slider(get('entrance_animation_duration'), 's');
  if (d || animated) {
    const size = d ? numberOr(d.size, EL_DEFAULT_DURATION_S) : EL_DEFAULT_DURATION_S;
    out.popup_anim_duration = clamp(Math.round(d?.unit === 'ms' ? size : size * 1000), 0, 5000);
  }
  out.popup_prevent_scroll = bool(get('prevent_scroll'));
  const auto = get('close_automatically');
  if (!isBlank(auto)) out.popup_auto_close = clamp(numberOr(auto, 0), 0, 3600);
  if (bool(get('avoid_multiple_popups'))) note('"Avoid multiple popups" has no Zadex equivalent: this popup can open while another one is open.');

  /* ---- triggers and rules ---- */
  const display = displaySettings(source.popupSettings);
  convertTriggers(display.triggers, str(get('open_selector')), out, note);
  convertTiming(display.timing, out, note);

  /* ---- leftovers ---- */
  const responsive = new Set<string>();
  const other: string[] = [];
  let customCss = false;
  for (const [key, value] of Object.entries(page)) {
    if (IGNORED.has(key) || used.has(key) || isBlank(value)) continue;
    if (key === 'content_wrapper_html_tag' && value === DOC_DEFAULTS.content_wrapper_html_tag) continue;
    const { base, bp } = splitDeviceKey(key);
    if (bp && used.has(base)) responsive.add(base);
    else if (key === 'custom_css') customCss = str(value) !== '';
    else other.push(key);
  }
  if (responsive.size) note(`Zadex popup settings are not responsive: the tablet / mobile values of ${[...responsive].sort().join(', ')} were not carried over.`);
  if (customCss) note('Custom CSS is not supported by Zadex (WordPress.org rule); the popup custom CSS was not carried over.');
  if (other.length) note(`Popup settings not carried over: ${other.sort().join(', ')}.`);
  return out;
}

/** Elementor dimensions -> one Zadex px number (top side; differing sides / non-px units noted). */
function side(key: string, label: string, fallback: number, page: ElSettings, used: Set<string>, note: Note): number {
  used.add(key);
  const d = dimensions(page[key]);
  if (!d) return fallback;
  const sides = [d.top, d.right, d.bottom, d.left].map((s) => numberOr(s, NaN)).filter((n) => Number.isFinite(n));
  if (!sides.length) return fallback;
  const value = sides[0];
  if (new Set(sides).size > 1) note(`Zadex popups have one ${label} for all sides: ${value}${d.unit} (the first Elementor side) is used.`);
  if (d.unit !== 'px' && d.unit !== '') {
    if (d.unit === 'em' || d.unit === 'rem') {
      note(`The popup ${label} in ${d.unit} became px (1${d.unit} = 16px).`);
      return clamp(Math.round(value * 16), 0, 200);
    }
    note(`The popup ${label} in ${d.unit} has no Zadex equivalent (px only); ${fallback}px is used.`);
    return fallback;
  }
  return clamp(value, 0, 200);
}

/**
 * Elementor triggers -> Zadex triggers (Pro 3.33.2 `display-settings/triggers.php`, defaults from
 * `popup:triggers`): `page_load` + `page_load_delay` (s, default 0), `scrolling` + `scrolling_direction` down | up
 * (default down) + `scrolling_offset` (%, default 50, down only), `scrolling_to` + `scrolling_to_selector`, `click` +
 * `click_times` (clicks anywhere on the body, default 1), `inactivity` + `inactivity_time` (s, default 30),
 * `exit_intent`, `adblock_detection` + `adblock_detection_delay` (s, default 0). The popup's "Open by selector"
 * (`open_selector`, layout settings) is a click trigger on that selector.
 */
function convertTriggers(t: Obj, openSelector: string, out: Settings, note: Note): void {
  const known = new Set<string>();
  const v = (key: string): unknown => {
    known.add(key);
    return t[key] === undefined || t[key] === null ? TRIGGER_DEFAULTS[key] : t[key];
  };
  if (bool(v('page_load'))) {
    out.popup_trigger_load = true;
    out.popup_trigger_load_delay = clamp(numberOr(v('page_load_delay'), 0), 0, 3600);
  } else known.add('page_load_delay');

  if (bool(v('scrolling'))) {
    out.popup_trigger_scroll = true;
    if (str(v('scrolling_direction')) === 'up') {
      known.add('scrolling_offset');
      out.popup_trigger_scroll_percent = 0;
      note('The "scroll up" trigger became a Zadex scroll trigger that opens on the first scroll: Zadex has no scroll-up trigger.');
    } else out.popup_trigger_scroll_percent = clamp(Math.round(numberOr(v('scrolling_offset'), 50)), 0, 100);
  } else known.add('scrolling_offset').add('scrolling_direction');

  if (bool(v('scrolling_to'))) {
    const selector = str(v('scrolling_to_selector'));
    if (selector) {
      out.popup_trigger_scroll_to = true;
      out.popup_trigger_scroll_to_selector = selector;
    } else note('The "scroll to element" trigger has no selector and was left off.');
  } else known.add('scrolling_to_selector');

  const clickAnywhere = bool(v('click'));
  const times = Math.round(numberOr(v('click_times'), 1));
  if (!clickAnywhere) known.add('click_times');
  if (clickAnywhere || openSelector) {
    out.popup_trigger_click = true;
    // Elementor counts clicks anywhere on the body; `body` matches every click target in Zadex (closest()).
    out.popup_trigger_click_selector = clickAnywhere ? 'body' : openSelector;
    if (clickAnywhere) {
      note('The "on click" trigger (clicks anywhere on the page) became a Zadex click trigger on `body`; unlike Elementor it stays armed, so later clicks can reopen the popup.');
      if (times > 1) note(`The click trigger opened the popup after ${times} clicks; the Zadex click trigger opens it on the first click.`);
      if (openSelector) note(`"Open by selector" (${openSelector}) is covered by the click-anywhere trigger.`);
    }
  }

  if (bool(v('inactivity'))) {
    out.popup_trigger_inactivity = true;
    out.popup_trigger_inactivity_seconds = clamp(Math.round(numberOr(v('inactivity_time'), 30)), 1, 3600);
  } else known.add('inactivity_time');

  if (bool(v('exit_intent'))) out.popup_trigger_exit = true;
  if (bool(v('adblock_detection'))) {
    out.popup_trigger_adblock = true;
    const delay = numberOr(v('adblock_detection_delay'), 0);
    if (delay > 0) note(`The AdBlock trigger waited ${delay}s; the Zadex AdBlock trigger opens as soon as an ad blocker is detected.`);
  } else known.add('adblock_detection_delay');

  const unknown = Object.keys(t).filter((k) => !known.has(k) && !isBlank(t[k]) && !TIMING_KEYS.test(k));
  if (unknown.length) note(`Popup triggers not carried over: ${unknown.sort().join(', ')}.`);
}

/** Keys of the timing group (ignored by the trigger leftovers when the server sent one flat object). */
const TIMING_KEYS = /^(page_views|sessions|url|sources|logged_in|devices|times|browsers|schedule)(_|$)/;

const escapeRegex = (s: string): string => s.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
/** Pro's "search engines" source: `/^(google|yahoo|bing|yandex|baidu)\./` on the referrer without scheme / www. */
const SEARCH_ENGINES = '^https?://(www\\.)?(google|yahoo|bing|yandex|baidu)\\.';

/**
 * Elementor advanced rules -> Zadex rules (Pro 3.33.2 `display-settings/timing.php`, defaults from `popup:timing`):
 * `page_views` + `page_views_views` ("show after X page views", default 3), `sessions` + `sessions_sessions`
 * (default 2), `times` + `times_times` (default 3) + `times_period` '' (persisting) | session | day | week | month +
 * `times_count` '' (on open) | close, `url` + `url_url` + `url_action` show | hide | regex ("arriving from"),
 * `sources` + `sources_sources` [search, external, internal] (default all three), `logged_in` + `logged_in_users`
 * all | custom + `logged_in_roles` ("hide for logged in users"), `devices` + `devices_devices` (desktop + active
 * breakpoints, default desktop / mobile / tablet), `browsers` + `browsers_browsers` all | custom +
 * `browsers_browsers_options`, `schedule` + `schedule_timezone` / `schedule_start_date` / `schedule_end_date`.
 */
function convertTiming(t: Obj, out: Settings, note: Note): void {
  const known = new Set<string>();
  const v = (key: string): unknown => {
    known.add(key);
    return t[key] === undefined || t[key] === null ? TIMING_DEFAULTS[key] : t[key];
  };
  const on = (key: string): boolean => {
    const value = bool(v(key));
    if (!value) for (const k of Object.keys(t)) if (k.startsWith(`${key}_`)) known.add(k);
    return value;
  };

  if (on('page_views')) out.popup_rule_views = clamp(Math.round(numberOr(v('page_views_views'), 3)), 0, 1000);
  if (on('sessions')) out.popup_rule_sessions = clamp(Math.round(numberOr(v('sessions_sessions'), 2)), 0, 1000);

  let referrerUsed = false;
  if (on('url')) {
    const value = str(v('url_url'));
    const action = str(v('url_action')) || 'show';
    if (value === '') note('The "arriving from" rule has no URL and was left out.');
    else {
      referrerUsed = true;
      if (action === 'hide') {
        out.popup_rule_referrer = 'regex';
        out.popup_rule_referrer_value = `^(?!.*(?:${escapeRegex(value)}))`.slice(0, 300);
        note(`The "hide when arriving from ${value}" rule became a Zadex referrer regex that excludes it.`);
      } else {
        out.popup_rule_referrer = action === 'regex' ? 'regex' : 'contains';
        out.popup_rule_referrer_value = value.slice(0, 300);
      }
    }
  }

  if (on('sources')) {
    const raw = v('sources_sources');
    const list = (Array.isArray(raw) ? raw : typeof raw === 'string' && raw ? [raw] : []).map(String);
    const set = new Set(list.filter((s) => ['search', 'external', 'internal'].includes(s)));
    if (set.size === 0 || set.size === 3) {
      // Every source (or none chosen): no restriction.
    } else if (referrerUsed) {
      note(`The "arriving from ${[...set].join(' / ')}" rule was left out: Zadex has a single referrer rule, already used by the URL rule.`);
    } else if (set.size === 1 && set.has('search')) {
      out.popup_rule_referrer = 'regex';
      out.popup_rule_referrer_value = SEARCH_ENGINES;
      note('The "arriving from search engines" rule became a Zadex referrer regex matching the search engines Elementor checks (Google, Yahoo, Bing, Yandex, Baidu).');
    } else {
      note(`The "arriving from ${[...set].join(' / ')} links" rule has no Zadex equivalent (Zadex matches the referrer text only) and was left out.`);
    }
  }

  if (on('logged_in')) {
    const users = str(v('logged_in_users')) || 'all';
    const rolesRaw = v('logged_in_roles');
    if (users === 'all') out.popup_rule_login = 'out';
    else {
      const roles = Array.isArray(rolesRaw) ? rolesRaw.map(String).join(', ') : str(rolesRaw);
      note(`"Hide for logged in users" with roles (${roles || 'none chosen'}) has no Zadex equivalent: Zadex can only hide the popup for every logged in visitor, so it stays visible to everyone.`);
    }
  }

  if (on('devices')) {
    const raw = v('devices_devices');
    const list = (Array.isArray(raw) ? raw : typeof raw === 'string' && raw ? [raw] : []).map(String);
    const devices = ['desktop', 'tablet', 'mobile'].filter((d) => list.includes(d));
    const extra = list.filter((d) => !['desktop', 'tablet', 'mobile'].includes(d));
    if (devices.length) out.popup_rule_devices = devices;
    else note('The devices rule had no device Zadex knows and was left out.');
    if (extra.length) note(`Devices ${extra.join(', ')} have no Zadex equivalent (desktop, tablet, mobile).`);
  }

  if (on('times')) {
    const times = clamp(Math.round(numberOr(v('times_times'), 3)), 0, 1000);
    const period = str(v('times_period'));
    const count = str(v('times_count'));
    if (period === 'session') out.popup_rule_max_session = times;
    else {
      out.popup_rule_max_total = times;
      if (period) note(`"Show up to ${times} times per ${period}" became "${times} times in total" (Zadex counts per session or in total).`);
    }
    if (count === 'close') note('Elementor counted the shows when the popup was closed; Zadex counts them when it opens.');
  }

  if (on('browsers')) {
    const which = str(v('browsers_browsers')) || 'all';
    if (which !== 'all') {
      const raw = t.browsers_browsers_options;
      const list = Array.isArray(raw) ? raw.map(String).join(', ') : str(raw);
      note(`The browsers rule (${list || 'none chosen'}) has no Zadex equivalent and was left out.`);
    }
  }
  if (on('schedule')) {
    const start = str(t.schedule_start_date);
    const end = str(t.schedule_end_date);
    if (start || end) note(`The schedule rule (${start || '…'} to ${end || '…'}) has no Zadex equivalent and was left out: publish / unpublish the Zadex popup by hand.`);
  }
  for (const k of Object.keys(t)) if (k.startsWith('browsers_') || k.startsWith('schedule_')) known.add(k);

  const unknown = Object.keys(t).filter((k) => !known.has(k) && !isBlank(t[k]) && !TRIGGER_KEYS.test(k));
  if (unknown.length) note(`Popup advanced rules not carried over: ${unknown.sort().join(', ')}.`);
}

/** Keys of the trigger group (ignored by the timing leftovers when the server sent one flat object). */
const TRIGGER_KEYS = /^(page_load|scrolling|click|inactivity|exit_intent|adblock_detection)(_|$)/;
