// Admin app entry: "Zadex -> Import from Elementor" (task M7). Mounted by PHP on #zadex-migrator-app.
import { createApp } from 'vue';
import App from './App.vue';
import { readConfig } from './config';
import { setDictionary } from './i18n';
import { createApi } from './lib/api';
import { createMigrator } from './lib/migrate';
import { createStore } from './lib/store';
import './admin.css';

const el = document.getElementById('zadex-migrator-app');
if (el) {
  const config = readConfig();
  setDictionary(config.i18n);
  if (!el.closest('.wrap')) el.classList.add('wrap');
  const store = createStore(createMigrator(createApi(config)), { canTemplates: config.caps?.editThemeOptions !== false });
  createApp(App, { store }).mount(el);
}
