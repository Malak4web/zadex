/**
 * Boot config printed by PHP (wp_add_inline_script / wp_localize_script) as `window.ZADEX_MIGRATOR`.
 */
export interface MigratorConfig {
  /** REST base of this plugin, e.g. `https://site/wp-json/zadex-migrator/v1/` (or `?rest_route=/zadex-migrator/v1/`). */
  restUrl: string;
  /** REST base of Zadex, e.g. `https://site/wp-json/zadex/v1/`. */
  zadexRestUrl: string;
  /** `wp_create_nonce('wp_rest')`. */
  nonce: string;
  adminUrl: string;
  siteUrl: string;
  /** English source string -> translation (from PHP `__()`), optional. */
  i18n?: Record<string, string>;
  /** Text direction of the admin (falls back to the document `dir`). */
  rtl?: boolean;
  /** Capabilities of the current user. `editThemeOptions` gates templates and the global import. */
  caps?: { editThemeOptions?: boolean };
}

declare global {
  interface Window {
    ZADEX_MIGRATOR?: Partial<MigratorConfig>;
  }
}

export function readConfig(win: Window = window): MigratorConfig {
  const c = win.ZADEX_MIGRATOR ?? {};
  const origin = win.location?.origin ?? '';
  return {
    restUrl: c.restUrl ?? `${origin}/wp-json/zadex-migrator/v1/`,
    zadexRestUrl: c.zadexRestUrl ?? `${origin}/wp-json/zadex/v1/`,
    nonce: c.nonce ?? '',
    adminUrl: c.adminUrl ?? `${origin}/wp-admin/`,
    siteUrl: c.siteUrl ?? origin,
    i18n: c.i18n ?? {},
    rtl: c.rtl,
    caps: { editThemeOptions: c.caps?.editThemeOptions !== false },
  };
}
