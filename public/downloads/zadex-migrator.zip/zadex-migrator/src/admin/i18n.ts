/**
 * Tiny translation helper for the admin app. English strings are the source (and the keys); PHP passes a
 * dictionary of translations in `window.ZADEX_MIGRATOR.i18n`. Placeholders follow WordPress' sprintf style:
 * `%s` (sequential) and `%1$s` (positional), plus `%d`.
 */
let dict: Record<string, string> = {};

export function setDictionary(d: Record<string, string> | undefined | null): void {
  dict = d && typeof d === 'object' ? { ...d } : {};
}

export function t(source: string, ...args: Array<string | number>): string {
  const str = dict[source] || source;
  if (!args.length) return str;
  let i = 0;
  return str.replace(/%(?:(\d+)\$)?([sd])/g, (_m, pos: string | undefined) => {
    const idx = pos ? Number(pos) - 1 : i++;
    const v = args[idx];
    return v === undefined ? '' : String(v);
  });
}

/** Number formatting that follows the admin locale (Arabic-Indic digits when the browser locale asks for them). */
export function n(value: number): string {
  try {
    return new Intl.NumberFormat(document.documentElement.lang || undefined).format(value);
  } catch {
    return String(value);
  }
}
