<script setup lang="ts">
import { onMounted, provide } from 'vue';
import { t } from './i18n';
import { STORE_KEY, type Store } from './lib/store';
import DocumentsTable from './components/DocumentsTable.vue';
import ConfirmDialog from './components/ConfirmDialog.vue';
import GlobalsStep from './components/GlobalsStep.vue';
import MigrateAllDialog from './components/MigrateAllDialog.vue';
import PreviewDialog from './components/PreviewDialog.vue';
import ReportDialog from './components/ReportDialog.vue';
import StatusCard from './components/StatusCard.vue';

const props = defineProps<{ store: Store }>();
provide(STORE_KEY, props.store);

onMounted(() => {
  void props.store.refresh();
});
</script>

<template>
  <div class="zxm" data-testid="zxm-app">
    <h1 class="wp-heading-inline zxm-page-title">{{ t('Import from Elementor') }}</h1>
    <p class="zxm-lede">{{ t('Convert Elementor pages into Zadex drafts, compare them side by side, then apply. Elementor data is never changed, and every page can be rolled back.') }}</p>
    <hr class="wp-header-end" />

    <div class="zxm-notices" aria-live="polite" data-testid="zxm-notices">
      <div v-for="msg in store.state.notices" :key="msg.id" class="zxm-notice" :class="`zxm-notice--${msg.type}`" :role="msg.type === 'error' ? 'alert' : 'status'">
        <span class="zxm-notice__text">{{ msg.text }}</span>
        <button type="button" class="zxm-icon-btn zxm-icon-btn--sm" :aria-label="t('Dismiss')" @click="store.dismiss(msg.id)">
          <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" fill="none" /></svg>
        </button>
      </div>
    </div>

    <div v-if="store.state.status && !store.state.status.zadex.active" class="zxm-inline-error" role="alert" data-testid="zxm-no-zadex">
      {{ t('Zadex is not active. Activate the Zadex plugin to convert pages.') }}
    </div>

    <div class="zxm-top">
      <StatusCard />
      <!-- Global settings and templates need edit_theme_options (the server refuses them otherwise). -->
      <GlobalsStep v-if="store.state.canTemplates" />
    </div>

    <DocumentsTable />

    <MigrateAllDialog />
    <PreviewDialog />
    <ReportDialog />
    <ConfirmDialog />
  </div>
</template>
