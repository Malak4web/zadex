<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { n, t } from '../i18n';
import type { ElementStatus, ReportEntry } from '@/convert/types';
import type { Conversion } from '../lib/migrate';
import ScoreBadge from './ScoreBadge.vue';

/**
 * Conversion report: score, counts per status, one row per Elementor element (status, Elementor type, Zadex type,
 * dropped settings, notes) with a status filter, and document-level notes. Presentational: the parent passes the
 * conversion (works inside the report dialog and in tests).
 */
const props = defineProps<{ conversion: Conversion }>();

type Filter = ElementStatus | 'all' | 'issues';
const filter = ref<Filter>('all');
watch(() => props.conversion, () => (filter.value = 'all'));

const STATUS_LABELS: Record<ElementStatus, string> = {
  converted: t('Converted'),
  partial: t('Partial'),
  fallback: t('HTML fallback'),
  skipped: t('Skipped'),
};
const STATUS_HELP: Record<ElementStatus, string> = {
  converted: t('Everything carried over.'),
  partial: t('Some settings were dropped or approximated.'),
  fallback: t('Elementor’s rendered HTML was kept in an HTML widget.'),
  skipped: t('Nothing could be kept.'),
};
const ORDER: ElementStatus[] = ['converted', 'partial', 'fallback', 'skipped'];

const summary = computed(() => props.conversion.result.summary);
const entries = computed(() => props.conversion.result.report.entries);
const notes = computed(() => props.conversion.result.report.notes);
const filtered = computed<ReportEntry[]>(() => {
  if (filter.value === 'all') return entries.value;
  if (filter.value === 'issues') return entries.value.filter((e) => e.status !== 'converted');
  return entries.value.filter((e) => e.status === filter.value);
});
const issues = computed(() => entries.value.filter((e) => e.status !== 'converted').length);

function count(s: ElementStatus): number {
  return summary.value[s];
}
</script>

<template>
  <div class="zxm-report" data-testid="zxm-report">
    <div class="zxm-report__top">
      <div class="zxm-report__score">
        <ScoreBadge :score="summary.score" />
        <div>
          <div class="zxm-report__score-label">{{ t('Fidelity score') }}</div>
          <div class="zxm-muted">{{ t('%s elements', n(summary.elements)) }}</div>
        </div>
      </div>
      <ul class="zxm-report__counts" data-testid="zxm-report-counts">
        <li v-for="s in ORDER" :key="s" class="zxm-report__count" :class="`is-${s}`" :title="STATUS_HELP[s]" :data-testid="`zxm-report-count-${s}`">
          <span class="zxm-status-icon" :class="`zxm-status-icon--${s}`" aria-hidden="true" />
          <span>{{ STATUS_LABELS[s] }}</span>
          <strong>{{ n(count(s)) }}</strong>
        </li>
      </ul>
    </div>

    <ul v-if="notes.length || conversion.fallbackTypes.length" class="zxm-notes zxm-report__notes" data-testid="zxm-report-notes">
      <li v-for="(note, i) in notes" :key="`n${i}`">{{ t(note) }}</li>
      <li v-if="conversion.fallbackTypes.length">{{ t('Widgets without a Zadex equivalent: %s', conversion.fallbackTypes.join(', ')) }}</li>
    </ul>

    <div class="zxm-segmented zxm-segmented--sm" role="group" :aria-label="t('Filter by status')">
      <button type="button" class="zxm-segmented__btn" :class="{ 'is-active': filter === 'all' }" :aria-pressed="filter === 'all'" data-testid="zxm-report-filter-all" @click="filter = 'all'">
        {{ t('All') }} <span class="zxm-muted">{{ n(entries.length) }}</span>
      </button>
      <button type="button" class="zxm-segmented__btn" :class="{ 'is-active': filter === 'issues' }" :aria-pressed="filter === 'issues'" data-testid="zxm-report-filter-issues" @click="filter = 'issues'">
        {{ t('Needs attention') }} <span class="zxm-muted">{{ n(issues) }}</span>
      </button>
      <button
        v-for="s in ORDER"
        :key="s"
        type="button"
        class="zxm-segmented__btn"
        :class="{ 'is-active': filter === s }"
        :aria-pressed="filter === s"
        :disabled="!count(s)"
        :data-testid="`zxm-report-filter-${s}`"
        @click="filter = s"
      >
        {{ STATUS_LABELS[s] }}
      </button>
    </div>

    <div class="zxm-table-wrap">
      <table class="zxm-table zxm-report__table">
        <thead>
          <tr>
            <th scope="col">{{ t('Status') }}</th>
            <th scope="col">{{ t('Elementor') }}</th>
            <th scope="col">{{ t('Zadex') }}</th>
            <th scope="col">{{ t('Details') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="e in filtered" :key="e.source" :data-testid="`zxm-report-row-${e.source}`" :data-status="e.status">
            <td class="zxm-report__status">
              <span class="zxm-status-icon" :class="`zxm-status-icon--${e.status}`" aria-hidden="true" />
              <span>{{ STATUS_LABELS[e.status] }}</span>
            </td>
            <td><code class="zxm-code">{{ e.sourceType }}</code> <span class="zxm-muted">#{{ e.source }}</span></td>
            <td>
              <code v-if="e.targetType" class="zxm-code">{{ e.targetType }}</code>
              <span v-else class="zxm-muted">–</span>
            </td>
            <td class="zxm-report__details">
              <div v-if="e.dropped.length" class="zxm-dropped">
                <span class="zxm-dropped__label">{{ t('Not carried over:') }}</span>
                <code v-for="k in e.dropped" :key="k" class="zxm-chip">{{ k }}</code>
              </div>
              <ul v-if="e.notes.length" class="zxm-report__entry-notes">
                <li v-for="(note, i) in e.notes" :key="i">{{ t(note) }}</li>
              </ul>
              <span v-if="!e.dropped.length && !e.notes.length" class="zxm-muted">–</span>
            </td>
          </tr>
          <tr v-if="!filtered.length">
            <td colspan="4" class="zxm-empty" data-testid="zxm-report-empty">{{ entries.length ? t('No elements with this status.') : t('This document has no elements.') }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
