<script setup lang="ts">
import { computed } from 'vue';
import { t } from '../i18n';
import { useStore } from '../lib/store';
import ReportPanel from './ReportPanel.vue';
import ZxmDialog from './ZxmDialog.vue';

const store = useStore();
const report = computed(() => store.state.report);
const item = computed(() => (report.value ? store.state.items.find((i) => i.id === report.value?.id) : undefined));
const canPreview = computed(() => (report.value ? !!store.previewUrlsOf(report.value.id) : false));

function preview(): void {
  const id = report.value?.id;
  if (!id) return;
  store.closeReport();
  store.openPreview(id);
}

function convert(): void {
  const id = report.value?.id;
  if (!id) return;
  store.closeReport();
  void store.convert(id);
}
</script>

<template>
  <ZxmDialog v-if="report" :title="t('Report: %s', report.title)" size="md" testid="zxm-report-dialog" @close="store.closeReport()">
    <div v-if="report.loading" class="zxm-skeleton" aria-busy="true" data-testid="zxm-report-loading">{{ t('Converting in memory to build the report…') }}</div>
    <div v-else-if="report.error" class="zxm-inline-error" role="alert" data-testid="zxm-report-error">{{ report.error }}</div>
    <ReportPanel v-else-if="report.conversion" :conversion="report.conversion" />
    <template #footer>
      <span v-if="report.conversion && !('previewUrls' in report.conversion)" class="zxm-muted zxm-foot-note">{{ t('Preview only: nothing was saved.') }}</span>
      <button type="button" class="zxm-btn" data-testid="zxm-report-preview" :disabled="!canPreview" @click="preview">{{ t('Preview') }}</button>
      <button v-if="item?.migration.state !== 'applied'" type="button" class="zxm-btn zxm-btn--primary" data-testid="zxm-report-convert" @click="convert">
        {{ item?.migration.state === 'draft' ? t('Convert again') : t('Convert to draft') }}
      </button>
    </template>
  </ZxmDialog>
</template>
