<script setup lang="ts">
import { computed } from 'vue';
import { n, t } from '../i18n';
import { useStore } from '../lib/store';

const store = useStore();
const s = computed(() => store.state.status);

const checks = computed(() => {
  const st = s.value;
  if (!st) return [];
  return [
    {
      key: 'zadex',
      ok: st.zadex.active,
      label: t('Zadex'),
      detail: st.zadex.active ? (st.zadex.version ? t('Active, version %s', st.zadex.version) : t('Active')) : t('Not active'),
    },
    {
      key: 'elementor',
      ok: st.elementor.active,
      warn: !st.elementor.active,
      label: t('Elementor'),
      detail: st.elementor.active
        ? st.elementor.version
          ? t('Active, version %s', st.elementor.version)
          : t('Active')
        : t('Not active: pages still convert from their saved data, but the before preview and HTML fallbacks need Elementor.'),
    },
    {
      key: 'kit',
      ok: !!st.kit,
      warn: !st.kit,
      label: t('Global kit'),
      detail: st.kit ? t('Found (#%s)', st.kit.id) : t('No Elementor kit found'),
    },
  ];
});
</script>

<template>
  <section class="zxm-card zxm-status" data-testid="zxm-status" aria-labelledby="zxm-status-title">
    <header class="zxm-card__head">
      <h2 id="zxm-status-title" class="zxm-card__title">{{ t('Site status') }}</h2>
      <button type="button" class="zxm-icon-btn" :aria-label="t('Refresh status')" data-testid="zxm-status-refresh" :disabled="store.state.statusLoading" @click="store.loadStatus()">
        <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true"><path d="M13 8a5 5 0 1 1-1.6-3.7M13 3v3h-3" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round" /></svg>
      </button>
    </header>

    <div v-if="store.state.statusError" class="zxm-inline-error" role="alert" data-testid="zxm-status-error">{{ store.state.statusError }}</div>
    <div v-else-if="!s" class="zxm-skeleton" aria-busy="true">{{ t('Checking your site…') }}</div>
    <template v-else>
      <ul class="zxm-checks">
        <li v-for="c in checks" :key="c.key" class="zxm-check" :class="{ 'is-ok': c.ok, 'is-warn': !c.ok && c.warn, 'is-bad': !c.ok && !c.warn }" :data-testid="`zxm-status-${c.key}`">
          <span class="zxm-check__dot" aria-hidden="true" />
          <span class="zxm-check__label">{{ c.label }}</span>
          <span class="zxm-check__detail">{{ c.detail }}</span>
        </li>
      </ul>
      <dl class="zxm-counts">
        <div class="zxm-count" data-testid="zxm-count-documents">
          <dt>{{ s.counts.templates ? t('Elementor pages') : t('Elementor documents') }}</dt>
          <dd>{{ n(s.counts.documents) }}</dd>
        </div>
        <div class="zxm-count" data-testid="zxm-count-drafts">
          <dt>{{ t('Drafts') }}</dt>
          <dd>{{ n(s.counts.drafts) }}</dd>
        </div>
        <div class="zxm-count" data-testid="zxm-count-migrated">
          <dt>{{ t('Applied') }}</dt>
          <dd>{{ n(s.counts.migrated) }}</dd>
        </div>
      </dl>
      <dl v-if="s.counts.templates && store.state.canTemplates" class="zxm-counts zxm-counts--templates" data-testid="zxm-count-templates">
        <div class="zxm-count" data-testid="zxm-count-templates-documents">
          <dt>{{ t('Elementor templates') }}</dt>
          <dd>{{ n(s.counts.templates.documents) }}</dd>
        </div>
        <div class="zxm-count" data-testid="zxm-count-templates-drafts">
          <dt>{{ t('Drafts') }}</dt>
          <dd>{{ n(s.counts.templates.drafts) }}</dd>
        </div>
        <div class="zxm-count" data-testid="zxm-count-templates-migrated">
          <dt>{{ t('Applied') }}</dt>
          <dd>{{ n(s.counts.templates.migrated) }}</dd>
        </div>
      </dl>
    </template>
  </section>
</template>
