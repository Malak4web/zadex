<script setup lang="ts">
import { computed } from 'vue';
import { t } from '../i18n';
import { hasZadexView } from '../lib/templates';
import type { PageItem } from '../lib/types';
import { useStore } from '../lib/store';

/** Convert / Preview / Report / Apply / Roll back for one row (pages and templates tabs). */
const props = defineProps<{ item: PageItem }>();

const store = useStore();
const st = store.state;

const busy = computed(() => !!st.rows[props.item.id]?.busy || (!!st.bulk && !st.bulk.finished) || st.migrateAll?.phase === 'running');
const disabled = computed(() => busy.value);
const previewUrls = computed(() => store.previewUrlsOf(props.item.id));
/** Saved templates have no Zadex view: no Preview button. */
const viewable = computed(() => hasZadexView(props.item));
/** An applied row converted again in this session: its new draft goes live on the next apply. */
const reapply = computed(() => props.item.migration.state === 'applied' && !!(st.rows[props.item.id]?.conversion as { previewUrls?: unknown } | null | undefined)?.previewUrls);
</script>

<template>
  <div class="zxm-actions">
    <button
      type="button"
      class="zxm-btn zxm-btn--sm"
      :class="{ 'zxm-btn--primary': item.migration.state === 'none' }"
      :disabled="disabled"
      :data-testid="`zxm-convert-${item.id}`"
      @click="store.convert(item.id)"
    >
      {{ item.migration.state === 'none' ? t('Convert') : t('Convert again') }}
    </button>
    <button
      v-if="viewable"
      type="button"
      class="zxm-btn zxm-btn--sm"
      :disabled="disabled || !previewUrls"
      :title="previewUrls ? '' : t('Convert first to preview')"
      :data-testid="`zxm-preview-${item.id}`"
      @click="store.openPreview(item.id)"
    >
      {{ t('Preview') }}
    </button>
    <button type="button" class="zxm-btn zxm-btn--sm" :disabled="disabled" :data-testid="`zxm-report-${item.id}`" @click="store.openReport(item.id)">{{ t('Report') }}</button>
    <button v-if="item.migration.state === 'draft' || reapply" type="button" class="zxm-btn zxm-btn--sm zxm-btn--primary" :disabled="disabled" :data-testid="`zxm-apply-${item.id}`" @click="store.apply(item.id)">
      {{ reapply ? t('Apply again') : t('Apply') }}
    </button>
    <button v-if="item.migration.state === 'applied'" type="button" class="zxm-btn zxm-btn--sm zxm-btn--danger-ghost" :disabled="busy" :data-testid="`zxm-rollback-${item.id}`" @click="store.rollback(item.id)">
      {{ t('Roll back') }}
    </button>
  </div>
</template>
