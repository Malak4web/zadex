<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { t } from '../i18n';
import { errorMessage } from '../lib/api';
import type { ItemChange, KitImportItem, KitReport } from '../lib/globals';
import type { GlobalsPreview } from '../lib/migrate';
import { useStore } from '../lib/store';

const store = useStore();

const preview = ref<GlobalsPreview | null>(null);
const loading = ref(false);
const error = ref('');
const busy = ref<'' | 'import' | 'restore'>('');
const imported = ref<KitReport | null>(null);
const restored = ref(false);

const kitId = computed(() => store.state.status?.kit?.id ?? null);
const report = computed<KitReport | null>(() => imported.value ?? preview.value?.conversion?.report ?? null);
const colors = computed(() => report.value?.colors ?? []);
const fonts = computed(() => report.value?.fonts ?? []);
const notes = computed(() => report.value?.notes ?? []);
const canImport = computed(() => !!preview.value?.available && !!kitId.value && !busy.value);

async function load(): Promise<void> {
  if (!store.state.status) return;
  loading.value = true;
  error.value = '';
  try {
    preview.value = await store.migrator.previewGlobals(kitId.value);
  } catch (e) {
    error.value = errorMessage(e);
  } finally {
    loading.value = false;
  }
}

watch(() => store.state.status, (s, old) => {
  if (s && (!old || old.kit?.id !== s.kit?.id || !preview.value)) void load();
}, { immediate: true });

const CHANGE_LABELS: Record<ItemChange, string> = { new: t('New'), changed: t('Updated'), same: '' };

function fontFamily(f: KitImportItem<{ family: string; weight?: string }>): string {
  return f.value?.family ?? '';
}
function fontWeight(f: KitImportItem<{ family: string; weight?: string }>): string {
  return f.value?.weight ?? '';
}

async function doImport(): Promise<void> {
  if (!kitId.value) return;
  const ok = await store.confirm({
    title: t('Import global colors and fonts?'),
    message: t('Elementor’s global colors, fonts, layout and breakpoints are written into the Zadex global settings. The current Zadex settings are backed up first and can be restored.'),
    confirmLabel: t('Import'),
  });
  if (!ok) return;
  busy.value = 'import';
  error.value = '';
  try {
    const out = await store.migrator.importGlobals(kitId.value);
    imported.value = out.report;
    restored.value = false;
    store.notify('success', t('Global colors and fonts imported into Zadex.'));
  } catch (e) {
    error.value = errorMessage(e);
    store.notify('error', t('Global import failed: %s', error.value));
  } finally {
    busy.value = '';
  }
}

async function doRestore(): Promise<void> {
  const ok = await store.confirm({
    title: t('Restore previous Zadex globals?'),
    message: t('The Zadex global settings saved before the last import are put back.'),
    confirmLabel: t('Restore'),
    danger: true,
  });
  if (!ok) return;
  busy.value = 'restore';
  error.value = '';
  try {
    await store.migrator.restoreGlobals();
    imported.value = null;
    restored.value = true;
    store.notify('success', t('Previous Zadex global settings restored.'));
    void load();
  } catch (e) {
    error.value = errorMessage(e);
    store.notify('error', t('Restore failed: %s', error.value));
  } finally {
    busy.value = '';
  }
}
</script>

<template>
  <section class="zxm-card zxm-globals" data-testid="zxm-globals" aria-labelledby="zxm-globals-title">
    <header class="zxm-card__head">
      <div>
        <h2 id="zxm-globals-title" class="zxm-card__title">{{ t('Global colors and fonts') }}</h2>
        <p class="zxm-card__sub">{{ t('Import the Elementor kit first so converted pages keep pointing at your global styles.') }}</p>
      </div>
    </header>

    <div v-if="error" class="zxm-inline-error" role="alert" data-testid="zxm-globals-error">{{ error }}</div>

    <div v-if="!store.state.status || loading" class="zxm-skeleton" aria-busy="true">{{ t('Reading the Elementor kit…') }}</div>
    <p v-else-if="preview && !preview.available" class="zxm-empty-line" data-testid="zxm-globals-unavailable">{{ t('Global import is not available in this version yet.') }}</p>
    <p v-else-if="!kitId || (preview && !preview.hasKit)" class="zxm-empty-line" data-testid="zxm-globals-nokit">{{ t('No Elementor kit was found, so there is nothing to import. Pages still convert.') }}</p>
    <template v-else-if="report">
      <p v-if="imported" class="zxm-done-line" data-testid="zxm-globals-imported">{{ t('Imported. These are now in Zadex:') }}</p>
      <p v-else class="zxm-card__sub zxm-globals__summary" data-testid="zxm-globals-summary">
        {{ t('The kit brings %1$s colors and %2$s fonts. After the import Zadex will have:', report.imported.colors, report.imported.fonts) }}
      </p>
      <div class="zxm-group">
        <h3 class="zxm-group__label">{{ t('Colors') }} <span class="zxm-muted">{{ colors.length }}</span></h3>
        <ul v-if="colors.length" class="zxm-swatches" data-testid="zxm-globals-colors">
          <li v-for="c in colors" :key="c.id" class="zxm-swatch" :class="`is-${c.change}`" :title="`${c.label} · ${c.value}`">
            <span class="zxm-swatch__chip" :style="{ background: c.value }" aria-hidden="true" />
            <span class="zxm-swatch__label">{{ c.label }} <span v-if="c.change !== 'same'" class="zxm-change" :class="`zxm-change--${c.change}`">{{ CHANGE_LABELS[c.change] }}</span></span>
            <code class="zxm-swatch__value">{{ c.value }}</code>
          </li>
        </ul>
        <p v-else class="zxm-muted">{{ t('No global colors in the kit.') }}</p>
      </div>
      <div class="zxm-group">
        <h3 class="zxm-group__label">{{ t('Fonts') }} <span class="zxm-muted">{{ fonts.length }}</span></h3>
        <ul v-if="fonts.length" class="zxm-fonts" data-testid="zxm-globals-fonts">
          <li v-for="f in fonts" :key="f.id" class="zxm-font">
            <span class="zxm-font__label">{{ f.label }} <span v-if="f.change !== 'same'" class="zxm-change" :class="`zxm-change--${f.change}`">{{ CHANGE_LABELS[f.change] }}</span></span>
            <span class="zxm-font__family">{{ fontFamily(f) || t('Default') }}<template v-if="fontWeight(f)"> · {{ fontWeight(f) }}</template></span>
          </li>
        </ul>
        <p v-else class="zxm-muted">{{ t('No global fonts in the kit.') }}</p>
      </div>
      <ul v-if="notes.length" class="zxm-notes" data-testid="zxm-globals-notes">
        <li v-for="(note, i) in notes" :key="i">{{ t(note) }}</li>
      </ul>
    </template>

    <p v-if="restored" class="zxm-done-line" data-testid="zxm-globals-restored">{{ t('Previous Zadex global settings restored.') }}</p>

    <footer class="zxm-card__foot">
      <button type="button" class="zxm-btn zxm-btn--primary" data-testid="zxm-globals-import" :disabled="!canImport" :aria-busy="busy === 'import'" @click="doImport">
        {{ busy === 'import' ? t('Importing…') : imported ? t('Import again') : t('Import globals') }}
      </button>
      <button type="button" class="zxm-btn" data-testid="zxm-globals-restore" :disabled="!!busy" :aria-busy="busy === 'restore'" @click="doRestore">
        {{ busy === 'restore' ? t('Restoring…') : t('Restore previous') }}
      </button>
    </footer>
  </section>
</template>
