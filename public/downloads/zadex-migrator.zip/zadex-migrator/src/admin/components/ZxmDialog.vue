<script setup lang="ts">
import { nextTick, onBeforeUnmount, onMounted, ref } from 'vue';
import { t } from '../i18n';

/**
 * Accessible modal shell: role=dialog + aria-modal, Escape closes, focus moves inside on open, Tab is kept
 * inside, and focus returns to the opener on close. `size`: sm (confirm), md (report), xl (preview).
 */
const props = withDefaults(defineProps<{ title: string; size?: 'sm' | 'md' | 'xl'; testid?: string; labelledby?: string }>(), {
  size: 'md',
  testid: 'zxm-dialog',
  labelledby: '',
});
const emit = defineEmits<{ close: [] }>();

const panel = ref<HTMLElement | null>(null);
const titleId = props.labelledby || `zxm-dlg-${Math.random().toString(36).slice(2, 8)}`;
let opener: Element | null = null;

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), iframe, [tabindex]:not([tabindex="-1"])';

function focusables(): HTMLElement[] {
  return panel.value ? Array.from(panel.value.querySelectorAll<HTMLElement>(FOCUSABLE)) : [];
}

function onKeydown(e: KeyboardEvent): void {
  if (e.key === 'Escape') {
    e.preventDefault();
    emit('close');
    return;
  }
  if (e.key !== 'Tab') return;
  const list = focusables();
  if (!list.length) return;
  const first = list[0];
  const last = list[list.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
}

onMounted(async () => {
  opener = document.activeElement;
  await nextTick();
  const auto = panel.value?.querySelector<HTMLElement>('[data-autofocus]:not([disabled])');
  (auto ?? focusables()[0] ?? panel.value)?.focus();
});

onBeforeUnmount(() => {
  if (opener instanceof HTMLElement) opener.focus();
});
</script>

<template>
  <div class="zxm-scrim" @mousedown.self="emit('close')">
    <div
      ref="panel"
      class="zxm-dialog"
      :class="`zxm-dialog--${size}`"
      role="dialog"
      aria-modal="true"
      :aria-labelledby="titleId"
      tabindex="-1"
      :data-testid="testid"
      @keydown="onKeydown"
    >
      <header class="zxm-dialog__head">
        <h2 :id="titleId" class="zxm-dialog__title">{{ title }}</h2>
        <div class="zxm-dialog__tools"><slot name="tools" /></div>
        <button type="button" class="zxm-icon-btn" :aria-label="t('Close')" :data-testid="`${testid}-close`" @click="emit('close')">
          <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" fill="none" /></svg>
        </button>
      </header>
      <div class="zxm-dialog__body"><slot /></div>
      <footer v-if="$slots.footer" class="zxm-dialog__foot"><slot name="footer" /></footer>
    </div>
  </div>
</template>
