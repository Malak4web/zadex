<script setup lang="ts">
import { t } from '../i18n';
import { useStore } from '../lib/store';
import ZxmDialog from './ZxmDialog.vue';

const store = useStore();

function answer(ok: boolean): void {
  store.state.confirm?.resolve(ok);
}
</script>

<template>
  <ZxmDialog v-if="store.state.confirm" :title="store.state.confirm.title" size="sm" testid="zxm-confirm" @close="answer(false)">
    <p class="zxm-confirm__msg">{{ store.state.confirm.message }}</p>
    <template #footer>
      <button type="button" class="zxm-btn" data-testid="zxm-confirm-cancel" @click="answer(false)">{{ t('Cancel') }}</button>
      <button
        type="button"
        class="zxm-btn"
        :class="store.state.confirm.danger ? 'zxm-btn--danger' : 'zxm-btn--primary'"
        data-testid="zxm-confirm-ok"
        data-autofocus
        @click="answer(true)"
      >
        {{ store.state.confirm.confirmLabel }}
      </button>
    </template>
  </ZxmDialog>
</template>
