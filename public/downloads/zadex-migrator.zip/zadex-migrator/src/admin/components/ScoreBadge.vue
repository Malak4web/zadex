<script setup lang="ts">
import { computed } from 'vue';
import { n, t } from '../i18n';

/** Fidelity score 0..100: >= 90 good, >= 70 fair, else low. `null` shows a dash (not converted yet). */
const props = defineProps<{ score: number | null | undefined }>();

const level = computed(() => {
  const s = props.score;
  if (s === null || s === undefined) return 'none';
  return s >= 90 ? 'good' : s >= 70 ? 'fair' : 'low';
});
const label = computed(() => (props.score === null || props.score === undefined ? t('Not converted') : t('Score %s out of 100', props.score)));
</script>

<template>
  <span class="zxm-score" :class="`zxm-score--${level}`" :title="label" :aria-label="label" data-testid="zxm-score">
    {{ score === null || score === undefined ? '–' : n(score) }}
  </span>
</template>
