<script setup lang="ts">
import { computed } from 'vue';
import { n, t } from '../i18n';
import { migrationTotals, STEP_ORDER, type MigrateStep, type MigrateStepKey } from '../lib/migrate-all';
import { useStore } from '../lib/store';
import { templateTypeLabel } from '../lib/templates';
import ScoreBadge from './ScoreBadge.vue';
import ZxmDialog from './ZxmDialog.vue';

/** "Migrate everything": plan -> ordered run with per-step progress -> summary with report links. */
const store = useStore();
const run = computed(() => store.state.migrateAll);
const steps = computed(() => run.value?.steps ?? null);
const plan = computed(() => run.value?.plan ?? null);
const running = computed(() => run.value?.phase === 'running');
const finished = computed(() => run.value?.phase === 'finished');
const totals = computed(() => (steps.value ? migrationTotals(steps.value) : null));
/** Steps the user may run (templates and globals need `edit_theme_options`; without it they are hidden). */
const visibleSteps = computed(() => (steps.value ? STEP_ORDER.filter((k) => steps.value![k].reason !== 'no-permission') : []));
const toProcess = computed(() => (steps.value ? STEP_ORDER.reduce((sum, k) => sum + (k === 'globals' ? 0 : steps.value![k].total), 0) : 0));

const TITLES: Record<MigrateStepKey, string> = {
  globals: t('Import global colors and fonts'),
  library: t('Saved templates and loop items'),
  popups: t('Popups'),
  theme: t('Theme templates'),
  pages: t('Pages'),
};

function description(key: MigrateStepKey, step: MigrateStep): string {
  if (key === 'globals') return t('The Elementor kit goes into the Zadex global settings (backed up first).');
  if (key === 'library') return t('%s to convert and apply. They go first so theme templates and pages can point at them; their Elementor templates stay published.', n(step.total));
  if (key === 'popups') return t('%s to convert and apply. They go before theme templates and pages, which link to them; each goes live with its display conditions and triggers and its Elementor popup is set to draft.', n(step.total));
  if (key === 'theme') return t('%s to convert and apply. Headers, footers, singles and archives go live with their display conditions; their Elementor templates are set to draft.', n(step.total));
  return step.apply ? t('%s to convert and apply.', n(step.total)) : t('%s to convert into drafts. Visitors keep seeing Elementor.', n(step.total));
}

function reasonText(step: MigrateStep): string {
  switch (step.reason) {
    case 'no-kit':
      return t('No Elementor kit, nothing to import.');
    case 'imported':
      return t('Already imported.');
    case 'unavailable':
      return t('Not available in this version.');
    case 'no-permission':
      return t('Needs permission to edit theme options.');
    case 'empty':
      return t('Nothing to migrate.');
    case 'cancelled':
      return t('Cancelled.');
    default:
      return '';
  }
}

function statusText(step: MigrateStep): string {
  if (step.status === 'pending') return t('Waiting');
  if (step.status === 'running') return step.key === 'globals' ? t('Importing…') : t('%1$s of %2$s', n(step.done), n(step.total));
  if (step.status === 'skipped') return t('Skipped');
  if (step.status === 'cancelled') return t('Cancelled');
  if (step.failed) return step.key === 'globals' ? t('Failed') : t('Done, %s failed', n(step.failed));
  return t('Done');
}

function percent(step: MigrateStep): number {
  return step.total ? Math.round((step.done / step.total) * 100) : 0;
}

const skippedCount = computed(() => plan.value?.skipped.length ?? 0);

function close(): void {
  store.closeMigrateAll();
}
</script>

<template>
  <ZxmDialog v-if="run" :title="t('Migrate everything')" size="md" testid="zxm-migrate" @close="close">
    <div v-if="run.phase === 'planning'" class="zxm-skeleton" aria-busy="true" data-testid="zxm-migrate-planning">{{ t('Looking at your site…') }}</div>

    <div v-else-if="run.phase === 'error'" class="zxm-inline-error" role="alert" data-testid="zxm-migrate-plan-error">
      {{ run.error }}
      <button type="button" class="zxm-link-btn" data-testid="zxm-migrate-retry" @click="store.openMigrateAll()">{{ t('Try again') }}</button>
    </div>

    <template v-else-if="steps">
      <p v-if="run.phase === 'ready' && plan?.templatesAllowed !== false" class="zxm-migrate__intro">
        {{ t('Runs in this order, so templates exist before the documents that use them. Templates are applied, which puts them live on your site; Elementor data is never changed and every item can be rolled back.') }}
      </p>
      <p v-else-if="run.phase === 'ready'" class="zxm-migrate__intro" data-testid="zxm-migrate-pages-only">
        {{ t('Your account can migrate pages only. Templates and global settings need a user who can edit theme options.') }}
      </p>

      <ol class="zxm-steps" aria-live="polite">
        <li v-for="(key, index) in visibleSteps" :key="key" class="zxm-step" :class="`is-${steps[key].status}`" :data-testid="`zxm-migrate-step-${key}`" :data-status="steps[key].status">
          <span class="zxm-step__num" aria-hidden="true">{{ n(index + 1) }}</span>
          <div class="zxm-step__body">
            <div class="zxm-step__head">
              <h3 class="zxm-step__title">{{ TITLES[key] }}</h3>
              <span class="zxm-step__status">
                <span v-if="steps[key].status === 'running'" class="zxm-spinner" aria-hidden="true" />
                {{ statusText(steps[key]) }}
              </span>
            </div>
            <p class="zxm-step__desc">{{ steps[key].reason ? reasonText(steps[key]) : description(key, steps[key]) }}</p>
            <p v-if="steps[key].error" class="zxm-row-error" role="alert" :data-testid="`zxm-migrate-step-error-${key}`">{{ steps[key].error }}</p>
            <label v-if="key === 'pages' && steps.pages.total" class="zxm-check-line">
              <input
                type="checkbox"
                :checked="run.applyPages"
                :disabled="run.phase !== 'ready'"
                data-testid="zxm-migrate-apply-pages"
                @change="store.setMigrateApplyPages(($event.target as HTMLInputElement).checked)"
              />
              <span>{{ t('Also apply pages') }}</span>
            </label>
            <div
              v-if="key !== 'globals' && steps[key].total && (steps[key].status === 'running' || steps[key].done > 0)"
              class="zxm-progress"
              role="progressbar"
              :aria-valuenow="percent(steps[key])"
              aria-valuemin="0"
              aria-valuemax="100"
              :aria-label="TITLES[key]"
            >
              <div class="zxm-progress__bar" :style="{ inlineSize: `${percent(steps[key])}%` }" />
            </div>
          </div>
        </li>
      </ol>

      <p v-if="run.phase === 'ready' && skippedCount" class="zxm-muted zxm-migrate__skipped" data-testid="zxm-migrate-skipped">
        {{ t('%s skipped: already applied or unknown template types.', n(skippedCount)) }}
      </p>
      <p v-if="run.phase === 'ready' && !toProcess && steps.globals.status === 'skipped'" class="zxm-empty-line" data-testid="zxm-migrate-nothing">{{ t('Everything is already migrated.') }}</p>

      <section v-if="finished && totals" class="zxm-migrate__summary" data-testid="zxm-migrate-summary" aria-labelledby="zxm-migrate-summary-title">
        <h3 id="zxm-migrate-summary-title" class="zxm-group__label">{{ run.cancelled ? t('Stopped. Finished items are kept.') : t('Finished') }}</h3>
        <dl class="zxm-counts">
          <div class="zxm-count" data-testid="zxm-migrate-count-converted">
            <dt>{{ t('Converted') }}</dt>
            <dd>{{ n(totals.converted) }}</dd>
          </div>
          <div class="zxm-count" data-testid="zxm-migrate-count-applied">
            <dt>{{ t('Applied') }}</dt>
            <dd>{{ n(totals.applied) }}</dd>
          </div>
          <div class="zxm-count" data-testid="zxm-migrate-count-failed">
            <dt>{{ t('Failed') }}</dt>
            <dd>{{ n(totals.failed) }}</dd>
          </div>
        </dl>
        <template v-for="key in STEP_ORDER" :key="key">
          <details v-if="key !== 'globals' && steps[key].items.length" class="zxm-migrate__group" :open="steps[key].failed > 0">
            <summary>{{ TITLES[key] }} <span class="zxm-muted">{{ n(steps[key].items.length) }}</span></summary>
            <ul class="zxm-migrate__items">
              <li v-for="r in steps[key].items" :key="r.id" class="zxm-migrate__item" :data-testid="`zxm-migrate-item-${r.id}`">
                <span class="zxm-migrate__name">
                  {{ r.title || t('(no title)') }}
                  <span v-if="r.templateType" class="zxm-muted">· {{ templateTypeLabel(r.templateType) }}</span>
                </span>
                <span v-if="r.error" class="zxm-row-error" :data-testid="`zxm-migrate-error-${r.id}`">{{ r.error }}</span>
                <span v-else class="zxm-muted">{{ r.applied ? t('Applied') : t('Draft') }}</span>
                <ScoreBadge :score="r.score" />
                <button v-if="r.converted" type="button" class="zxm-btn zxm-btn--sm" :data-testid="`zxm-migrate-report-${r.id}`" @click="store.openReport(r.id)">{{ t('Report') }}</button>
              </li>
            </ul>
          </details>
        </template>
      </section>
    </template>

    <template #footer>
      <template v-if="running">
        <span class="zxm-muted zxm-foot-note" role="status">{{ run.stopping ? t('Stopping after the items in progress…') : t('Keep this page open until it finishes.') }}</span>
        <button type="button" class="zxm-btn" data-testid="zxm-migrate-cancel" :disabled="run.stopping" @click="store.cancelMigrateAll()">{{ run.stopping ? t('Stopping…') : t('Cancel') }}</button>
      </template>
      <template v-else-if="finished || run.phase === 'error'">
        <button type="button" class="zxm-btn zxm-btn--primary" data-testid="zxm-migrate-done" data-autofocus @click="close">{{ t('Close') }}</button>
      </template>
      <template v-else>
        <button type="button" class="zxm-btn" data-testid="zxm-migrate-dismiss" @click="close">{{ t('Cancel') }}</button>
        <button
          type="button"
          class="zxm-btn zxm-btn--primary"
          data-testid="zxm-migrate-start"
          data-autofocus
          :disabled="run.phase !== 'ready' || (!toProcess && steps?.globals.status === 'skipped')"
          @click="store.startMigrateAll()"
        >
          {{ t('Start migration') }}
        </button>
      </template>
    </template>
  </ZxmDialog>
</template>
