<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue';
import { t } from '../i18n';
import { useStore } from '../lib/store';
import ZxmDialog from './ZxmDialog.vue';

/**
 * Side-by-side preview: Elementor original and Zadex draft, each in an iframe rendered at the chosen device width
 * (desktop 1280 / tablet 768 / mobile 390) and scaled down to fit its column.
 */
const store = useStore();

const DEVICES = [
  { key: 'desktop', width: 1280, label: t('Desktop') },
  { key: 'tablet', width: 768, label: t('Tablet') },
  { key: 'mobile', width: 390, label: t('Mobile') },
] as const;
type DeviceKey = (typeof DEVICES)[number]['key'];

const device = ref<DeviceKey>('desktop');
const deviceWidth = computed(() => DEVICES.find((d) => d.key === device.value)?.width ?? 1280);
const preview = computed(() => store.state.preview);

const stage = ref<HTMLElement | null>(null);
const paneSize = ref({ w: 600, h: 600 });
const loaded = ref<Record<string, boolean>>({});
let ro: ResizeObserver | null = null;

function measure(): void {
  const pane = stage.value?.querySelector<HTMLElement>('.zxm-preview__frame');
  if (pane) paneSize.value = { w: pane.clientWidth || 600, h: pane.clientHeight || 600 };
}

onMounted(() => {
  measure();
  if (typeof ResizeObserver !== 'undefined' && stage.value) {
    ro = new ResizeObserver(() => measure());
    ro.observe(stage.value);
  }
});
onBeforeUnmount(() => ro?.disconnect());

const scale = computed(() => Math.min(1, paneSize.value.w / deviceWidth.value));
const rtl = typeof document !== 'undefined' && document.documentElement.dir === 'rtl';
const frameStyle = computed(() => ({
  width: `${deviceWidth.value}px`,
  height: `${Math.round(paneSize.value.h / scale.value)}px`,
  transform: `scale(${scale.value})`,
  transformOrigin: rtl ? 'top right' : 'top left',
}));
const percent = computed(() => Math.round(scale.value * 100));

const panes = computed(() => {
  const p = preview.value;
  if (!p) return [];
  return [
    { key: 'elementor', label: t('Elementor (original)'), url: p.urls.elementor },
    { key: 'zadex', label: t('Zadex (draft)'), url: p.urls.zadex },
  ];
});

function close(): void {
  loaded.value = {};
  store.closePreview();
}
</script>

<template>
  <ZxmDialog v-if="preview" :title="t('Preview: %s', preview.title)" size="xl" testid="zxm-preview" @close="close">
    <template #tools>
      <div class="zxm-segmented" role="group" :aria-label="t('Preview width')">
        <button
          v-for="d in DEVICES"
          :key="d.key"
          type="button"
          class="zxm-segmented__btn"
          :class="{ 'is-active': device === d.key }"
          :aria-pressed="device === d.key"
          :data-testid="`zxm-preview-device-${d.key}`"
          @click="device = d.key"
        >
          {{ d.label }} <span class="zxm-muted">{{ d.width }}</span>
        </button>
      </div>
      <span class="zxm-muted zxm-preview__zoom" data-testid="zxm-preview-zoom">{{ percent }}%</span>
    </template>
    <div ref="stage" class="zxm-preview">
      <section v-for="p in panes" :key="p.key" class="zxm-preview__pane" :data-testid="`zxm-preview-pane-${p.key}`">
        <header class="zxm-preview__bar">
          <span class="zxm-preview__label">{{ p.label }}</span>
          <a :href="p.url" target="_blank" rel="noopener" class="zxm-link-btn" :data-testid="`zxm-preview-open-${p.key}`">
            {{ t('Open in new tab') }}<span class="screen-reader-text"> ({{ p.label }})</span>
          </a>
        </header>
        <div class="zxm-preview__frame">
          <div v-if="!loaded[p.key]" class="zxm-preview__loading" aria-hidden="true"><span class="zxm-spinner" /></div>
          <iframe
            :src="p.url"
            :title="p.label"
            :style="frameStyle"
            class="zxm-preview__iframe"
            :data-testid="`zxm-preview-iframe-${p.key}`"
            @load="loaded[p.key] = true"
          />
        </div>
      </section>
    </div>
  </ZxmDialog>
</template>
