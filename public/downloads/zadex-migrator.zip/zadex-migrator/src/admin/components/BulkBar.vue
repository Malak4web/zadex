<script setup lang="ts">
import { computed } from 'vue';
import { n, t } from '../i18n';
import { useStore } from '../lib/store';

const store = useStore();
const st = store.state;

const selectedCount = computed(() => st.selected.length);
/** Only drafts can be applied. */
const applicable = computed(() => st.items.filter((i) => st.selected.includes(i.id) && i.migration.state === 'draft').map((i) => i.id));
const bulk = computed(() => st.bulk);
const running = computed(() => !!bulk.value && !bulk.value.finished);
const percent = computed(() => {
  const b = bulk.value;
  return b && b.progress.total ? Math.round((b.progress.done / b.progress.total) * 100) : 0;
});
const visible = computed(() => selectedCount.value > 0 || !!bulk.value);
</script>

<template>
  <div v-if="visible" class="zxm-bulk" :class="{ 'is-running': running }" data-testid="zxm-bulkbar">
    <template v-if="bulk">
      <div class="zxm-bulk__progress">
        <span class="zxm-bulk__label" role="status" aria-live="polite" data-testid="zxm-bulk-status">
          <template v-if="running">{{ bulk.kind === 'convert' ? t('Converting %1$s of %2$s…', n(bulk.progress.done + bulk.progress.running.length), n(bulk.progress.total)) : t('Applying %1$s of %2$s…', n(bulk.progress.done + bulk.progress.running.length), n(bulk.progress.total)) }}</template>
          <template v-else-if="bulk.cancelled">{{ t('Stopped after %1$s of %2$s.', n(bulk.progress.done), n(bulk.progress.total)) }}</template>
          <template v-else>{{ t('Done: %1$s of %2$s.', n(bulk.progress.done), n(bulk.progress.total)) }}</template>
          <template v-if="bulk.progress.failed"> {{ t('%s failed.', n(bulk.progress.failed)) }}</template>
        </span>
        <div class="zxm-progress" role="progressbar" :aria-valuenow="percent" aria-valuemin="0" aria-valuemax="100" :aria-label="t('Progress')">
          <div class="zxm-progress__bar" :style="{ inlineSize: `${percent}%` }" />
        </div>
      </div>
      <button v-if="running" type="button" class="zxm-btn zxm-btn--sm" data-testid="zxm-bulk-cancel" :disabled="bulk.stopping" @click="store.cancelBulk()">
        {{ bulk.stopping ? t('Stopping…') : t('Cancel') }}
      </button>
      <button v-else type="button" class="zxm-btn zxm-btn--sm" data-testid="zxm-bulk-dismiss" @click="store.clearBulk()">{{ t('Dismiss') }}</button>
    </template>
    <template v-else>
      <span class="zxm-bulk__label" data-testid="zxm-bulk-count">{{ t('%s selected', n(selectedCount)) }}</span>
      <div class="zxm-bulk__actions">
        <button type="button" class="zxm-btn zxm-btn--sm zxm-btn--primary" data-testid="zxm-bulk-convert" @click="store.bulkConvert()">{{ t('Convert selected') }}</button>
        <button type="button" class="zxm-btn zxm-btn--sm" data-testid="zxm-bulk-apply" :disabled="!applicable.length" :title="applicable.length ? '' : t('Only drafts can be applied')" @click="store.bulkApply(applicable)">
          {{ applicable.length ? t('Apply %s drafts', n(applicable.length)) : t('Apply selected') }}
        </button>
        <button type="button" class="zxm-link-btn" data-testid="zxm-bulk-clear" @click="store.selectAll(false)">{{ t('Clear selection') }}</button>
      </div>
    </template>
  </div>
</template>
