<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from 'vue';
import { n, t } from '../i18n';
import type { DocumentKind, MigrationState, PageItem } from '../lib/types';
import { useStore } from '../lib/store';
import { TEMPLATE_FILTER_TYPES, templateTypeLabel } from '../lib/templates';
import BulkBar from './BulkBar.vue';
import RowActions from './RowActions.vue';
import ScoreBadge from './ScoreBadge.vue';

const store = useStore();
const st = store.state;

const TABS: Array<{ value: DocumentKind; label: string }> = [
  { value: 'pages', label: t('Pages') },
  { value: 'templates', label: t('Templates') },
];

const STATES: Array<{ value: MigrationState | ''; label: string }> = [
  { value: '', label: t('All') },
  { value: 'none', label: t('Not converted') },
  { value: 'draft', label: t('Draft') },
  { value: 'applied', label: t('Applied') },
];

const TYPE_LABELS: Record<string, string> = {
  page: t('Page'),
  post: t('Post'),
  elementor_library: t('Template'),
};

const isTemplates = computed(() => st.kind === 'templates');

const typeOptions = computed(() => {
  const set = new Set(['page', 'post']);
  for (const i of st.items) set.add(i.type);
  if (st.filters.type) set.add(st.filters.type);
  set.delete('elementor_library');
  return [...set].map((value) => ({ value, label: typeLabel(value) }));
});

const templateTypeOptions = computed(() => TEMPLATE_FILTER_TYPES.map((value) => ({ value, label: templateTypeLabel(value) })));

function typeLabel(type: string): string {
  return TYPE_LABELS[type] ?? type;
}

const STATE_LABELS: Record<MigrationState, string> = { none: t('Not converted'), draft: t('Draft'), applied: t('Applied') };

const search = ref(st.filters.search);
let timer: ReturnType<typeof setTimeout> | undefined;
function onSearchInput(): void {
  clearTimeout(timer);
  timer = setTimeout(() => store.setFilter('search', search.value), 300);
}
function submitSearch(): void {
  clearTimeout(timer);
  store.setFilter('search', search.value);
}
onBeforeUnmount(() => clearTimeout(timer));
// Each tab keeps its own search text.
watch(
  () => st.kind,
  () => {
    clearTimeout(timer);
    search.value = st.filters.search;
  },
);

function onTabKeydown(e: KeyboardEvent): void {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
  e.preventDefault();
  const rtl = getComputedStyle(e.currentTarget as HTMLElement).direction === 'rtl';
  const idx = TABS.findIndex((tab) => tab.value === st.kind);
  let next = idx;
  if (e.key === 'Home') next = 0;
  else if (e.key === 'End') next = TABS.length - 1;
  else next = (idx + ((e.key === 'ArrowRight') !== rtl ? 1 : -1) + TABS.length) % TABS.length;
  store.setKind(TABS[next].value);
  const list = (e.currentTarget as HTMLElement).querySelectorAll<HTMLElement>('[role="tab"]');
  list[next]?.focus();
}

const selectable = computed(() => st.items);
const allSelected = computed(() => selectable.value.length > 0 && selectable.value.every((i) => st.selected.includes(i.id)));
const someSelected = computed(() => st.selected.length > 0 && !allSelected.value);
const locked = computed(() => (!!st.bulk && !st.bulk.finished) || st.migrateAll?.phase === 'running');

function selectAll(on: boolean): void {
  st.selected = on ? selectable.value.map((i) => i.id) : [];
}

function busyLabel(i: PageItem): string {
  const b = st.rows[i.id]?.busy;
  if (b === 'convert') return t('Converting…');
  if (b === 'apply') return t('Applying…');
  if (b === 'rollback') return t('Rolling back…');
  if (b === 'report') return t('Analyzing…');
  return '';
}
function rowError(i: PageItem): string {
  return st.rows[i.id]?.error ?? '';
}
function score(i: PageItem): number | null {
  const c = st.rows[i.id]?.conversion;
  return c ? c.result.summary.score : i.migration?.score ?? null;
}
function formatDate(s: string): string {
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  try {
    return d.toLocaleDateString(document.documentElement.lang || undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return d.toDateString();
  }
}

function goto(page: number): void {
  if (page < 1 || page > st.totalPages || page === st.filters.page) return;
  store.setFilter('page', page);
}

const columns = computed(() => (isTemplates.value ? 8 : 6));
const hasFilters = computed(() => !!(st.filters.state || st.filters.type || st.filters.templateType || st.filters.search));
function clearFilters(): void {
  search.value = '';
  st.filters.state = '';
  st.filters.type = '';
  st.filters.templateType = '';
  store.setFilter('search', '');
}
</script>

<template>
  <section class="zxm-card zxm-docs" data-testid="zxm-documents" aria-labelledby="zxm-docs-title">
    <header class="zxm-card__head zxm-docs__head">
      <div>
        <h2 id="zxm-docs-title" class="zxm-card__title">{{ st.canTemplates ? t('Pages and templates') : t('Pages') }}</h2>
        <p class="zxm-card__sub">{{ t('Convert creates a draft only. Visitors keep seeing Elementor until you apply.') }}</p>
      </div>
      <button type="button" class="zxm-btn zxm-btn--primary" data-testid="zxm-migrate-all" :disabled="locked || (!!st.status && !st.status.zadex.active)" @click="store.openMigrateAll()">
        {{ t('Migrate everything') }}
      </button>
    </header>

    <div v-if="st.canTemplates" class="zxm-tabs" role="tablist" :aria-label="t('Document kind')" @keydown="onTabKeydown">
      <button
        v-for="tab in TABS"
        :id="`zxm-tab-${tab.value}`"
        :key="tab.value"
        type="button"
        role="tab"
        class="zxm-tab"
        :class="{ 'is-active': st.kind === tab.value }"
        :aria-selected="st.kind === tab.value"
        aria-controls="zxm-docs-panel"
        :tabindex="st.kind === tab.value ? 0 : -1"
        :disabled="locked"
        :data-testid="`zxm-tab-${tab.value}`"
        @click="store.setKind(tab.value)"
      >
        {{ tab.label }}
      </button>
    </div>

    <div id="zxm-docs-panel" :role="st.canTemplates ? 'tabpanel' : undefined" :aria-labelledby="st.canTemplates ? `zxm-tab-${st.kind}` : undefined">
      <div class="zxm-toolbar" role="search">
        <div class="zxm-segmented" role="group" :aria-label="t('Filter by state')">
          <button
            v-for="s in STATES"
            :key="s.value"
            type="button"
            class="zxm-segmented__btn"
            :class="{ 'is-active': st.filters.state === s.value }"
            :aria-pressed="st.filters.state === s.value"
            :data-testid="`zxm-filter-state-${s.value || 'all'}`"
            @click="store.setFilter('state', s.value)"
          >
            {{ s.label }}
          </button>
        </div>
        <label v-if="isTemplates" class="zxm-field">
          <span class="screen-reader-text">{{ t('Filter by template type') }}</span>
          <select class="zxm-select" :value="st.filters.templateType" data-testid="zxm-filter-template-type" @change="store.setFilter('templateType', ($event.target as HTMLSelectElement).value)">
            <option value="">{{ t('All template types') }}</option>
            <option v-for="o in templateTypeOptions" :key="o.value" :value="o.value">{{ o.label }}</option>
          </select>
        </label>
        <label v-else class="zxm-field">
          <span class="screen-reader-text">{{ t('Filter by type') }}</span>
          <select class="zxm-select" :value="st.filters.type" data-testid="zxm-filter-type" @change="store.setFilter('type', ($event.target as HTMLSelectElement).value)">
            <option value="">{{ t('All types') }}</option>
            <option v-for="o in typeOptions" :key="o.value" :value="o.value">{{ o.label }}</option>
          </select>
        </label>
        <form class="zxm-search" @submit.prevent="submitSearch">
          <label class="zxm-field">
            <span class="screen-reader-text">{{ isTemplates ? t('Search templates') : t('Search pages') }}</span>
            <input v-model="search" type="search" class="zxm-input" :placeholder="t('Search by title')" data-testid="zxm-search" @input="onSearchInput" />
          </label>
        </form>
      </div>

      <BulkBar />

      <div v-if="st.listError" class="zxm-inline-error" role="alert" data-testid="zxm-list-error">
        {{ st.listError }}
        <button type="button" class="zxm-link-btn" data-testid="zxm-list-retry" @click="store.loadPages()">{{ t('Try again') }}</button>
      </div>

      <div class="zxm-table-wrap" :aria-busy="st.listLoading">
        <table class="zxm-table">
          <thead>
            <tr>
              <th class="zxm-col-check" scope="col">
                <input
                  type="checkbox"
                  :checked="allSelected"
                  :indeterminate="someSelected"
                  :disabled="!selectable.length || locked"
                  :aria-label="t('Select all on this page')"
                  data-testid="zxm-select-all"
                  @change="selectAll(($event.target as HTMLInputElement).checked)"
                />
              </th>
              <th scope="col">{{ t('Title') }}</th>
              <th scope="col" class="zxm-col-type">{{ isTemplates ? t('Elementor type') : t('Type') }}</th>
              <th v-if="isTemplates" scope="col" class="zxm-col-conditions">{{ t('Conditions') }}</th>
              <th scope="col" class="zxm-col-state">{{ t('Migration') }}</th>
              <th scope="col" class="zxm-col-score">{{ t('Score') }}</th>
              <th v-if="isTemplates" scope="col" class="zxm-col-target">{{ t('Zadex template') }}</th>
              <th scope="col" class="zxm-col-actions"><span class="screen-reader-text">{{ t('Actions') }}</span></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="i in st.items" :key="i.id" :class="{ 'is-selected': st.selected.includes(i.id) }" :data-testid="`zxm-row-${i.id}`" :data-state="i.migration.state">
              <td class="zxm-col-check">
                <input
                  type="checkbox"
                  :checked="st.selected.includes(i.id)"
                  :disabled="locked"
                  :aria-label="t('Select %s', i.title || t('(no title)'))"
                  :data-testid="`zxm-select-${i.id}`"
                  @change="store.toggleSelect(i.id, ($event.target as HTMLInputElement).checked)"
                />
              </td>
              <td class="zxm-col-title">
                <div class="zxm-title">
                  <a :href="i.viewUrl" target="_blank" rel="noopener" class="zxm-title__link">{{ i.title || t('(no title)') }}</a>
                  <span v-if="i.status !== 'publish'" class="zxm-post-status">{{ i.status }}</span>
                </div>
                <div class="zxm-meta">
                  <span>#{{ i.id }}</span>
                  <span>{{ formatDate(i.modified) }}</span>
                  <a v-if="i.editUrl" :href="i.editUrl" class="zxm-meta__link">{{ t('Edit') }}</a>
                </div>
                <div v-if="rowError(i)" class="zxm-row-error" role="alert" :data-testid="`zxm-row-error-${i.id}`">{{ rowError(i) }}</div>
              </td>
              <td class="zxm-col-type">
                <span v-if="isTemplates" class="zxm-ttype" :data-testid="`zxm-ttype-${i.id}`">{{ templateTypeLabel(i.templateType) }}</span>
                <template v-else>{{ typeLabel(i.type) }}</template>
              </td>
              <td v-if="isTemplates" class="zxm-col-conditions" :data-testid="`zxm-conditions-${i.id}`">
                <span v-if="i.conditionsSummary">{{ i.conditionsSummary }}</span>
                <span v-else class="zxm-muted">—</span>
              </td>
              <td class="zxm-col-state">
                <span class="zxm-state" :class="`zxm-state--${i.migration.state}`" :data-testid="`zxm-state-${i.id}`">{{ STATE_LABELS[i.migration.state] ?? i.migration.state }}</span>
                <span v-if="busyLabel(i)" class="zxm-busy" role="status"><span class="zxm-spinner" aria-hidden="true" />{{ busyLabel(i) }}</span>
              </td>
              <td class="zxm-col-score">
                <button v-if="score(i) !== null" type="button" class="zxm-score-btn" :aria-label="t('Open report for %s', i.title || t('(no title)'))" :data-testid="`zxm-score-${i.id}`" @click="store.openReport(i.id)">
                  <ScoreBadge :score="score(i)" />
                </button>
                <ScoreBadge v-else :score="null" />
              </td>
              <td v-if="isTemplates" class="zxm-col-target" :data-testid="`zxm-target-${i.id}`">
                <a v-if="i.target?.editUrl" :href="i.target.editUrl" class="zxm-target-link" target="_blank" rel="noopener">
                  {{ t('Edit in Zadex') }}<span class="screen-reader-text"> {{ t('(opens in a new tab)') }}</span>
                </a>
                <span v-else class="zxm-muted">—</span>
              </td>
              <td class="zxm-col-actions">
                <RowActions :item="i" />
              </td>
            </tr>
            <tr v-if="!st.items.length && st.listLoaded && !st.listLoading && !st.listError">
              <td :colspan="columns" class="zxm-empty" data-testid="zxm-empty">
                <template v-if="hasFilters">
                  <strong>{{ isTemplates ? t('No templates match these filters.') : t('No pages match these filters.') }}</strong>
                  <button type="button" class="zxm-link-btn" data-testid="zxm-clear-filters" @click="clearFilters">{{ t('Clear filters') }}</button>
                </template>
                <template v-else-if="isTemplates">
                  <strong>{{ t('No Elementor templates found.') }}</strong>
                  <span>{{ t('Theme Builder templates, loop items and saved sections built with Elementor show up here.') }}</span>
                </template>
                <template v-else>
                  <strong>{{ t('No Elementor pages found.') }}</strong>
                  <span>{{ t('Pages and posts built with Elementor show up here.') }}</span>
                </template>
              </td>
            </tr>
            <tr v-if="!st.listLoaded && st.listLoading">
              <td :colspan="columns" class="zxm-empty" aria-busy="true">{{ isTemplates ? t('Loading templates…') : t('Loading pages…') }}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <nav v-if="st.totalPages > 1" class="zxm-pager" :aria-label="t('Pagination')" data-testid="zxm-pager">
        <span class="zxm-muted">{{ t('%s items', n(st.total)) }}</span>
        <button type="button" class="zxm-btn zxm-btn--sm" :disabled="st.filters.page <= 1" data-testid="zxm-page-prev" @click="goto(st.filters.page - 1)">
          <span aria-hidden="true" class="zxm-flip">‹</span> {{ t('Previous') }}
        </button>
        <span class="zxm-pager__pos" aria-live="polite">{{ t('Page %1$s of %2$s', n(st.filters.page), n(st.totalPages)) }}</span>
        <button type="button" class="zxm-btn zxm-btn--sm" :disabled="st.filters.page >= st.totalPages" data-testid="zxm-page-next" @click="goto(st.filters.page + 1)">
          {{ t('Next') }} <span aria-hidden="true" class="zxm-flip">›</span>
        </button>
      </nav>
    </div>
  </section>
</template>
