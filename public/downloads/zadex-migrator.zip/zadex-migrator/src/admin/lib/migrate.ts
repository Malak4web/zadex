import { convertDocument, supportedWidgets } from '@/convert';
import { breakpointsFrom, documentCss, pageCss } from '@/css/zadex-css';
import type { ConvertResult, ElElement, ElSettings, SourceDocument, ZadexEnv } from '@/convert/types';
import type { Api } from './api';
import { convertKit, globalCss, kitImportAvailable, type KitConversion } from './globals';
import type {
  ApplyResponse,
  DraftBody,
  DraftResponse,
  MigrationTarget,
  PreviewUrls,
  StatusResponse,
  ZadexContext,
  ZadexGlobalResponse,
  ZadexWidgetsResponse,
} from './types';

/** A converted document plus the CSS Zadex stores with it (what POST /draft receives). */
export interface Conversion {
  postId: number;
  source: SourceDocument;
  result: ConvertResult;
  css: string;
  pageCss: string;
  /** Widget types without a mapper that were asked for as rendered HTML (empty when none). */
  fallbackTypes: string[];
}

export interface ConvertedPage extends Conversion {
  previewUrls: PreviewUrls;
  /** Templates only (see DraftResponse.targetUpdated). */
  targetUpdated?: boolean;
}

export interface BulkProgress {
  done: number;
  total: number;
  failed: number;
  running: number[];
}

export interface BulkItemResult<T> {
  id: number;
  ok: boolean;
  value?: T;
  error?: unknown;
}

export interface BulkResult<T> {
  results: BulkItemResult<T>[];
  cancelled: boolean;
}

export interface BulkOptions<T> {
  concurrency?: number;
  signal?: AbortSignal;
  onProgress?: (p: BulkProgress) => void;
  onItem?: (r: BulkItemResult<T>) => void;
}

export interface GlobalsPreview {
  available: boolean;
  /** Kit settings found (Elementor kit post). */
  hasKit: boolean;
  conversion: KitConversion | null;
}

export interface MigratorDeps {
  convert?: (source: SourceDocument, env: ZadexEnv) => ConvertResult;
  supported?: () => string[];
}

/**
 * Widget types that have a mapper but may still fall back to Elementor's rendered HTML (an embedded Elementor
 * template not migrated yet, Facebook comment embeds), so their HTML is requested too.
 */
const RENDER_ALSO = new Set(['template', 'global', 'facebook-embed']);

/**
 * Collects the widget types of a tree that the converter has no mapper for. The server only renders Elementor
 * HTML for the types the client lists (`?render=a,b`), so a first pass over the raw tree decides what to ask for.
 */
export function unknownWidgetTypes(elements: ElElement[], supported: Iterable<string>): string[] {
  const known = new Set(supported);
  const found = new Set<string>();
  const walk = (list: ElElement[] | undefined) => {
    for (const el of list ?? []) {
      const t = el.widgetType;
      if (el.elType === 'widget' && t && (!known.has(t) || RENDER_ALSO.has(t))) found.add(t);
      walk(el.elements);
    }
  };
  walk(elements);
  return [...found].sort();
}

/** `ConvertResult.target` (templates only): where the backend stores the draft. Absent for regular pages. */
export function conversionTarget(c: Pick<Conversion, 'result'>): MigrationTarget | undefined {
  const target = (c.result as { target?: unknown }).target;
  if (!target || typeof target !== 'object') return undefined;
  const kind = (target as { kind?: unknown }).kind;
  return kind === 'theme' || kind === 'library' ? (target as MigrationTarget) : undefined;
}

/**
 * Runs `task` for each id with at most `concurrency` in flight. Cancelling stops starting new items; items already
 * running finish (their requests are not torn down half-way).
 */
export async function runBulk<T>(ids: number[], task: (id: number) => Promise<T>, opts: BulkOptions<T> = {}): Promise<BulkResult<T>> {
  const concurrency = Math.max(1, opts.concurrency ?? 2);
  const queue = [...ids];
  const results: BulkItemResult<T>[] = [];
  const running = new Set<number>();
  let failed = 0;
  const report = () => opts.onProgress?.({ done: results.length, total: ids.length, failed, running: [...running] });
  const cancelled = () => opts.signal?.aborted === true;

  async function worker(): Promise<void> {
    while (queue.length && !cancelled()) {
      const id = queue.shift() as number;
      running.add(id);
      report();
      let r: BulkItemResult<T>;
      try {
        r = { id, ok: true, value: await task(id) };
      } catch (error) {
        failed++;
        r = { id, ok: false, error };
      }
      running.delete(id);
      results.push(r);
      opts.onItem?.(r);
      report();
    }
  }

  report();
  await Promise.all(Array.from({ length: Math.min(concurrency, ids.length) }, () => worker()));
  return { results, cancelled: cancelled() && results.length < ids.length };
}

export function createMigrator(api: Api, deps: MigratorDeps = {}) {
  const convert = deps.convert ?? convertDocument;
  const supported = deps.supported ?? supportedWidgets;
  let zadexPromise: Promise<ZadexContext> | null = null;
  /** Set from GET /status: when Elementor is inactive the server cannot render fallbacks, skip the second fetch. */
  let elementorActive = true;

  function loadZadex(force = false): Promise<ZadexContext> {
    if (!zadexPromise || force) {
      zadexPromise = Promise.all([api.zadex.get<ZadexWidgetsResponse>('widgets'), api.zadex.get<ZadexGlobalResponse>('global')]).then(
        ([w, g]) => ({
          env: { manifests: w.widgets ?? [], commonControls: w.commonControls ?? [], global: g.settings },
          breakpoints: breakpointsFrom(g.breakpoints),
          breakpointsConfig: g.breakpoints ?? {},
          global: g.settings,
        }),
      );
      zadexPromise.catch(() => {
        zadexPromise = null;
      });
    }
    return zadexPromise;
  }

  async function status(): Promise<StatusResponse> {
    const s = await api.get<StatusResponse>('status');
    elementorActive = s.elementor?.active !== false;
    return s;
  }

  /** GET /source, then (only when the tree has widgets without a mapper) again with `?render=` for their HTML. */
  async function fetchSource(id: number): Promise<{ source: SourceDocument; fallbackTypes: string[] }> {
    const first = await api.get<SourceDocument>(`source/${id}`);
    const unknown = unknownWidgetTypes(first.elements ?? [], supported());
    if (!unknown.length || !elementorActive) return { source: first, fallbackTypes: [] };
    const withHtml = await api.get<SourceDocument>(`source/${id}`, { render: unknown.join(',') });
    return { source: withHtml, fallbackTypes: unknown };
  }

  /** Converts a document in memory (nothing is saved). */
  async function analyzePage(id: number): Promise<Conversion> {
    const [zx, { source, fallbackTypes }] = await Promise.all([loadZadex(), fetchSource(id)]);
    const result = convert(source, zx.env);
    const postId = source.postId || id;
    return {
      postId,
      source,
      result,
      css: documentCss(result.document.elements, zx.env, zx.breakpoints),
      pageCss: pageCss(result.pageSettings, postId, zx.breakpoints),
      fallbackTypes,
    };
  }

  function draftBody(c: Conversion): DraftBody {
    const body: DraftBody = {
      data: c.result.document,
      css: c.css,
      pageSettings: { settings: c.result.pageSettings, css: c.pageCss },
      template: c.result.template,
      report: c.result.report,
      summary: c.result.summary,
    };
    const target = conversionTarget(c);
    if (target) body.target = target;
    return body;
  }

  /** GET source -> convert -> CSS -> POST draft. Visitors see no change until apply. */
  async function convertPage(id: number): Promise<ConvertedPage> {
    const c = await analyzePage(id);
    const res = await api.post<DraftResponse>(`draft/${id}`, draftBody(c));
    const out: ConvertedPage = { ...c, previewUrls: res.previewUrls };
    if (typeof res.targetUpdated === 'boolean') out.targetUpdated = res.targetUpdated;
    return out;
  }

  function applyPage(id: number): Promise<ApplyResponse> {
    return api.post<ApplyResponse>(`apply/${id}`, {});
  }

  function rollbackPage(id: number): Promise<{ restored: boolean }> {
    return api.post<{ restored: boolean }>(`rollback/${id}`, {});
  }

  function bulkConvert(ids: number[], opts: BulkOptions<ConvertedPage> = {}) {
    return runBulk(ids, convertPage, { concurrency: 2, ...opts });
  }

  function bulkApply(ids: number[], opts: BulkOptions<ApplyResponse> = {}) {
    return runBulk(ids, applyPage, { concurrency: 2, ...opts });
  }

  /** Kit settings: the kit post's source (`kit`, or its page settings — a kit stores its settings there). */
  async function fetchKit(kitId: number): Promise<ElSettings | null> {
    const src = await api.get<SourceDocument>(`source/${kitId}`);
    const kit = src.kit && Object.keys(src.kit).length ? src.kit : src.pageSettings;
    return kit && typeof kit === 'object' ? kit : null;
  }

  /** What the kit import would write, computed against the current Zadex global settings (nothing saved). */
  async function previewGlobals(kitId: number | null | undefined): Promise<GlobalsPreview> {
    if (!kitImportAvailable()) return { available: false, hasKit: !!kitId, conversion: null };
    if (!kitId) return { available: true, hasKit: false, conversion: null };
    const [zx, kit] = await Promise.all([loadZadex(), fetchKit(kitId)]);
    if (!kit) return { available: true, hasKit: false, conversion: null };
    return { available: true, hasKit: true, conversion: convertKit(kit, zx.global, zx.breakpointsConfig) };
  }

  /**
   * Backs up the Zadex global settings, converts the kit against the *fresh* current globals (so ids that already
   * exist are merged, not duplicated) and saves settings + CSS + breakpoints through Zadex's own route.
   */
  async function importGlobals(kitId: number): Promise<KitConversion> {
    const [current, kit] = await Promise.all([api.zadex.get<ZadexGlobalResponse>('global'), fetchKit(kitId)]);
    if (!kit) throw new Error('No Elementor kit settings were found.');
    await api.post('global-backup', {});
    const out = convertKit(kit, current.settings, current.breakpoints);
    const bpConfig = out.breakpoints ?? current.breakpoints;
    const css = globalCss(out.global, breakpointsFrom(bpConfig));
    const body: Record<string, unknown> = { settings: out.global, css };
    if (out.breakpoints) body.breakpoints = out.breakpoints;
    await api.zadex.post('global', body);
    await loadZadex(true).catch(() => undefined);
    return out;
  }

  async function restoreGlobals(): Promise<{ restored: boolean }> {
    const r = await api.post<{ restored: boolean }>('global-restore', {});
    await loadZadex(true).catch(() => undefined);
    return r;
  }

  return {
    api,
    loadZadex,
    status,
    fetchSource,
    analyzePage,
    convertPage,
    applyPage,
    rollbackPage,
    bulkConvert,
    bulkApply,
    previewGlobals,
    importGlobals,
    restoreGlobals,
    setElementorActive(v: boolean) {
      elementorActive = v;
    },
  };
}

export type Migrator = ReturnType<typeof createMigrator>;
