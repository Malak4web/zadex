import type { Breakpoint, ConvertResult, ControlDef, GlobalSettings, WidgetManifest, ZadexEnv } from '@/convert/types';

/** REST shapes of `zadex-migrator/v1` (see docs/ARCHITECTURE.md) and the parts of `zadex/v1` the app reads. */

export type MigrationState = 'none' | 'draft' | 'applied';

export interface StatusResponse {
  zadex: { active: boolean; version?: string };
  elementor: { active: boolean; version?: string };
  kit: { id: number } | null;
  /** Pages only (posts, pages, …); templates are counted in `templates`. */
  counts: { documents: number; migrated: number; drafts: number; templates?: { documents: number; migrated: number; drafts: number } };
  /** A Zadex globals backup exists (the kit was imported at least once). */
  globalBackup?: boolean;
}

/** Documents area tab: regular posts / pages, or Elementor templates (`elementor_library`). */
export type DocumentKind = 'pages' | 'templates';

/**
 * Where the draft of a template goes (from `ConvertResult.target`): a Zadex theme template (`zadex_template`, with
 * display rules and settings) or a Zadex library item (`zadex_library`).
 */
export type MigrationTarget =
  | { kind: 'theme'; type: string; rules?: unknown[]; settings?: Record<string, unknown> }
  | { kind: 'library'; type: string };

/** The Zadex post a template row was migrated into (template rows only). */
export interface TargetPost {
  id: number;
  editUrl?: string;
  status?: string;
}

export interface PreviewUrls {
  elementor: string;
  zadex: string;
}

export interface PageItem {
  id: number;
  title: string;
  /** Post type (page, post, elementor_library, …). */
  type: string;
  /** Post status (publish, draft, private, …). */
  status: string;
  modified: string;
  viewUrl: string;
  editUrl: string;
  migration: {
    state: MigrationState;
    score: number | null;
    appliedAt?: string | null;
    hasZadexData?: boolean;
  };
  /** Optional: preview links of a stored draft (lets the list open a preview for drafts made earlier). */
  previewUrls?: PreviewUrls | null;
  /** Template rows: Elementor `_elementor_template_type` (header, footer, single, loop-item, section, popup, …). */
  templateType?: string;
  /** Template rows: human readable display conditions ("Entire site", "All posts, except …"). */
  conditionsSummary?: string;
  /** Template rows: the Zadex template / library post once a draft exists. */
  target?: TargetPost | null;
}

export interface PagesQuery {
  kind?: DocumentKind;
  state?: MigrationState | '';
  type?: string;
  search?: string;
  page?: number;
  per_page?: number;
}

export interface PagesResponse {
  items: PageItem[];
  total: number;
  pages: number;
}

export interface DraftBody {
  data: ConvertResult['document'];
  css: string;
  pageSettings: { settings: ConvertResult['pageSettings']; css: string };
  template: string;
  report: ConvertResult['report'];
  summary: ConvertResult['summary'];
  /** Templates only: where the backend stores the draft (theme template or library item). */
  target?: MigrationTarget;
}

export interface DraftResponse {
  saved: boolean;
  /** Saved templates (library) have no Zadex view: `zadex` is ''. */
  previewUrls: PreviewUrls;
  /** Templates: the Zadex target post. */
  target?: TargetPost | null;
  /**
   * Templates: false when the target is already published (applied template) — the new draft goes live on the next
   * apply, like a page.
   */
  targetUpdated?: boolean;
}

export interface ApplyResponse {
  applied: boolean;
  viewUrl?: string;
  editUrl?: string;
}

export interface ZadexWidgetsResponse {
  widgets: WidgetManifest[];
  commonControls: ControlDef[];
}

export type BreakpointsConfig = Partial<Record<Breakpoint['key'], { value?: number; enabled?: boolean; [k: string]: unknown }>>;

export interface ZadexGlobalResponse {
  settings: GlobalSettings;
  css: string;
  breakpoints: BreakpointsConfig;
}

/** Everything about the Zadex install the converter needs, loaded once per page view. */
export interface ZadexContext {
  env: ZadexEnv;
  breakpoints: Breakpoint[];
  breakpointsConfig: BreakpointsConfig;
  global: GlobalSettings;
}
