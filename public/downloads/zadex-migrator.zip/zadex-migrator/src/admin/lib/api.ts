import { t } from '../i18n';
import type { MigratorConfig } from '../config';

export type Query = Record<string, string | number | boolean | null | undefined>;

/** A failed REST call. `message` is user-facing (WP_Error message when the server sent one). */
export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly code: string = '',
    public readonly data: unknown = null,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export interface RestClient {
  get<T>(path: string, query?: Query): Promise<T>;
  post<T>(path: string, body?: unknown): Promise<T>;
}

export interface Api extends RestClient {
  /** `zadex/v1` namespace (widgets, global settings). */
  zadex: RestClient;
}

type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

/**
 * Builds a REST URL from a namespace base and a route. Works with pretty permalinks (`/wp-json/ns/v1/`) and with
 * plain permalinks (`/index.php?rest_route=/ns/v1/`).
 */
export function restUrl(base: string, path: string, query?: Query): string {
  const route = path.replace(/^\/+/, '');
  const url = new URL(base, typeof location !== 'undefined' ? location.href : 'http://localhost/');
  const restRoute = url.searchParams.get('rest_route');
  if (restRoute !== null) {
    url.searchParams.set('rest_route', `${restRoute.replace(/\/+$/, '')}/${route}`);
  } else {
    url.pathname = `${url.pathname.replace(/\/+$/, '')}/${route}`;
  }
  for (const [k, v] of Object.entries(query ?? {})) {
    if (v === undefined || v === null || v === '') continue;
    url.searchParams.set(k, String(v));
  }
  return url.toString();
}

function client(base: string, nonce: string, fetchImpl: FetchLike): RestClient {
  async function request<T>(method: 'GET' | 'POST', path: string, query?: Query, body?: unknown): Promise<T> {
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (nonce) headers['X-WP-Nonce'] = nonce;
    const init: RequestInit = { method, headers, credentials: 'same-origin' };
    if (method === 'POST') {
      headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(body ?? {});
    }
    let res: Response;
    try {
      res = await fetchImpl(restUrl(base, path, query), init);
    } catch {
      throw new ApiError(t('Network error: the server could not be reached.'), 0, 'network');
    }
    const text = await res.text();
    let json: unknown = null;
    if (text) {
      try {
        json = JSON.parse(text);
      } catch {
        json = undefined;
      }
    }
    if (!res.ok) {
      const err = (json && typeof json === 'object' ? json : {}) as { code?: string; message?: string; data?: unknown };
      const message = typeof err.message === 'string' && err.message ? stripTags(err.message) : t('Request failed (%s).', res.status);
      throw new ApiError(message, res.status, err.code ?? '', err.data ?? null);
    }
    if (json === undefined) {
      throw new ApiError(t('The server returned an invalid response.'), res.status, 'invalid_json');
    }
    return json as T;
  }
  return {
    get: <T>(path: string, query?: Query) => request<T>('GET', path, query),
    post: <T>(path: string, body?: unknown) => request<T>('POST', path, undefined, body),
  };
}

function stripTags(s: string): string {
  return s.replace(/<[^>]*>/g, '');
}

export function createApi(config: Pick<MigratorConfig, 'restUrl' | 'zadexRestUrl' | 'nonce'>, fetchImpl?: FetchLike): Api {
  const f: FetchLike = fetchImpl ?? ((input, init) => fetch(input, init));
  const own = client(config.restUrl, config.nonce, f);
  return { ...own, zadex: client(config.zadexRestUrl, config.nonce, f) };
}

/** User-facing message for any thrown value. */
export function errorMessage(e: unknown): string {
  if (e instanceof Error && e.message) return e.message;
  return t('Something went wrong.');
}
