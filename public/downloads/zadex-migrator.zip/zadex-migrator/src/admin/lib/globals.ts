import { convertKit as kitConverter, type CurrentBreakpoints, type KitResult } from '@/convert/kit';
import { globalCss as zadexGlobalCss } from '@/css/zadex-css';
import type { Breakpoint, ElSettings, GlobalSettings } from '@/convert/types';
import type { BreakpointsConfig } from './types';

/**
 * Admin-side wrapper around the kit converter (`src/convert/kit.ts`) and `globalCss()` (`src/css/zadex-css.ts`):
 * adds the per-item lists the Globals step shows (every global color / font after the import, flagged new /
 * changed / unchanged against the current Zadex settings). Tests can swap the converter with `setConvertKit`.
 */

export type ItemChange = 'new' | 'changed' | 'same';

export interface KitImportItem<T = unknown> {
  id: string;
  label: string;
  value: T;
  change: ItemChange;
}

export interface KitReport {
  notes: string[];
  /** Global colors after the import (merged with the existing Zadex colors). */
  colors: KitImportItem<string>[];
  /** Global fonts after the import. */
  fonts: KitImportItem<{ family: string; weight?: string }>[];
  /** Number of colors / fonts the kit brings in. */
  imported: { colors: number; fonts: number };
  /** Kit setting keys with a value that could not be carried over. */
  dropped: string[];
}

export interface KitConversion {
  global: GlobalSettings;
  breakpoints?: BreakpointsConfig;
  report: KitReport;
}

type ConvertKit = (kit: ElSettings, current: GlobalSettings, currentBreakpoints?: CurrentBreakpoints) => KitResult;

let override: ConvertKit | null | undefined;

/** Tests: replace the kit converter (`null` = unavailable, `undefined` = the real one). */
export function setConvertKit(fn: ConvertKit | null | undefined): void {
  override = fn;
}

function converter(): ConvertKit | null {
  return override === undefined ? kitConverter : override;
}

export function kitImportAvailable(): boolean {
  return converter() !== null;
}

function diff<T>(after: Array<{ id: string; label: string; value: T }> | undefined, before: Array<{ id: string; value: T }> | undefined): KitImportItem<T>[] {
  const prev = new Map((before ?? []).map((i) => [i.id, JSON.stringify(i.value)]));
  return (after ?? []).map((i) => ({
    id: i.id,
    label: i.label,
    value: i.value,
    change: !prev.has(i.id) ? 'new' : prev.get(i.id) === JSON.stringify(i.value) ? 'same' : 'changed',
  }));
}

export function convertKit(kit: ElSettings, currentGlobal: GlobalSettings, currentBreakpoints?: BreakpointsConfig): KitConversion {
  const fn = converter();
  if (!fn) throw new Error('Kit import is not available in this build.');
  const out = fn(kit, currentGlobal, currentBreakpoints as CurrentBreakpoints | undefined);
  const r = (out.report ?? {}) as Partial<KitResult['report']>;
  return {
    global: out.global,
    breakpoints: out.breakpoints as BreakpointsConfig | undefined,
    report: {
      notes: r.notes ?? [],
      colors: diff(out.global.colors, currentGlobal.colors),
      fonts: diff(out.global.fonts, currentGlobal.fonts),
      imported: { colors: typeof r.colors === 'number' ? r.colors : 0, fonts: typeof r.fonts === 'number' ? r.fonts : 0 },
      dropped: r.dropped ?? [],
    },
  };
}

export function globalCss(global: GlobalSettings, breakpoints: Breakpoint[]): string {
  return zadexGlobalCss(global, breakpoints);
}
