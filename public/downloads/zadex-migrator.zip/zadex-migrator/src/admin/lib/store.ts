import { inject, markRaw, reactive, type InjectionKey } from 'vue';
import { t } from '../i18n';
import { errorMessage } from './api';
import type { BulkProgress, Conversion, ConvertedPage, Migrator } from './migrate';
import { createSteps, planMigration, runMigration, type MigratePlan, type MigrateStep, type MigrateStepKey } from './migrate-all';
import { hasZadexView, hidesElementorOnApply, isPopup, isTemplate, matchesTemplateType, rowsOfKind, templateGroup, templateTypeLabel } from './templates';
import type { DocumentKind, MigrationState, PageItem, PreviewUrls, StatusResponse } from './types';

export interface ListFilters {
  state: MigrationState | '';
  /** Pages tab: post type. */
  type: string;
  /** Templates tab: Elementor template type. */
  templateType: string;
  search: string;
  page: number;
  perPage: number;
}

export interface MigrateAllState {
  phase: 'planning' | 'ready' | 'running' | 'finished' | 'error';
  error: string;
  plan: MigratePlan | null;
  steps: Record<MigrateStepKey, MigrateStep> | null;
  applyPages: boolean;
  controller: AbortController | null;
  stopping: boolean;
  cancelled: boolean;
}

function defaultFilters(): ListFilters {
  return { state: '', type: '', templateType: '', search: '', page: 1, perPage: 20 };
}

export interface Notice {
  id: number;
  type: 'success' | 'error' | 'info' | 'warning';
  text: string;
}

export type RowAction = 'convert' | 'apply' | 'rollback' | 'report';

export interface RowState {
  busy?: RowAction | null;
  error?: string | null;
  conversion?: Conversion | ConvertedPage | null;
  previewUrls?: PreviewUrls | null;
}

export interface ConfirmRequest {
  title: string;
  message: string;
  confirmLabel: string;
  danger?: boolean;
  resolve: (ok: boolean) => void;
}

export interface BulkState {
  kind: 'convert' | 'apply';
  progress: BulkProgress;
  controller: AbortController;
  finished: boolean;
  cancelled: boolean;
  stopping: boolean;
}

/**
 * App state + actions shared by the admin components (provided by App.vue, injected with `useStore()`).
 * Every server call goes through the migrator service, so components stay thin and tests can mock fetch only.
 */
export interface StoreOptions {
  /** `edit_theme_options`: templates tab, template steps and the global import. Default true. */
  canTemplates?: boolean;
}

export function createStore(migrator: Migrator, options: StoreOptions = {}) {
  const canTemplates = options.canTemplates !== false;
  let noticeSeq = 0;
  let listSeq = 0;
  const tabFilters: Record<DocumentKind, ListFilters> = { pages: defaultFilters(), templates: defaultFilters() };
  const state = reactive({
    /** Active tab of the documents area; `filters` is that tab's own filter set (kept per tab). */
    kind: 'pages' as DocumentKind,
    /** The user may migrate templates (`edit_theme_options`); without it the Templates tab is hidden. */
    canTemplates,
    tabFilters,
    status: null as StatusResponse | null,
    statusError: '' as string,
    statusLoading: false,
    items: [] as PageItem[],
    total: 0,
    totalPages: 0,
    listLoading: false,
    listError: '' as string,
    listLoaded: false,
    filters: tabFilters.pages,
    selected: [] as number[],
    rows: {} as Record<number, RowState>,
    bulk: null as BulkState | null,
    notices: [] as Notice[],
    preview: null as { id: number; title: string; urls: PreviewUrls } | null,
    report: null as { id: number; title: string; loading: boolean; error: string; conversion: Conversion | null } | null,
    confirm: null as ConfirmRequest | null,
    migrateAll: null as MigrateAllState | null,
    /** Titles of rows seen outside the current list (migrate everything), for notices and the report dialog. */
    titles: {} as Record<number, string>,
  });

  function row(id: number): RowState {
    if (!state.rows[id]) state.rows[id] = { busy: null, error: null, conversion: null, previewUrls: null };
    return state.rows[id];
  }

  function notify(type: Notice['type'], text: string): void {
    const id = ++noticeSeq;
    state.notices.push({ id, type, text });
    if (state.notices.length > 4) state.notices.shift();
  }

  function dismiss(id: number): void {
    const i = state.notices.findIndex((n) => n.id === id);
    if (i >= 0) state.notices.splice(i, 1);
  }

  function confirm(req: Omit<ConfirmRequest, 'resolve'>): Promise<boolean> {
    state.confirm?.resolve(false);
    return new Promise((resolve) => {
      state.confirm = {
        ...req,
        resolve: (ok: boolean) => {
          state.confirm = null;
          resolve(ok);
        },
      };
    });
  }

  async function loadStatus(): Promise<void> {
    state.statusLoading = true;
    try {
      state.status = await migrator.status();
      state.statusError = '';
    } catch (e) {
      state.statusError = errorMessage(e);
    } finally {
      state.statusLoading = false;
    }
  }

  async function loadPages(): Promise<void> {
    state.listLoading = true;
    const f = state.filters;
    const kind = state.kind;
    const seq = ++listSeq;
    try {
      const res = await migrator.api.get<{ items: PageItem[]; total: number; pages: number }>('pages', {
        kind,
        state: f.state,
        type: kind === 'pages' ? f.type : '',
        template_type: kind === 'templates' ? f.templateType : '',
        search: f.search.trim(),
        page: f.page,
        per_page: f.perPage,
      });
      if (seq !== listSeq) return; // a newer request (tab switch, filter) is on its way
      // Guards for a server that ignores `kind` / `template_type`.
      let items = rowsOfKind(res.items ?? [], kind);
      if (kind === 'templates' && f.templateType) items = items.filter((i) => matchesTemplateType(f.templateType, i.templateType));
      state.items = items;
      state.total = res.total ?? state.items.length;
      state.totalPages = res.pages ?? 1;
      state.listError = '';
      const visible = new Set(state.items.map((i) => i.id));
      state.selected = state.selected.filter((id) => visible.has(id));
    } catch (e) {
      if (seq === listSeq) state.listError = errorMessage(e);
    } finally {
      if (seq === listSeq) {
        state.listLoading = false;
        state.listLoaded = true;
      }
    }
  }

  function refresh(): Promise<void> {
    return Promise.all([loadPages(), loadStatus()]).then(() => undefined);
  }

  function setFilter<K extends keyof ListFilters>(key: K, value: ListFilters[K]): void {
    state.filters[key] = value;
    if (key !== 'page') state.filters.page = 1;
    void loadPages();
  }

  /** Switches the documents tab; each tab keeps its own filters and page. */
  function setKind(kind: DocumentKind): void {
    if (kind === state.kind || (kind === 'templates' && !state.canTemplates)) return;
    state.kind = kind;
    state.filters = state.tabFilters[kind];
    state.selected = [];
    state.items = [];
    state.total = 0;
    state.totalPages = 0;
    state.listError = '';
    state.listLoaded = false;
    void loadPages();
  }

  function item(id: number): PageItem | undefined {
    return state.items.find((i) => i.id === id);
  }

  function titleOf(id: number): string {
    return item(id)?.title || state.titles[id] || t('(no title)');
  }

  /** Apply confirmation text: templates explain where the Zadex version goes and what happens to Elementor's. */
  function applyMessage(id: number): string {
    const i = item(id);
    if (i && isTemplate(i)) {
      if (isPopup(i)) {
        const conditions = i.conditionsSummary?.trim();
        return conditions
          ? t('The Zadex popup for "%1$s" goes live with its display conditions (%2$s) and triggers; the Elementor popup is set to draft so Elementor Pro stops showing it. You can roll back at any time.', titleOf(id), conditions)
          : t('The Zadex popup for "%s" goes live with its display conditions and triggers; the Elementor popup is set to draft so Elementor Pro stops showing it. You can roll back at any time.', titleOf(id));
      }
      if (hidesElementorOnApply(i.templateType)) {
        const conditions = i.conditionsSummary?.trim();
        return conditions
          ? t('The Zadex template for "%1$s" goes live with its display conditions (%2$s), and the Elementor template is set to draft so Elementor Pro stops using it. You can roll back at any time.', titleOf(id), conditions)
          : t('The Zadex template for "%s" goes live with its display conditions, and the Elementor template is set to draft so Elementor Pro stops using it. You can roll back at any time.', titleOf(id));
      }
      if (templateGroup(i.templateType) === 'loop') {
        return t('The Zadex loop item for "%s" is published, so converted loop grids can use it. The Elementor template stays published, so Elementor pages that use it keep working. You can roll back at any time.', titleOf(id));
      }
      return t('The Zadex version of "%1$s" (%2$s) is published to the Zadex library. The Elementor template stays published, so Elementor pages that embed it keep working. You can roll back at any time.', titleOf(id), templateTypeLabel(i.templateType));
    }
    return t('"%s" will be shown with Zadex. The Elementor data is kept and a backup is made, so you can roll back at any time.', titleOf(id));
  }

  /** Preview links, or null when there is nothing to compare (no draft yet, or a saved template: no Zadex view). */
  function previewUrlsOf(id: number): PreviewUrls | null {
    const urls = row(id).previewUrls ?? item(id)?.previewUrls ?? null;
    return urls && urls.zadex ? urls : null;
  }

  async function convert(id: number): Promise<boolean> {
    const r = row(id);
    r.busy = 'convert';
    r.error = null;
    try {
      const c = await migrator.convertPage(id);
      r.conversion = markRaw(c);
      r.previewUrls = c.previewUrls;
      const i = item(id);
      if (c.targetUpdated === false) {
        notify('info', t('"%1$s" converted (score %2$s). The live Zadex template is unchanged; the new version goes live when you apply again.', titleOf(id), c.result.summary.score));
      } else if (i && !hasZadexView(i)) {
        notify('success', t('"%1$s" converted (score %2$s). Check the report, then apply.', titleOf(id), c.result.summary.score));
      } else {
        notify('success', t('"%1$s" converted (score %2$s). Preview it before applying.', titleOf(id), c.result.summary.score));
      }
      await refresh();
      return true;
    } catch (e) {
      r.error = errorMessage(e);
      notify('error', t('Could not convert "%1$s": %2$s', titleOf(id), r.error));
      return false;
    } finally {
      r.busy = null;
    }
  }

  async function apply(id: number, ask = true): Promise<boolean> {
    if (ask) {
      const ok = await confirm({
        title: t('Apply the Zadex version?'),
        message: applyMessage(id),
        confirmLabel: t('Apply'),
      });
      if (!ok) return false;
    }
    const r = row(id);
    r.busy = 'apply';
    r.error = null;
    try {
      await migrator.applyPage(id);
      notify('success', t('"%s" now uses Zadex.', titleOf(id)));
      await refresh();
      return true;
    } catch (e) {
      r.error = errorMessage(e);
      notify('error', t('Could not apply "%1$s": %2$s', titleOf(id), r.error));
      return false;
    } finally {
      r.busy = null;
    }
  }

  async function rollback(id: number): Promise<boolean> {
    const ok = await confirm({
      title: t('Roll back to Elementor?'),
      message: (() => {
        const i = item(id);
        if (i && isPopup(i)) {
          return t('The Zadex popup for "%s" goes back to draft (kept for history) and the Elementor popup gets its previous status back.', titleOf(id));
        }
        if (i && isTemplate(i)) {
          return hidesElementorOnApply(i.templateType)
            ? t('The Zadex template for "%s" goes back to draft (kept for history) and the Elementor template gets its previous status back.', titleOf(id))
            : t('The Zadex template for "%s" goes back to draft (kept for history). The Elementor template was not changed.', titleOf(id));
        }
        return t('"%s" will be shown with Elementor again and its previous Zadex content is restored from the backup.', titleOf(id));
      })(),
      confirmLabel: t('Roll back'),
      danger: true,
    });
    if (!ok) return false;
    const r = row(id);
    r.busy = 'rollback';
    r.error = null;
    try {
      await migrator.rollbackPage(id);
      notify('success', t('"%s" is back on Elementor.', titleOf(id)));
      await refresh();
      return true;
    } catch (e) {
      r.error = errorMessage(e);
      notify('error', t('Could not roll back "%1$s": %2$s', titleOf(id), r.error));
      return false;
    } finally {
      r.busy = null;
    }
  }

  function openPreview(id: number): void {
    const urls = previewUrlsOf(id);
    if (!urls) return;
    state.preview = { id, title: titleOf(id), urls };
  }

  function closePreview(): void {
    state.preview = null;
  }

  /** Report of the last conversion in this session, or a fresh in-memory conversion (nothing saved). */
  async function openReport(id: number): Promise<void> {
    const r = row(id);
    state.report = { id, title: titleOf(id), loading: !r.conversion, error: '', conversion: r.conversion ?? null };
    if (r.conversion) return;
    r.busy = 'report';
    try {
      const c = await migrator.analyzePage(id);
      r.conversion = markRaw(c);
      if (state.report?.id === id) state.report.conversion = r.conversion;
    } catch (e) {
      if (state.report?.id === id) state.report.error = errorMessage(e);
    } finally {
      r.busy = null;
      if (state.report?.id === id) state.report.loading = false;
    }
  }

  function closeReport(): void {
    state.report = null;
  }

  /** Opens the "Migrate everything" wizard and computes its plan (nothing is written until `startMigrateAll`). */
  async function openMigrateAll(): Promise<void> {
    if (state.migrateAll && state.migrateAll.phase === 'running') return;
    const run: MigrateAllState = reactive({ phase: 'planning', error: '', plan: null, steps: null, applyPages: false, controller: null, stopping: false, cancelled: false });
    state.migrateAll = run;
    try {
      const plan = await planMigration(migrator, { templates: state.canTemplates });
      run.plan = markRaw(plan);
      run.steps = createSteps(plan, run.applyPages);
      run.phase = 'ready';
    } catch (e) {
      run.error = errorMessage(e);
      run.phase = 'error';
    }
  }

  async function startMigrateAll(): Promise<void> {
    const run = state.migrateAll;
    if (!run || run.phase !== 'ready' || !run.plan || !run.steps) return;
    const plan = run.plan;
    for (const i of [...plan.loop, ...plan.library, ...plan.theme, ...plan.pages]) state.titles[i.id] = i.title;
    const controller = markRaw(new AbortController());
    run.controller = controller;
    run.phase = 'running';
    const steps = run.steps;
    steps.pages.apply = run.applyPages;
    const seen = new Set<object>();
    const service = {
      // Conversions are large and never mutated: keep them out of Vue's deep reactivity.
      convertPage: async (id: number) => markRaw(await migrator.convertPage(id)),
      applyPage: (id: number) => migrator.applyPage(id),
      importGlobals: (kitId: number) => migrator.importGlobals(kitId),
    };
    const out = await runMigration(service, plan, steps, {
      applyPages: run.applyPages,
      signal: controller.signal,
      onUpdate: () => {
        // Converted items feed the per-row state, so Preview / Report work from the list and the summary.
        for (const key of ['library', 'popups', 'theme', 'pages'] as const) {
          for (const r of steps[key].items) {
            if (seen.has(r)) continue;
            seen.add(r);
            if (r.conversion) {
              const rs = row(r.id);
              rs.conversion = r.conversion;
              rs.previewUrls = r.conversion.previewUrls;
            }
            row(r.id).error = r.error ?? null;
          }
        }
      },
    });
    run.cancelled = out.cancelled;
    run.stopping = false;
    run.phase = 'finished';
    notify(out.cancelled ? 'warning' : 'success', out.cancelled ? t('Migration cancelled. Finished items are kept.') : t('Migration finished.'));
    await refresh();
  }

  function setMigrateApplyPages(on: boolean): void {
    const run = state.migrateAll;
    if (!run || run.phase !== 'ready' || !run.steps) return;
    run.applyPages = on;
    run.steps.pages.apply = on;
  }

  function cancelMigrateAll(): void {
    const run = state.migrateAll;
    if (!run || run.phase !== 'running' || !run.controller) return;
    run.stopping = true;
    run.controller.abort();
  }

  /** Closing while running only asks the run to stop (the dialog stays until it has). */
  function closeMigrateAll(): void {
    const run = state.migrateAll;
    if (!run) return;
    if (run.phase === 'running') {
      cancelMigrateAll();
      return;
    }
    state.migrateAll = null;
  }

  function toggleSelect(id: number, on?: boolean): void {
    const i = state.selected.indexOf(id);
    const want = on ?? i < 0;
    if (want && i < 0) state.selected.push(id);
    if (!want && i >= 0) state.selected.splice(i, 1);
  }

  function selectAll(on: boolean): void {
    state.selected = on ? state.items.map((i) => i.id) : [];
  }

  async function runBulk(kind: 'convert' | 'apply', ids: number[]): Promise<void> {
    if (!ids.length || (state.bulk && !state.bulk.finished)) return;
    if (kind === 'apply') {
      const templates = state.kind === 'templates';
      const ok = await confirm({
        title: templates ? t('Apply %d templates?', ids.length) : t('Apply %d pages?', ids.length),
        message: templates
          ? t('Theme templates and popups go live with their display conditions (popups with their triggers too) and their Elementor templates are set to draft. Loop items and saved templates are published in Zadex and stay published in Elementor. Each one can be rolled back.')
          : t('The selected pages with a draft will be shown with Zadex. Backups are made, so each page can be rolled back.'),
        confirmLabel: t('Apply all'),
      });
      if (!ok) return;
    }
    const controller = markRaw(new AbortController());
    const bulk: BulkState = reactive({ kind, controller, finished: false, cancelled: false, stopping: false, progress: { done: 0, total: ids.length, failed: 0, running: [] } });
    state.bulk = bulk;
    const onProgress = (p: BulkProgress) => {
      bulk.progress = p;
      for (const id of p.running) row(id).busy = kind;
    };
    const onItem = (res: { id: number; ok: boolean; value?: unknown; error?: unknown }) => {
      const r = row(res.id);
      r.busy = null;
      r.error = res.ok ? null : errorMessage(res.error);
      if (res.ok && kind === 'convert') {
        const c = res.value as ConvertedPage;
        r.conversion = markRaw(c);
        r.previewUrls = c.previewUrls;
      }
    };
    const out =
      kind === 'convert'
        ? await migrator.bulkConvert(ids, { signal: controller.signal, onProgress, onItem })
        : await migrator.bulkApply(ids, { signal: controller.signal, onProgress, onItem });
    bulk.finished = true;
    bulk.cancelled = out.cancelled;
    const ok = out.results.filter((r) => r.ok).length;
    const failed = out.results.length - ok;
    const msg = kind === 'convert' ? t('%1$d converted, %2$d failed.', ok, failed) : t('%1$d applied, %2$d failed.', ok, failed);
    notify(failed ? 'warning' : 'success', out.cancelled ? `${t('Cancelled.')} ${msg}` : msg);
    await refresh();
  }

  function cancelBulk(): void {
    if (!state.bulk || state.bulk.finished) return;
    state.bulk.stopping = true;
    state.bulk.controller.abort();
  }

  function clearBulk(): void {
    if (state.bulk?.finished) state.bulk = null;
  }

  return {
    state,
    migrator,
    row,
    notify,
    dismiss,
    confirm,
    loadStatus,
    loadPages,
    refresh,
    setFilter,
    setKind,
    applyMessage,
    previewUrlsOf,
    convert,
    apply,
    rollback,
    openPreview,
    closePreview,
    openReport,
    closeReport,
    toggleSelect,
    selectAll,
    bulkConvert: (ids: number[] = state.selected) => runBulk('convert', [...ids]),
    bulkApply: (ids: number[] = state.selected) => runBulk('apply', [...ids]),
    cancelBulk,
    clearBulk,
    openMigrateAll,
    startMigrateAll,
    setMigrateApplyPages,
    cancelMigrateAll,
    closeMigrateAll,
  };
}

export type Store = ReturnType<typeof createStore>;

export const STORE_KEY: InjectionKey<Store> = Symbol('zxm-store');

export function useStore(): Store {
  const s = inject(STORE_KEY);
  if (!s) throw new Error('Zadex Migrator store not provided');
  return s;
}
