import { t } from '../i18n';
import type { DocumentKind, PageItem } from './types';

/**
 * Elementor template types (`_elementor_template_type`) as the admin app groups them. The migration order follows
 * these groups: saved templates and loop items first (other documents reference them through the id maps), then
 * popups (pages and headers link to them through `popupTemplates`), then theme templates, then pages.
 */
export type TemplateGroup = 'loop' | 'library' | 'theme' | 'popup' | 'other';

export const LIBRARY_TYPES = ['page', 'section', 'container'] as const;
export const LOOP_TYPES = ['loop-item'] as const;
export const THEME_TYPES = ['header', 'footer', 'single', 'single-post', 'single-page', 'archive', 'search-results', 'error-404', 'product', 'product-archive'] as const;
export const POPUP_TYPES = ['popup'] as const;

/** Post type of every Elementor template. */
export const TEMPLATE_POST_TYPE = 'elementor_library';

const LABELS: Record<string, () => string> = {
  header: () => t('Header'),
  footer: () => t('Footer'),
  single: () => t('Single'),
  'single-post': () => t('Single'),
  'single-page': () => t('Single'),
  archive: () => t('Archive'),
  'search-results': () => t('Search results'),
  'error-404': () => t('404'),
  'loop-item': () => t('Loop item'),
  section: () => t('Saved section'),
  page: () => t('Saved page'),
  container: () => t('Saved container'),
  product: () => t('Product'),
  'product-archive': () => t('Product archive'),
  popup: () => t('Popup'),
};

/** Translated label of an Elementor template type (unknown types show as they are). */
export function templateTypeLabel(type: string | undefined | null): string {
  if (!type) return t('Template');
  return LABELS[type]?.() ?? type;
}

/** Template types offered in the Templates tab filter, in display order (Single variants collapsed). */
export const TEMPLATE_FILTER_TYPES = ['header', 'footer', 'single', 'archive', 'search-results', 'error-404', 'loop-item', 'section', 'page', 'container', 'product', 'product-archive', 'popup'];

export function templateGroup(type: string | undefined | null): TemplateGroup {
  const ty = type ?? '';
  if ((LOOP_TYPES as readonly string[]).includes(ty)) return 'loop';
  if ((LIBRARY_TYPES as readonly string[]).includes(ty)) return 'library';
  if ((THEME_TYPES as readonly string[]).includes(ty)) return 'theme';
  if ((POPUP_TYPES as readonly string[]).includes(ty)) return 'popup';
  return 'other';
}

/** Does a template-type filter value match a row type (`single` matches `single-post` / `single-page`)? */
export function matchesTemplateType(filter: string, type: string | undefined): boolean {
  if (!filter) return true;
  if (!type) return false;
  return filter === 'single' ? type === 'single' || type.startsWith('single-') : type === filter;
}

export function isTemplate(item: Pick<PageItem, 'type'>): boolean {
  return item.type === TEMPLATE_POST_TYPE;
}

/** Elementor popups (they become Zadex popup templates: display conditions + triggers). */
export function isPopup(item: Pick<PageItem, 'type' | 'templateType'>): boolean {
  return isTemplate(item) && templateGroup(item.templateType) === 'popup';
}

/**
 * Theme templates (header, footer, single, archive, search, 404, product, product archive) and popups set the
 * Elementor template to draft on apply so Elementor Pro stops using it; loop items and saved templates stay published
 * in Elementor.
 */
export function hidesElementorOnApply(type: string | undefined | null): boolean {
  const group = templateGroup(type);
  return group === 'theme' || group === 'popup';
}

/** Saved templates (`zadex_library`) have no Zadex editor or front-end view: no preview, no edit link. */
export function hasZadexView(item: Pick<PageItem, 'type' | 'templateType'>): boolean {
  return !(isTemplate(item) && templateGroup(item.templateType) === 'library');
}

/** Client-side guard for servers that ignore `?kind=` (older backend): keeps only the rows of the tab. */
export function rowsOfKind(items: PageItem[], kind: DocumentKind): PageItem[] {
  return items.filter((i) => (kind === 'templates' ? isTemplate(i) : !isTemplate(i)));
}
