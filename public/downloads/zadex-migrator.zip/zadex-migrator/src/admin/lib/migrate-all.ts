import { errorMessage } from './api';
import { kitImportAvailable } from './globals';
import { runBulk, type ConvertedPage, type Migrator } from './migrate';
import { rowsOfKind, templateGroup } from './templates';
import type { DocumentKind, PageItem, PagesResponse } from './types';

/**
 * "Migrate everything": an ordered run over the whole site (pure service, no Vue).
 *
 *   1. globals  — import the Elementor kit (only when a kit exists and no globals backup exists yet)
 *   2. library  — convert + apply loop items, then saved templates (page / section / container)
 *   3. popups   — convert + apply popups (display conditions + triggers)
 *   4. theme    — convert + apply theme templates (header, footer, single, archive, …)
 *   5. pages    — convert pages into drafts (apply too only when asked)
 *
 * The order matters: the server builds the id maps (`loopTemplates`, `libraryTemplates`, `popupTemplates`) from
 * templates that are already migrated, so the documents that reference them (headers / pages with popup links,
 * forms opening a popup) must be converted afterwards. Items already applied are skipped; unknown template types are
 * listed as skipped. Cancelling stops starting new items and skips the remaining steps.
 */

export type MigrateStepKey = 'globals' | 'library' | 'popups' | 'theme' | 'pages';
export type MigrateStepStatus = 'pending' | 'running' | 'done' | 'skipped' | 'cancelled';

export interface MigrateItemResult {
  id: number;
  title: string;
  templateType?: string;
  converted: boolean;
  applied: boolean;
  score: number | null;
  error?: string;
  conversion?: ConvertedPage;
}

export interface MigrateStep {
  key: MigrateStepKey;
  status: MigrateStepStatus;
  /** Items this step will process (globals: 1 or 0). */
  total: number;
  done: number;
  failed: number;
  /** Whether converted items are applied too. */
  apply: boolean;
  /** Why the whole step was skipped (`no-kit`, `imported`, `unavailable`, `no-permission`, `empty`, `cancelled`). */
  reason?: string;
  error?: string;
  items: MigrateItemResult[];
}

export type SkipReason = 'applied' | 'unknown';

export interface MigratePlan {
  /** False without `edit_theme_options`: templates and globals are left out (steps skipped as `no-permission`). */
  templatesAllowed: boolean;
  kitId: number | null;
  importGlobals: boolean;
  /** Set when globals are not imported: `no-kit` | `imported` | `unavailable`. */
  globalsReason?: string;
  loop: PageItem[];
  library: PageItem[];
  popups: PageItem[];
  theme: PageItem[];
  pages: PageItem[];
  skipped: Array<{ item: PageItem; reason: SkipReason }>;
}

export interface MigrateRunOptions {
  applyPages?: boolean;
  signal?: AbortSignal;
  concurrency?: number;
  /** Called after every change of `steps` (they are mutated in place, so a reactive object updates the UI). */
  onUpdate?: () => void;
}

export const STEP_ORDER: MigrateStepKey[] = ['globals', 'library', 'popups', 'theme', 'pages'];

const PER_PAGE = 100;
const MAX_PAGES = 100;

/** Every row of a tab (all pages of `/pages?kind=`), filtered client-side when the server ignores `kind`. */
export async function fetchAllRows(migrator: Pick<Migrator, 'api'>, kind: DocumentKind): Promise<PageItem[]> {
  const out: PageItem[] = [];
  const seen = new Set<number>();
  for (let page = 1; page <= MAX_PAGES; page++) {
    const res = await migrator.api.get<PagesResponse>('pages', { kind, page, per_page: PER_PAGE });
    for (const item of rowsOfKind(res.items ?? [], kind)) {
      if (seen.has(item.id)) continue;
      seen.add(item.id);
      out.push(item);
    }
    if (!res.items?.length || page >= (res.pages ?? 1)) break;
  }
  return out;
}

/** Reads status + every template and page, and decides what each step will do (nothing is written). */
export async function planMigration(migrator: Pick<Migrator, 'api' | 'status'>, opts: { templates?: boolean } = {}): Promise<MigratePlan> {
  const templatesAllowed = opts.templates !== false;
  const [status, templates, pages] = await Promise.all([
    migrator.status(),
    templatesAllowed ? fetchAllRows(migrator, 'templates') : Promise.resolve([] as PageItem[]),
    fetchAllRows(migrator, 'pages'),
  ]);
  const kitId = status.kit?.id ?? null;
  let globalsReason: string | undefined;
  if (!templatesAllowed) globalsReason = 'no-permission';
  else if (!kitId) globalsReason = 'no-kit';
  else if (!kitImportAvailable()) globalsReason = 'unavailable';
  else if (status.globalBackup) globalsReason = 'imported';

  const plan: MigratePlan = { templatesAllowed, kitId, importGlobals: !globalsReason, globalsReason, loop: [], library: [], popups: [], theme: [], pages: [], skipped: [] };
  for (const item of templates) {
    const group = templateGroup(item.templateType);
    if (group === 'other') plan.skipped.push({ item, reason: 'unknown' });
    else if (item.migration?.state === 'applied') plan.skipped.push({ item, reason: 'applied' });
    else plan[group === 'popup' ? 'popups' : group].push(item);
  }
  for (const item of pages) {
    if (item.migration?.state === 'applied') plan.skipped.push({ item, reason: 'applied' });
    else plan.pages.push(item);
  }
  return plan;
}

/** Initial step list for a plan (what the wizard shows before it starts). */
export function createSteps(plan: MigratePlan, applyPages = false): Record<MigrateStepKey, MigrateStep> {
  const step = (key: MigrateStepKey, total: number, apply: boolean, reason?: string): MigrateStep => ({
    key,
    status: reason ? 'skipped' : 'pending',
    total,
    done: 0,
    failed: 0,
    apply,
    reason,
    items: [],
  });
  const libraryTotal = plan.loop.length + plan.library.length;
  const noTemplates = plan.templatesAllowed === false ? 'no-permission' : 'empty';
  return {
    globals: step('globals', plan.importGlobals ? 1 : 0, true, plan.importGlobals ? undefined : plan.globalsReason),
    library: step('library', libraryTotal, true, libraryTotal ? undefined : noTemplates),
    popups: step('popups', plan.popups.length, true, plan.popups.length ? undefined : noTemplates),
    theme: step('theme', plan.theme.length, true, plan.theme.length ? undefined : noTemplates),
    pages: step('pages', plan.pages.length, applyPages, plan.pages.length ? undefined : 'empty'),
  };
}

/** Runs the steps in order (mutating `steps`). Resolves when done or cancelled; item errors never reject. */
export async function runMigration(
  migrator: Pick<Migrator, 'convertPage' | 'applyPage' | 'importGlobals'>,
  plan: MigratePlan,
  steps: Record<MigrateStepKey, MigrateStep>,
  opts: MigrateRunOptions = {},
): Promise<{ cancelled: boolean }> {
  const update = () => opts.onUpdate?.();
  const aborted = () => opts.signal?.aborted === true;
  steps.pages.apply = !!opts.applyPages;

  const runItems = async (step: MigrateStep, items: PageItem[]): Promise<boolean> => {
    if (!items.length) return false;
    const byId = new Map(items.map((i) => [i.id, i]));
    const task = async (id: number): Promise<MigrateItemResult> => {
      const item = byId.get(id) as PageItem;
      const r: MigrateItemResult = { id, title: item.title, templateType: item.templateType, converted: false, applied: false, score: null };
      try {
        const c = await migrator.convertPage(id);
        r.converted = true;
        r.conversion = c;
        r.score = c.result.summary.score;
        if (step.apply) {
          await migrator.applyPage(id);
          r.applied = true;
        }
      } catch (e) {
        r.error = errorMessage(e);
      }
      return r;
    };
    const res = await runBulk(
      items.map((i) => i.id),
      task,
      {
        concurrency: opts.concurrency ?? 2,
        signal: opts.signal,
        onItem: (out) => {
          const r = out.value as MigrateItemResult;
          step.items.push(r);
          step.done++;
          if (r.error) step.failed++;
          update();
        },
      },
    );
    return res.cancelled;
  };

  let cancelled = false;
  for (const key of STEP_ORDER) {
    const step = steps[key];
    if (step.status === 'skipped') continue;
    if (cancelled || aborted()) {
      cancelled = true;
      step.status = 'cancelled';
      step.reason = 'cancelled';
      update();
      continue;
    }
    step.status = 'running';
    update();
    if (key === 'globals') {
      try {
        await migrator.importGlobals(plan.kitId as number);
      } catch (e) {
        step.error = errorMessage(e);
        step.failed = 1;
      }
      step.done = 1;
    } else if (key === 'library') {
      // Loop items first: saved templates may hold loop grids that point at them.
      cancelled = (await runItems(step, plan.loop)) || aborted();
      if (!cancelled) cancelled = await runItems(step, plan.library);
    } else {
      cancelled = await runItems(step, key === 'popups' ? plan.popups : key === 'theme' ? plan.theme : plan.pages);
    }
    step.status = cancelled || (aborted() && step.done < step.total) ? 'cancelled' : 'done';
    if (step.status === 'cancelled') cancelled = true;
    update();
  }
  return { cancelled };
}

/** Totals for the summary. */
export function migrationTotals(steps: Record<MigrateStepKey, MigrateStep>) {
  let converted = 0;
  let applied = 0;
  let failed = 0;
  for (const key of STEP_ORDER) {
    if (key === 'globals') continue;
    for (const r of steps[key].items) {
      if (r.converted) converted++;
      if (r.applied) applied++;
      if (r.error) failed++;
    }
  }
  return { converted, applied, failed, globals: steps.globals.status === 'done' && !steps.globals.error };
}
