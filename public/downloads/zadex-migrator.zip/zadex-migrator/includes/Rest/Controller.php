<?php
namespace ZadexMigrator\Rest;

defined('ABSPATH') || exit;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use ZadexMigrator\Migration\Documents;
use ZadexMigrator\Migration\Elementor;
use ZadexMigrator\Migration\Preview;
use ZadexMigrator\Migration\Source;
use ZadexMigrator\Migration\Store;
use ZadexMigrator\Migration\Targets;

/**
 * REST namespace zadex-migrator/v1 (see docs/ARCHITECTURE.md). Nonce: X-WP-Nonce (wp_rest), checked by core's
 * cookie authentication. Every route needs edit_posts, per-post routes edit_post on that post, global routes
 * edit_theme_options (also required for every Elementor template: `elementor_library` posts, kits included).
 *
 *  GET  /status
 *  GET  /pages?kind=pages|templates&state=&type=&search=&page=&per_page=
 *  GET  /source/{id}?render=a,b
 *  GET  /draft/{id}      stored report / summary / previewUrls
 *  POST /draft/{id}      {data, css, pageSettings:{settings,css}, template, report, summary, target?}
 *                        (target: Elementor templates only, see Migration\Targets)
 *  POST /apply/{id}
 *  POST /rollback/{id}
 *  POST /global-backup   {force?}
 *  POST /global-restore
 */
final class Controller
{
    public const NS = 'zadex-migrator/v1';

    public function register(): void
    {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes(): void
    {
        $id_arg = [
            'id' => [
                'type'              => 'integer',
                'required'          => true,
                'minimum'           => 1,
                'sanitize_callback' => 'absint',
            ],
        ];
        register_rest_route(self::NS, '/status', [
            'methods'             => 'GET',
            'callback'            => [$this, 'status'],
            'permission_callback' => [$this, 'can_edit_posts'],
        ]);
        register_rest_route(self::NS, '/pages', [
            'methods'             => 'GET',
            'callback'            => [$this, 'pages'],
            'permission_callback' => [$this, 'can_edit_posts'],
            'args'                => [
                'kind'     => ['type' => 'string', 'enum' => ['', 'pages', 'templates'], 'default' => 'pages', 'sanitize_callback' => 'sanitize_key'],
                'state'    => ['type' => 'string', 'enum' => ['', 'none', 'draft', 'applied'], 'default' => '', 'sanitize_callback' => 'sanitize_key'],
                'type'     => ['type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_key'],
                'template_type' => ['type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_key'],
                'search'   => ['type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_text_field'],
                'page'     => ['type' => 'integer', 'default' => 1, 'minimum' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => Documents::MAX_PER_PAGE, 'sanitize_callback' => 'absint'],
            ],
        ]);
        register_rest_route(self::NS, '/source/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'source'],
            'permission_callback' => [$this, 'can_edit_post'],
            'args'                => $id_arg + [
                'render' => ['type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);
        register_rest_route(self::NS, '/draft/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_draft'],
                'permission_callback' => [$this, 'can_edit_post'],
                'args'                => $id_arg,
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'draft'],
                'permission_callback' => [$this, 'can_edit_post'],
                'args'                => $id_arg,
            ],
        ]);
        foreach (['apply' => 'apply', 'rollback' => 'rollback'] as $route => $method) {
            register_rest_route(self::NS, '/' . $route . '/(?P<id>\d+)', [
                'methods'             => 'POST',
                'callback'            => [$this, $method],
                'permission_callback' => [$this, 'can_edit_post'],
                'args'                => $id_arg,
            ]);
        }
        register_rest_route(self::NS, '/global-backup', [
            'methods'             => 'POST',
            'callback'            => [$this, 'global_backup'],
            'permission_callback' => [$this, 'can_edit_theme'],
        ]);
        register_rest_route(self::NS, '/global-restore', [
            'methods'             => 'POST',
            'callback'            => [$this, 'global_restore'],
            'permission_callback' => [$this, 'can_edit_theme'],
        ]);
    }

    // ---------------------------------------------------------------- permissions

    public function can_edit_posts(): bool
    {
        return current_user_can('edit_posts');
    }

    public function can_edit_post(WP_REST_Request $request): bool
    {
        $id = self::id($request);
        if ($id <= 0 || !current_user_can('edit_posts') || !current_user_can('edit_post', $id)) {
            return false;
        }
        // Kits hold site-wide settings and templates become site-wide theme parts / library items: same capability as
        // the global routes (and as Zadex's own theme builder).
        return !Elementor::is_library($id) || current_user_can('edit_theme_options');
    }

    public function can_edit_theme(): bool
    {
        return current_user_can('edit_posts') && current_user_can('edit_theme_options');
    }

    // ---------------------------------------------------------------- routes

    public function status(): WP_REST_Response
    {
        $kit = Elementor::kit_id();
        return new WP_REST_Response([
            'zadex'     => ['active' => class_exists('\\Zadex\\Plugin'), 'version' => defined('ZADEX_VERSION') ? (string) constant('ZADEX_VERSION') : ''],
            'elementor' => ['active' => Elementor::is_active(), 'version' => Elementor::version()],
            'kit'       => $kit > 0 && get_post($kit) ? ['id' => $kit] : null,
            'counts'    => [
                'documents' => Documents::count(''),
                'migrated'  => Documents::count(Store::STATE_APPLIED),
                'drafts'    => Documents::count(Store::STATE_DRAFT),
                'templates' => [
                    'documents' => Documents::count('', 'templates'),
                    'migrated'  => Documents::count(Store::STATE_APPLIED, 'templates'),
                    'drafts'    => Documents::count(Store::STATE_DRAFT, 'templates'),
                ],
            ],
            'globalBackup' => Store::global_backup() !== null,
        ]);
    }

    public function pages(WP_REST_Request $request): WP_REST_Response
    {
        $input = [];
        foreach (['kind', 'state', 'type', 'template_type', 'search', 'page', 'per_page'] as $key) {
            if ($request[$key] !== null) {
                $input[$key] = $request[$key];
            }
        }
        return new WP_REST_Response(Documents::query($input));
    }

    public function source(WP_REST_Request $request)
    {
        $render = $request['render'];
        $result = Source::build(self::id($request), Source::sanitize_types(is_string($render) ? $render : ''));
        return is_wp_error($result) ? $result : new WP_REST_Response($result);
    }

    public function draft(WP_REST_Request $request)
    {
        $id = self::id($request);
        if (!get_post($id)) {
            return self::not_found();
        }
        $result = Store::save_draft($id, $request->get_json_params());
        if (is_wp_error($result)) {
            return $result;
        }
        $out = ['saved' => true, 'previewUrls' => self::preview_urls($id)];
        if (Targets::is_template($id)) {
            $out['target'] = Targets::target_info($id);
            $out['targetUpdated'] = !empty($result['targetUpdated']);
        }
        return new WP_REST_Response($out);
    }

    /** Stored draft without the document itself: report, summary, template, createdAt, state, previewUrls. */
    public function get_draft(WP_REST_Request $request)
    {
        $id = self::id($request);
        if (!get_post($id)) {
            return self::not_found();
        }
        $draft = Store::draft($id);
        if ($draft === null) {
            return new WP_Error('zxm_no_draft', __('This page has not been converted yet.', 'zadex-migrator'), ['status' => 404]);
        }
        $out = [
            'report'      => $draft['report'] ?? ['entries' => [], 'notes' => []],
            'summary'     => $draft['summary'] ?? Store::sanitize_summary([]),
            'template'    => (string) ($draft['template'] ?? ''),
            'createdAt'   => (string) ($draft['createdAt'] ?? ''),
            'state'       => Store::state_name($id),
            'previewUrls' => self::preview_urls($id),
        ];
        if (Targets::is_template($id)) {
            $out['target'] = Targets::target_info($id);
            $out['targetSpec'] = isset($draft['target']) && is_array($draft['target']) ? $draft['target'] : null;
        }
        return new WP_REST_Response($out);
    }

    public function apply(WP_REST_Request $request)
    {
        $id = self::id($request);
        $result = Store::apply($id);
        if (is_wp_error($result)) {
            return $result;
        }
        if (Targets::is_template($id)) {
            $target = Targets::target_info($id);
            $target_id = $target !== null ? (int) $target['id'] : 0;
            return new WP_REST_Response([
                'applied' => true,
                'viewUrl' => $target_id > 0 ? (string) get_preview_post_link($target_id) : '',
                'editUrl' => $target !== null ? $target['editUrl'] : '',
                'target'  => $target,
            ]);
        }
        return new WP_REST_Response([
            'applied' => true,
            'viewUrl' => (string) get_permalink($id),
            'editUrl' => \Zadex\Plugin::instance()->editor->edit_url($id),
        ]);
    }

    public function rollback(WP_REST_Request $request)
    {
        $result = Store::rollback(self::id($request));
        return is_wp_error($result) ? $result : new WP_REST_Response(['restored' => true]);
    }

    public function global_backup(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $force = is_array($body) && !empty($body['force']);
        $written = Store::backup_global($force);
        return new WP_REST_Response(['saved' => true, 'kept' => !$written]);
    }

    public function global_restore()
    {
        $result = Store::restore_global();
        return is_wp_error($result) ? $result : new WP_REST_Response(['restored' => true]);
    }

    // ---------------------------------------------------------------- helpers

    private static function id(WP_REST_Request $request): int
    {
        $id = $request['id'];
        return is_numeric($id) ? max(0, (int) $id) : 0;
    }

    /** @return array{elementor: string, zadex: string} */
    private static function preview_urls(int $id): array
    {
        if (Targets::is_template($id)) {
            return Targets::preview_urls($id);
        }
        return ['elementor' => Preview::url($id, 'elementor'), 'zadex' => Preview::url($id, 'zadex')];
    }

    private static function not_found(): WP_Error
    {
        return new WP_Error('zxm_not_found', __('Post not found.', 'zadex-migrator'), ['status' => 404]);
    }
}
