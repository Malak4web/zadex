<?php
namespace ZadexMigrator;

defined('ABSPATH') || exit;

/**
 * Resolves the admin app from build/manifest.json (Vite), like Zadex's own Assets class. Development: define
 * ZADEX_MIGRATOR_DEV = true in wp-config.php while `npm run dev` runs (Vite on ZADEX_MIGRATOR_DEV_SERVER, default
 * http://localhost:5190).
 */
final class Assets
{
    public const ENTRY_ADMIN = 'src/admin/main.ts';

    private string $manifest_path;
    private string $build_url;
    private ?array $manifest = null;

    public function __construct(?string $manifest_path = null, ?string $build_url = null)
    {
        $this->manifest_path = $manifest_path ?? ZADEX_MIGRATOR_PATH . 'build/manifest.json';
        $this->build_url = $build_url ?? ZADEX_MIGRATOR_URL . 'build/';
    }

    public function is_dev(): bool
    {
        return defined('ZADEX_MIGRATOR_DEV') && (bool) constant('ZADEX_MIGRATOR_DEV');
    }

    public function dev_server(): string
    {
        return defined('ZADEX_MIGRATOR_DEV_SERVER') ? (string) constant('ZADEX_MIGRATOR_DEV_SERVER') : 'http://localhost:5190';
    }

    public function manifest(): array
    {
        if ($this->manifest === null) {
            $this->manifest = [];
            if ($this->manifest_path !== '' && is_readable($this->manifest_path)) {
                $decoded = wp_json_file_decode($this->manifest_path, ['associative' => true]);
                if (is_array($decoded)) {
                    $this->manifest = $decoded;
                }
            }
        }
        return $this->manifest;
    }

    public function has_build(string $entry = self::ENTRY_ADMIN): bool
    {
        return $this->is_dev() || !empty($this->manifest()[$entry]['file']);
    }

    /**
     * Module scripts + stylesheets of an entry, following imported chunks.
     *
     * @return array{js: string[], css: string[]}
     */
    public function entry(string $entry): array
    {
        if ($this->is_dev()) {
            return ['js' => [$this->dev_server() . '/@vite/client', $this->dev_server() . '/' . $entry], 'css' => []];
        }
        $manifest = $this->manifest();
        $js = [];
        $css = [];
        $seen = [];
        $walk = function (string $key) use (&$walk, &$js, &$css, &$seen, $manifest): void {
            if (isset($seen[$key]) || empty($manifest[$key]) || !is_array($manifest[$key])) {
                return;
            }
            $seen[$key] = true;
            $chunk = $manifest[$key];
            foreach ((array) ($chunk['imports'] ?? []) as $import) {
                $walk((string) $import);
            }
            foreach ((array) ($chunk['css'] ?? []) as $file) {
                $css[] = $this->build_url . $file;
            }
            if (!empty($chunk['file']) && !empty($chunk['isEntry'])) {
                $js[] = $this->build_url . $chunk['file'];
            }
        };
        $walk($entry);
        return ['js' => array_values(array_unique($js)), 'css' => array_values(array_unique($css))];
    }

    /** Enqueues an entry: styles with wp_enqueue_style, scripts as script modules (WordPress 6.5+). */
    public function enqueue_entry(string $entry, string $handle): void
    {
        $assets = $this->entry($entry);
        foreach ($assets['css'] as $i => $href) {
            wp_enqueue_style($handle . ($i ? '-' . $i : ''), $href, [], ZADEX_MIGRATOR_VERSION);
        }
        foreach ($assets['js'] as $i => $src) {
            wp_enqueue_script_module($handle . ($i ? '-' . $i : ''), $src, [], ZADEX_MIGRATOR_VERSION);
        }
    }
}
