<?php
namespace ZadexMigrator\Migration;

defined('ABSPATH') || exit;

use Zadex\Documents\Document;
use Zadex\Frontend\Templates;

/**
 * Side-by-side preview: `?zadex_migrator_preview=zadex|elementor&_wpnonce=…` on a post's front-end URL, for users
 * who can edit the post (nonce action `zadex_migrator_preview_{id}`).
 *
 *  zadex      serves the stored draft through `get_post_metadata` filters (Zadex data / CSS / page settings /
 *             template, `_zadex_edit_mode` = builder) and makes Elementor step aside (`_elementor_edit_mode` = '',
 *             its content filter removed), so only Zadex renders the content. Nothing is written.
 *  elementor  forces Elementor rendering (`_elementor_edit_mode` = builder, `_zadex_edit_mode` = '', the template
 *             from the backup), used for the comparison after an apply.
 *
 * Applied Zadex popups never open by themselves in either mode (`filter_popups`).
 */
final class Preview
{
    public const QUERY = 'zadex_migrator_preview';
    public const NONCE = 'zadex_migrator_preview_';

    private int $post_id = 0;
    private string $mode = '';
    /** @var array<string, mixed> meta key => value served (null = behave as if the meta did not exist) */
    private array $overrides = [];

    public function register(): void
    {
        // `wp`: the query is parsed (queried object known) and nothing has rendered yet; Elementor decides what to
        // render on template_redirect.
        add_action('wp', [$this, 'maybe_start'], 1);
    }

    /** Preview URL for one mode (a nonce for the current user is included). */
    public static function url(int $post_id, string $mode): string
    {
        $base = (string) get_preview_post_link($post_id);
        if ($base === '') {
            $base = (string) get_permalink($post_id);
        }
        return add_query_arg([self::QUERY => $mode, '_wpnonce' => wp_create_nonce(self::NONCE . $post_id)], $base);
    }

    /** Requested mode ('' when the query arg is missing or unknown). Routing only; maybe_start() checks nonce + caps. */
    public static function requested_mode(): string
    {
        $mode = isset($_GET[self::QUERY]) ? sanitize_key(wp_unslash($_GET[self::QUERY])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified in maybe_start().
        return in_array($mode, ['zadex', 'elementor'], true) ? $mode : '';
    }

    public function maybe_start(): void
    {
        $mode = self::requested_mode();
        if ($mode === '') {
            return;
        }
        $post_id = (int) get_queried_object_id();
        if ($post_id <= 0) {
            // phpcs:disable WordPress.Security.NonceVerification.Recommended -- the nonce is verified right below.
            $post_id = isset($_GET['p']) ? absint(wp_unslash($_GET['p'])) : 0;
            if ($post_id <= 0 && isset($_GET['page_id'])) {
                $post_id = absint(wp_unslash($_GET['page_id']));
            }
            // phpcs:enable WordPress.Security.NonceVerification.Recommended
        }
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if ($post_id <= 0 || !wp_verify_nonce($nonce, self::NONCE . $post_id) || !current_user_can('edit_post', $post_id)) {
            wp_die(esc_html__('This preview link is not valid for your account. Open the preview again from the Zadex Migrator screen.', 'zadex-migrator'), '', ['response' => 403]);
        }
        $overrides = $mode === 'zadex' ? self::zadex_overrides($post_id) : self::elementor_overrides($post_id);
        if ($overrides === null) {
            wp_die(esc_html__('There is no converted draft for this page yet.', 'zadex-migrator'), '', ['response' => 404]);
        }
        $this->start($post_id, $mode, $overrides);
    }

    /** Installs the meta overrides and the request tweaks (also used by tests). */
    public function start(int $post_id, string $mode, array $overrides): void
    {
        $this->post_id = $post_id;
        $this->mode = $mode;
        $this->overrides = $overrides;
        add_filter('get_post_metadata', [$this, 'filter_meta'], 1, 4);
        add_filter('show_admin_bar', '__return_false');
        add_filter('wp_robots', 'wp_robots_no_robots');
        // Live Zadex popups (applied migrations) would open over the comparison: see filter_popups().
        add_filter('zadex/popups/ids', [$this, 'filter_popups'], 20, 1);
        if ($mode === 'zadex') {
            // After Elementor's own template_redirect setup (priority 10): it must not print the builder content.
            add_action('template_redirect', [$this, 'unhook_elementor'], 11);
        }
        if (!headers_sent()) {
            nocache_headers();
        }
    }

    public function mode(): string
    {
        return $this->mode;
    }

    /**
     * Metas served in the Zadex preview, from the draft (null without a draft).
     *
     * @return array<string, mixed>|null
     */
    public static function zadex_overrides(int $post_id): ?array
    {
        $draft = Store::draft($post_id);
        if ($draft === null) {
            return null;
        }
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        $current = (string) get_post_meta($post_id, Templates::META, true);
        $backup = Store::backup($post_id);
        if ($backup !== null && array_key_exists(Templates::META, $backup['metas'])) {
            $current = (string) ($backup['metas'][Templates::META] ?? '');
        }
        return [
            Document::META_DATA => (string) wp_json_encode($draft['data'], $flags),
            Document::META_CSS  => isset($draft['css']) && is_string($draft['css']) ? $draft['css'] : '',
            Document::META_MODE => 'builder',
            Document::META_PAGE => isset($draft['pageSettings']) && is_array($draft['pageSettings']) ? (string) wp_json_encode($draft['pageSettings'], JSON_UNESCAPED_UNICODE) : null,
            Templates::META     => Store::target_template($current, (string) ($draft['template'] ?? '')),
            Elementor::META_MODE => '',
        ];
    }

    /**
     * Metas served in the Elementor preview: Elementor renders, Zadex does not; after an apply the original page
     * template comes back from the backup.
     *
     * @return array<string, mixed>
     */
    public static function elementor_overrides(int $post_id): array
    {
        $out = [
            Elementor::META_MODE => 'builder',
            Document::META_MODE  => '',
        ];
        $backup = Store::backup($post_id);
        if ($backup !== null && array_key_exists(Templates::META, $backup['metas'])) {
            $out[Templates::META] = $backup['metas'][Templates::META];
        }
        return $out;
    }

    /**
     * `get_post_metadata`: serves the override for the previewed post. Returning an array makes WordPress use its
     * first item for single reads and the whole list otherwise.
     *
     * @param mixed $value
     * @return mixed
     */
    public function filter_meta($value, $object_id, $meta_key, $single)
    {
        if ((int) $object_id !== $this->post_id || !is_string($meta_key) || $meta_key === '' || !array_key_exists($meta_key, $this->overrides)) {
            return $value;
        }
        $served = $this->overrides[$meta_key];
        if ($served === null) {
            return $single ? [''] : [];
        }
        return [$served];
    }

    /**
     * `zadex/popups/ids` (Zadex `[popup id => auto]`): the Elementor preview shows no Zadex popup at all (it shows what
     * Elementor renders); the Zadex preview keeps the popups the page links to but never opens one by itself (a
     * page-load / scroll / exit popup with an overlay would cover the side-by-side comparison).
     *
     * @param mixed $ids
     * @return mixed
     */
    public function filter_popups($ids)
    {
        if (!is_array($ids) || $this->mode === '') {
            return $ids;
        }
        if ($this->mode === 'elementor') {
            return [];
        }
        return array_map(static fn() => false, $ids);
    }

    /** Removes Elementor's `the_content` filter for the Zadex preview (it would otherwise render its own tree). */
    public function unhook_elementor(): void
    {
        if (!Elementor::is_active()) {
            return;
        }
        $frontend = \Elementor\Plugin::$instance->frontend ?? null;
        if (is_object($frontend) && method_exists($frontend, 'remove_content_filter')) {
            $frontend->remove_content_filter();
        }
    }
}
