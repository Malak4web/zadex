<?php
namespace ZadexMigrator\Migration;

defined('ABSPATH') || exit;

use WP_Error;
use Zadex\Documents\Document;
use Zadex\Library\Store as LibraryStore;
use Zadex\Theme\Conditions;
use Zadex\Theme\TemplatePost;

/**
 * Elementor templates (`elementor_library` posts) and the Zadex posts they migrate into (docs/ARCHITECTURE.md
 * "Theme Builder and saved templates"). The Elementor post is never converted in place:
 *
 *  theme templates (header, footer, single, archive, search, 404, loop item, WooCommerce product templates)
 *      -> a `zadex_template` post (Zadex TemplatePost: type, conditions, settings)
 *  popups -> a `zadex_template` post of type `popup` (layout / triggers / rules live in its page settings `popup_*`)
 *  saved templates (page, section, container)
 *      -> a `zadex_library` post (Zadex Library Store: `_zadex_library_type` page | section)
 *
 * `_zadex_migrator_target` (int) on the Elementor post holds the target id. Kits are not supported (globals step).
 */
final class Targets
{
    public const META_TARGET = '_zadex_migrator_target';

    /** Elementor template types that become Zadex library items. */
    public const LIBRARY_TYPES = ['page', 'section', 'container'];

    /** Elementor template types this migrator cannot convert (kit: global settings step). */
    public const UNSUPPORTED = ['kit'];

    /** Elementor template type -> Zadex template type, used when the draft body carries no target. */
    public const THEME_TYPES = [
        'header'          => 'header',
        'footer'          => 'footer',
        'single'          => 'single',
        'single-post'     => 'single',
        'single-page'     => 'single',
        'archive'         => 'archive',
        'search-results'  => 'search',
        'error-404'       => '404',
        'loop-item'       => 'loop-item',
        'product'         => 'product',
        'product-archive' => 'product_archive',
        'popup'           => 'popup',
    ];

    /** Whether the post is an Elementor template handled by the template flow (library post, not a kit). */
    public static function is_template(int $post_id): bool
    {
        return Elementor::is_library($post_id) && Elementor::template_type($post_id) !== 'kit';
    }

    /** Whether the Elementor template is a saved template (page / section / container) rather than a theme part. */
    public static function is_library_type(string $elementor_type): bool
    {
        return in_array($elementor_type, self::LIBRARY_TYPES, true);
    }

    /** 400 error for template types the migrator does not convert (null when supported). */
    public static function unsupported(int $post_id): ?WP_Error
    {
        $type = Elementor::template_type($post_id);
        if (in_array($type, self::UNSUPPORTED, true)) {
            return new WP_Error('zxm_unsupported', __('This Elementor template type cannot be migrated.', 'zadex-migrator'), ['status' => 400]);
        }
        return null;
    }

    // ---------------------------------------------------------------- draft body target

    /**
     * Validates + sanitizes the draft body's `target` with Zadex's own sanitizers. Missing target: derived from the
     * Elementor template type (no conditions, default settings).
     *
     * @return array|WP_Error {kind:'theme', type, rules, settings} | {kind:'library', type}
     */
    public static function sanitize_target(int $post_id, $target)
    {
        $unsupported = self::unsupported($post_id);
        if ($unsupported !== null) {
            return $unsupported;
        }
        $elementor_type = Elementor::template_type($post_id);
        $library = self::is_library_type($elementor_type);
        if ($target === null) {
            $target = $library
                ? ['kind' => 'library', 'type' => $elementor_type === 'page' ? 'page' : 'section']
                : ['kind' => 'theme', 'type' => self::THEME_TYPES[$elementor_type] ?? '', 'rules' => [], 'settings' => []];
        }
        if (!is_array($target)) {
            return self::bad_target(__('Invalid template target.', 'zadex-migrator'));
        }
        $kind = $target['kind'] ?? '';
        if ($kind !== ($library ? 'library' : 'theme')) {
            return self::bad_target($library
                ? __('A saved Elementor template must become a Zadex library template.', 'zadex-migrator')
                : __('An Elementor theme template must become a Zadex theme template.', 'zadex-migrator'));
        }
        if ($library) {
            return ['kind' => 'library', 'type' => LibraryStore::sanitize_type($target['type'] ?? '')];
        }
        $type = TemplatePost::sanitize_type($target['type'] ?? '');
        if ($type === '') {
            // Zadex registers its product / product_archive types only while WooCommerce is active.
            $requested = is_string($target['type'] ?? null) ? strtolower(trim($target['type'])) : '';
            if (in_array($requested, ['product', 'product_archive'], true)) {
                return self::bad_target(__('WooCommerce is not active: Zadex has no product templates without it. Activate WooCommerce, then convert this template again.', 'zadex-migrator'));
            }
            return self::bad_target(__('Unknown Zadex template type.', 'zadex-migrator'));
        }
        // An Elementor popup becomes a Zadex popup and nothing else becomes one.
        if (($type === 'popup') !== ($elementor_type === 'popup')) {
            return self::bad_target($type === 'popup'
                ? __('Only an Elementor popup can become a Zadex popup.', 'zadex-migrator')
                : __('An Elementor popup must become a Zadex popup.', 'zadex-migrator'));
        }
        return [
            'kind'     => 'theme',
            'type'     => $type,
            'rules'    => Conditions::sanitize(isset($target['rules']) && is_array($target['rules']) ? $target['rules'] : []),
            'settings' => TemplatePost::sanitize_settings(isset($target['settings']) && is_array($target['settings']) ? $target['settings'] : []),
        ];
    }

    private static function bad_target(string $message): WP_Error
    {
        return new WP_Error('zxm_bad_request', $message, ['status' => 400]);
    }

    // ---------------------------------------------------------------- target posts

    /** Stored target id when that post still exists (not trashed) and is a Zadex template / library item, else 0. */
    public static function target_id(int $post_id): int
    {
        $id = absint(get_post_meta($post_id, self::META_TARGET, true));
        if ($id <= 0) {
            return 0;
        }
        $post = get_post($id);
        if (!$post || (string) $post->post_status === 'trash' || !in_array((string) $post->post_type, [TemplatePost::POST_TYPE, LibraryStore::CPT], true)) {
            return 0;
        }
        return $id;
    }

    /** Target post status ('' without a target). */
    public static function target_status(int $post_id): string
    {
        $id = self::target_id($post_id);
        $post = $id > 0 ? get_post($id) : null;
        return $post ? (string) $post->post_status : '';
    }

    /**
     * Writes the draft into the target post (created when missing, or when its post type no longer matches the
     * kind) through Zadex's Document::save, then type / settings / conditions (theme) or library type. $status
     * 'publish' publishes it (apply); null keeps the current status (new targets are drafts).
     *
     * @return int|WP_Error target id
     */
    public static function write(int $post_id, array $draft, ?string $status = null)
    {
        $target = isset($draft['target']) && is_array($draft['target']) ? $draft['target'] : null;
        if ($target === null) {
            return new WP_Error('zxm_no_draft', __('Convert the template again before applying it.', 'zadex-migrator'), ['status' => 400]);
        }
        $post = get_post($post_id);
        $title = $post ? html_entity_decode((string) $post->post_title, ENT_QUOTES, 'UTF-8') : '';
        $theme = ($target['kind'] ?? '') === 'theme';
        $post_type = $theme ? TemplatePost::POST_TYPE : LibraryStore::CPT;
        $id = self::target_id($post_id);
        if ($id > 0 && get_post_type($id) !== $post_type) {
            $id = 0;
        }
        if ($id === 0) {
            $id = $theme ? TemplatePost::create($title, (string) $target['type']) : self::create_library_item($title);
            if ($id <= 0) {
                return new WP_Error('zxm_target_failed', __('The Zadex template could not be created.', 'zadex-migrator'), ['status' => 500]);
            }
            update_post_meta($post_id, self::META_TARGET, $id);
        }
        $library_type = $theme ? '' : LibraryStore::sanitize_type($target['type'] ?? '');
        $page = isset($draft['pageSettings']) && is_array($draft['pageSettings']) ? $draft['pageSettings'] : null;
        if (!$theme && $library_type !== 'page') {
            $page = null; // Zadex keeps page settings for page library items only.
        }
        $saved = Document::save(
            $id,
            isset($draft['data']) && is_array($draft['data']) ? $draft['data'] : Document::empty_document(),
            isset($draft['css']) && is_string($draft['css']) ? $draft['css'] : '',
            $page,
            $status
        );
        if (is_wp_error($saved)) {
            return $saved;
        }
        if ($theme) {
            TemplatePost::set_type($id, (string) $target['type']);
            // After Document::save: Zadex's document_saved hook syncs settings from page settings first.
            TemplatePost::set_settings($id, isset($target['settings']) && is_array($target['settings']) ? $target['settings'] : []);
            TemplatePost::set_conditions($id, isset($target['rules']) && is_array($target['rules']) ? $target['rules'] : []);
        } else {
            update_post_meta($id, LibraryStore::META_TYPE, $library_type);
            if ($status === 'publish') {
                do_action('zadex/library/saved', $id, $library_type);
            }
        }
        self::flush();
        return $id;
    }

    /** Draft `zadex_library` post (Zadex's Store::create publishes at once; the migrator publishes on apply). */
    private static function create_library_item(string $title): int
    {
        $id = wp_insert_post(wp_slash([
            'post_type'    => LibraryStore::CPT,
            'post_title'   => $title !== '' ? $title : __('Imported template', 'zadex-migrator'),
            'post_status'  => 'draft',
            'post_content' => '',
        ]), true);
        if (is_wp_error($id) || !$id) {
            return 0;
        }
        update_post_meta((int) $id, LibraryStore::META_TAGS, []);
        return (int) $id;
    }

    /** Sets a post's status (no-op when unchanged). */
    public static function set_status(int $id, string $status): void
    {
        $post = $id > 0 ? get_post($id) : null;
        if ($post && (string) $post->post_status !== $status) {
            wp_update_post(['ID' => $id, 'post_status' => $status]);
        }
    }

    /**
     * Whether applying should set the Elementor template to draft: only theme parts that Elementor Pro shows through
     * display conditions. Loop items and saved templates stay published (Elementor pages not migrated yet still
     * embed them).
     */
    public static function hides_elementor(array $target): bool
    {
        return ($target['kind'] ?? '') === 'theme' && ($target['type'] ?? '') !== 'loop-item';
    }

    /** Clears the per-request template caches of Zadex and Elementor Pro after a template changed. */
    public static function flush(): void
    {
        if (class_exists('\\Zadex\\Theme\\Resolver')) {
            \Zadex\Theme\Resolver::reset();
        }
        $module = '\\ElementorPro\\Modules\\ThemeBuilder\\Module';
        if (!class_exists($module) || !method_exists($module, 'instance')) {
            return;
        }
        try {
            $manager = $module::instance()->get_conditions_manager();
            $cache = is_object($manager) && method_exists($manager, 'get_cache') ? $manager->get_cache() : null;
            if (is_object($cache) && method_exists($cache, 'regenerate')) {
                $cache->regenerate();
            }
        } catch (\Throwable $e) {
            unset($e); // Elementor Pro rebuilds its cache on its own next save.
        }
    }

    // ---------------------------------------------------------------- read side

    /**
     * Id maps for the converter, from the `_zadex_migrator_target` metas of migrated templates whose target still
     * exists: loopTemplates (Elementor loop item id -> Zadex loop-item template id) and libraryTemplates (Elementor
     * template id -> Zadex template / library id, every migrated template).
     *
     * popupTemplates: Elementor popup id -> Zadex popup template id.
     *
     * @return array{loopTemplates: array<string, int>, libraryTemplates: array<string, int>, popupTemplates: array<string, int>}
     */
    public static function id_maps(): array
    {
        $ids = get_posts([
            'post_type'        => Elementor::LIBRARY_TYPE,
            'post_status'      => 'any',
            'numberposts'      => 500,
            'fields'           => 'ids',
            'meta_key'         => self::META_TARGET, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- admin-only REST route, bounded.
            'suppress_filters' => false,
        ]);
        $loop = [];
        $library = [];
        $popups = [];
        foreach ((array) $ids as $id) {
            $id = is_object($id) ? (int) $id->ID : (int) $id;
            $target = self::target_id($id);
            if ($target <= 0) {
                continue;
            }
            $library[(string) $id] = $target;
            $zadex_type = get_post_type($target) === TemplatePost::POST_TYPE ? TemplatePost::type($target) : '';
            if ($zadex_type === 'loop-item') {
                $loop[(string) $id] = $target;
            } elseif ($zadex_type === 'popup') {
                $popups[(string) $id] = $target;
            }
        }
        return ['loopTemplates' => $loop, 'libraryTemplates' => $library, 'popupTemplates' => $popups];
    }

    /** `{id, editUrl, status}` of the target, null without one. */
    public static function target_info(int $post_id): ?array
    {
        $id = self::target_id($post_id);
        if ($id <= 0) {
            return null;
        }
        $post = get_post($id);
        return [
            'id'      => $id,
            // Library items have no editor / front-end view in Zadex (they are inserted from its library panel).
            'editUrl' => self::is_library_item($id) ? '' : self::edit_url($id),
            'status'  => $post ? (string) $post->post_status : '',
        ];
    }

    /** Zadex editor URL of a target. */
    public static function edit_url(int $id): string
    {
        $plugin = class_exists('\\Zadex\\Plugin') ? \Zadex\Plugin::instance() : null;
        if ($plugin !== null && isset($plugin->editor) && is_object($plugin->editor) && method_exists($plugin->editor, 'edit_url')) {
            return (string) $plugin->editor->edit_url($id);
        }
        return (string) get_preview_post_link($id, ['zadex' => 'edit']);
    }

    /**
     * Preview URLs of a template: Elementor side through the migrator's preview of the Elementor post, Zadex side
     * the target's own preview (Zadex renders a single `zadex_template` with its template preview view, editors
     * only; drafts included). '' when there is no target yet or the target is a library item (not viewable).
     *
     * @return array{elementor: string, zadex: string}
     */
    public static function preview_urls(int $post_id): array
    {
        $id = self::target_id($post_id);
        return [
            'elementor' => Preview::url($post_id, 'elementor'),
            'zadex'     => $id > 0 && !self::is_library_item($id) ? (string) get_preview_post_link($id) : '',
        ];
    }

    private static function is_library_item(int $id): bool
    {
        return get_post_type($id) === LibraryStore::CPT;
    }

    /**
     * One-line English summary of Elementor conditions ("Entire site", "Singular: post, not Singular: page #12").
     *
     * @param string[] $conditions
     */
    public static function conditions_summary(array $conditions): string
    {
        $parts = [];
        foreach ($conditions as $condition) {
            if (!is_string($condition) || $condition === '') {
                continue;
            }
            $bits = explode('/', $condition);
            $mode = array_shift($bits);
            if (!in_array($mode, ['include', 'exclude'], true)) {
                array_unshift($bits, (string) $mode);
                $mode = 'include';
            }
            $text = self::condition_label($bits);
            $parts[] = $mode === 'exclude' ? sprintf(/* translators: %s: excluded display condition */ __('not %s', 'zadex-migrator'), $text) : $text;
        }
        return $parts === [] ? __('No conditions', 'zadex-migrator') : implode(', ', $parts);
    }

    /** @param string[] $bits condition without its include/exclude prefix */
    private static function condition_label(array $bits): string
    {
        $group = (string) ($bits[0] ?? '');
        $sub = (string) ($bits[1] ?? '');
        $value = (string) ($bits[2] ?? '');
        $special = [
            'general'                => __('Entire site', 'zadex-migrator'),
            'singular'               => __('All singular', 'zadex-migrator'),
            'archive'                => __('All archives', 'zadex-migrator'),
            'singular/front_page'    => __('Front page', 'zadex-migrator'),
            'singular/not_found404'  => __('404 page', 'zadex-migrator'),
            'archive/search'         => __('Search results', 'zadex-migrator'),
            'archive/date'           => __('Date archives', 'zadex-migrator'),
            'archive/author'         => __('Author archives', 'zadex-migrator'),
            'archive/post_archive'   => __('Archive: post', 'zadex-migrator'),
        ];
        $key = $sub !== '' ? $group . '/' . $sub : $group;
        if ($value === '' && isset($special[$key])) {
            return $special[$key];
        }
        $groups = ['singular' => __('Singular', 'zadex-migrator'), 'archive' => __('Archive', 'zadex-migrator')];
        $label = $groups[$group] ?? str_replace('_', ' ', $group);
        $detail = trim(str_replace('_', ' ', $sub) . ($value !== '' ? ' #' . $value : ''));
        foreach (array_slice($bits, 3) as $extra) {
            $detail .= ' ' . str_replace('_', ' ', (string) $extra);
        }
        return $detail !== '' ? $label . ': ' . trim($detail) : $label;
    }
}
