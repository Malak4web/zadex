<?php
namespace ZadexMigrator\Migration;

defined('ABSPATH') || exit;

use WP_Error;

/**
 * Builds the `SourceDocument` (src/convert/types.ts) of one Elementor document: decoded `_elementor_data`, page
 * settings, page template, active kit settings, site direction, Elementor version, details of every attachment the
 * tree references (alt, sizes, sanitized inline SVG) and, when Elementor is active, Elementor-rendered HTML for the
 * widget types the client asks for.
 *
 * For a kit post (GET source/{status.kit.id}), `kit` holds that kit's own settings. Elementor templates add
 * `templateType` + `conditions` (popups also `popupSettings`); every source carries the id maps of migrated
 * templates (`loopTemplates`, `libraryTemplates`, `popupTemplates`) and, when the tree places Elementor Pro global
 * widgets, `globalWidgets` (template id -> the template's widget element).
 *
 * After an apply, `_elementor_edit_mode` and `_wp_page_template` hold the Zadex values; the source then reports the
 * original template from the migration backup so re-converting gives the same result.
 */
final class Source
{
    public const MAX_MEDIA = 500;
    public const MAX_SVG_BYTES = 524288;

    /**
     * @param string[] $render widget types to render server-side (Elementor active only)
     * @return array|WP_Error
     */
    public static function build(int $post_id, array $render = [])
    {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('zxm_not_found', __('Post not found.', 'zadex-migrator'), ['status' => 404]);
        }
        // A kit (site settings) usually has no element tree; the client reads its `kit` / `pageSettings`.
        $is_kit = Elementor::is_kit($post_id);
        if (!$is_kit && !metadata_exists('post', $post_id, Elementor::META_DATA)) {
            return new WP_Error('zxm_not_elementor', __('This content has no Elementor data.', 'zadex-migrator'), ['status' => 400]);
        }
        $elements = Elementor::decode_data(get_post_meta($post_id, Elementor::META_DATA, true));
        $page_settings = Elementor::decode_settings(get_post_meta($post_id, Elementor::META_PAGE, true));
        $kit = $is_kit ? $page_settings : Elementor::kit_settings();

        $template = (string) get_post_meta($post_id, '_wp_page_template', true);
        $backup = Store::backup($post_id);
        if ($backup !== null && array_key_exists('_wp_page_template', $backup['metas'])) {
            $template = (string) ($backup['metas']['_wp_page_template'] ?? '');
        }

        $version = (string) get_post_meta($post_id, Elementor::META_VERSION, true);
        $ids = self::media_ids([$elements, $page_settings]);

        $out = [
            'postId'           => (int) $post_id,
            'title'            => (string) $post->post_title,
            'postType'         => (string) $post->post_type,
            'elements'         => self::normalize($elements),
            'pageSettings'     => (object) $page_settings,
            'template'         => $template,
            'elementorVersion' => $version !== '' ? $version : Elementor::version(),
            'rtl'              => function_exists('is_rtl') && is_rtl(),
            'media'            => (object) self::media($ids),
            'rendered'         => (object) Elementor::render_widgets($post_id, $elements, self::sanitize_types($render)),
        ];
        // An active kit that stores no settings (fresh install, or only the site name) is still sent, as `{}`: the
        // converter then applies Elementor's default kit fonts / colors, which Elementor renders with (V7).
        if ($kit !== [] || (!$is_kit && Elementor::kit_id() > 0)) {
            $out['kit'] = (object) $kit;
        }
        // v4 atomic elements: global classes referenced by the tree and the kit's global variables.
        $classes = Elementor::global_classes(Elementor::global_class_ids($elements));
        if ($classes !== []) {
            $out['globalClasses'] = (object) $classes;
            $class_media = self::media_ids($classes);
            if ($class_media !== []) {
                $out['media'] = (object) (self::media(array_values(array_unique(array_merge($ids, $class_media)))));
            }
        }
        $variables = Elementor::global_variables();
        if ($variables !== []) {
            $out['globalVariables'] = (object) $variables;
        }
        $menus = self::menus();
        if ($menus !== []) {
            $out['menus'] = (object) $menus;
        }
        // Elementor templates: type + raw display conditions (the converter maps both to the Zadex target).
        if (!$is_kit && $post->post_type === Elementor::LIBRARY_TYPE) {
            $out['templateType'] = Elementor::template_type($post_id);
            $out['conditions'] = Elementor::conditions($post_id);
            if ($out['templateType'] === 'popup') {
                // Triggers + advanced rules ({triggers, timing}); `{}` when the popup has none stored.
                // Empty groups stay objects in JSON (`{"triggers": {}}`, not `[]`).
                $out['popupSettings'] = (object) array_map(
                    static fn($group) => $group === [] ? (object) [] : $group,
                    Elementor::popup_display_settings($post_id)
                );
            }
        }
        // Id maps of templates migrated already (loop grids, template widgets reference them).
        $maps = Targets::id_maps();
        $out['loopTemplates'] = (object) $maps['loopTemplates'];
        $out['libraryTemplates'] = (object) $maps['libraryTemplates'];
        $out['popupTemplates'] = (object) $maps['popupTemplates'];
        // Elementor Pro global widgets: the template's widget element, converted in place by the `global` mapper.
        $globals = self::global_widgets($elements);
        if ($globals !== []) {
            $out['globalWidgets'] = (object) $globals;
            $global_media = self::media_ids($globals);
            if ($global_media !== []) {
                $known = array_map('intval', array_keys((array) $out['media']));
                $out['media'] = (object) (self::media(array_values(array_unique(array_merge($known, $global_media)))));
            }
        }
        return $out;
    }

    /**
     * Elementor Pro global widget instances (`widgetType: 'global'` + `templateID`) anywhere in the tree -> the first
     * element of each referenced template's `_elementor_data` (normalized). Missing / trashed templates are left out.
     *
     * @param array<int, array> $elements
     * @return array<string, array>
     */
    public static function global_widgets(array $elements): array
    {
        $ids = [];
        self::walk_globals($elements, $ids, 0);
        $out = [];
        foreach (array_slice(array_keys($ids), 0, 100) as $id) {
            $post = get_post($id);
            if (!$post || $post->post_type !== Elementor::LIBRARY_TYPE || $post->post_status === 'trash') {
                continue;
            }
            $data = Elementor::decode_data(get_post_meta($id, Elementor::META_DATA, true));
            if (isset($data[0]) && is_array($data[0])) {
                $out[(string) $id] = self::normalize([$data[0]])[0];
            }
        }
        return $out;
    }

    /** @param array<int, true> $ids */
    private static function walk_globals(array $elements, array &$ids, int $depth): void
    {
        if ($depth > 64) {
            return;
        }
        foreach ($elements as $el) {
            if (!is_array($el)) {
                continue;
            }
            if (($el['widgetType'] ?? '') === 'global' && self::is_id($el['templateID'] ?? null)) {
                $ids[(int) $el['templateID']] = true;
            }
            if (isset($el['elements']) && is_array($el['elements'])) {
                self::walk_globals($el['elements'], $ids, $depth + 1);
            }
        }
    }

    /**
     * WordPress navigation menus as slug => term id: Elementor Pro's nav-menu widget stores the menu slug, the Zadex
     * nav-menu widget needs the term id.
     *
     * @return array<string, int>
     */
    public static function menus(): array
    {
        if (!function_exists('wp_get_nav_menus')) {
            return [];
        }
        $out = [];
        foreach ((array) wp_get_nav_menus() as $menu) {
            if (is_object($menu) && isset($menu->term_id, $menu->slug)) {
                $out[(string) $menu->slug] = (int) $menu->term_id;
            }
        }
        return $out;
    }

    /**
     * JSON shape fix-up: empty `settings` / `styles` must stay objects (`{}`), not lists, after a PHP round-trip.
     *
     * @param array<int, array> $elements
     * @return array<int, array>
     */
    public static function normalize(array $elements): array
    {
        foreach ($elements as $i => $el) {
            if (!is_array($el)) {
                continue;
            }
            foreach (['settings', 'styles'] as $key) {
                if (array_key_exists($key, $el) && (!is_array($el[$key]) || $el[$key] === [])) {
                    $el[$key] = (object) (is_array($el[$key]) ? $el[$key] : []);
                }
            }
            if (!isset($el['settings'])) {
                $el['settings'] = (object) [];
            }
            $el['elements'] = isset($el['elements']) && is_array($el['elements']) ? self::normalize($el['elements']) : [];
            $elements[$i] = $el;
        }
        return array_values($elements);
    }

    /**
     * Normalizes the `render` list: widget type names (lowercase letters, digits, `-`, `_`), at most 100.
     *
     * @param mixed $types array or comma-separated string
     * @return string[]
     */
    public static function sanitize_types($types): array
    {
        if (is_string($types)) {
            $types = explode(',', $types);
        }
        if (!is_array($types)) {
            return [];
        }
        $out = [];
        foreach ($types as $type) {
            if (!is_string($type)) {
                continue;
            }
            $clean = sanitize_key($type);
            if ($clean !== '') {
                $out[$clean] = true;
            }
        }
        return array_slice(array_keys($out), 0, 100);
    }

    /**
     * Every attachment id referenced anywhere in the given values: `{id, url}` shapes (images, backgrounds, galleries,
     * icon SVGs, hosted videos) and v4 atomic `{$$type: image-attachment-id, value: id}` props.
     *
     * @return int[]
     */
    public static function media_ids($value): array
    {
        $ids = [];
        self::walk_media($value, $ids, 0);
        return array_slice(array_keys($ids), 0, self::MAX_MEDIA);
    }

    /** @param array<int, true> $ids */
    private static function walk_media($value, array &$ids, int $depth): void
    {
        if (!is_array($value) || $depth > 64) {
            return;
        }
        if (array_key_exists('id', $value) && array_key_exists('url', $value) && self::is_id($value['id'])) {
            $ids[(int) $value['id']] = true;
        }
        if (($value['$$type'] ?? null) === 'image-attachment-id' && self::is_id($value['value'] ?? null)) {
            $ids[(int) $value['value']] = true;
        }
        foreach ($value as $child) {
            if (is_array($child)) {
                self::walk_media($child, $ids, $depth + 1);
            }
        }
    }

    private static function is_id($value): bool
    {
        return (is_int($value) && $value > 0) || (is_string($value) && ctype_digit($value) && (int) $value > 0);
    }

    /**
     * @param int[] $ids
     * @return array<string, array> id => MediaInfo
     */
    public static function media(array $ids): array
    {
        $out = [];
        foreach ($ids as $id) {
            $info = self::media_info((int) $id);
            if ($info !== null) {
                $out[(string) $id] = $info;
            }
        }
        return $out;
    }

    /** MediaInfo of one attachment (null when it is not an attachment). */
    public static function media_info(int $id): ?array
    {
        $post = get_post($id);
        if (!$post || $post->post_type !== 'attachment') {
            return null;
        }
        $url = wp_get_attachment_url($id);
        if (!is_string($url) || $url === '') {
            return null;
        }
        $info = ['id' => $id, 'url' => $url];
        $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
        if (is_string($alt) && $alt !== '') {
            $info['alt'] = sanitize_text_field($alt);
        }
        $meta = wp_get_attachment_metadata($id);
        $meta = is_array($meta) ? $meta : [];
        if (!empty($meta['width']) && !empty($meta['height'])) {
            $info['width'] = (int) $meta['width'];
            $info['height'] = (int) $meta['height'];
        }
        $sizes = [];
        foreach ((isset($meta['sizes']) && is_array($meta['sizes']) ? $meta['sizes'] : []) as $name => $size) {
            $src = wp_get_attachment_image_src($id, (string) $name);
            if (is_array($src) && !empty($src[0])) {
                $sizes[(string) $name] = ['url' => (string) $src[0], 'width' => (int) ($src[1] ?? 0), 'height' => (int) ($src[2] ?? 0)];
            }
        }
        if ($sizes !== []) {
            $info['sizes'] = $sizes;
        }
        if (get_post_mime_type($id) === 'image/svg+xml') {
            $svg = self::svg_markup($id);
            if ($svg !== '') {
                $info['svg'] = $svg;
            }
        }
        return $info;
    }

    /** Sanitized markup of a local SVG attachment ('' when unreadable, too large or Zadex's sanitizer is missing). */
    public static function svg_markup(int $id): string
    {
        if (!method_exists('\\Zadex\\Documents\\Sanitizer', 'clean_svg')) {
            return '';
        }
        $file = get_attached_file($id);
        if (!is_string($file) || $file === '' || !is_file($file) || !is_readable($file) || filesize($file) > self::MAX_SVG_BYTES) {
            return '';
        }
        $raw = '';
        $fs = class_exists('\\Zadex\\Filesystem') ? \Zadex\Filesystem::get() : null;
        if ($fs !== null && method_exists($fs, 'get_contents')) {
            $raw = (string) $fs->get_contents($file);
        }
        return $raw === '' ? '' : \Zadex\Documents\Sanitizer::clean_svg($raw);
    }
}
