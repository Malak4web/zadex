<?php
namespace ZadexMigrator\Migration;

defined('ABSPATH') || exit;

use WP_Error;
use Zadex\Documents\Document;
use Zadex\Documents\Sanitizer;
use Zadex\Frontend\Templates;

/**
 * Draft / apply / rollback of one converted document, and backup / restore of the Zadex globals.
 *
 * Post meta (JSON strings, stored slashed because update_post_meta() unslashes):
 *  _zadex_migrator_draft   {data, css, pageSettings, template, report, summary, createdAt}
 *  _zadex_migrator_backup  {metas: {meta_key: previous value | null when it did not exist}, at}
 *  _zadex_migrator_state   {state: draft|applied, score, at, appliedAt?}
 * Option: zadex_migrator_global_backup {global, globalCss, breakpoints (null = did not exist), at}
 */
final class Store
{
    public const META_DRAFT = '_zadex_migrator_draft';
    public const META_BACKUP = '_zadex_migrator_backup';
    public const META_STATE = '_zadex_migrator_state';
    public const OPTION_GLOBAL_BACKUP = 'zadex_migrator_global_backup';

    public const STATE_DRAFT = 'draft';
    public const STATE_APPLIED = 'applied';

    /** Metas saved before apply and put back by rollback. */
    public const BACKED_UP = [
        Document::META_DATA,
        Document::META_CSS,
        Document::META_MODE,
        Document::META_PAGE,
        Elementor::META_MODE,
        Templates::META,
    ];

    // ---------------------------------------------------------------- drafts

    /**
     * Validates + sanitizes a draft body (same sanitizer as the Zadex editor, so the preview shows exactly what
     * apply will store) and saves it. Keeps an `applied` state (the page stays Zadex-rendered until re-applied).
     *
     * @return array|WP_Error the stored draft
     */
    public static function save_draft(int $post_id, $body)
    {
        if (!is_array($body) || !isset($body['data']) || !is_array($body['data']) || !isset($body['data']['elements']) || !is_array($body['data']['elements'])) {
            return new WP_Error('zxm_bad_request', __('Missing document data.', 'zadex-migrator'), ['status' => 400]);
        }
        // Elementor templates go to a Zadex template / library post: validate where before storing anything.
        $target = null;
        if (Targets::is_template($post_id)) {
            $target = Targets::sanitize_target($post_id, $body['target'] ?? null);
            if (is_wp_error($target)) {
                return $target;
            }
        }
        $sanitizer = self::sanitizer();
        $page = null;
        if (isset($body['pageSettings']) && is_array($body['pageSettings'])) {
            $page = [
                'settings' => isset($body['pageSettings']['settings']) && is_array($body['pageSettings']['settings']) ? $body['pageSettings']['settings'] : [],
                'css'      => isset($body['pageSettings']['css']) && is_string($body['pageSettings']['css']) ? $body['pageSettings']['css'] : '',
            ];
            $page = $sanitizer->sanitize_settings_generic($page);
        }
        $summary = self::sanitize_summary($body['summary'] ?? []);
        $draft = [
            'data'         => $sanitizer->sanitize_document($body['data']),
            'css'          => Document::sanitize_css(isset($body['css']) && is_string($body['css']) ? $body['css'] : ''),
            'pageSettings' => $page,
            'template'     => Templates::sanitize($body['template'] ?? ''),
            'report'       => self::sanitize_report($body['report'] ?? []),
            'summary'      => $summary,
            'createdAt'    => gmdate('c'),
        ];
        if ($target !== null) {
            $draft['template'] = '';
            $draft['target'] = $target;
        }
        self::put_json($post_id, self::META_DRAFT, $draft);
        $state = self::state($post_id);
        if (($state['state'] ?? '') !== self::STATE_APPLIED) {
            self::put_json($post_id, self::META_STATE, ['state' => self::STATE_DRAFT, 'score' => $summary['score'], 'at' => gmdate('c')]);
        }
        if ($target !== null) {
            // The draft goes into the target post while it is unpublished; a published (applied) target only changes
            // on the next apply, like an applied page.
            $draft['targetUpdated'] = false;
            if (Targets::target_status($post_id) !== 'publish') {
                $written = Targets::write($post_id, $draft);
                if (is_wp_error($written)) {
                    return $written;
                }
                $draft['targetUpdated'] = true;
            }
        }
        return $draft;
    }

    public static function draft(int $post_id): ?array
    {
        $draft = self::get_json($post_id, self::META_DRAFT);
        return is_array($draft) && isset($draft['data']) && is_array($draft['data']) ? $draft : null;
    }

    /** @return array{state?:string, score?:int|float, at?:string, appliedAt?:string} */
    public static function state(int $post_id): array
    {
        $state = self::get_json($post_id, self::META_STATE);
        return is_array($state) ? $state : [];
    }

    public static function backup(int $post_id): ?array
    {
        $backup = self::get_json($post_id, self::META_BACKUP);
        return is_array($backup) && isset($backup['metas']) && is_array($backup['metas']) ? $backup : null;
    }

    /** 'none' | 'draft' | 'applied' */
    public static function state_name(int $post_id): string
    {
        $state = (string) (self::state($post_id)['state'] ?? '');
        return in_array($state, [self::STATE_DRAFT, self::STATE_APPLIED], true) ? $state : 'none';
    }

    // ---------------------------------------------------------------- apply / rollback

    /**
     * Applies the stored draft: backup (first apply only), Zadex save (sanitizer, revisions, hooks), Zadex template,
     * Elementor stops rendering (`_elementor_edit_mode` = ''), state = applied.
     *
     * @return true|WP_Error
     */
    public static function apply(int $post_id)
    {
        if (!get_post($post_id)) {
            return new WP_Error('zxm_not_found', __('Post not found.', 'zadex-migrator'), ['status' => 404]);
        }
        $unsupported = Targets::is_template($post_id) ? Targets::unsupported($post_id) : null;
        if ($unsupported !== null) {
            return $unsupported;
        }
        $draft = self::draft($post_id);
        if ($draft === null) {
            return new WP_Error('zxm_no_draft', __('Convert the page before applying it.', 'zadex-migrator'), ['status' => 400]);
        }
        if (Targets::is_template($post_id)) {
            return self::apply_template($post_id, $draft);
        }
        $created_backup = false;
        if (self::backup($post_id) === null) {
            self::put_json($post_id, self::META_BACKUP, ['metas' => self::snapshot($post_id), 'at' => gmdate('c')]);
            $created_backup = true;
        }
        $result = Document::save(
            $post_id,
            $draft['data'],
            isset($draft['css']) && is_string($draft['css']) ? $draft['css'] : '',
            isset($draft['pageSettings']) && is_array($draft['pageSettings']) ? $draft['pageSettings'] : null
        );
        if (is_wp_error($result)) {
            if ($created_backup) {
                self::restore_backup($post_id);
            }
            return $result;
        }
        $current = (string) get_post_meta($post_id, Templates::META, true);
        $template = self::target_template($current, (string) ($draft['template'] ?? ''));
        if ($template === null) {
            delete_post_meta($post_id, Templates::META);
        } elseif ($template !== $current) {
            Templates::save($post_id, $template);
        }
        update_post_meta($post_id, Elementor::META_MODE, '');
        $summary = isset($draft['summary']) && is_array($draft['summary']) ? $draft['summary'] : [];
        self::put_json($post_id, self::META_STATE, [
            'state'     => self::STATE_APPLIED,
            'score'     => $summary['score'] ?? 0,
            'at'        => gmdate('c'),
            'appliedAt' => gmdate('c'),
        ]);
        do_action('zadex_migrator/applied', $post_id);
        return true;
    }

    /**
     * Restores every backed-up meta (metas that did not exist are deleted), drops the backup and moves the state
     * back to draft (the draft is kept so it can be applied again).
     *
     * @return true|WP_Error
     */
    public static function rollback(int $post_id)
    {
        if (!get_post($post_id)) {
            return new WP_Error('zxm_not_found', __('Post not found.', 'zadex-migrator'), ['status' => 404]);
        }
        $backup = self::backup($post_id);
        if ($backup === null) {
            return new WP_Error('zxm_no_backup', __('This page has not been applied, there is nothing to roll back.', 'zadex-migrator'), ['status' => 400]);
        }
        if (array_key_exists('status', $backup)) {
            return self::rollback_template($post_id, $backup);
        }
        self::restore_backup($post_id);
        $state = self::state($post_id);
        if (self::draft($post_id) !== null) {
            self::put_json($post_id, self::META_STATE, ['state' => self::STATE_DRAFT, 'score' => $state['score'] ?? 0, 'at' => gmdate('c')]);
        } else {
            delete_post_meta($post_id, self::META_STATE);
        }
        do_action('zadex_migrator/rolled_back', $post_id);
        return true;
    }

    /**
     * Applies an Elementor template's draft: the target is written and published (conditions / settings included),
     * the Elementor post status is backed up (first apply only) and, for theme parts shown through display
     * conditions, set to draft so Elementor Pro stops using it. Elementor metas are not touched.
     *
     * Backup shape for templates: {metas: {}, status: <Elementor post status>, target: <id>, at}.
     *
     * @return true|WP_Error
     */
    private static function apply_template(int $post_id, array $draft)
    {
        $unsupported = Targets::unsupported($post_id);
        if ($unsupported !== null) {
            return $unsupported;
        }
        $backup = self::backup($post_id);
        if ($backup !== null && !array_key_exists('status', $backup)) {
            return new WP_Error('zxm_bad_request', __('This template was applied as a page by an earlier version: roll it back first.', 'zadex-migrator'), ['status' => 400]);
        }
        $target = isset($draft['target']) && is_array($draft['target']) ? $draft['target'] : null;
        if ($target === null) {
            return new WP_Error('zxm_no_draft', __('Convert the template again before applying it.', 'zadex-migrator'), ['status' => 400]);
        }
        $target_id = Targets::write($post_id, $draft, 'publish');
        if (is_wp_error($target_id)) {
            return $target_id;
        }
        $post = get_post($post_id);
        if ($backup === null) {
            self::put_json($post_id, self::META_BACKUP, [
                'metas'  => (object) [],
                'status' => $post ? (string) $post->post_status : 'publish',
                'target' => $target_id,
                'at'     => gmdate('c'),
            ]);
        }
        if (Targets::hides_elementor($target)) {
            Targets::set_status($post_id, 'draft');
        }
        Targets::flush();
        $summary = isset($draft['summary']) && is_array($draft['summary']) ? $draft['summary'] : [];
        self::put_json($post_id, self::META_STATE, [
            'state'     => self::STATE_APPLIED,
            'score'     => $summary['score'] ?? 0,
            'at'        => gmdate('c'),
            'appliedAt' => gmdate('c'),
        ]);
        do_action('zadex_migrator/applied', $post_id);
        return true;
    }

    /**
     * Template rollback: the target goes back to draft (kept, with its document, for history and a later apply),
     * the Elementor post gets its backed-up status back.
     *
     * @return true
     */
    private static function rollback_template(int $post_id, array $backup)
    {
        $target_id = Targets::target_id($post_id);
        if ($target_id > 0) {
            Targets::set_status($target_id, 'draft');
        }
        $status = is_string($backup['status'] ?? null) ? sanitize_key($backup['status']) : '';
        if (in_array($status, ['publish', 'draft', 'pending', 'private', 'future'], true)) {
            Targets::set_status($post_id, $status);
        }
        delete_post_meta($post_id, self::META_BACKUP);
        Targets::flush();
        $state = self::state($post_id);
        if (self::draft($post_id) !== null) {
            self::put_json($post_id, self::META_STATE, ['state' => self::STATE_DRAFT, 'score' => $state['score'] ?? 0, 'at' => gmdate('c')]);
        } else {
            delete_post_meta($post_id, self::META_STATE);
        }
        do_action('zadex_migrator/rolled_back', $post_id);
        return true;
    }

    /**
     * Template stored on apply. A Zadex template from the draft wins; with the theme default (''), Elementor's own
     * templates (elementor_canvas, elementor_header_footer, elementor_theme) are removed (null = delete the meta)
     * and any other theme template is kept.
     */
    public static function target_template(string $current, string $draft): ?string
    {
        $draft = Templates::sanitize($draft);
        if ($draft !== '') {
            return $draft;
        }
        if ($current !== '' && (str_starts_with($current, 'elementor_') || Templates::sanitize($current) !== '')) {
            return null;
        }
        return $current;
    }

    /** @return array<string, mixed> meta key => current value (null when the meta does not exist) */
    private static function snapshot(int $post_id): array
    {
        $out = [];
        foreach (self::BACKED_UP as $key) {
            $out[$key] = metadata_exists('post', $post_id, $key) ? get_post_meta($post_id, $key, true) : null;
        }
        return $out;
    }

    private static function restore_backup(int $post_id): void
    {
        $backup = self::backup($post_id);
        if ($backup === null) {
            return;
        }
        foreach (self::BACKED_UP as $key) {
            $value = array_key_exists($key, $backup['metas']) ? $backup['metas'][$key] : null;
            if ($value === null) {
                delete_post_meta($post_id, $key);
            } else {
                update_post_meta($post_id, $key, wp_slash($value));
            }
        }
        delete_post_meta($post_id, self::META_BACKUP);
    }

    // ---------------------------------------------------------------- globals

    /**
     * Copies the Zadex globals (option zadex_global + zadex_global_css + breakpoints in zadex_settings) before a kit
     * import. An existing backup is kept (it holds the state before the first import) unless $force.
     *
     * @return bool whether a new backup was written
     */
    public static function backup_global(bool $force = false): bool
    {
        if (!$force && is_array(get_option(self::OPTION_GLOBAL_BACKUP, null))) {
            return false;
        }
        $settings = get_option('zadex_settings', null);
        update_option(self::OPTION_GLOBAL_BACKUP, [
            'global'      => get_option('zadex_global', null),
            'globalCss'   => get_option('zadex_global_css', null),
            'breakpoints' => is_array($settings) && array_key_exists('breakpoints', $settings) ? $settings['breakpoints'] : null,
            'at'          => gmdate('c'),
        ], false);
        return true;
    }

    public static function global_backup(): ?array
    {
        $backup = get_option(self::OPTION_GLOBAL_BACKUP, null);
        return is_array($backup) ? $backup : null;
    }

    /** @return true|WP_Error */
    public static function restore_global()
    {
        $backup = self::global_backup();
        if ($backup === null) {
            return new WP_Error('zxm_no_backup', __('There is no backup of the global settings.', 'zadex-migrator'), ['status' => 404]);
        }
        foreach (['global' => 'zadex_global', 'globalCss' => 'zadex_global_css'] as $field => $option) {
            if (!array_key_exists($field, $backup) || $backup[$field] === null) {
                delete_option($option);
            } else {
                update_option($option, $backup[$field]);
            }
        }
        $settings = get_option('zadex_settings', null);
        if (is_array($settings) || ($backup['breakpoints'] ?? null) !== null) {
            $settings = is_array($settings) ? $settings : [];
            if (($backup['breakpoints'] ?? null) === null) {
                unset($settings['breakpoints']);
            } else {
                $settings['breakpoints'] = $backup['breakpoints'];
            }
            update_option('zadex_settings', $settings);
        }
        delete_option(self::OPTION_GLOBAL_BACKUP);
        return true;
    }

    // ---------------------------------------------------------------- helpers

    private static function sanitizer(): Sanitizer
    {
        return new Sanitizer(\Zadex\Plugin::instance()->widgets);
    }

    /** @return array{elements:int, converted:int, partial:int, fallback:int, skipped:int, score:float} */
    public static function sanitize_summary($summary): array
    {
        $summary = is_array($summary) ? $summary : [];
        $out = [];
        foreach (['elements', 'converted', 'partial', 'fallback', 'skipped'] as $key) {
            $out[$key] = isset($summary[$key]) && is_numeric($summary[$key]) ? max(0, (int) $summary[$key]) : 0;
        }
        $score = isset($summary['score']) && is_numeric($summary['score']) ? (float) $summary['score'] : 0.0;
        $out['score'] = round(max(0.0, min(100.0, $score)), 2);
        return $out;
    }

    /** Report: plain data only (strings sanitized as text, numbers / booleans kept, depth limited). */
    public static function sanitize_report($report, int $depth = 0)
    {
        if ($depth > 6) {
            return null;
        }
        if (is_array($report)) {
            $out = [];
            foreach ($report as $key => $value) {
                $out[is_int($key) ? $key : sanitize_text_field((string) $key)] = self::sanitize_report($value, $depth + 1);
            }
            return $out;
        }
        if (is_string($report)) {
            return sanitize_text_field($report);
        }
        if (is_int($report) || is_float($report) || is_bool($report)) {
            return $report;
        }
        return null;
    }

    private static function put_json(int $post_id, string $key, array $value): void
    {
        update_post_meta($post_id, $key, wp_slash((string) wp_json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)));
    }

    /** @return mixed decoded JSON or null */
    private static function get_json(int $post_id, string $key)
    {
        $raw = get_post_meta($post_id, $key, true);
        return is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
    }
}
