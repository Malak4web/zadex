<?php
namespace ZadexMigrator\Migration;

defined('ABSPATH') || exit;

use Zadex\Documents\Document;

/**
 * Lists the Elementor documents that can be migrated: posts of any public post type (`kind=pages`, default) or
 * Elementor templates (`kind=templates`: `elementor_library`, kits excluded; popups included) that are built with Elementor
 * (`_elementor_edit_mode` = builder) or were migrated already (they keep a migration state after apply, when
 * Elementor no longer claims them).
 */
final class Documents
{
    public const STATUSES = ['publish', 'draft', 'pending', 'private', 'future'];
    public const MAX_PER_PAGE = 100;

    /** `kind` filter: pages = every post type except Elementor templates; templates = Elementor templates. */
    public const KINDS = ['pages', 'templates'];

    /** Elementor template types never listed (kits: global settings step). */
    public const HIDDEN_TEMPLATE_TYPES = ['kit'];

    /**
     * Post types searched (public types + Elementor templates, never attachments). $kind narrows the list: 'pages'
     * without `elementor_library`, 'templates' only `elementor_library`.
     */
    public static function post_types(string $kind = ''): array
    {
        if ($kind === 'templates') {
            return [Elementor::LIBRARY_TYPE];
        }
        $types = array_values(array_diff(array_map('strval', array_keys((array) get_post_types(['public' => true]))), ['attachment']));
        if ($kind === 'pages') {
            return array_values(array_diff($types, [Elementor::LIBRARY_TYPE]));
        }
        if (!in_array(Elementor::LIBRARY_TYPE, $types, true)) {
            $types[] = Elementor::LIBRARY_TYPE;
        }
        return $types;
    }

    /**
     * Normalized list parameters.
     *
     * @return array{kind:string, template_type:string, state:string, type:string, search:string, page:int, per_page:int}
     */
    public static function params(array $input): array
    {
        $kind = isset($input['kind']) && is_string($input['kind']) ? sanitize_key($input['kind']) : '';
        $kind = in_array($kind, self::KINDS, true) ? $kind : 'pages';
        $state = isset($input['state']) && is_string($input['state']) ? sanitize_key($input['state']) : '';
        $type = isset($input['type']) && is_string($input['type']) ? sanitize_key($input['type']) : '';
        $template_type = isset($input['template_type']) && is_string($input['template_type']) ? sanitize_key($input['template_type']) : '';
        return [
            'kind'     => $kind,
            // Elementor `_elementor_template_type` filter (templates only); hidden types (kit) are never listed.
            'template_type' => $kind === 'templates' && !in_array($template_type, self::HIDDEN_TEMPLATE_TYPES, true) ? $template_type : '',
            'state'    => in_array($state, ['none', Store::STATE_DRAFT, Store::STATE_APPLIED], true) ? $state : '',
            'type'     => in_array($type, self::post_types($kind), true) ? $type : '',
            'search'   => isset($input['search']) && is_scalar($input['search']) ? sanitize_text_field((string) $input['search']) : '',
            'page'     => isset($input['page']) ? max(1, (int) $input['page']) : 1,
            'per_page' => isset($input['per_page']) ? max(1, min(self::MAX_PER_PAGE, (int) $input['per_page'])) : 20,
        ];
    }

    /** WP_Query arguments for the normalized parameters. */
    public static function query_args(array $params): array
    {
        $params = array_merge(['kind' => 'pages', 'state' => '', 'type' => '', 'search' => '', 'page' => 1, 'per_page' => 20], $params);
        $templates = $params['kind'] === 'templates';
        $meta = [
            'relation' => 'AND',
            [
                'relation' => 'OR',
                ['key' => Elementor::META_MODE, 'value' => 'builder'],
                ['key' => Store::META_STATE, 'compare' => 'EXISTS'],
            ],
            $templates
                ? ['key' => Elementor::META_TEMPLATE_TYPE, 'value' => self::HIDDEN_TEMPLATE_TYPES, 'compare' => 'NOT IN']
                : [
                    'relation' => 'OR',
                    ['key' => Elementor::META_TEMPLATE_TYPE, 'compare' => 'NOT EXISTS'],
                    ['key' => Elementor::META_TEMPLATE_TYPE, 'value' => 'kit', 'compare' => '!='],
                ],
        ];
        $template_type = $templates ? (string) ($params['template_type'] ?? '') : '';
        if ($template_type !== '') {
            // "single" also covers Elementor's single-post / single-page variants.
            $meta[] = $template_type === 'single'
                ? ['key' => Elementor::META_TEMPLATE_TYPE, 'value' => ['single', 'single-post', 'single-page'], 'compare' => 'IN']
                : ['key' => Elementor::META_TEMPLATE_TYPE, 'value' => $template_type];
        }
        if ($params['state'] === 'none') {
            $meta[] = ['key' => Store::META_STATE, 'compare' => 'NOT EXISTS'];
        } elseif ($params['state'] !== '') {
            $meta[] = ['key' => Store::META_STATE, 'value' => '"state":"' . $params['state'] . '"', 'compare' => 'LIKE'];
        }
        $args = [
            'post_type'           => $params['type'] !== '' ? $params['type'] : self::post_types($templates ? 'templates' : 'pages'),
            'post_status'         => self::STATUSES,
            'meta_query'          => $meta, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- admin-only list, paginated.
            'posts_per_page'      => (int) $params['per_page'],
            'paged'               => (int) $params['page'],
            'orderby'             => 'modified',
            'order'               => 'DESC',
            'ignore_sticky_posts' => true,
            'suppress_filters'    => false,
        ];
        if ($params['search'] !== '') {
            $args['s'] = $params['search'];
        }
        // Users who cannot edit other people's content only see their own documents.
        if (!current_user_can('edit_others_posts')) {
            $args['author'] = get_current_user_id();
        }
        return $args;
    }

    /**
     * @return array{items: array<int, array>, total: int, pages: int}
     */
    public static function query(array $input): array
    {
        $query = new \WP_Query(self::query_args(self::params($input)));
        $items = [];
        foreach ((array) $query->posts as $post) {
            if (is_object($post) && current_user_can('edit_post', (int) $post->ID)) {
                $items[] = self::item($post);
            }
        }
        return ['items' => $items, 'total' => (int) $query->found_posts, 'pages' => (int) $query->max_num_pages];
    }

    /** Number of documents for a state filter ('' = all) and kind (pages | templates). */
    public static function count(string $state = '', string $kind = 'pages'): int
    {
        $args = self::query_args(['kind' => $kind, 'state' => $state, 'per_page' => 1, 'page' => 1]);
        $args['fields'] = 'ids';
        $query = new \WP_Query($args);
        return (int) $query->found_posts;
    }

    /** One list row. */
    public static function item(object $post): array
    {
        $id = (int) $post->ID;
        $state = Store::state($id);
        $name = Store::state_name($id);
        $data = get_post_meta($id, Document::META_DATA, true);
        $item = [
            'id'        => $id,
            'title'     => html_entity_decode((string) get_the_title($id), ENT_QUOTES, 'UTF-8'),
            'type'      => (string) $post->post_type,
            'status'    => (string) $post->post_status,
            'modified'  => (string) ($post->post_modified_gmt ?? ''),
            'viewUrl'   => (string) get_permalink($id),
            'editUrl'   => (string) get_edit_post_link($id, 'raw'),
            'migration' => [
                'state'        => $name,
                'score'        => $name === 'none' ? null : (isset($state['score']) && is_numeric($state['score']) ? $state['score'] + 0 : null),
                'appliedAt'    => $name === Store::STATE_APPLIED ? (string) ($state['appliedAt'] ?? $state['at'] ?? '') : null,
                'hasZadexData' => is_string($data) && $data !== '',
            ],
        ];
        if ((string) $post->post_type === Elementor::LIBRARY_TYPE) {
            // Template rows: Elementor type, its display conditions in words, the Zadex target.
            $type = Elementor::template_type($id);
            $target = Targets::target_info($id);
            $item['templateType'] = $type;
            $item['conditionsSummary'] = Targets::is_library_type($type) ? '' : Targets::conditions_summary(Elementor::conditions($id));
            $item['target'] = $target;
            $item['migration']['hasZadexData'] = $target !== null;
            if (Store::draft($id) !== null) {
                $item['previewUrls'] = Targets::preview_urls($id);
            }
            return $item;
        }
        if (Store::draft($id) !== null) {
            $item['previewUrls'] = ['elementor' => Preview::url($id, 'elementor'), 'zadex' => Preview::url($id, 'zadex')];
        }
        return $item;
    }
}
