<?php
namespace ZadexMigrator\Migration;

defined('ABSPATH') || exit;

/**
 * Read-only access to Elementor: meta keys, the active kit, and (only when Elementor is active) server-side
 * rendering of single elements for the converter's HTML fallback. Elementor data is never modified here.
 */
final class Elementor
{
    public const META_DATA = '_elementor_data';
    public const META_MODE = '_elementor_edit_mode';
    public const META_PAGE = '_elementor_page_settings';
    public const META_VERSION = '_elementor_version';
    public const META_TEMPLATE_TYPE = '_elementor_template_type';
    public const META_CONDITIONS = '_elementor_conditions';
    public const META_POPUP_DISPLAY = '_elementor_popup_display_settings';
    public const OPTION_KIT = 'elementor_active_kit';
    public const LIBRARY_TYPE = 'elementor_library';

    public static function is_active(): bool
    {
        return defined('ELEMENTOR_VERSION') && class_exists('\\Elementor\\Plugin');
    }

    public static function version(): string
    {
        if (defined('ELEMENTOR_VERSION')) {
            return (string) constant('ELEMENTOR_VERSION');
        }
        return (string) get_option('elementor_version', '');
    }

    /** Active kit post id (0 when none). */
    public static function kit_id(): int
    {
        return absint(get_option(self::OPTION_KIT, 0));
    }

    /** Whether a post is an Elementor kit (site settings document: elementor_library with template type `kit`). */
    public static function is_kit(int $post_id): bool
    {
        return $post_id > 0
            && get_post_type($post_id) === self::LIBRARY_TYPE
            && get_post_meta($post_id, self::META_TEMPLATE_TYPE, true) === 'kit';
    }

    /** Whether a post is an Elementor template (any `elementor_library` post, kits included). */
    public static function is_library(int $post_id): bool
    {
        return $post_id > 0 && get_post_type($post_id) === self::LIBRARY_TYPE;
    }

    /** `_elementor_template_type` of a post ('' when missing). */
    public static function template_type(int $post_id): string
    {
        $type = get_post_meta($post_id, self::META_TEMPLATE_TYPE, true);
        return is_string($type) ? sanitize_key($type) : '';
    }

    /**
     * Display conditions of an Elementor Pro theme template (`_elementor_conditions`: an array meta of strings such as
     * `include/general`, `exclude/singular/page/123`; JSON or a single string tolerated).
     *
     * @return string[]
     */
    public static function conditions(int $post_id): array
    {
        $raw = get_post_meta($post_id, self::META_CONDITIONS, true);
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) {
                $decoded = maybe_unserialize($raw);
            }
            $raw = is_array($decoded) ? $decoded : [$raw];
        }
        if (!is_array($raw)) {
            return [];
        }
        $out = [];
        foreach ($raw as $condition) {
            if (!is_string($condition)) {
                continue;
            }
            $clean = trim(preg_replace('/[^A-Za-z0-9_\-\/]/', '', $condition) ?? '', '/');
            if ($clean !== '' && !in_array($clean, $out, true)) {
                $out[] = $clean;
            }
        }
        return array_slice($out, 0, 100);
    }

    /**
     * Popup triggers and advanced rules (`_elementor_popup_display_settings` = {triggers: {...}, timing: {...}}):
     * array meta, JSON or serialized string; [] when absent or unreadable.
     */
    public static function popup_display_settings(int $post_id): array
    {
        return self::decode_settings(get_post_meta($post_id, self::META_POPUP_DISPLAY, true));
    }

    /** Settings of the active kit (global colors, typography, layout, breakpoints), [] when there is none. */
    public static function kit_settings(): array
    {
        $id = self::kit_id();
        return $id > 0 ? self::decode_settings(get_post_meta($id, self::META_PAGE, true)) : [];
    }

    /**
     * Global class ids (v4 atomic elements) referenced by `settings.classes.value` anywhere in the tree. Local style
     * ids (`e-<element id>-…`) are left out: their definitions travel with the element (`styles`).
     *
     * @return string[]
     */
    public static function global_class_ids(array $elements): array
    {
        $ids = [];
        $walk = static function (array $list, int $depth) use (&$walk, &$ids): void {
            if ($depth > 64) {
                return;
            }
            foreach ($list as $el) {
                if (!is_array($el)) {
                    continue;
                }
                $classes = $el['settings']['classes']['value'] ?? null;
                if (is_array($classes)) {
                    foreach ($classes as $id) {
                        if (is_string($id) && $id !== '' && strncmp($id, 'e-', 2) !== 0 && preg_match('/^[A-Za-z0-9_-]{1,64}$/', $id)) {
                            $ids[$id] = true;
                        }
                    }
                }
                if (isset($el['elements']) && is_array($el['elements'])) {
                    $walk($el['elements'], $depth + 1);
                }
            }
        };
        $walk($elements, 0);
        return array_slice(array_keys($ids), 0, 500);
    }

    /**
     * Definitions of the given global classes (`{id, label, type, variants}` per id). Uses Elementor's repository
     * when Elementor is active, else reads the `e_global_class` posts directly so a deactivated Elementor still works.
     *
     * @param string[] $ids
     * @return array<string, array>
     */
    public static function global_classes(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        $repo = '\\Elementor\\Modules\\GlobalClasses\\Global_Classes_Repository';
        if (class_exists($repo)) {
            try {
                $items = $repo::make()->get_by_ids($ids);
                return is_array($items) ? $items : [];
            } catch (\Throwable $e) {
                // Fall through to the direct read.
            }
        }
        $posts = get_posts([
            'post_type'        => 'e_global_class',
            'post_status'      => 'any',
            'numberposts'      => 500,
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- bounded lookup by class id (500 max), admin-only REST route.
            'meta_query'       => [['key' => '_elementor_global_class_id', 'value' => $ids, 'compare' => 'IN']],
        ]);
        $out = [];
        foreach ($posts as $post) {
            $id = (string) get_post_meta($post->ID, '_elementor_global_class_id', true);
            $data = get_post_meta($post->ID, '_elementor_global_class_data', true);
            if (is_string($data)) {
                $data = json_decode($data, true);
            }
            if ($id !== '' && is_array($data)) {
                $out[$id] = array_merge($data, ['id' => $id, 'label' => $data['label'] ?? $post->post_title]);
            }
        }
        return $out;
    }

    /** Global variables of the active kit (v4 `_elementor_global_variables`), [] when there are none. */
    public static function global_variables(): array
    {
        $id = self::kit_id();
        if ($id <= 0) {
            return [];
        }
        $raw = get_post_meta($id, '_elementor_global_variables', true);
        if (is_string($raw)) {
            $raw = json_decode($raw, true);
        }
        return is_array($raw) ? $raw : [];
    }

    /**
     * Decodes `_elementor_data`. Elementor stores it as a slashed JSON string (wp_slash(wp_json_encode(...))),
     * WordPress unslashes on save, so the meta is normally plain JSON; data written by importers / older versions
     * can still carry the slashes, and some tools store the decoded array directly.
     */
    public static function decode_data($raw): array
    {
        if (is_array($raw)) {
            return array_values(array_filter($raw, 'is_array'));
        }
        if (!is_string($raw) || $raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        // Double-encoded JSON (a JSON string holding JSON).
        if (is_string($decoded)) {
            $decoded = json_decode($decoded, true);
        }
        if (!is_array($decoded)) {
            $decoded = json_decode(stripslashes($raw), true);
        }
        return is_array($decoded) ? array_values(array_filter($decoded, 'is_array')) : [];
    }

    /** `_elementor_page_settings` / kit settings: an array meta, tolerating JSON or serialized strings. */
    public static function decode_settings($raw): array
    {
        if (is_array($raw)) {
            return $raw;
        }
        if (!is_string($raw) || $raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }
        $value = maybe_unserialize($raw);
        return is_array($value) ? $value : [];
    }

    /**
     * Elementor-rendered HTML of the widgets whose type is listed, keyed by element id. Empty unless Elementor is
     * active. Rendering happens inside the post's document context, with output buffering, one element at a time.
     *
     * @param array<int, array> $elements
     * @param string[]          $types
     * @return array<string, string>
     */
    public static function render_widgets(int $post_id, array $elements, array $types, int $limit = 200): array
    {
        if (!self::is_active() || $types === [] || $elements === []) {
            return [];
        }
        $targets = [];
        self::collect_widgets($elements, $types, $targets, $limit);
        if ($targets === []) {
            return [];
        }
        $plugin = \Elementor\Plugin::$instance;
        $document = null;
        $switched = false;
        try {
            $document = $plugin->documents->get_doc_for_frontend($post_id);
            if ($document) {
                $plugin->documents->switch_to_document($document);
                $switched = true;
            }
        } catch (\Throwable $e) {
            $document = null;
        }
        $out = [];
        foreach ($targets as $data) {
            $html = self::render_element($data);
            if ($html !== '') {
                $out[(string) $data['id']] = $html;
            }
        }
        if ($switched) {
            $plugin->documents->restore_document();
        }
        return $out;
    }

    /** One element's HTML through Elementor's own element classes ('' on failure). */
    public static function render_element(array $data): string
    {
        if (!self::is_active()) {
            return '';
        }
        $level = ob_get_level();
        ob_start();
        try {
            $instance = \Elementor\Plugin::$instance->elements_manager->create_element_instance($data);
            if ($instance) {
                $instance->print_element();
            }
        } catch (\Throwable $e) {
            // An element that fails to render simply gets no fallback HTML.
            unset($e);
        }
        $html = '';
        while (ob_get_level() > $level) {
            $html = (string) ob_get_clean() . $html;
        }
        return trim($html);
    }

    /**
     * @param array<int, mixed> $elements
     * @param string[]          $types
     * @param array<int, array> $out
     */
    private static function collect_widgets(array $elements, array $types, array &$out, int $limit): void
    {
        foreach ($elements as $el) {
            if (count($out) >= $limit) {
                return;
            }
            if (!is_array($el)) {
                continue;
            }
            $type = isset($el['widgetType']) && is_string($el['widgetType']) ? $el['widgetType'] : '';
            if (($el['elType'] ?? '') === 'widget' && $type !== '' && in_array($type, $types, true) && isset($el['id'])) {
                $out[] = $el;
                continue;
            }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                self::collect_widgets($el['elements'], $types, $out, $limit);
            }
        }
    }
}
