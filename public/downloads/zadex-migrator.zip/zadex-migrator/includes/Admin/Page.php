<?php
namespace ZadexMigrator\Admin;

defined('ABSPATH') || exit;

use ZadexMigrator\Assets;
use ZadexMigrator\Migration\Elementor;
use ZadexMigrator\Rest\Controller;

/**
 * "Zadex → Import from Elementor": the page is only the mount point of the Vue admin app (src/admin/main.ts).
 * Config for the app: `window.ZADEX_MIGRATOR` (inline script attached to the `zadex-migrator-config` handle).
 */
final class Page
{
    public const SLUG = 'zadex-migrator';
    public const PARENT = 'zadex';
    public const HANDLE = 'zadex-migrator-admin';
    public const CONFIG_HANDLE = 'zadex-migrator-config';
    public const MOUNT_ID = 'zadex-migrator-app';

    private Assets $assets;
    private string $hook = '';

    public function __construct(?Assets $assets = null)
    {
        $this->assets = $assets ?? new Assets();
    }

    public function register(): void
    {
        // After Zadex adds its top-level menu (admin_menu, priority 10).
        add_action('admin_menu', [$this, 'menu'], 20);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
    }

    public function menu(): void
    {
        $hook = add_submenu_page(
            self::PARENT,
            __('Import from Elementor', 'zadex-migrator'),
            __('Import from Elementor', 'zadex-migrator'),
            'edit_posts',
            self::SLUG,
            [$this, 'render']
        );
        $this->hook = is_string($hook) ? $hook : '';
    }

    public function hook(): string
    {
        return $this->hook;
    }

    public function render(): void
    {
        if (!current_user_can('edit_posts')) {
            return;
        }
        echo '<div class="wrap">';
        if (!$this->assets->has_build()) {
            echo '<div class="notice notice-error"><p>' . esc_html__('The Zadex Migrator app is missing (build/manifest.json). Reinstall the plugin.', 'zadex-migrator') . '</p></div>';
        }
        echo '<div id="' . esc_attr(self::MOUNT_ID) . '"></div></div>';
    }

    public function enqueue(string $hook): void
    {
        if ($this->hook === '' || $hook !== $this->hook || !current_user_can('edit_posts')) {
            return;
        }
        wp_register_script(self::CONFIG_HANDLE, false, [], ZADEX_MIGRATOR_VERSION, false);
        wp_add_inline_script(
            self::CONFIG_HANDLE,
            'window.ZADEX_MIGRATOR = ' . wp_json_encode($this->config(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES) . ';'
        );
        wp_enqueue_script(self::CONFIG_HANDLE);
        $this->assets->enqueue_entry(Assets::ENTRY_ADMIN, self::HANDLE);
    }

    /** Data the admin app boots with. */
    public function config(): array
    {
        return [
            'version'      => ZADEX_MIGRATOR_VERSION,
            'restUrl'      => esc_url_raw(rest_url(Controller::NS . '/')),
            'zadexRestUrl' => esc_url_raw(rest_url('zadex/v1/')),
            'nonce'        => wp_create_nonce('wp_rest'),
            'adminUrl'     => esc_url_raw(admin_url()),
            'siteUrl'      => esc_url_raw(home_url('/')),
            'mountId'      => self::MOUNT_ID,
            'site'         => [
                'name'     => get_bloginfo('name'),
                'url'      => esc_url_raw(home_url('/')),
                'adminUrl' => esc_url_raw(admin_url()),
                'locale'   => function_exists('get_user_locale') ? get_user_locale() : get_locale(),
                'rtl'      => is_rtl(),
            ],
            'zadex'        => ['version' => defined('ZADEX_VERSION') ? (string) constant('ZADEX_VERSION') : ''],
            'elementor'    => ['active' => Elementor::is_active(), 'version' => Elementor::version()],
            'caps'         => ['editThemeOptions' => current_user_can('edit_theme_options')],
            // Translated UI strings (English source in the app's t()); filled when the plugin ships translations.
            'i18n'         => (object) apply_filters('zadex_migrator/admin/i18n', []),
        ];
    }
}
