<?php
namespace ZadexMigrator;

defined('ABSPATH') || exit;

/**
 * Minimal PSR-4 autoloader used when the plugin ships without Composer.
 */
final class Autoloader
{
    public static function register(): void
    {
        spl_autoload_register([self::class, 'load']);
    }

    public static function load(string $class): void
    {
        $prefix = 'ZadexMigrator\\';
        if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
            return;
        }
        $relative = substr($class, strlen($prefix));
        $file = ZADEX_MIGRATOR_PATH . 'includes/' . str_replace('\\', '/', $relative) . '.php';
        if (is_file($file)) {
            require_once $file;
        }
    }
}
