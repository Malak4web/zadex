<?php
namespace ZadexMigrator;

defined('ABSPATH') || exit;

/**
 * Boots the migrator. Each module registers its own hooks; add one line per module in boot().
 */
final class Plugin
{
    private static ?Plugin $instance = null;

    public static function instance(): Plugin
    {
        return self::$instance ??= new self();
    }

    public function boot(): void
    {
        // Zadex is a hard requirement ("Requires Plugins: zadex"); stay inert if it is missing anyway.
        if (!class_exists('Zadex\\Plugin')) {
            return;
        }
        (new Rest\Controller())->register();
        (new Migration\Preview())->register();
        (new Admin\Page())->register();
        do_action('zadex_migrator/loaded', $this);
    }
}
